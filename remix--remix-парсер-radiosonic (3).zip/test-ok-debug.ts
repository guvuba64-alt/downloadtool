import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp("Tones And I - Dance Monkey").then(x => console.dir(x, {depth: null})).catch(console.error);
