const axios = require('axios');
axios.get('https://api.deezer.com/search?q=test&limit=10')
  .then(r => console.log("OK", r.status))
  .catch(e => console.log("ERR", e.message, e.response?.status));
