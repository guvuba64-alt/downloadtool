import axios from 'axios';
axios.get('https://api.deezer.com/search?q=Joniveli%20Tee%20t%C3%A4st%C3%A4%20hitti').then(r => console.log(r.data.data[0])).catch(console.error);
