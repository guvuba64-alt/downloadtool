const fs = require('fs');

let report = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

report = report.replace(
  "updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error' } : l));",
  "updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error', errorMessage: errData?.description || 'Bad Request (400)' } : l));"
);

report = report.replace(
  "updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error' } : l));",
  "updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error', errorMessage: err?.message || 'Error' } : l));"
);

fs.writeFileSync('src/components/ReportTab.tsx', report);

let logs = fs.readFileSync('src/components/LogsTab.tsx', 'utf8');
logs = logs.replace(
  "logs: {chatId: string, label: string, status: 'queued'|'sent'|'error'}[]",
  "logs: {chatId: string, label: string, status: 'queued'|'sent'|'error', errorMessage?: string}[]"
);

logs = logs.replace(
  "{log.status === 'error' ? t(\"Error\", \"Ошибка\") :",
  "{log.status === 'error' ? (log.errorMessage ? `Ошибка: ${log.errorMessage}` : t(\"Error\", \"Ошибка\")) :"
);

fs.writeFileSync('src/components/LogsTab.tsx', logs);
console.log('Fixed');
