const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace('import { BotBuilderTab } from "./components/BotBuilderTab";\n', '');
content = content.replace('{ id: "bot-builder", label: t("Bot Builder", "Конструктор Бота") },', '');
content = content.replace('{activeAppTab === "bot-builder" && <TgAuthGuard t={t}><BotBuilderTab t={t} /></TgAuthGuard>}', '');

fs.writeFileSync('src/App.tsx', content);
console.log('Removed BotBuilderTab from App.tsx');
