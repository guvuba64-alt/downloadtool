import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp("Dance Monkey").then(r => console.dir(r, {depth:null}));
