const fs = require('fs');

const newHelp = `import React from 'react';
import { HelpCircle, FileText, Music, Send, Key, Shield, Layers, Code, Settings, Link2, Clock, PlayCircle, Database, Server, Smartphone, UserCheck, AlertTriangle } from 'lucide-react';

export const HelpModal = ({ onClose, t }: { onClose: () => void, t: any }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-6xl max-h-[95vh] bg-white dark:bg-[#121212] rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200 border border-zinc-200 dark:border-zinc-800">
        
        {/* Header */}
        <div className="p-6 md:p-8 border-b border-zinc-200 dark:border-white/10 shrink-0 flex items-start sm:items-center gap-4 bg-zinc-50 dark:bg-zinc-900/50">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shrink-0">
            <HelpCircle className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-zinc-900 dark:text-white tracking-tight leading-tight">{t("Detailed Guide & Knowledge Base", "Энциклопедия платформы")}</h2>
            <p className="text-sm sm:text-base text-zinc-500 dark:text-zinc-400 mt-1">{t("Complete documentation, deep dive into architecture, and step-by-step explanations.", "Максимально подробное объяснение каждого винтика: как это работает, зачем создано и какую бизнес-задачу решает.")}</p>
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 md:p-8 space-y-16 custom-scrollbar bg-white dark:bg-[#121212]">
          
          {/* 1. Архитектура */}
          <section>
            <div className="flex items-center gap-3 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div className="p-2 bg-indigo-100 dark:bg-indigo-500/20 rounded-lg text-indigo-600 dark:text-indigo-400"><Layers className="w-6 h-6" /></div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">1. Фундамент и Архитектура приложения</h3>
            </div>
            <div className="space-y-6 text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
              <p className="text-base">Наше приложение — это не просто плеер. Это мощная CRM-система и музыкальный комбайн для артистов, лейблов и менеджеров. Оно спроектировано как <strong>конвейер из трёх независимых блоков</strong>, которые передают данные друг другу.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                <div className="bg-zinc-50 dark:bg-zinc-800/50 p-6 rounded-2xl border border-zinc-200 dark:border-white/5 shadow-sm">
                  <Database className="w-8 h-8 text-indigo-500 mb-4" />
                  <h4 className="font-bold text-zinc-900 dark:text-white text-lg mb-2">Блок 1: Сбор данных (Data Mining)</h4>
                  <p className="opacity-90 mb-3"><strong>Зачем:</strong> Ни одна платформа не дает все данные сразу. Менеджерам приходится вручную заходить на Spotify, VK, Apple, чтобы собирать ссылки и проверять загрузку релизов.</p>
                  <p className="opacity-90"><strong>Как работает:</strong> Этот блок содержит алгоритмы-парсеры. Вы даете ему одну ссылку (например, Яндекс Музыку), а он скрытно отправляет запросы на другие сайты, находит совпадения по названию и авторам, и собирает всё в единую карточку релиза с ISRC кодами и ссылками.</p>
                </div>
                
                <div className="bg-zinc-50 dark:bg-zinc-800/50 p-6 rounded-2xl border border-zinc-200 dark:border-white/5 shadow-sm">
                  <Server className="w-8 h-8 text-emerald-500 mb-4" />
                  <h4 className="font-bold text-zinc-900 dark:text-white text-lg mb-2">Блок 2: Вычисления (Отчёты и Финансы)</h4>
                  <p className="opacity-90 mb-3"><strong>Зачем:</strong> Дистрибьютор присылает доходы в гигантской таблице Excel на 100 000 строк. Артист не сможет в ней разобраться.</p>
                  <p className="opacity-90"><strong>Как работает:</strong> Ядро парсит вашу таблицу. Оно суммирует все копейки со всех стримингов для каждого конкретного артиста. Затем оно применяет математику: вычитает процент лейбла (допустим, 30%), формирует красивый HTML-документ с логотипом, и с помощью библиотеки конвертирует его в настоящий PDF-акт выполненных работ.</p>
                </div>

                <div className="bg-zinc-50 dark:bg-zinc-800/50 p-6 rounded-2xl border border-zinc-200 dark:border-white/5 shadow-sm">
                  <Smartphone className="w-8 h-8 text-blue-500 mb-4" />
                  <h4 className="font-bold text-zinc-900 dark:text-white text-lg mb-2">Блок 3: Доставка (Рассылка в Telegram)</h4>
                  <p className="opacity-90 mb-3"><strong>Зачем:</strong> Когда у лейбла 50 артистов, отправлять каждому PDF вручную — это часы потраченного времени.</p>
                  <p className="opacity-90"><strong>Как работает:</strong> Модуль берет сгенерированные PDF-файлы из второго блока. Используя официальное API Telegram и ваш токен бота, он начинает рассылку: находит по Chat ID нужного артиста и отправляет ему сообщение с прикрепленным документом, отчитываясь вам о статусе отправки.</p>
                </div>
              </div>
            </div>
          </section>

          {/* 2. Подробно о вкладках */}
          <section>
            <div className="flex items-center gap-3 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div className="p-2 bg-emerald-100 dark:bg-emerald-500/20 rounded-lg text-emerald-600 dark:text-emerald-400"><Settings className="w-6 h-6" /></div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">2. Глубокий разбор каждой вкладки</h3>
            </div>
            
            <div className="space-y-6">
              
              <div className="bg-white dark:bg-zinc-900 p-6 sm:p-8 rounded-3xl border border-zinc-200 dark:border-white/10 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-white text-xl mb-4 flex items-center gap-3"><Music className="w-6 h-6 text-pink-500"/> Поиск и Моя Волна (Встроенный Плеер)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm text-zinc-600 dark:text-zinc-300">
                  <div>
                    <h5 className="font-bold text-zinc-800 dark:text-zinc-200 mb-2">Вкладка "Поиск"</h5>
                    <p className="mb-4">Это ваш шлюз в базу данных Яндекс Музыки. Введя имя артиста, приложение делает защищенный GET-запрос к API. Сервер возвращает JSON-объект со списком треков и альбомов. Мы берем из него ссылки на MP3-файлы и передаем в наш встроенный аудиоплеер (полоса воспроизведения внизу экрана), позволяя вам слушать музыку прямо во время работы с документами.</p>
                  </div>
                  <div>
                    <h5 className="font-bold text-zinc-800 dark:text-zinc-200 mb-2">Вкладка "Моя Волна" (Vibe)</h5>
                    <p className="mb-4">Это алгоритмическое радио. Оно берет ID трека, который играет сейчас, и отправляет его рекомендательной нейросети Яндекса. Нейросеть возвращает очередь из похожих по жанру, темпу и настроению треков. Идеально для поиска референсов (похожего звучания) для ваших собственных релизов.</p>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-zinc-900 p-6 sm:p-8 rounded-3xl border border-zinc-200 dark:border-white/10 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-white text-xl mb-4 flex items-center gap-3"><Link2 className="w-6 h-6 text-purple-500"/> Универсальный парсер (Агрегатор релизов)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-300 space-y-4">
                  <p><strong>Суть проблемы:</strong> У вас есть ссылка <code>music.yandex.ru/album/123</code>. Вам нужно сделать пост-релиз в соцсетях со ссылками на VK, Apple и Spotify. Искать везде вручную — долго. Плюс, вам нужно убедиться, что дистрибьютор не ошибся и присвоил трекам правильные ISRC коды на всех площадках.</p>
                  <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700">
                    <p className="font-bold mb-2">Пошаговый процесс под капотом:</p>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Вы вставляете ссылку. Парсер обращается к Яндексу и извлекает точные метаданные (название релиза: "Midnight", артист: "The Band", год: 2023).</li>
                      <li>Парсер берет это название и в фоновом режиме отправляет автоматизированные поисковые запросы (Search API) к Spotify, VK и Одноклассникам.</li>
                      <li>Он сравнивает результаты, находит 100% совпадения и формирует для вас "Смарт-ссылку" (SmartLink) — единый список всех площадок, где доступен релиз.</li>
                      <li>Параллельно он достает скрытые технические данные (ISRC и UPC), чтобы вы могли скопировать их в один клик.</li>
                    </ol>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-zinc-900 p-6 sm:p-8 rounded-3xl border border-zinc-200 dark:border-white/10 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-white text-xl mb-4 flex items-center gap-3"><FileText className="w-6 h-6 text-amber-500"/> Отчёты и PDF Генератор (Финансовое ядро)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-300 space-y-4">
                  <p>Это сердце приложения для лейблов. Дистрибьюторы (Believe, ONErpm, Zvonko) выдают отчеты в виде "сырых" данных. В этой вкладке происходит магия превращения сырых данных в деньги.</p>
                  <p><strong>Алгоритм работы:</strong></p>
                  <ul className="list-disc pl-5 space-y-2 mb-4">
                    <li><strong>Парсинг CSV:</strong> Приложение читает файл построчно, разбивая текст по запятым. Оно находит колонки "Артист", "Название", "Сумма" (Revenue).</li>
                    <li><strong>Агрегация:</strong> Допустим, трек слушали 1000 раз в VK и 500 в Spotify. Программа суммирует эти доходы в единую цифру для конкретного трека.</li>
                    <li><strong>Распределение:</strong> Программа применяет вашу ставку. Если трек заработал 10 000 рублей, а в настройках лейбла стоит 30%, артисту запишется к выплате 7 000 рублей.</li>
                    <li><strong>Рендеринг (HTML to Canvas):</strong> Программа рисует невидимую веб-страницу с таблицей, вашим логотипом и подписью. Затем делает "снимок" этой страницы (как скриншот) и конвертирует его в идеальный PDF документ А4 формата.</li>
                  </ul>
                  <div className="bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-200 dark:border-amber-800/50">
                    <p className="text-amber-900 dark:text-amber-300 font-medium text-xs">Все расчеты происходят локально прямо в процессоре вашего компьютера/смартфона. Ваши финансовые таблицы никуда не загружаются и остаются абсолютно конфиденциальными.</p>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-zinc-900 p-6 sm:p-8 rounded-3xl border border-zinc-200 dark:border-white/10 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-white text-xl mb-4 flex items-center gap-3"><Send className="w-6 h-6 text-blue-500"/> Журнал логов (Контроль Telegram рассылки)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-300 space-y-4">
                  <p>В этой вкладке вы контролируете процесс массовой отправки файлов артистам. Здесь выводятся статусы и ошибки сервера Telegram (API Responses).</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 bg-zinc-50 dark:bg-zinc-800/50 rounded-xl border border-zinc-200 dark:border-zinc-700">
                      <p className="font-bold text-red-500 mb-1">Ошибка 400 (Bad Request)</p>
                      <p className="text-xs">Означает, что запрос сформирован неверно. Чаще всего причина: "Chat not found" (пользователь с таким Chat ID не существует), либо "Bot was blocked by the user" (артист заблокировал бота, и бот больше не может писать ему первым). Приложение пропускает такого артиста и отправляет остальным.</p>
                    </div>
                    <div className="p-4 bg-zinc-50 dark:bg-zinc-800/50 rounded-xl border border-zinc-200 dark:border-zinc-700">
                      <p className="font-bold text-amber-500 mb-1">Ошибка 429 (Too Many Requests)</p>
                      <p className="text-xs">Защита Telegram от спама. Telegram разрешает отправлять примерно 30 сообщений в секунду. Если вы рассылаете отчеты слишком быстро, Telegram выдает 429 и просит подождать. Наше приложение автоматически "замораживается" на нужное время (retry_after) и затем возобновляет рассылку.</p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </section>

          {/* 3. Коды UPC и ISRC */}
          <section>
            <div className="flex items-center gap-3 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div className="p-2 bg-purple-100 dark:bg-purple-500/20 rounded-lg text-purple-600 dark:text-purple-400"><Code className="w-6 h-6" /></div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">3. База знаний: Коды UPC и ISRC</h3>
            </div>
            
            <div className="space-y-6 text-sm text-zinc-600 dark:text-zinc-300">
              <p className="text-base">Эти цифровые коды — это основа монетизации в музыкальной индустрии. Без них вы бы не смогли получать деньги со стримингов.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-purple-50 dark:bg-purple-900/10 p-6 rounded-3xl border border-purple-200 dark:border-purple-900/30">
                  <h4 className="font-bold text-purple-900 dark:text-purple-300 text-lg mb-3">UPC (Universal Product Code)</h4>
                  <p className="mb-4"><strong>Назначение:</strong> Штрих-код всего физического или цифрового товара (Альбома, EP или Сингла).</p>
                  <p className="mb-4"><strong>Пример:</strong> <code>3616851234567</code> (обычно 12 или 13 цифр).</p>
                  <p><strong>Зачем он нужен:</strong> Когда релиз доставляется на витрину Apple Music или Spotify, он регистрируется как единый товар под UPC. По этому коду формируются агрегированные отчеты о продажах всего альбома в целом.</p>
                </div>

                <div className="bg-pink-50 dark:bg-pink-900/10 p-6 rounded-3xl border border-pink-200 dark:border-pink-900/30">
                  <h4 className="font-bold text-pink-900 dark:text-pink-300 text-lg mb-3">ISRC (Int. Standard Recording Code)</h4>
                  <p className="mb-4"><strong>Назначение:</strong> Уникальный паспорт конкретной аудиодорожки (звукозаписи). Выдается навсегда.</p>
                  <p className="mb-4"><strong>Структура:</strong> <code>US-S1Z-23-00001</code> <br/>(Страна - Владелец - Год - Номер трека).</p>
                  <p><strong>Зачем он нужен (Критично!):</strong> Музыкальные сервисы платят роялти именно за прослушивания по ISRC! Если трек выйдет сегодня синглом, а завтра войдет в сборник лучших хитов — пока у них один ISRC, прослушивания будут складываться в общий кошелек.</p>
                </div>
              </div>
            </div>
          </section>

          {/* 4. API, Токены, Cookie */}
          <section>
            <div className="flex items-center gap-3 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div className="p-2 bg-amber-100 dark:bg-amber-500/20 rounded-lg text-amber-600 dark:text-amber-400"><Key className="w-6 h-6" /></div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">4. API, Токены, JSON и Cookies: Как программы общаются</h3>
            </div>
            
            <div className="space-y-6 text-sm text-zinc-600 dark:text-zinc-300">
              
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-6 rounded-2xl border border-zinc-200 dark:border-white/5">
                <h4 className="font-bold text-zinc-900 dark:text-white text-lg mb-3">Что такое API? (Аналогия с Рестораном)</h4>
                <p className="mb-3">Представьте, что вы (наше приложение) пришли в ресторан. База данных Spotify или Telegram — это закрытая кухня. Вы не можете просто зайти на кухню и взять данные сами.</p>
                <p><strong>API (Application Programming Interface)</strong> — это ваш Официант. Вы даете ему заказ (API Request): "Принеси информацию о треке". Официант идет на кухню, берет данные и возвращает вам блюдо в строго заданном формате (JSON ответ). Благодаря API программы могут обмениваться миллионами сообщений в секунду.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-2xl border border-blue-200 dark:border-blue-900/30">
                  <h4 className="font-bold text-blue-900 dark:text-blue-300 text-lg mb-2">Зачем нужен Token (API Key)?</h4>
                  <p className="mb-3">Это ваш VIP-пропуск в ресторане. Telegram не позволит первому встречному рассылать сообщения от чужого имени.</p>
                  <ul className="list-disc pl-5 space-y-2 opacity-90">
                    <li><strong>Telegram Bot Token:</strong> Строка вида <code>12345:ABCDef...</code>. Выдаётся главным ботом @BotFather. Этот токен доказывает серверам Telegram, что именно ВЫ владеете ботом.</li>
                    <li><strong>Spotify Client ID / Secret:</strong> Выдается в панели Spotify for Developers. Дает легальное разрешение приложению искать треки в базе.</li>
                  </ul>
                </div>

                <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-2xl border border-emerald-200 dark:border-emerald-900/30">
                  <h4 className="font-bold text-emerald-900 dark:text-emerald-300 text-lg mb-2">Секреты обхода блокировок: Cookie и JSON</h4>
                  <p className="mb-3">VK Музыка, Одноклассники и Звук — закрытые экосистемы. Они активно блокируют роботов и не дают открытого API "официанта", чтобы никто массово не скачивал музыку.</p>
                  <ul className="list-disc pl-5 space-y-2 opacity-90">
                    <li><strong>Session Cookie (Слепок браузера):</strong> Когда вы входите в свой аккаунт VK, сайт ставит на вас невидимую цифровую печать (Cookie). Вставляя этот Cookie в наше приложение, парсер "надевает маску" вашего браузера и легально собирает названия треков, обходя защиту от роботов.</li>
                    <li><strong>Ручной ввод JSON:</strong> Иногда серверы включают жесткую Капчу (проверку на человека). В таком случае приложение просит вас открыть панель разработчика (F12) и вручную скопировать код, который отдал сервер. Вы вставляете этот текст, а программа сама извлечет из него ISRC и UPC коды.</li>
                  </ul>
                </div>
              </div>

            </div>
          </section>

          {/* 5. Безопасность */}
          <section>
            <div className="flex items-center gap-3 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div className="p-2 bg-red-100 dark:bg-red-500/20 rounded-lg text-red-600 dark:text-red-400"><Shield className="w-6 h-6" /></div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">5. Безопасность и Приватность (Offline First)</h3>
            </div>
            
            <div className="bg-red-50 dark:bg-red-900/10 p-6 sm:p-8 rounded-3xl border border-red-200 dark:border-red-900/30">
              <div className="flex items-center gap-2 mb-4 text-red-800 dark:text-red-400">
                <AlertTriangle className="w-6 h-6" />
                <h4 className="font-bold text-xl uppercase tracking-wide">Критическое предупреждение</h4>
              </div>
              <p className="text-sm font-medium text-red-900 dark:text-red-300 mb-6">Никогда, ни при каких обстоятельствах, не передавайте посторонним лицам ваши токены Telegram, Client Secret от Spotify или Session Cookies! Получив их, злоумышленники смогут управлять вашими ботами или зайти в ваш аккаунт!</p>
              
              <div className="space-y-4 text-sm text-zinc-700 dark:text-zinc-300">
                <p className="font-bold text-zinc-900 dark:text-white text-base">Как мы защищаем ваши данные:</p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <UserCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Локальное хранилище (Local Storage):</strong> Все ваши токены, подписи директора и настройки лейбла сохраняются ИСКЛЮЧИТЕЛЬНО в памяти вашего текущего браузера на вашем устройстве.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <UserCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Отсутствие серверной базы данных:</strong> У нас (создателей этого приложения) нет серверов или баз данных, куда бы сливалась ваша информация. Мы физически не можем украсть ваши ключи или увидеть ваши финансовые отчеты. Приложение работает автономно (Offline First).</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <UserCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Прямое взаимодействие:</strong> Во время отправки рассылки в Telegram или парсинга Яндекс Музыки, ваш браузер напрямую, минуя нас, соединяется с серверами этих компаний.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <UserCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Автоматическое уничтожение:</strong> Если вы очистите историю и кэш вашего браузера, все введенные ключи удалятся безвозвратно. Если вы откроете приложение с другого телефона или компьютера — вам придется вводить все настройки с нуля.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

        </div>

        {/* Footer */}
        <div className="p-6 border-t border-zinc-200 dark:border-white/10 shrink-0 bg-zinc-50 dark:bg-zinc-900/80 flex justify-end">
          <button onClick={onClose} className="px-8 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold rounded-xl transition-all hover:scale-105 active:scale-95 shadow-lg shadow-blue-500/25">
            {t("I read everything, close the guide", "Я внимательно всё изучил, закрыть базу знаний")}
          </button>
        </div>
      </div>
    </div>
  );
};
`
fs.writeFileSync('src/components/HelpModal.tsx', newHelp);
console.log('HelpModal maxed out completely');
