import axios from 'axios';
axios.get('https://api.music.yandex.kz/tracks/53066380', {
  headers: { 'User-Agent': 'Yandex-Music-API' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data)).catch(console.error);
