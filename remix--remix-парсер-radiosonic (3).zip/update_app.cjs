const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Replace tab in state and rendering
code = code.replace(
  'const [activeAppTab, setActiveAppTab] = useState<"parser" | "search" | "history" | "vibe" | "artist" | "report" | "creator" | "logs" | "prompts" | "transfer" | "yandex">("search");',
  'const [activeAppTab, setActiveAppTab] = useState<"parser" | "search" | "history" | "vibe" | "artist" | "report" | "creator" | "logs" | "prompts" | "transfer" | "unique_parser">("unique_parser");'
);

code = code.replace(
  '{ id: "yandex", label: t("Yandex Parser", "Парсер Яндекс") },',
  '{ id: "unique_parser", label: t("Unique Parser", "Уникальный парсер") },'
);

// Replace YandexMusicTab import with UniqueParserTab
code = code.replace(
  'import { YandexMusicTab } from "./components/YandexMusicTab";',
  'import { UniqueParserTab } from "./components/UniqueParserTab";'
);

// Replace YandexMusicTab render with UniqueParserTab
const oldRender = `{activeAppTab === "yandex" && (
          <YandexMusicTab
            onPlayTrack={handlePlayTrackGlobally}
            onSelectAlbum={(id) => {
              handleOpenAlbumModal(id);
            }}
            onSelectArtist={(id) => {
              setCurrentArtistId(id);
              setActiveAppTab("artist");
            }}
            t={t}
          />
        )}`;

const newRender = `{activeAppTab === "unique_parser" && (
          <UniqueParserTab t={t} />
        )}`;

code = code.replace(oldRender, newRender);

fs.writeFileSync('src/App.tsx', code);
console.log("Updated App.tsx to use UniqueParserTab");
