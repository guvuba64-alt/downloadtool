import axios from 'axios';
axios.get('https://api.deezer.com/track/3135556').then(r => console.log(r.data.contributors)).catch(console.error);
