const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex = /return l\.includes\('национальный цифровой агрегатор'\) \|\| l\.includes\('zvonko'\) \|\| l\.includes\('звонко'\) \|\| l\.includes\('sp digital'\) \|\| l\.includes\('sp_digital'\) \|\| l\.includes\('сп диджитал'\) \|\| l\.includes\('believe'\) \|\| l\.includes\('fuga'\) \|\| l\.includes\('onerpm'\) \|\| l\.includes\('freshtunes'\) \|\| l\.includes\('orchard'\) \|\| l\.includes\('sony'\) \|\| l\.includes\('warner'\) \|\| l\.includes\('universal'\);/;

const replacement = `return l.includes('национальный цифровой агрегатор') || l.includes('нца') || l.includes('национальное музыкальное издательство') || l.includes('zvonko') || l.includes('звонко') || l.includes('sp digital') || l.includes('sp_digital') || l.includes('сп диджитал') || l.includes('believe') || l.includes('fuga') || l.includes('onerpm') || l.includes('freshtunes') || l.includes('orchard') || l.includes('sony') || l.includes('warner') || l.includes('universal');`;

code = code.replace(regex, replacement);
fs.writeFileSync('server-okru.ts', code);
