import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://www.deezer.com/en/track/14497554').then(r => console.dir(r, {depth:null}));
