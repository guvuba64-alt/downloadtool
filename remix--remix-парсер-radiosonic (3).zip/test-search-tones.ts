import { searchOkRu } from './server-okru.js';
searchOkRu("Tones And I Dance Monkey").then(r => console.dir(r, {depth:null}));
