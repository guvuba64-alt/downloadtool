import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://open.spotify.com/track/1rgnBhdG2JDFTbYkYRZAku').then(console.log);
