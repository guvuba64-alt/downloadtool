const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex1 = /if \(playInfo\?\.track\?\.copyrightOwnerName\) \{\s*resObj\.copyright = \(typeof playInfo\.track\.copyrightOwnerName === 'string' && playInfo\.track\.copyrightOwnerName\.trim\(\)\.length > 0\) \? playInfo\.track\.copyrightOwnerName\.trim\(\) : null;\s*resObj\.label = resObj\.copyright \|\| foundLabel;\s*\}/;

const replacement1 = `if (playInfo?.copyrightOwnerName) {
           const newCopy = (typeof playInfo.copyrightOwnerName === 'string' && playInfo.copyrightOwnerName.trim().length > 0) ? playInfo.copyrightOwnerName.trim() : null;
           resObj.copyright = newCopy || resObj.copyright;
           resObj.label = resObj.copyright || foundLabel;
       }`;

const regex2 = /if \(playInfo\.copyrightOwnerName\) \{\s*resObj\.copyright = \(typeof playInfo\.copyrightOwnerName === 'string' && playInfo\.copyrightOwnerName\.trim\(\)\.length > 0\) \? playInfo\.copyrightOwnerName\.trim\(\) : null;\s*\}/;

const replacement2 = `if (playInfo.copyrightOwnerName) {
            const newCopy = (typeof playInfo.copyrightOwnerName === 'string' && playInfo.copyrightOwnerName.trim().length > 0) ? playInfo.copyrightOwnerName.trim() : null;
            resObj.copyright = newCopy || resObj.copyright;
          }`;

code = code.replace(regex1, replacement1);
code = code.replace(regex2, replacement2);
fs.writeFileSync('server-okru.ts', code);
