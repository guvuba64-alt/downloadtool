const fs = require('fs');
const c = fs.readFileSync('src/App.tsx', 'utf8');

const s = c.indexOf('{activeAppTab === "parser"');
if (s > -1) {
  const sub = c.substring(s, s + 3000);
  console.log(sub);
}
