import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  timeout: 5000,
  validateStatus: () => true
}).then(r => {
  const html = r.data;
  const nextData = html.match(/<script id="__NEXT_DATA__" type="application\/json">({.*?})<\/script>/s);
  if (nextData) {
    console.log(nextData[1].substring(0, 500));
  } else {
    console.log("no next data");
    const yandexData = html.match(/window\.__yandex_music_initial_state__\s*=\s*({.*?});/s);
    if (yandexData) console.log(yandexData[1].substring(0, 500));
  }
});
