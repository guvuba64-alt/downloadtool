import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru "album/7542918/track/53066380"');
axios.get(`https://html.duckduckgo.com/html/?q=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const match = r.data.match(/<a class="result__url" href="[^"]+">.*?<\/a>.*?<a class="result__snippet[^>]+>(.*?)<\/a>/s);
  console.log(r.data.substring(0, 100));
  console.log("Snippet:", match ? match[1] : 'none');
  const titleMatch = r.data.match(/<h2 class="result__title">.*?<a[^>]+>(.*?)<\/a>.*?<\/h2>/s);
  console.log("Title:", titleMatch ? titleMatch[1] : 'none');
});
