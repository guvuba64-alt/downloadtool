import { searchOkRu } from './server-okru.js';
searchOkRu('https://open.spotify.com/track/1rgnBhdG2JDFTbYkYRZAku').then(r => console.dir(r, {depth:null})).catch(console.error);
