import axios from 'axios';
const q = encodeURIComponent("Tones And I Dance Monkey");
const res = await axios.get(`https://ok.ru/music/search/${q}`, {
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  }
});
const html = res.data;
const tracks = html.match(/\{[^{}]*"(?:track|tracks|pLine|publisher|copyright)"[^{}]*\}/g);
console.log(tracks ? tracks.length : 0);
