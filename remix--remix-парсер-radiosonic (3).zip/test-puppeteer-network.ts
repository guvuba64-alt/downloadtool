import { addExtra } from 'puppeteer-extra';
import vanillaPuppeteer from 'puppeteer';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';

const puppeteer = addExtra(vanillaPuppeteer);
puppeteer.use(StealthPlugin());

async function run() {
  console.log("Checking if puppeteer can intercept network...");
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    
    page.on('response', async (res) => {
      if (res.url().includes('play')) {
        console.log("Intercepted!", res.url());
      }
    });

    console.log("Success");
  } catch (e) {
    console.error(e);
  } finally {
    if (browser) await browser.close();
  }
}
run();
