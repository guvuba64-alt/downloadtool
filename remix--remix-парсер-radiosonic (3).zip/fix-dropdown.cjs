const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetHeader = `{/* Header */}
        <div className="flex justify-between items-start mb-6">
    <header className="flex items-center gap-4">`;

const replacementHeader = `{/* Header */}
        <div className="flex justify-between items-start mb-6 transition-all duration-500">
    <header className="flex items-center gap-4">`;

code = code.replace(targetHeader, replacementHeader);

const headerEndTarget = `          </div>
        </header>`;

const headerEndReplacement = `          </div>
        </header>
        
        {/* Theme Settings Dropdown */}
        <div className="flex items-center gap-2 text-sm z-50">
          <span className="text-current opacity-60 font-medium">{t("Theme:", "Тема:")}</span>
          <select
            value={appTheme}
            onChange={(e) => setAppTheme(e.target.value)}
            className="bg-black/5 dark:bg-white/10 text-current px-3 py-1.5 rounded-lg border-0 cursor-pointer focus:ring-2 focus:ring-current outline-none transition-all duration-300"
          >
            <option value="default">Стандартная</option>
            <option value="minimalism">Минимализм (Clean)</option>
            <option value="anime">Аниме (Kawaii & Neon)</option>
            <option value="designer">Дизайнерская (Glass)</option>
            <option value="cyberpunk">Киберпанк (High Tech)</option>
            <option value="brutalism">Брутализм (Bold)</option>
          </select>
        </div>`;

if(code.includes(headerEndTarget) && !code.includes("Theme Settings Dropdown")) {
    code = code.replace(headerEndTarget, headerEndReplacement);
}

fs.writeFileSync('src/App.tsx', code);
console.log('Dropdown fixed');
