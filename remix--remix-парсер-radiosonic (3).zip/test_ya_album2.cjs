const axios = require('axios');
const yandexToken = process.env.YANDEX_MUSIC_TOKEN || "y0__xCK7-OYBRje-AYgpby9wRYw6a7F7wddxnj7HXeOAc7Jw0Hgrw8ZXN3M3A";
axios.get("https://api.music.yandex.net/search?type=album&text=FUKOUNA+GIRL", { headers: { 'Authorization': `OAuth ${yandexToken}`, 'User-Agent': 'Yandex-Music-API' }})
  .then(r => {
     const albums = r.data.result.albums.results;
     if (albums.length > 0) {
        console.log("Found album ID:", albums[0].id);
        return axios.get("https://api.music.yandex.net/albums/" + albums[0].id + "/with-tracks", { headers: { 'Authorization': `OAuth ${yandexToken}`, 'User-Agent': 'Yandex-Music-API' }});
     }
  })
  .then(r => {
     if (r) {
        const t = r.data.result.volumes[0];
        console.log("Track 1 ISRC:", t[0].isrc);
        console.log("Track 2 ISRC:", t[1].isrc);
     }
  }).catch(e => console.log(e.message));
