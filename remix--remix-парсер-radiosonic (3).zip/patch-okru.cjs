const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf-8');

// We will simplify OKRuCopyrightResolver to strictly adhere to the prompt's rules

// First, fix the interceptOkRuNetworkResponse so it waits for the intercept properly.
code = code.replace(/async function interceptOkRuNetworkResponse[\s\S]*?return null;\n}/, `async function interceptOkRuNetworkResponse(trackId: string): Promise<any> {
  const cleanId = String(trackId).replace(/^(?:okru_|dz_|it_|ya_)/, '');
  let browser;
  try {
    const activeProxy = okProxyConfig.enabled ? parseProxyString(okProxyConfig.proxyUrl) : null;
    const puppeteerArgs = [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu',
      '--blink-settings=imagesEnabled=false' // speed up
    ];
    if (activeProxy) {
      puppeteerArgs.push(activeProxy.puppeteerArg);
    }

    browser = await puppeteer.launch({ 
      args: puppeteerArgs,
      headless: true
    });
    const page = await browser.newPage();
    
    if (okCookies && okCookies.length > 0) {
      const pCookies = okCookies.map(c => ({
        name: c.name,
        value: c.value,
        domain: '.ok.ru',
        path: '/'
      }));
      await page.setCookie(...pCookies);
    }

    // Capture the JSON directly from the CDP response event
    let capturedData = null;
    const capturePromise = new Promise((resolve) => {
      page.on('response', async (response) => {
        const url = response.url();
        if (url.includes('web-api/music/play') || url.includes('play;jsessionid') || url.includes('play?')) {
          try {
            const json = await response.json();
            if (json && (json.track || json.copyrightOwnerName)) {
              capturedData = json;
              resolve(json);
            }
          } catch (e) {}
        }
      });
      // Fallback timeout
      setTimeout(() => resolve(null), 8000);
    });

    await page.goto('https://ok.ru/music', { waitUntil: 'domcontentloaded', timeout: 15000 });
    
    await page.evaluate(async (tid) => {
      try {
        await fetch('/web-api/music/play', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: 'trackId=' + tid
        });
      } catch (e) {}
    }, cleanId);

    const cdpResult = await capturePromise;
    if (cdpResult) {
      return cdpResult;
    }

  } catch (e) {
    console.error('CDP Intercept Error:', e);
  } finally {
    if (browser) {
      await browser.close().catch(()=>0);
    }
  }
  return null;
}`);

// Rewrite OKRuCopyrightResolver to remove all P-Line parsing, year extraction, and fallbacks.
const resolverRegex = /export async function OKRuCopyrightResolver\([\s\S]*?\n\s*return\s*result;\n\}/m;
const strictResolver = `export async function OKRuCopyrightResolver(track: TrackInput): Promise<ResolvedTrackCopyright> {
  if (!track || !track.title) {
    return {
      copyright: null,
      copyrightOwner: null,
      copyrightOwnerId: null,
      copyrightOwnerName: null,
      copyrightYear: null,
      copyrightFormatted: null,
      copyrightStatus: 'not_found',
      source: 'OK.RU'
    };
  }

  // 1. In-memory Cache Check
  const lookupKeys = getCopyrightCacheKeys(track);
  for (const k of lookupKeys) {
    if (okruCopyrightCache.has(k)) {
      const cached = okruCopyrightCache.get(k)!;
      return { ...cached, source: 'OK.RU' };
    }
  }

  // 2. Search OK.ru to find the track ID
  const title = (track.title || '').trim();
  let artistsStr = '';
  if (Array.isArray(track.artists)) {
    artistsStr = track.artists.filter(Boolean).join(', ');
  } else if (typeof track.artists === 'string') {
    artistsStr = track.artists.trim();
  } else if (typeof track.artist === 'string') {
    artistsStr = track.artist.trim();
  }
  
  const query = \`\${artistsStr} \${title}\`.trim();
  let candidates: any[] = [];
  try {
    const searchRes = await axios.post('https://ok.ru/web-api/music/search/tracks', 
      new URLSearchParams({ query }),
      {
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'X-Requested-With': 'XMLHttpRequest',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          ...(okCookies && okCookies.length > 0 ? { Cookie: okCookies.map(c => \`\${c.name}=\${c.value}\`).join('; ') } : {})
        },
        timeout: 4000,
        validateStatus: () => true,
      }
    );

    if (searchRes.status === 200 && searchRes.data) {
      const html = typeof searchRes.data === 'string' ? searchRes.data : JSON.stringify(searchRes.data);
      const jsonMatches = html.match(/\\{[^{}]*"(?:track|tracks)"[^{}]*\\}/g) || [];
      for (const m of jsonMatches) {
        try {
          const parsed = JSON.parse(m);
          if (parsed.track) candidates.push(parsed.track);
          if (Array.isArray(parsed.tracks)) candidates.push(...parsed.tracks);
        } catch (je) {}
      }
    }
  } catch (e) {}

  let bestCandidate: any = null;
  let bestScore = 0;
  for (const cand of candidates) {
    const match = matchTrackCandidate(cand, track);
    if (match.matched && match.score > bestScore) {
      bestScore = match.score;
      bestCandidate = cand;
    }
  }

  let finalCopyrightOwnerName: string | null = null;
  let finalCopyrightOwnerId: number | string | null = null;

  if (bestCandidate && bestCandidate.id) {
    // USE CDP AUTOMATION DIRECTLY TO GET THE JSON FOR THIS TRACK
    const playInfo = await getOkAudioStreamUrl(bestCandidate.id);
    
    // STRICT RULE: Only take from track.copyrightOwnerName or track.copyrightOwnerId from the real response
    if (playInfo && playInfo.track) {
       finalCopyrightOwnerName = playInfo.track.copyrightOwnerName || null;
       finalCopyrightOwnerId = playInfo.track.copyrightOwnerId ?? null;
    } else if (playInfo) {
       finalCopyrightOwnerName = playInfo.copyrightOwnerName || null;
       finalCopyrightOwnerId = playInfo.copyrightOwnerId ?? null;
    }
  }

  const isCopyrightFound = Boolean(finalCopyrightOwnerName && finalCopyrightOwnerName.trim().length > 0);

  const result: ResolvedTrackCopyright = {
    copyright: finalCopyrightOwnerName || null,
    copyrightOwner: finalCopyrightOwnerName || null,
    copyrightOwnerName: finalCopyrightOwnerName || null,
    copyrightOwnerId: finalCopyrightOwnerId ?? null,
    copyrightYear: null, // STRICT RULE: Do not extract year automatically
    copyrightFormatted: null, // STRICT RULE: Do not formulate P-Line
    copyrightStatus: isCopyrightFound ? 'found' : 'not_found',
    source: 'OK.RU',
    rawTrack: bestCandidate || undefined
  };

  const cacheEntry: CopyrightCacheEntry = {
    ...result,
    timestamp: Date.now()
  };
  for (const k of lookupKeys) {
    okruCopyrightCache.set(k, cacheEntry);
  }
  if (bestCandidate && bestCandidate.id) {
    okruCopyrightCache.set(\`okru_id_\${bestCandidate.id}\`, cacheEntry);
  }

  return result;
}`;

code = code.replace(resolverRegex, strictResolver);
fs.writeFileSync('server-okru.ts', code);
