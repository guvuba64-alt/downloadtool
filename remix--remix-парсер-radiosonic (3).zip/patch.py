import re

with open('src/components/UnifiedParserTab.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Default active tab
content = content.replace('useState<\n    "script_zip" | "okru_vk" | "openapi" | "bulk"\n  >("script_zip")', 'useState<\n    "okru_vk" | "openapi" | "bulk"\n  >("okru_vk")')
content = content.replace('useState<"script_zip" | "okru_vk" | "openapi" | "bulk">("script_zip")', 'useState<"okru_vk" | "openapi" | "bulk">("okru_vk")')

# 2. Remove "script_zip" tab from the map
content = re.sub(r'\{\s*id:\s*"script_zip"[^\}]+\},', '', content)

# 3. Remove F12 / Userscript functions
content = re.sub(r'const generateDynamicUserscript = \(\) => \{.*?\n  \};\n\n  // Generate static F12 Injector', '// F12 Injector removed', content, flags=re.DOTALL)
content = re.sub(r'const generateF12Injector = \(\) => \{.*?\n  \};', '', content, flags=re.DOTALL)
content = re.sub(r'const generatePythonScript = \(\) => \{.*?\n  \};', '', content, flags=re.DOTALL)
content = re.sub(r'const handleDownloadSnifferZip = async \(\) => \{.*?\n  \};\n', '', content, flags=re.DOTALL)

# 4. Remove activeSubTab === "script_zip" render block
content = re.sub(r'\{\s*activeSubTab === "script_zip" && \(\s*<div.*?\{/\* SUBTAB 2: OK\.RU / VK', '{/* SUBTAB 2: OK.RU / VK', content, flags=re.DOTALL)

# 5. Modify the "Универсальный парсер" text
content = content.replace('Поддерживает ссылки от Яндекс Музыки, Spotify, Apple Music, Deezer, OK.ru, VK до Звука и YouTube. За официальный Copyright (℗/©, правообладатели, ISRC/UPC и Play-поток) отвечает каталог OK.ru.', 'Полная автоматизация. Вставьте ссылку на трек или релиз (Яндекс, Spotify, Apple, OK.ru, VK и др.). Программа сама найдет трек на OK.ru, автоматически запустит перехват сетевого JSON-ответа (play;jsessionid=...) и извлечет copyrightOwnerName.')

# 6. Remove the Raw JSON Data Block
content = re.sub(r'\{/\* Raw JSON Data Block \*/\}.*?\{/\* Script Viewers \(Tampermonkey & F12 Console\) \*/\}', '', content, flags=re.DOTALL) # wait, I already removed Script Viewers. Let's match just the JSON block.
content = re.sub(r'\{/\* Raw JSON Data Block \*/\}.*?</pre>\s*</div>', '', content, flags=re.DOTALL)

with open('src/components/UnifiedParserTab.tsx', 'w', encoding='utf-8') as f:
    f.write(content)
print("Patch successful!")
