import axios from 'axios';
axios.get('https://music.yandex.ru/iframe/#track/53066380/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const match = r.data.match(/Dance Monkey/i);
  console.log("Dance Monkey in embed:", !!match);
  const jsonMatch = r.data.match(/var Ya = (.*?);<\/script>/s);
  console.log("Ya object length:", jsonMatch ? jsonMatch[1].length : 'none');
}).catch(console.error);
