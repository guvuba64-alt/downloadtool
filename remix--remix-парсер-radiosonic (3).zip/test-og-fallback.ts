import axios from 'axios';
import * as cheerio from 'cheerio';

async function fallbackTitle(url: string) {
  try {
    const res = await axios.get(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 3000,
      validateStatus: () => true
    });
    const $ = cheerio.load(res.data);
    const ogTitle = $('meta[property="og:title"]').attr('content');
    const title = $('title').text();
    console.log("ogTitle:", ogTitle, "title:", title);
  } catch (e) {
    console.log("error", e.message);
  }
}

fallbackTitle('https://music.apple.com/us/album/dance-monkey/1473264639?i=1473264640');
fallbackTitle('https://music.yandex.ru/album/7542918/track/53066380');
