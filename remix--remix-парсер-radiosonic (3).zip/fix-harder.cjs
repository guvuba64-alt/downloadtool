const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');
content = content.replace(/                \)\}\n              <\/div>\n              \{\/\* Right Column/g, `              </div>\n              {/* Right Column`);
content = content.replace(/                \)\}\n              <\/div>\n              \{\/\* Right Column/g, `              </div>\n              {/* Right Column`);

fs.writeFileSync('src/components/ReportTab.tsx', content);
