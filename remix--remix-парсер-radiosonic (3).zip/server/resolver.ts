import axios from 'axios';
import { parseOkRuUrl, searchOkRu } from '../server-okru';

export interface ProviderResult {
  source: string;
  status: 'confirmed' | 'probable' | 'uncertain' | 'not_found' | 'error' | 'rate_limited';
  data?: {
    id?: string;
    artist?: string;
    title?: string;
    version?: string;
    album?: string;
    duration?: number; // seconds
    releaseDate?: string;
    isrc?: string;
    upc?: string;
    label?: string;
    copyright?: string;
    publisher?: string;
    url?: string;
    coverUri?: string;
    previewUrl?: string;
    playUrl?: string;
    tracks?: any[];
  };
  error?: string;
}

export async function resolveOkRu(query: string): Promise<ProviderResult> {
  try {
    let okData;
    if (query.includes('ok.ru')) {
      okData = await parseOkRuUrl(query);
    } else {
      okData = await searchOkRu(query);
    }
    
    if (!okData || !okData.track) {
      return { source: 'ok.ru', status: 'not_found' };
    }
    
    return {
      source: 'ok.ru',
      status: 'confirmed',
      data: {
        artist: okData.track.ensembleName,
        title: okData.track.name,
        album: okData.track.album?.name,
        duration: okData.track.duration,
        releaseDate: okData.track.releaseDate || okData.track.year,
        copyright: okData.copyright,
        url: okData.playUrl || (query.includes('ok.ru') ? query : undefined)
      }
    };
  } catch (e: any) {
    return { source: 'ok.ru', status: 'error', error: e.message };
  }
}

export async function resolveApple(query: string): Promise<ProviderResult> {
  try {
    const isUrl = query.includes('apple.com');
    let searchUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=1`;
    
    if (isUrl) {
      const match = query.match(/i=(\d+)/);
      if (match) {
        searchUrl = `https://itunes.apple.com/lookup?id=${match[1]}&entity=song`;
      } else {
        return { source: 'apple', status: 'not_found', error: 'Could not extract ID from URL' };
      }
    }
    
    const res = await axios.get(searchUrl, { timeout: 5000 });
    const results = res.data.results;
    if (!results || results.length === 0) return { source: 'apple', status: 'not_found' };
    
    const track = results[0];
    return {
      source: 'apple',
      status: 'confirmed',
      data: {
        artist: track.artistName,
        title: track.trackName,
        album: track.collectionName,
        duration: track.trackTimeMillis ? Math.floor(track.trackTimeMillis / 1000) : undefined,
        releaseDate: track.releaseDate,
        label: track.copyright,
        copyright: track.copyright,
        url: track.trackViewUrl
      }
    };
  } catch (e: any) {
    return { source: 'apple', status: 'error', error: e.message };
  }
}

export async function resolveDeezer(query: string): Promise<ProviderResult> {
  try {
    const isUrl = query.includes('deezer.com');
    let searchUrl = `https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=1`;
    
    if (isUrl) {
      const match = query.match(/track\/([a-zA-Z0-9_]+)/);
      if (match) {
        searchUrl = `https://api.deezer.com/track/${match[1].replace('dz_', '')}`;
      } else {
        return { source: 'deezer', status: 'not_found' };
      }
    }
    
    const res = await axios.get(searchUrl, { timeout: 5000 });
    
    // Deezer search returns data array, track lookup returns object directly
    let track = res.data.data ? res.data.data[0] : res.data;
    if (!track || track.error) return { source: 'deezer', status: 'not_found' };
    
    // Get full track info to get ISRC
    if (!track.isrc) {
      const fullRes = await axios.get(`https://api.deezer.com/track/${track.id}`, { timeout: 5000 });
      if (fullRes.data && !fullRes.data.error) track = fullRes.data;
    }
    
    let upc, label;
    if (track.album && track.album.id) {
        try {
            const albumRes = await axios.get(`https://api.deezer.com/album/${track.album.id}`, { timeout: 5000 });
            if (albumRes.data && !albumRes.data.error) {
                upc = albumRes.data.upc;
                label = albumRes.data.label;
            }
        } catch(e) {}
    }
    
    return {
      source: 'deezer',
      status: 'confirmed',
      data: {
        artist: track.artist?.name,
        title: track.title,
        version: track.title_version,
        album: track.album?.title,
        duration: track.duration,
        releaseDate: track.release_date,
        isrc: track.isrc,
        upc: upc,
        label: label,
        copyright: label,
        url: track.link
      }
    };
  } catch (e: any) {
    return { source: 'deezer', status: 'error', error: e.message };
  }
}

export async function resolveMusicBrainz(query: string): Promise<ProviderResult> {
  try {
    const res = await axios.get(`https://musicbrainz.org/ws/2/recording?query=${encodeURIComponent(query)}&fmt=json&limit=1`, { 
      headers: { 'User-Agent': 'MusicResolver/1.0 (test@example.com)' },
      timeout: 5000 
    });
    
    const recordings = res.data.recordings;
    if (!recordings || recordings.length === 0) return { source: 'musicbrainz', status: 'not_found' };
    
    const track = recordings[0];
    const isrc = track.isrcs && track.isrcs.length > 0 ? track.isrcs[0] : undefined;
    
    return {
      source: 'musicbrainz',
      status: 'confirmed',
      data: {
        artist: track['artist-credit']?.[0]?.name,
        title: track.title,
        duration: track.length ? Math.floor(track.length / 1000) : undefined,
        isrc: isrc,
      }
    };
  } catch (e: any) {
    return { source: 'musicbrainz', status: 'error', error: e.message };
  }
}


let spotifyAccessToken: string | null = null;
let spotifyTokenExpiresAt: number = 0;

async function getSpotifyToken(customClientId?: string, customClientSecret?: string) {
  const clientId = customClientId || process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = customClientSecret || process.env.SPOTIFY_CLIENT_SECRET;
  
  if (!clientId || !clientSecret) {
    throw new Error('Spotify credentials not configured in environment variables');
  }

  if (spotifyAccessToken && Date.now() < spotifyTokenExpiresAt && !customClientId) {
    return spotifyAccessToken;
  }

  const response = await axios.post('https://accounts.spotify.com/api/token', 
    'grant_type=client_credentials',
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64'),
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    }
  );

  spotifyAccessToken = response.data.access_token;
  spotifyTokenExpiresAt = Date.now() + (response.data.expires_in - 60) * 1000;
  return spotifyAccessToken;
}

export async function resolveSpotify(query: string, customClientId?: string, customClientSecret?: string): Promise<ProviderResult> {
    try {
        const isUrl = query.includes('spotify.com');
        let searchUrl = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`;
        let isAlbum = false;
        let trackIdFromUrl = '';
        let albumIdFromUrl = '';
        
        if (isUrl) {
            const trackMatch = query.match(/track\/([a-zA-Z0-9_]+)/);
            const albumMatch = query.match(/album\/([a-zA-Z0-9_]+)/);
            if (trackMatch) {
                trackIdFromUrl = trackMatch[1].replace('sp_', '');
                searchUrl = `https://api.spotify.com/v1/tracks/${trackIdFromUrl}`;
            } else if (albumMatch) {
                albumIdFromUrl = albumMatch[1].replace('sp_', '');
                searchUrl = `https://api.spotify.com/v1/albums/${albumIdFromUrl}`;
                isAlbum = true;
            } else {
                return { source: 'spotify', status: 'not_found', error: 'Could not extract track/album ID from URL' };
            }
        }

        let token: string | null = null;
        try {
            token = await getSpotifyToken(customClientId, customClientSecret);
        } catch (tokErr) {
            // No credentials configured -> proceed with free Embed fallback
        }

        if (token) {
            try {
                const res = await axios.get(searchUrl, {
                    headers: { 
                        'Authorization': `Bearer ${token}`,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    },
                    timeout: 5000
                });

                if (isAlbum) {
                    const album = res.data;
                    return {
                        source: 'spotify',
                        status: 'confirmed',
                        data: {
                            id: album.id,
                            artist: album.artists?.map((a: any) => a.name).join(', '),
                            title: album.name,
                            album: album.name,
                            releaseDate: album.release_date,
                            upc: album.external_ids?.upc || album.external_ids?.ean,
                            label: album.label,
                            copyright: album.copyrights?.[0]?.text,
                            coverUri: album.images?.[0]?.url,
                            url: album.external_urls?.spotify || `https://open.spotify.com/album/${album.id}`,
                            tracks: album.tracks?.items?.map((t: any) => ({
                                id: t.id,
                                title: t.name,
                                durationMs: t.duration_ms,
                                url: t.external_urls?.spotify || `https://open.spotify.com/track/${t.id}`
                            }))
                        }
                    };
                } else {
                    const track = isUrl ? res.data : (res.data.tracks?.items?.[0]);
                    if (!track) return { source: 'spotify', status: 'not_found' };

                    return {
                        source: 'spotify',
                        status: 'confirmed',
                        data: {
                            id: track.id,
                            artist: track.artists?.map((a: any) => a.name).join(', '),
                            title: track.name,
                            album: track.album?.name,
                            duration: track.duration_ms ? Math.floor(track.duration_ms / 1000) : undefined,
                            releaseDate: track.album?.release_date,
                            isrc: track.external_ids?.isrc,
                            upc: track.album?.external_ids?.upc,
                            label: track.album?.label,
                            copyright: track.album?.copyrights?.[0]?.text,
                            coverUri: track.album?.images?.[0]?.url,
                            url: track.external_urls?.spotify || `https://open.spotify.com/track/${track.id}`
                        }
                    };
                }
            } catch (apiErr) {
                // Spotify API request failed -> continue to free embed fallback
            }
        }

        // --- FREE ZERO-KEY FALLBACK: Spotify Embed Scraping ---
        if (isUrl && (trackIdFromUrl || albumIdFromUrl)) {
            const embedType = albumIdFromUrl ? 'album' : 'track';
            const embedId = albumIdFromUrl || trackIdFromUrl;
            try {
                const embedRes = await axios.get(`https://open.spotify.com/embed/${embedType}/${embedId}`, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    },
                    timeout: 5000
                });

                const nextDataMatch = embedRes.data.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/);
                if (nextDataMatch) {
                    const parsed = JSON.parse(nextDataMatch[1]);
                    const entity = parsed?.props?.pageProps?.state?.data?.entity;
                    if (entity) {
                        const coverUrl = entity.visualIdentity?.image?.find((img: any) => img.maxWidth >= 640)?.url || entity.visualIdentity?.image?.[0]?.url;
                        
                        if (embedType === 'album') {
                            const albumTracks = (entity.trackList || []).map((t: any) => ({
                                id: t.uri ? t.uri.replace('spotify:track:', '') : t.uid,
                                title: t.title,
                                artist: t.subtitle || entity.artists?.map((a: any) => a.name).join(', '),
                                durationMs: t.duration,
                                url: t.uri ? `https://open.spotify.com/track/${t.uri.replace('spotify:track:', '')}` : undefined,
                                previewUrl: t.audioPreview?.url
                            }));
                            return {
                                source: 'spotify',
                                status: 'confirmed',
                                data: {
                                    id: entity.id || albumIdFromUrl,
                                    artist: entity.artists?.map((a: any) => a.name).join(', ') || entity.subtitle || 'Various Artists',
                                    title: entity.name || entity.title,
                                    album: entity.name || entity.title,
                                    releaseDate: entity.releaseDate?.isoString ? entity.releaseDate.isoString.split('T')[0] : undefined,
                                    coverUri: coverUrl,
                                    url: `https://open.spotify.com/album/${albumIdFromUrl}`,
                                    tracks: albumTracks
                                }
                            };
                        } else {
                            return {
                                source: 'spotify',
                                status: 'confirmed',
                                data: {
                                    id: entity.id || trackIdFromUrl,
                                    artist: entity.artists?.map((a: any) => a.name).join(', ') || 'Unknown Artist',
                                    title: entity.title || entity.name,
                                    album: entity.name || entity.title,
                                    duration: entity.duration ? Math.floor(entity.duration / 1000) : undefined,
                                    releaseDate: entity.releaseDate?.isoString ? entity.releaseDate.isoString.split('T')[0] : undefined,
                                    coverUri: coverUrl,
                                    url: `https://open.spotify.com/track/${trackIdFromUrl}`,
                                    previewUrl: entity.audioPreview?.url
                                }
                            };
                        }
                    }
                }
            } catch (embedErr) {
                // Embed scraping failed
            }
        }

        // --- FINAL FALLBACK: Deezer API (If Spotify is blocking/failing) ---
        if (isUrl) {
            try {
                // If it's a URL, we can't search Deezer by Spotify URL directly. 
                // However, if we extracted track/album IDs, we can't do much without a name.
                // We'll just return not_found.
                return { source: 'spotify', status: 'not_found', error: 'Could not resolve Spotify data (Embed scraping failed)' };
            } catch (fallbackErr) {
                // Fallback failed
            }
        }

        return { source: 'spotify', status: 'not_found', error: 'Could not resolve Spotify data' };
    } catch (e: any) {
        let errorMsg = e.message;
        if (e.response && e.response.data) {
            errorMsg = typeof e.response.data === 'string' ? e.response.data : JSON.stringify(e.response.data);
        }
        return { source: 'spotify', status: 'error', error: errorMsg };
    }
}


export async function resolveYandex(query: string): Promise<ProviderResult> {
    // We will use existing yandex music logic from server.ts if possible, or simple API
    try {
        const res = await axios.get(`https://api.music.yandex.net/search?text=${encodeURIComponent(query)}&type=all&page=0&nocorrect=false`, {
            headers: { "User-Agent": "Yandex-Music-API" },
            timeout: 5000
        });
        const tracks = res.data.result?.tracks?.results;
        if (!tracks || tracks.length === 0) return { source: 'yandex', status: 'not_found' };
        
        const track = tracks[0];
        
        // Fetch track details for ISRC? Yandex often doesn't give ISRC publicly without auth, but we can try
        return {
            source: 'yandex',
            status: 'confirmed',
            data: {
                artist: track.artists?.map((a:any) => a.name).join(', '),
                title: track.title,
                version: track.version,
                album: track.albums?.[0]?.title,
                duration: track.durationMs ? Math.floor(track.durationMs / 1000) : undefined,
                releaseDate: track.albums?.[0]?.releaseDate,
                label: track.albums?.[0]?.labels?.[0]?.name,
                url: `https://music.yandex.ru/track/${track.id}`
            }
        };
    } catch(e:any) {
        return { source: 'yandex', status: 'error', error: e.message };
    }
}


export async function resolveVK(query: string): Promise<ProviderResult> {
    return { source: 'vk', status: 'error', error: 'Not implemented' };
}
export async function resolveZvuk(query: string): Promise<ProviderResult> {
    return { source: 'zvuk', status: 'error', error: 'Not implemented' };
}

export interface ResolvedMetadata {
  identity: { artist: string; title: string; version: string; album: string; duration: number | null; releaseDate: string | null; confidence: number; };
  recording: { isrc: { value: string | null; status: string; sources: string[]; } };
  release: { upc: { value: string | null; status: string; sources: string[]; } };
  rights: { phonogram: any[]; copyright: any[]; publisher: any[]; };
  label: string | null;
  distributors: any[];
  sources: Record<string, any>;
  conflicts: any[];
}

export async function resolveMetadataMultiSource(query: string, spotifyClientId?: string, spotifyClientSecret?: string): Promise<ResolvedMetadata> {
    let searchQuery = query;
    let initialResolve: any = null;
    let initialSource = "";
    
    // If it's a URL, resolve it first to get the track title/artist
    if (query.includes('ok.ru')) {
        initialResolve = await resolveOkRu(query);
        initialSource = 'ok.ru';
    } else if (query.includes('apple.com')) {
        initialResolve = await resolveApple(query);
        initialSource = 'apple';
    } else if (query.includes('spotify.com')) {
        initialResolve = await resolveSpotify(query, spotifyClientId, spotifyClientSecret);
        initialSource = 'spotify';
    } else if (query.includes('deezer.com')) {
        initialResolve = await resolveDeezer(query);
        initialSource = 'deezer';
    } else if (query.includes('music.yandex')) {
        initialResolve = await resolveYandex(query);
        initialSource = 'yandex';
    }
    
    if (initialResolve && initialResolve.status === 'confirmed' && initialResolve.data) {
        searchQuery = `${initialResolve.data.artist || ''} ${initialResolve.data.title || ''}`.trim();
        if (!searchQuery) searchQuery = query;
    }
    
    const promises: Promise<ProviderResult>[] = [];
    promises.push(initialSource === 'ok.ru' ? Promise.resolve(initialResolve) : resolveOkRu(searchQuery));
    promises.push(initialSource === 'yandex' ? Promise.resolve(initialResolve) : resolveYandex(searchQuery));
    promises.push(initialSource === 'spotify' ? Promise.resolve(initialResolve) : resolveSpotify(searchQuery, spotifyClientId, spotifyClientSecret));
    promises.push(initialSource === 'apple' ? Promise.resolve(initialResolve) : resolveApple(searchQuery));
    promises.push(initialSource === 'deezer' ? Promise.resolve(initialResolve) : resolveDeezer(searchQuery));
    promises.push(initialSource === 'musicbrainz' ? Promise.resolve(initialResolve) : resolveMusicBrainz(searchQuery));
    promises.push(initialSource === 'vk' ? Promise.resolve(initialResolve) : resolveVK(searchQuery));
    promises.push(initialSource === 'zvuk' ? Promise.resolve(initialResolve) : resolveZvuk(searchQuery));

    const results = await Promise.allSettled(promises);
    
    const sources: Record<string, any> = {};
    const validResults: any[] = [];
    const isrcMap: Record<string, string[]> = {};
    const upcMap: Record<string, string[]> = {};
    
    results.forEach((res, idx) => {
        const names = ['ok.ru', 'yandex', 'spotify', 'apple', 'deezer', 'musicbrainz', 'vk', 'zvuk'];
        const name = names[idx];
        if (res.status === 'fulfilled') {
            sources[name] = res.value;
            if (res.value.status === 'confirmed' && res.value.data) {
                validResults.push({ source: name, data: res.value.data });
                if (res.value.data.isrc) {
                    if (!isrcMap[res.value.data.isrc]) isrcMap[res.value.data.isrc] = [];
                    isrcMap[res.value.data.isrc].push(name);
                }
                if (res.value.data.upc) {
                    if (!upcMap[res.value.data.upc]) upcMap[res.value.data.upc] = [];
                    upcMap[res.value.data.upc].push(name);
                }
            }
        } else {
            sources[name] = { source: name, status: 'error', error: String(res.reason) };
        }
    });

    let bestArtist = "Unknown";
    let bestTitle = "Unknown";
    let bestVersion = "";
    let bestAlbum = "";
    let bestDuration: any = null;
    let bestReleaseDate: any = null;
    let bestCopyright: any = null;
    let bestLabel: any = null;
    let phonograms: any[] = [];
    let copyrights: any[] = [];
    let distributors: any[] = [];

    // Aggregating
    for (const res of validResults) {
        const { source, data } = res;
        if (bestArtist === "Unknown" && data.artist) bestArtist = data.artist;
        if (bestTitle === "Unknown" && data.title) bestTitle = data.title;
        if (!bestVersion && data.version) bestVersion = data.version;
        if (!bestAlbum && data.album) bestAlbum = data.album;
        if (!bestDuration && data.duration) bestDuration = data.duration;
        if (!bestReleaseDate && data.releaseDate) bestReleaseDate = data.releaseDate;
        
        if (data.copyright) {
            copyrights.push({ raw: data.copyright, entity: classifyCopyright(data.copyright), source });
        }
        if (data.label) {
            bestLabel = data.label;
        }
    }
    
    let isrcValue = null;
    let isrcStatus = "unknown";
    let isrcSources: string[] = [];
    const isrcKeys = Object.keys(isrcMap);
    if (isrcKeys.length === 1) {
        isrcValue = isrcKeys[0];
        isrcStatus = "confirmed";
        isrcSources = isrcMap[isrcValue];
    } else if (isrcKeys.length > 1) {
        isrcStatus = "conflict";
    }
    
    let upcValue = null;
    let upcStatus = "unknown";
    let upcSources: string[] = [];
    const upcKeys = Object.keys(upcMap);
    if (upcKeys.length === 1) {
        upcValue = upcKeys[0];
        upcStatus = "confirmed";
        upcSources = upcMap[upcValue];
    } else if (upcKeys.length > 1) {
        upcStatus = "conflict";
    }

    let allConflicts = [];
    if (isrcKeys.length > 1) allConflicts.push(...isrcKeys.map(k => ({ type: 'isrc', value: k, sources: isrcMap[k] })));
    if (upcKeys.length > 1) allConflicts.push(...upcKeys.map(k => ({ type: 'upc', value: k, sources: upcMap[k] })));

    return {
        identity: { artist: bestArtist, title: bestTitle, version: bestVersion, album: bestAlbum, duration: bestDuration, releaseDate: bestReleaseDate, confidence: 90 },
        recording: { isrc: { value: isrcValue, status: isrcStatus, sources: isrcSources } },
        release: { upc: { value: upcValue, status: upcStatus, sources: upcSources } },
        rights: { phonogram: phonograms, copyright: copyrights, publisher: [] },
        label: bestLabel,
        distributors,
        sources,
        conflicts: allConflicts
    };
}

function classifyCopyright(raw: string) {
    if (raw.includes("℗")) {
        return raw.split("℗")[1].replace(/[0-9]{4}/, '').trim();
    }
    return raw;
}
