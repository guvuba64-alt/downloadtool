import axios from 'axios';
import crypto from 'crypto';
import { getServerSupabaseClient } from './supabaseManager';
import { getMemoryToken, verifyTelegramBotToken } from './universalTokenManager';
import { db } from '../src/db';
import { tokens } from '../src/db/schema';
import { eq } from 'drizzle-orm';
import { 
  confirmTelegramAuthByBot, 
  cancelTelegramAuthByBot, 
  CHIEF_OWNER_TG_ID 
} from './ownerAuthService';

let activeBotToken: string = process.env.TELEGRAM_BOT_TOKEN || '';
let activeWebhookUrl: string = process.env.TELEGRAM_WEBHOOK_URL || '';

export function setActiveBotToken(token: string) {
  activeBotToken = token.trim();
}

export function getActiveBotToken(): string {
  return activeBotToken || getMemoryToken('telegram_bot') || process.env.TELEGRAM_BOT_TOKEN || '';
}

export async function sendTelegramMessage(chatId: string | number, text: string, options: any = {}) {
  const token = getActiveBotToken();
  if (!token) throw new Error('Telegram Bot Token не задан');

  try {
    const res = await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: options.disable_web_page_preview ?? false,
      reply_markup: options.reply_markup,
    }, { timeout: 10000 });
    return res.data;
  } catch (err: any) {
    console.error('Telegram sendMessage error:', err.response?.data || err.message);
    throw err;
  }
}

export async function sendTelegramAudio(chatId: string | number, audioUrl: string, caption: string, options: any = {}) {
  const token = getActiveBotToken();
  if (!token) throw new Error('Telegram Bot Token не задан');

  try {
    const res = await axios.post(`https://api.telegram.org/bot${token}/sendAudio`, {
      chat_id: chatId,
      audio: audioUrl,
      caption,
      parse_mode: 'HTML',
      title: options.title,
      performer: options.performer,
      reply_markup: options.reply_markup,
    }, { timeout: 15000 });
    return res.data;
  } catch (err: any) {
    console.error('Telegram sendAudio error:', err.response?.data || err.message);
    // If sending audio directly fails, fall back to sending message with playable link
    return sendTelegramMessage(chatId, `${caption}\n\n▶️ <b>Слушать онлайн:</b> ${audioUrl}`, options);
  }
}

export async function setTelegramWebhook(botToken: string, webhookUrl: string) {
  const cleanToken = botToken.trim();
  const cleanUrl = webhookUrl.trim();

  const res = await axios.post(`https://api.telegram.org/bot${cleanToken}/setWebhook`, {
    url: cleanUrl,
    allowed_updates: ['message', 'callback_query', 'inline_query'],
  }, { timeout: 10000 });

  activeBotToken = cleanToken;
  activeWebhookUrl = cleanUrl;
  return res.data;
}

export async function getTelegramWebhookInfo(botToken?: string) {
  const token = (botToken || getActiveBotToken()).trim();
  if (!token) return { ok: false, error: 'Токен бота не настроен' };

  try {
    const res = await axios.get(`https://api.telegram.org/bot${token}/getWebhookInfo`, { timeout: 8000 });
    return res.data;
  } catch (e: any) {
    return { ok: false, error: e.response?.data?.description || e.message };
  }
}

/**
 * Validate Telegram Mini App WebApp initData string
 */
export function validateTelegramInitData(initData: string, botToken: string): { valid: boolean; user?: any } {
  if (!initData || !botToken) return { valid: false };

  try {
    const urlParams = new URLSearchParams(initData);
    const hash = urlParams.get('hash');
    urlParams.delete('hash');

    // Sort parameters alphabetically
    const paramsList: string[] = [];
    Array.from(urlParams.keys())
      .sort()
      .forEach((key) => {
        paramsList.push(`${key}=${urlParams.get(key)}`);
      });

    const dataCheckString = paramsList.join('\n');
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const calculatedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    if (calculatedHash === hash) {
      const userStr = urlParams.get('user');
      const user = userStr ? JSON.parse(userStr) : null;
      return { valid: true, user };
    }
    return { valid: false };
  } catch (e) {
    return { valid: false };
  }
}

/**
 * Fetch next track from "Моя волна" (Yandex Music Rotor)
 */
async function fetchWaveNextTrack(station: string = 'user:onyourwave'): Promise<any> {
  let yToken = getMemoryToken('yandex');
  if (!yToken) {
    try {
      const dbTokens = await db.select().from(tokens).where(eq(tokens.userId, 'default_user')).limit(1);
      if (dbTokens.length > 0) yToken = dbTokens[0].accessToken;
    } catch (e) {}
  }

  const cleanToken = (yToken || '').trim().replace(/^OAuth\s+/i, '');
  const headers: Record<string, string> = {
    'User-Agent': 'Yandex-Music-API',
    'Accept': 'application/json',
  };
  if (cleanToken) {
    headers['Authorization'] = `OAuth ${cleanToken}`;
  }

  try {
    const res = await axios.get(`https://api.music.yandex.net/rotor/station/${station}/tracks`, {
      headers,
      timeout: 10000,
    });

    const sequence = res.data?.result?.sequence;
    if (Array.isArray(sequence) && sequence.length > 0) {
      const item = sequence[0];
      const track = item.track;
      if (track) {
        const title = track.title || 'Без названия';
        const artist = Array.isArray(track.artists) ? track.artists.map((a: any) => a.name).join(', ') : (track.artists || 'Неизвестный исполнитель');
        const cover = track.coverUri ? `https://${track.coverUri.replace('%%', '400x400')}` : undefined;
        return {
          id: track.id,
          title,
          artist,
          cover,
          duration: track.durationMs ? Math.round(track.durationMs / 1000) : 180,
          batchId: res.data?.result?.batchId,
          backgroundVideoUri: track.backgroundVideoUri,
        };
      }
    }
  } catch (err: any) {
    console.warn('Rotor station fetch warning, fallback to chart:', err.message);
  }

  // Fallback to top chart
  try {
    const res = await axios.get('https://api.music.yandex.net/chart', {
      headers: { 'User-Agent': 'Yandex-Music-API' },
      timeout: 8000,
    });
    const chartTracks = res.data?.result?.chart?.tracks;
    if (Array.isArray(chartTracks) && chartTracks.length > 0) {
      const randomIdx = Math.floor(Math.random() * Math.min(chartTracks.length, 25));
      const t = chartTracks[randomIdx]?.track;
      if (t) {
        return {
          id: t.id,
          title: t.title,
          artist: Array.isArray(t.artists) ? t.artists.map((a: any) => a.name).join(', ') : t.artists,
          cover: t.coverUri ? `https://${t.coverUri.replace('%%', '400x400')}` : undefined,
          duration: t.durationMs ? Math.round(t.durationMs / 1000) : 180,
        };
      }
    }
  } catch (e) {}

  return {
    id: '53066380',
    title: 'Моя волна',
    artist: 'Яндекс Музыка',
    cover: 'https://avatars.yandex.net/get-music-misc/28592/wave-cover/400x400',
    duration: 180,
  };
}

/**
 * Handle incoming Telegram Bot Webhook update
 */
export async function handleTelegramWebhookUpdate(update: any, appUrl: string = '') {
  if (!update) return;

  // 1. Handle Messages
  if (update.message) {
    const msg = update.message;
    const chatId = msg.chat?.id;
    const text = (msg.text || '').trim();
    const from = msg.from;

    if (!chatId) return;

    // Record user to Supabase if configured
    try {
      const supa = getServerSupabaseClient();
      if (supa && from?.id) {
        await supa.from('profiles').upsert({
          telegram_id: from.id,
          username: from.username || null,
          first_name: from.first_name || null,
          last_name: from.last_name || null,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'telegram_id' });
      }
    } catch (e) {}

    // Command: /start auth_<requestId> (Secure 2FA login)
    if (text.startsWith('/start auth_')) {
      const authId = text.replace(/^\/start\s+auth_/, '').trim();
      const isOwner = String(from?.id) === CHIEF_OWNER_TG_ID;

      if (!isOwner) {
        await sendTelegramMessage(
          chatId,
          `⛔ <b>Доступ запрещен</b>\n\n` +
          `Ваш Telegram ID (<code>${from?.id || 'неизвестен'}</code>) не зарегистрирован как Главный Владелец.\n` +
          `Попытка входа отклонена.`
        );
        return;
      }

      const promptText = `👑 <b>Запрос на вход в панель Главного Владельца</b>\n\n` +
        `Сайт запрашивает подтверждение доступа к разделам Supabase, Telegram-боту и серверным токенам.\n\n` +
        `👤 <b>Ваш аккаунт:</b> @${from?.username || from?.first_name || 'Owner'} (ID: <code>${from.id}</code>)\n` +
        `⏱️ <b>Срок действия:</b> 5 минут\n\n` +
        `Вы подтверждаете вход?`;

      await sendTelegramMessage(chatId, promptText, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '✅ Подтвердить вход', callback_data: `owner_auth_yes_${authId}` },
              { text: '❌ Отклонить', callback_data: `owner_auth_no_${authId}` }
            ]
          ]
        }
      });
      return;
    }

    // Command: /start
    if (text.startsWith('/start')) {
      const webAppUrl = appUrl || process.env.APP_URL || 'https://yandex-music-player.app';
      const welcome = `🎵 <b>Добро пожаловать в Музыкальный Бот и Сервер!</b>\n\n` +
        `Все функции стриминга теперь доступны онлайн и в Telegram:\n` +
        `• 🌊 <b>Моя волна</b> — бесконечный поток рекомендаций\n` +
        `• 🔍 <b>Поиск треков</b> — Яндекс Музыка, VK Музыка, OK.ru\n` +
        `• 📱 <b>Telegram Mini App</b> — полноценный плеер прямо в Telegram\n` +
        `• ☁️ <b>Синхронизация с Supabase</b> — облачные токены и история\n\n` +
        `<i>Выберите действие ниже:</i>`;

      await sendTelegramMessage(chatId, welcome, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🌊 Запустить «Мою волну»', callback_data: 'wave_next' },
              { text: '🔍 Поиск музыки', callback_data: 'prompt_search' },
            ],
            [
              { text: '📱 Открыть Web Player', web_app: { url: webAppUrl } },
            ],
            [
              { text: '🔑 Статус токенов', callback_data: 'check_tokens' },
              { text: 'ℹ️ Помощь и команды', callback_data: 'bot_help' },
            ],
          ],
        },
      });
      return;
    }

    // Command: /wave or /mywave
    if (text.startsWith('/wave') || text.startsWith('/mywave') || text.toLowerCase().includes('волна')) {
      const track = await fetchWaveNextTrack();
      const streamUrl = `${appUrl}/api/music/stream?trackId=${track.id}`;
      const msgText = `🌊 <b>Моя волна</b>\n\n` +
        `🎶 <b>${track.title}</b>\n` +
        `👤 <i>${track.artist}</i>\n\n` +
        `🔊 <a href="${streamUrl}">Прямой аудио-поток трека</a>`;

      await sendTelegramMessage(chatId, msgText, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '❤️ Нравится', callback_data: `like_${track.id}` },
              { text: '⏭️ Следующий', callback_data: 'wave_next' },
            ],
            [
              { text: '📱 Открыть в плеере', web_app: { url: `${appUrl}?playId=${track.id}` } },
            ],
          ],
        },
      });
      return;
    }

    // Command: /tokens
    if (text.startsWith('/tokens')) {
      const yToken = getMemoryToken('yandex') || 'Не задан';
      const vkToken = getMemoryToken('vk') || 'Не задан';
      const okToken = getMemoryToken('ok_ru') || 'Не задан';
      const supa = getServerSupabaseClient();

      const tokensInfo = `🔑 <b>Статус интеграции токенов (От А до Я):</b>\n\n` +
        `• <b>Яндекс Музыка:</b> ${yToken !== 'Не задан' ? '🟢 Подключен' : '🟡 Не настроен'}\n` +
        `• <b>VK Музыка:</b> ${vkToken !== 'Не задан' ? '🟢 Подключен' : '⚪ Не настроен'}\n` +
        `• <b>OK.ru:</b> ${okToken !== 'Не задан' ? '🟢 Подключен' : '⚪ Не настроен'}\n` +
        `• <b>Облако Supabase:</b> ${supa ? '🟢 Активно' : '🟡 Локальный режим'}\n\n` +
        `<i>Для изменения токенов откройте веб-приложение во вкладке «Облако & Supabase».</i>`;

      await sendTelegramMessage(chatId, tokensInfo, {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🌐 Открыть настройки токенов', web_app: { url: `${appUrl}?tab=cloud` } }]
          ]
        }
      });
      return;
    }

    // Command: /search <query>
    if (text.startsWith('/search') || text.startsWith('поиск ')) {
      const q = text.replace(/^\/search\s*/, '').replace(/^поиск\s*/, '').trim();
      if (!q) {
        await sendTelegramMessage(chatId, '🔍 <i>Введите поисковый запрос:</i> например <code>/search Miyagi</code>');
        return;
      }

      try {
        const searchRes = await axios.get(`https://api.music.yandex.net/search?text=${encodeURIComponent(q)}&type=track`, {
          headers: { 'User-Agent': 'Yandex-Music-API' },
          timeout: 8000,
        });

        const tracks = searchRes.data?.result?.tracks?.results || [];
        if (tracks.length === 0) {
          await sendTelegramMessage(chatId, `🔍 По запросу «${q}» ничего не найдено.`);
          return;
        }

        const topTracks = tracks.slice(0, 5);
        let resp = `🔍 <b>Результаты поиска:</b> «${q}»\n\n`;

        const keyboard: any[][] = [];

        topTracks.forEach((t: any, idx: number) => {
          const art = Array.isArray(t.artists) ? t.artists.map((a: any) => a.name).join(', ') : t.artists;
          resp += `${idx + 1}. <b>${t.title}</b> — <i>${art}</i>\n`;
          keyboard.push([
            { text: `▶️ ${idx + 1}. ${t.title.substring(0, 25)}`, callback_data: `play_${t.id}` }
          ]);
        });

        keyboard.push([
          { text: '📱 Открыть все результаты в плеере', web_app: { url: `${appUrl}?q=${encodeURIComponent(q)}` } }
        ]);

        await sendTelegramMessage(chatId, resp, { reply_markup: { inline_keyboard: keyboard } });
      } catch (err: any) {
        await sendTelegramMessage(chatId, `❌ Ошибка поиска: ${err.message}`);
      }
      return;
    }

    // Command: /help
    if (text.startsWith('/help')) {
      const help = `📖 <b>Справочник команд музыкального бота:</b>\n\n` +
        `• <code>/start</code> — Главное интерактивное меню\n` +
        `• <code>/wave</code> — Поток рекомендаций «Моя волна»\n` +
        `• <code>/search &lt;название&gt;</code> — Поиск треков\n` +
        `• <code>/tokens</code> — Проверка состояния токенов и Supabase\n` +
        `• <code>/help</code> — Это справочное меню\n\n` +
        `<i>Бот напрямую интегрирован с вашим сервером и базой Supabase.</i>`;
      await sendTelegramMessage(chatId, help);
      return;
    }

    // Default response
    await sendTelegramMessage(chatId, `🎶 Получено сообщение: «${text}»\n\nИспользуйте команду /wave для включения «Моей волны» или /search для поиска музыки.`, {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌊 Включить Мою волну', callback_data: 'wave_next' }],
          [{ text: '📱 Открыть плеер', web_app: { url: appUrl } }],
        ]
      }
    });
  }

  // 2. Handle Callback Queries (Button clicks)
  if (update.callback_query) {
    const cb = update.callback_query;
    const chatId = cb.message?.chat?.id;
    const data = cb.data || '';

    if (!chatId) return;

    // Handle Owner 2FA confirmation from Telegram
    if (data.startsWith('owner_auth_yes_')) {
      const authId = data.replace('owner_auth_yes_', '').trim();
      const from = cb.from;
      const res = await confirmTelegramAuthByBot(authId, from.id, from.username, chatId);
      if (res.success) {
        await sendTelegramMessage(chatId, `✅ <b>Вход подтвержден в Telegram!</b>\n\nКод подтверждения для второго фактора (Email 2FA) отправлен на вашу подтверждённую почту и в этот чат. Введите его на сайте для завершения входа.`);
      } else {
        await sendTelegramMessage(chatId, `❌ <b>Ошибка:</b> ${res.error || 'Не удалось подтвердить'}`);
      }
      return;
    }

    if (data.startsWith('owner_auth_no_')) {
      const authId = data.replace('owner_auth_no_', '').trim();
      cancelTelegramAuthByBot(authId);
      await sendTelegramMessage(chatId, `🚫 <b>Попытка входа отклонена и заблокирована.</b>`);
      return;
    }

    if (data === 'wave_next') {
      const track = await fetchWaveNextTrack();
      const streamUrl = `${appUrl}/api/music/stream?trackId=${track.id}`;
      const msgText = `🌊 <b>Моя волна</b>\n\n` +
        `🎶 <b>${track.title}</b>\n` +
        `👤 <i>${track.artist}</i>\n\n` +
        `🔊 <a href="${streamUrl}">Слушать поток трека</a>`;

      await sendTelegramMessage(chatId, msgText, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '❤️ Нравится', callback_data: `like_${track.id}` },
              { text: '⏭️ Следующий', callback_data: 'wave_next' },
            ],
            [
              { text: '📱 Открыть в плеере', web_app: { url: `${appUrl}?playId=${track.id}` } },
            ],
          ],
        },
      });
      return;
    }

    if (data.startsWith('like_')) {
      const trackId = data.replace('like_', '');
      await sendTelegramMessage(chatId, `❤️ Трек #${trackId} добавлен в ваши лайки «Моей волны»! Рекомендации обновлены.`);
      return;
    }

    if (data.startsWith('play_')) {
      const trackId = data.replace('play_', '');
      const streamUrl = `${appUrl}/api/music/stream?trackId=${trackId}`;
      await sendTelegramMessage(chatId, `▶️ <b>Воспроизведение трека #${trackId}</b>\n\nСсылка на аудиопоток: ${streamUrl}`, {
        reply_markup: {
          inline_keyboard: [
            [{ text: '📱 Слушать в плеере', web_app: { url: `${appUrl}?playId=${trackId}` } }],
            [{ text: '🌊 Вернуться в Мою волну', callback_data: 'wave_next' }]
          ]
        }
      });
      return;
    }

    if (data === 'check_tokens') {
      const yToken = getMemoryToken('yandex') || 'Не задан';
      const vkToken = getMemoryToken('vk') || 'Не задан';
      const supa = getServerSupabaseClient();
      await sendTelegramMessage(chatId, `🔑 <b>Интеграции:</b>\n\nЯндекс Музыка: ${yToken !== 'Не задан' ? '🟢' : '🟡'}\nVK: ${vkToken !== 'Не задан' ? '🟢' : '⚪'}\nSupabase: ${supa ? '🟢' : '🟡'}`);
      return;
    }

    if (data === 'prompt_search') {
      await sendTelegramMessage(chatId, `🔍 Напишите <code>/search &lt;песня или артист&gt;</code> для мгновенного поиска.`);
      return;
    }

    if (data === 'bot_help') {
      await sendTelegramMessage(chatId, `📖 Команды:\n/start — Меню\n/wave — Моя волна\n/search &lt;запрос&gt; — Поиск\n/tokens — Токены`);
      return;
    }
  }
}
