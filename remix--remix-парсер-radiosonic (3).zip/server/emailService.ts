import nodemailer from 'nodemailer';

type MailTransporter = any;
let transporter: MailTransporter | null = null;

function getTransporter(): MailTransporter | null {
  if (transporter) return transporter;

  const host = process.env.SMTP_HOST || process.env.MAIL_HOST;
  const port = parseInt(process.env.SMTP_PORT || process.env.MAIL_PORT || '587', 10);
  const user = process.env.SMTP_USER || process.env.MAIL_USER;
  const pass = process.env.SMTP_PASS || process.env.MAIL_PASS || process.env.SMTP_PASSWORD;

  if (host && user && pass) {
    try {
      transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: { user, pass }
      });
      return transporter;
    } catch (e) {
      console.warn('[EmailService] Failed to create SMTP transporter:', e);
    }
  }

  return null;
}

export async function sendOtpEmail(
  toEmail: string,
  otpCode: string,
  options: { deviceLabel?: string; ip?: string } = {}
): Promise<{ success: boolean; method: string; error?: string }> {
  const cleanEmail = (toEmail || '').trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    return { success: false, method: 'none', error: 'Некорректный адрес электронной почты' };
  }

  console.log(`\n======================================================`);
  console.log(`[Email 2FA] OTP Code for ${cleanEmail}: [ ${otpCode} ]`);
  console.log(`Device: ${options.deviceLabel || 'Неизвестно'} | IP: ${options.ip || '127.0.0.1'}`);
  console.log(`======================================================\n`);

  const mailer = getTransporter();
  if (mailer) {
    try {
      const fromSender = process.env.SMTP_FROM || process.env.MAIL_FROM || `"Cloud Music Suite" <${process.env.SMTP_USER || 'auth@music-suite.local'}>`;
      await mailer.sendMail({
        from: fromSender,
        to: cleanEmail,
        subject: `Код подтверждения входа: ${otpCode}`,
        text: `Ваш код подтверждения для входа: ${otpCode}. Действует 5 минут.\nУстройство: ${options.deviceLabel || 'Browser'}\nЕсли это были не вы, проигнорируйте это письмо.`,
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 28px; background: #0f1117; border-radius: 20px; border: 1px solid #27272a; color: #ffffff;">
            <div style="text-align: center; margin-bottom: 24px;">
              <span style="display: inline-block; padding: 8px 18px; border-radius: 9999px; background: rgba(16, 185, 129, 0.15); color: #34d399; font-weight: 800; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em;">
                Двухфакторная защита (2FA)
              </span>
            </div>
            <h2 style="margin: 0 0 12px; font-size: 22px; font-weight: 800; text-align: center; color: #ffffff;">
              Код подтверждения входа
            </h2>
            <p style="margin: 0 0 28px; font-size: 14px; line-height: 1.6; text-align: center; color: #a1a1aa;">
              Используйте этот одноразовый 6-значный код для завершения входа в панель:
            </p>
            <div style="text-align: center; margin: 0 0 28px;">
              <div style="display: inline-block; padding: 18px 36px; border-radius: 16px; background: #000000; border: 2px solid #8b5cf6; font-size: 34px; font-weight: 900; letter-spacing: 8px; color: #a78bfa; font-family: monospace;">
                ${otpCode}
              </div>
            </div>
            <p style="margin: 0 0 16px; font-size: 13px; color: #71717a; text-align: center;">
              ⏱️ Код действует <b>5 минут</b>. Никому не сообщайте этот код.
            </p>
            <div style="padding: 16px; border-radius: 12px; background: #18181b; border: 1px solid #27272a; font-size: 12px; color: #a1a1aa; line-height: 1.5;">
              <div>💻 <b>Устройство:</b> ${options.deviceLabel || 'Веб-браузер'}</div>
              <div>🌐 <b>IP-адрес:</b> ${options.ip || '127.0.0.1'}</div>
            </div>
          </div>
        `
      });
      return { success: true, method: 'smtp' };
    } catch (err: any) {
      console.warn('[EmailService] SMTP send error (logged to console instead):', err.message);
      return { success: true, method: 'console_fallback' };
    }
  }

  return { success: true, method: 'console' };
}
