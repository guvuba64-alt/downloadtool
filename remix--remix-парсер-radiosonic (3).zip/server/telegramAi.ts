import { GoogleGenAI } from '@google/genai';
import { sqlite } from '../src/db';

export interface TelegramAiConfig {
  enabled: boolean;
  provider: 'custom' | 'openai' | 'gemini' | 'anthropic' | 'deepseek' | 'groq' | 'ollama';
  apiUrl: string;
  apiKey: string;
  model: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  accessMode: 'owner_only' | 'contacts_only' | 'all';
  historyLimit: number;
  ownerChatId: string;
  unauthorizedResponse: 'silent' | 'reject_message';
  autoFallback?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

export const DEFAULT_AI_CONFIG: TelegramAiConfig = {
  enabled: true,
  provider: 'gemini',
  apiUrl: '',
  apiKey: '',
  model: 'gemini-3.1-flash-lite',
  systemPrompt: 'Ты профессиональный персональный ИИ-ассистент музыкального лейбла в Telegram. Отвечай вежливо, емко и по делу. Помогай артистам и менеджерам с релизами, дистрибуцией, промо-материалами, текстами, идеями и любыми вопросами.',
  temperature: 0.7,
  maxTokens: 1500,
  accessMode: 'owner_only',
  historyLimit: 8,
  ownerChatId: '8981404137',
  unauthorizedResponse: 'silent',
  autoFallback: true,
};

export const PROVIDER_DEFAULTS: Record<string, { apiUrl: string; model: string; name: string }> = {
  custom: {
    apiUrl: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    name: 'Custom API Endpoint',
  },
  openai: {
    apiUrl: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    name: 'OpenAI (ChatGPT)',
  },
  gemini: {
    apiUrl: '',
    model: 'gemini-3.1-flash-lite',
    name: 'Google Gemini',
  },
  deepseek: {
    apiUrl: 'https://api.deepseek.com/v1/chat/completions',
    model: 'deepseek-chat',
    name: 'DeepSeek AI',
  },
  groq: {
    apiUrl: 'https://api.groq.com/openai/v1/chat/completions',
    model: 'llama-3.3-70b-versatile',
    name: 'Groq (Ultra-Fast)',
  },
  anthropic: {
    apiUrl: 'https://api.anthropic.com/v1/messages',
    model: 'claude-3-5-sonnet-20241022',
    name: 'Anthropic Claude',
  },
  ollama: {
    apiUrl: 'http://localhost:11434/v1/chat/completions',
    model: 'llama3',
    name: 'Ollama (Local / Self-Hosted)',
  },
};

export function normalizeApiUrl(url: string, provider: string = 'custom'): string {
  let clean = (url || '').trim();
  if (!clean) {
    return PROVIDER_DEFAULTS[provider]?.apiUrl || 'https://api.openai.com/v1/chat/completions';
  }
  clean = clean.replace(/\/+$/, '');

  if (provider === 'gemini') return clean;
  if (provider === 'anthropic') {
    if (clean.endsWith('/messages')) return clean;
    if (clean.endsWith('/v1')) return `${clean}/messages`;
    return `${clean}/v1/messages`;
  }

  // OpenAI-compatible / Custom / DeepSeek / Groq / Ollama:
  if (clean.endsWith('/chat/completions') || clean.endsWith('/completions')) {
    return clean;
  }
  if (clean.endsWith('/v1')) {
    return `${clean}/chat/completions`;
  }
  return `${clean}/v1/chat/completions`;
}

/**
 * Fetch available models from OpenAI-compatible provider
 */
export async function fetchAvailableModels(
  apiUrl?: string,
  apiKey?: string,
  provider: string = 'custom'
): Promise<string[]> {
  const normKey = (apiKey || currentConfig.apiKey || '').trim();
  const rawUrl = (apiUrl || currentConfig.apiUrl || '').trim();
  const normUrl = normalizeApiUrl(rawUrl, provider);

  let modelsUrl = '';
  if (normUrl.includes('/v1/chat/completions')) {
    modelsUrl = normUrl.replace('/v1/chat/completions', '/v1/models');
  } else if (normUrl.includes('/chat/completions')) {
    modelsUrl = normUrl.replace('/chat/completions', '/models');
  } else {
    modelsUrl = `${normUrl.replace(/\/+$/, '')}/models`;
  }

  const headers: Record<string, string> = {};
  if (normKey) {
    headers['Authorization'] = `Bearer ${normKey}`;
  }

  const controller = new AbortController();
  const tId = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(modelsUrl, { headers, signal: controller.signal });
    if (!res.ok) return [];
    const json = await res.json();
    const rawList = Array.isArray(json?.data) ? json.data : Array.isArray(json) ? json : [];
    return rawList
      .map((m: any) => (typeof m === 'string' ? m : m.id || m.name))
      .filter(Boolean);
  } catch {
    return [];
  } finally {
    clearTimeout(tId);
  }
}

export interface ModelScanStatus {
  id: string;
  available: boolean;
  status: number;
  latencyMs: number;
  error?: string;
  isFree: boolean;
  testedAt: number;
}

let cachedScanResults: { timestamp: number; results: ModelScanStatus[] } = {
  timestamp: 0,
  results: [],
};

export function getCachedModelScanResults(): { timestamp: number; results: ModelScanStatus[] } {
  return cachedScanResults;
}

/**
 * Actively scan and probe models on the API provider
 */
export async function scanModelsAvailability(
  apiUrl?: string,
  apiKey?: string,
  provider: string = 'custom',
  specificModels?: string[]
): Promise<ModelScanStatus[]> {
  const normKey = (apiKey || currentConfig.apiKey || '').trim();
  const rawUrl = (apiUrl || currentConfig.apiUrl || '').trim();
  const endpoint = normalizeApiUrl(rawUrl, provider);

  let modelList: string[] = [];
  if (specificModels && specificModels.length > 0) {
    modelList = specificModels;
  } else {
    modelList = await fetchAvailableModels(rawUrl, normKey, provider);
  }

  // If no models returned from provider /models, fall back to known models
  if (modelList.length === 0) {
    modelList = [
      'free/gemini-3.8-flash',
      'free/deepseek-v4.1-flash',
      'free/gpt-5.6-luna',
      'free/glm-5.3-flash',
      'free/deepseek-v4-flash-0731',
      'gpt-4o-mini',
      'deepseek-chat',
      'gpt-4o',
    ];
  }

  const probeModel = async (modelName: string): Promise<ModelScanStatus> => {
    const isFree = modelName.toLowerCase().startsWith('free/');
    const start = Date.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (normKey) {
      headers['Authorization'] = `Bearer ${normKey}`;
    }

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers,
        signal: controller.signal,
        body: JSON.stringify({
          model: modelName,
          messages: [{ role: 'user', content: 'hi' }],
          max_tokens: 2,
        }),
      });

      const latencyMs = Date.now() - start;

      if (res.ok) {
        return {
          id: modelName,
          available: true,
          status: res.status,
          latencyMs,
          isFree,
          testedAt: Date.now(),
        };
      }

      const errText = await res.text();
      let errorMsg = `HTTP ${res.status}`;
      try {
        const parsed = JSON.parse(errText);
        const detail = parsed.error?.message || parsed.message || (typeof parsed.error === 'string' ? parsed.error : '');
        if (detail) {
          if (res.status === 402 || detail.toLowerCase().includes('balance') || detail.toLowerCase().includes('credit') || detail.toLowerCase().includes('check-in')) {
            errorMsg = `402: Баланс исчерпан (${detail.slice(0, 75)})`;
          } else if (res.status === 404) {
            errorMsg = `404: Модель не найдена (${detail.slice(0, 75)})`;
          } else if (res.status === 429) {
            errorMsg = `429: Лимит запросов Rate-Limit (${detail.slice(0, 75)})`;
          } else {
            errorMsg = `${res.status}: ${detail.slice(0, 75)}`;
          }
        }
      } catch {
        errorMsg = `${res.status}: ${errText.slice(0, 60)}`;
      }

      return {
        id: modelName,
        available: false,
        status: res.status,
        latencyMs,
        error: errorMsg,
        isFree,
        testedAt: Date.now(),
      };
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      const isTimeout = err.name === 'AbortError' || err.code === 'ETIMEDOUT' || err.message?.includes('timeout');
      return {
        id: modelName,
        available: false,
        status: isTimeout ? 408 : 500,
        latencyMs,
        error: isTimeout ? 'Таймаут шлюза (превышено 9с)' : (err.message || 'Ошибка сети'),
        isFree,
        testedAt: Date.now(),
      };
    } finally {
      clearTimeout(timeout);
    }
  };

  // Run in chunks of 5 parallel probes
  const results: ModelScanStatus[] = [];
  const chunkSize = 5;
  for (let i = 0; i < modelList.length; i += chunkSize) {
    const chunk = modelList.slice(i, i + chunkSize);
    const chunkRes = await Promise.all(chunk.map(probeModel));
    results.push(...chunkRes);
  }

  // Sort: available first (free on top, then lowest latency), then unavailable
  results.sort((a, b) => {
    if (a.available !== b.available) return a.available ? -1 : 1;
    if (a.available && b.available) {
      if (a.isFree !== b.isFree) return a.isFree ? -1 : 1;
      return a.latencyMs - b.latencyMs;
    }
    return a.id.localeCompare(b.id);
  });

  cachedScanResults = {
    timestamp: Date.now(),
    results,
  };

  return results;
}

let currentConfig: TelegramAiConfig = { ...DEFAULT_AI_CONFIG };
const chatMemory = new Map<string, ChatMessage[]>();

// Logger reference
let loggerFn: ((level: 'error' | 'warn' | 'info' | 'debug', cat: any, msg: string, details?: any) => void) | null = null;
let safeTgFetchFn: ((url: string, opts?: any, timeout?: number) => Promise<any>) | null = null;
let getTgConfigFn: (() => { tokens: string[]; contacts: { id: string; label: string }[] }) | null = null;

export function initTelegramAiManager(options: {
  logger: (level: 'error' | 'warn' | 'info' | 'debug', cat: any, msg: string, details?: any) => void;
  safeTelegramFetch: (url: string, opts?: any, timeout?: number) => Promise<any>;
  getTgConfig: () => { tokens: string[]; contacts: { id: string; label: string }[] };
}) {
  loggerFn = options.logger;
  safeTgFetchFn = options.safeTelegramFetch;
  getTgConfigFn = options.getTgConfig;

  // Load config from SQLite
  sqlite
    .execute('SELECT * FROM tg_ai_config WHERE id = 1 LIMIT 1')
    .then((res) => {
      if (res.rows && res.rows.length > 0) {
        const row = res.rows[0];
        currentConfig = {
          enabled: Boolean(row.enabled),
          provider: (row.provider as any) || DEFAULT_AI_CONFIG.provider,
          apiUrl: (row.api_url as string) || '',
          apiKey: (row.api_key as string) || '',
          model: (row.model as string) || DEFAULT_AI_CONFIG.model,
          systemPrompt: (row.system_prompt as string) || DEFAULT_AI_CONFIG.systemPrompt,
          temperature: typeof row.temperature === 'number' ? row.temperature : DEFAULT_AI_CONFIG.temperature,
          maxTokens: typeof row.max_tokens === 'number' ? row.max_tokens : DEFAULT_AI_CONFIG.maxTokens,
          accessMode: (row.access_mode as any) || DEFAULT_AI_CONFIG.accessMode,
          historyLimit: typeof row.history_limit === 'number' ? row.history_limit : DEFAULT_AI_CONFIG.historyLimit,
          ownerChatId: (row.owner_chat_id as string) || DEFAULT_AI_CONFIG.ownerChatId,
          unauthorizedResponse: (row.unauthorized_response as any) || DEFAULT_AI_CONFIG.unauthorizedResponse,
        };
        log('info', `ИИ-Бот: Настройки успешно загружены из базы данных. Провайдер: ${currentConfig.provider}, Модель: ${currentConfig.model}, Владелец: [${currentConfig.ownerChatId}], Режим: ${currentConfig.accessMode}`);
      }
    })
    .catch((err) => {
      console.error('Failed to load tg_ai_config from sqlite:', err);
    });
}

function log(level: 'error' | 'warn' | 'info' | 'debug', msg: string, details?: any) {
  if (loggerFn) {
    loggerFn(level, 'telegram', msg, details);
  } else {
    console.log(`[${level.toUpperCase()}][TELEGRAM] ${msg}`, details || '');
  }
}

export function getTelegramAiConfig(): TelegramAiConfig {
  return { ...currentConfig };
}

export async function saveTelegramAiConfig(newConfig: Partial<TelegramAiConfig>): Promise<TelegramAiConfig> {
  currentConfig = {
    ...currentConfig,
    ...newConfig,
  };

  if (currentConfig.apiUrl && currentConfig.provider !== 'gemini') {
    currentConfig.apiUrl = normalizeApiUrl(currentConfig.apiUrl, currentConfig.provider);
  }

  try {
    await sqlite.execute({
      sql: `INSERT OR REPLACE INTO tg_ai_config 
            (id, enabled, provider, api_url, api_key, model, system_prompt, temperature, max_tokens, access_mode, history_limit, owner_chat_id, unauthorized_response) 
            VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [
        currentConfig.enabled ? 1 : 0,
        currentConfig.provider,
        currentConfig.apiUrl,
        currentConfig.apiKey,
        currentConfig.model,
        currentConfig.systemPrompt,
        currentConfig.temperature,
        currentConfig.maxTokens,
        currentConfig.accessMode,
        currentConfig.historyLimit,
        currentConfig.ownerChatId || '8160231965',
        currentConfig.unauthorizedResponse || 'silent',
      ],
    });
    log('info', `ИИ-Бот: Настройки сохранены в БД. Модель: ${currentConfig.model}, Провайдер: ${currentConfig.provider}, Владелец: ${currentConfig.ownerChatId}, Режим: ${currentConfig.accessMode}`);
  } catch (err: any) {
    log('error', `Ошибка сохранения настроек ИИ-Бота в БД: ${err.message}`, err);
    throw err;
  }

  return currentConfig;
}

export const GEMINI_RESERVE_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-flash-latest',
];

/**
 * Executes a Gemini prompt through an ordered resilience pool.
 * If a model returns 503 (high demand spikes) or 429 (quota/rate-limit),
 * it seamlessly switches to the next available model.
 */
async function generateWithGeminiFallbackPool(
  ai: GoogleGenAI,
  contents: any[],
  config: TelegramAiConfig,
  preferredModel?: string,
  startTime?: number
): Promise<{ text: string; durationMs: number; model: string; provider: string }> {
  const start = startTime || Date.now();
  const candidates: string[] = [];

  if (preferredModel) {
    let cleanPreferred = preferredModel.trim();
    if (
      cleanPreferred === 'gemini-1.5-flash' ||
      cleanPreferred === 'gemini-2.5-flash' ||
      cleanPreferred === 'gemini-1.5-pro' ||
      cleanPreferred === 'gemini-2.0-flash'
    ) {
      cleanPreferred = 'gemini-3.1-flash-lite';
    }
    candidates.push(cleanPreferred);
  }

  for (const m of GEMINI_RESERVE_MODELS) {
    if (!candidates.includes(m)) {
      candidates.push(m);
    }
  }

  let lastError: any = null;
  for (const mName of candidates) {
    try {
      const res = await ai.models.generateContent({
        model: mName,
        contents,
        config: {
          systemInstruction: config.systemPrompt || undefined,
          temperature: config.temperature,
          maxOutputTokens: config.maxTokens || 1500,
        },
      });

      if (res.text && res.text.trim()) {
        return {
          text: res.text.trim(),
          durationMs: Date.now() - start,
          model: mName,
          provider: 'Google Gemini',
        };
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || String(err);
      if (loggerFn) {
        loggerFn('warn', 'telegram', `Gemini модель «${mName}» вернула ошибку (${errMsg.substring(0, 100)}). Переключение на резервную модель...`);
      }
    }
  }

  throw lastError || new Error('Все доступные модели Google Gemini временно перегружены');
}

/**
 * Execute AI generation via specified provider or currentConfig
 */
export async function executeAiCompletion(
  messages: { role: string; content: string }[],
  overrideConfig?: Partial<TelegramAiConfig>
): Promise<{ text: string; durationMs: number; model: string; provider: string }> {
  const config = { ...currentConfig, ...(overrideConfig || {}) };
  const startTime = Date.now();

  const provider = config.provider || 'custom';
  const model = config.model || PROVIDER_DEFAULTS[provider]?.model || 'gpt-4o-mini';

  // 1. GOOGLE GEMINI
  if (provider === 'gemini') {
    let key = config.apiKey?.trim();
    // If the key is empty or is clearly a non-Gemini key (starts with sk-), fall back to process.env.GEMINI_API_KEY
    if (!key || key.startsWith('sk-')) {
      if (process.env.GEMINI_API_KEY) {
        key = process.env.GEMINI_API_KEY;
      }
    }
    if (!key && process.env.GEMINI_API_KEY) {
      key = process.env.GEMINI_API_KEY;
    }
    if (!key) {
      throw new Error('API ключ Gemini не указан (введите ключ в настройках ИИ-бота или установите GEMINI_API_KEY)');
    }

    const ai = new GoogleGenAI({ apiKey: key });

    // Format messages for Gemini API
    const contents: any[] = [];
    for (const msg of messages) {
      if (msg.role === 'system') continue;
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      });
    }

    // Ensure at least one message exists
    if (contents.length === 0) {
      contents.push({ role: 'user', parts: [{ text: 'Привет!' }] });
    }

    return await generateWithGeminiFallbackPool(
      ai,
      contents,
      config,
      model || 'gemini-3.1-flash-lite',
      startTime
    );
  }

  // 2. ANTHROPIC CLAUDE
  if (provider === 'anthropic') {
    const key = config.apiKey?.trim();
    if (!key) {
      throw new Error('API ключ Anthropic Claude не указан');
    }
    const endpoint = config.apiUrl?.trim() || 'https://api.anthropic.com/v1/messages';

    const anthropicMessages = messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.content,
      }));

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: model || 'claude-3-5-sonnet-20241022',
        max_tokens: config.maxTokens || 1500,
        temperature: config.temperature ?? 0.7,
        system: config.systemPrompt || undefined,
        messages: anthropicMessages,
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`Anthropic API (${response.status}): ${errBody.substring(0, 300)}`);
    }

    const data = await response.json();
    const durationMs = Date.now() - startTime;
    const text = data.content?.[0]?.text || 'Пустой ответ от Claude';
    return { text, durationMs, model, provider: 'Anthropic Claude' };
  }

  // 3. OPENAI-COMPATIBLE / CUSTOM / DEEPSEEK / GROQ / OLLAMA
  const endpoint = normalizeApiUrl(config.apiUrl || '', provider);

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  const key = config.apiKey?.trim();
  if (key) {
    headers['Authorization'] = `Bearer ${key}`;
  }

  const payloadMessages: any[] = [];
  if (config.systemPrompt && config.systemPrompt.trim()) {
    payloadMessages.push({ role: 'system', content: config.systemPrompt.trim() });
  }

  for (const m of messages) {
    if (m.role === 'system') continue;
    payloadMessages.push({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: m.content,
    });
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 45000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers,
      signal: controller.signal,
      body: JSON.stringify({
        model,
        messages: payloadMessages,
        temperature: config.temperature ?? 0.7,
        max_tokens: config.maxTokens ?? 1500,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      let parsedMessage = '';
      try {
        const errJson = JSON.parse(errText);
        parsedMessage = errJson.error?.message || errJson.message || (typeof errJson.error === 'string' ? errJson.error : '');
      } catch {}

      if (res.status === 404) {
        if (parsedMessage.includes("Model '") || parsedMessage.includes('model_not_found') || parsedMessage.includes('not found')) {
          throw new Error(
            `Модель «${model}» не найдена на сервере API (${endpoint}). Доступные бесплатные модели провайдера: free/gemini-3.8-flash, free/deepseek-v4.1-flash, free/gpt-5.6-luna. Детали: ${parsedMessage || errText.substring(0, 150)}`
          );
        }
        throw new Error(
          `Эндпоинт не найден (HTTP 404): ${endpoint}. Проверьте правильность URL API в панели. Детали: ${parsedMessage || errText.substring(0, 150)}`
        );
      }

      if (res.status === 402) {
        throw new Error(
          `Недостаточно баланса (HTTP 402) для платной модели «${model}». Выберите бесплатную модель: free/gemini-3.8-flash, free/deepseek-v4.1-flash, free/gpt-5.6-luna или пополните баланс на ${endpoint}.`
        );
      }

      throw new Error(`AI API HTTP ${res.status}: ${parsedMessage || errText.substring(0, 350)}`);
    }

    const data = await res.json();
    const durationMs = Date.now() - startTime;

    let text =
      data.choices?.[0]?.message?.content ||
      data.choices?.[0]?.text ||
      data.response ||
      (typeof data === 'string' ? data : '');

    if (!text && data.message) {
      text = typeof data.message === 'string' ? data.message : JSON.stringify(data.message);
    }

    // Clean any <think> reasoning tags if present
    if (typeof text === 'string' && text.includes('<think>')) {
      text = text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    }

    if (!text) {
      text = 'Получен пустой ответ от API модели.';
    }

    return {
      text,
      durationMs,
      model,
      provider: PROVIDER_DEFAULTS[provider]?.name || 'Custom API',
    };
  } catch (primaryErr: any) {
    const errMsg = primaryErr?.message || String(primaryErr);
    const isQuotaOrBalanceError =
      errMsg.includes('402') ||
      errMsg.includes('429') ||
      errMsg.includes('Rate limit') ||
      errMsg.includes('баланс') ||
      errMsg.includes('quota') ||
      errMsg.includes('Daily check-in') ||
      errMsg.includes('check-in required') ||
      errMsg.includes('Insufficient Balance');

    // If autoFallback is active:
    if (config.autoFallback !== false) {
      // If it's a custom provider and NOT a global account balance/rate-limit error, try alternate models
      if (!isQuotaOrBalanceError && provider === 'custom') {
        const fallbackCandidates = [
          'free/gemini-3.8-flash',
          'free/deepseek-v4.1-flash',
          'free/gpt-5.6-luna',
          'free/qwen-3.8-max',
          'free/glm-5.3-flash',
          'free/deepseek-v4-flash-0731',
        ].filter((f) => f !== model);

        for (const fModel of fallbackCandidates) {
          try {
            if (loggerFn) {
              loggerFn('warn', 'telegram', `AI: Модель «${model}» недоступна (${primaryErr.message}). Автоматический переход на «${fModel}»...`);
            }
            const fController = new AbortController();
            const fTimeout = setTimeout(() => fController.abort(), 12000);
            const fRes = await fetch(endpoint, {
              method: 'POST',
              headers,
              signal: fController.signal,
              body: JSON.stringify({
                model: fModel,
                messages: payloadMessages,
                temperature: config.temperature ?? 0.7,
                max_tokens: config.maxTokens ?? 1500,
              }),
            });
            clearTimeout(fTimeout);

            if (fRes.ok) {
              const fData = await fRes.json();
              let fText =
                fData.choices?.[0]?.message?.content ||
                fData.choices?.[0]?.text ||
                fData.response ||
                '';
              if (typeof fText === 'string' && fText.includes('<think>')) {
                fText = fText.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
              }
              if (fText) {
                return {
                  text: fText,
                  durationMs: Date.now() - startTime,
                  model: `${fModel} (auto-fallback)`,
                  provider: `${PROVIDER_DEFAULTS[provider]?.name || 'Custom API'} [Резерв]`,
                };
              }
            }
          } catch {
            // Continue to next fallback candidate
          }
        }
      }

      // If custom models failed or provider hit 402/429 balance or rate-limit, engage server-side Google Gemini!
      const geminiKey = process.env.GEMINI_API_KEY || (config.provider === 'gemini' ? config.apiKey : '');
      if (geminiKey) {
        try {
          if (loggerFn) {
            loggerFn(
              'warn',
              'telegram',
              `AI: Основной провайдер недоступен (${isQuotaOrBalanceError ? 'лимит/баланс исчерпан' : 'сбой моделей'}). Запуск отказоустойчивого шлюза Google Gemini...`
            );
          }
          const ai = new GoogleGenAI({ apiKey: geminiKey });
          const contents: any[] = [];
          for (const msg of messages) {
            if (msg.role === 'system') continue;
            contents.push({
              role: msg.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: msg.content }],
            });
          }
          if (contents.length === 0) {
            contents.push({ role: 'user', parts: [{ text: 'Привет!' }] });
          }

          const gemResult = await generateWithGeminiFallbackPool(
            ai,
            contents,
            config,
            'gemini-3.1-flash-lite',
            startTime
          );

          return {
            text: gemResult.text,
            durationMs: gemResult.durationMs,
            model: `${gemResult.model} (Emergency Fallback)`,
            provider: 'Google Gemini [Аварийный Шлюз 24/7]',
          };
        } catch (gemErr: any) {
          if (loggerFn) {
            loggerFn('error', 'telegram', `Сбой аварийного шлюза Gemini: ${gemErr?.message || gemErr}`);
          }
        }
      }
    }
    throw primaryErr;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Split text into chunks <= 4000 characters for Telegram
 */
export function splitTelegramMessage(text: string, maxChunk = 4000): string[] {
  if (text.length <= maxChunk) return [text];

  const chunks: string[] = [];
  let remaining = text;

  while (remaining.length > 0) {
    if (remaining.length <= maxChunk) {
      chunks.push(remaining);
      break;
    }

    // Try finding paragraph break
    let splitIdx = remaining.lastIndexOf('\n\n', maxChunk);
    if (splitIdx < 1000) {
      // Try newline
      splitIdx = remaining.lastIndexOf('\n', maxChunk);
    }
    if (splitIdx < 500) {
      // Try space
      splitIdx = remaining.lastIndexOf(' ', maxChunk);
    }
    if (splitIdx <= 0) {
      splitIdx = maxChunk;
    }

    chunks.push(remaining.substring(0, splitIdx).trim());
    remaining = remaining.substring(splitIdx).trim();
  }

  return chunks;
}

/**
 * Send message to Telegram chat with chunking
 */
export async function sendTelegramChunked(token: string, chatId: string, text: string) {
  if (!safeTgFetchFn) return;
  const chunks = splitTelegramMessage(text);

  for (const chunk of chunks) {
    const formData = new URLSearchParams();
    formData.append('chat_id', chatId);
    formData.append('text', chunk);

    await safeTgFetchFn(
      `https://api.telegram.org/bot${token}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString(),
      },
      12000
    ).catch((err: any) => {
      console.error('Failed to send TG chunk:', err);
    });
  }
}

/**
 * Send typing status to Telegram
 */
export async function sendTelegramTyping(token: string, chatId: string) {
  if (!safeTgFetchFn) return;
  try {
    const formData = new URLSearchParams();
    formData.append('chat_id', chatId);
    formData.append('action', 'typing');
    await safeTgFetchFn(
      `https://api.telegram.org/bot${token}/sendChatAction`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString(),
      },
      5000
    );
  } catch (e) {}
}

/**
 * Handle incoming Telegram update for both Polling and Webhook
 */
export async function handleIncomingTelegramUpdate(token: string, update: any) {
  if (!update || !update.message) return;
  const msg = update.message;
  const chatId = msg.chat?.id ? msg.chat.id.toString() : '';
  if (!chatId) return;

  const rawText = msg.text || msg.caption || '';
  const fromUser = msg.from?.username
    ? `@${msg.from.username}`
    : `${msg.from?.first_name || ''} ${msg.from?.last_name || ''}`.trim() || chatId;

  const tgConfig = getTgConfigFn ? getTgConfigFn() : { tokens: [], contacts: [] };
  const contact = tgConfig.contacts.find((c) => c.id === chatId);
  const ownerIdNormalized = (currentConfig.ownerChatId || '8160231965').trim();
  const isOwner = chatId === ownerIdNormalized || chatId === '8160231965';
  const isContact = Boolean(contact);
  const userTag = isOwner ? `👑 [VIP ВЛАДЕЛЕЦ] ${fromUser}` : `[${fromUser}]`;

  // === OWNER VIP COMMANDS ===
  if (isOwner && (rawText === '/admin' || rawText === '/panel')) {
    const adminPanelText =
      `👑 *ПАНЕЛЬ ВЛАДЕЛЬЦА (VIP ПРИОРИТЕТ)*\n\n` +
      `• *Ваш Telegram ID:* \`${chatId}\` (Абсолютный приоритет)\n` +
      `• *Состояние ИИ:* ${currentConfig.enabled ? '🟢 Активен' : '🔴 Отключен'}\n` +
      `• *Провайдер:* ${PROVIDER_DEFAULTS[currentConfig.provider]?.name || currentConfig.provider}\n` +
      `• *Активная модель:* \`${currentConfig.model}\`\n` +
      `• *Режим доступа:* ${
        currentConfig.accessMode === 'owner_only'
          ? '🔒 Только Я (Строго Приватный, другие заблокированы)'
          : currentConfig.accessMode === 'contacts_only'
          ? '👥 Владелец + Доверенные контакты'
          : '🌐 Все пользователи (с VIP-приоритетом для вас)'
      }\n` +
      `• *Реакция на других:* ${currentConfig.unauthorizedResponse === 'silent' ? '🤫 Игнорировать молча' : '⚠️ Отвечать об отказе'}\n` +
      `• *Глубина памяти:* ${currentConfig.historyLimit} (для вас VIP x2: ${currentConfig.historyLimit * 2})\n\n` +
      `⚡ *Команды быстрого управления:* \n` +
      `• \`/setmodel <имя>\` — сменить модель (напр. \`/setmodel gemini-3.1-flash-lite\` или \`/setmodel deepseek-chat\`)\n` +
      `• \`/mode owner_only\` — запереть бота только для себя\n` +
      `• \`/mode contacts_only\` — доступ для вас и контактов лейбла\n` +
      `• \`/mode all\` — открыть для всех с вашим приоритетом\n` +
      `• \`/wipe_others\` — удалить переписки всех посторонних пользователей\n` +
      `• \`/clear\` — очистить свой диалог`;

    await sendTelegramChunked(token, chatId, adminPanelText);
    log('info', `TG: Владелец запросил панель управления (/admin)`);
    return;
  }

  // Owner command: /setmodel
  if (isOwner && rawText.startsWith('/setmodel')) {
    const parts = rawText.split(/\s+/);
    if (parts.length < 2 || !parts[1].trim()) {
      await sendTelegramChunked(token, chatId, '⚠️ Укажите модель: `/setmodel gemini-3.1-flash-lite` или `/setmodel deepseek-chat`');
      return;
    }
    const newModel = parts[1].trim();
    await saveTelegramAiConfig({ model: newModel });
    await sendTelegramChunked(token, chatId, `✅ *Модель успешно изменена на:* \`${newModel}\``);
    log('info', `TG: Владелец сменил модель ИИ на "${newModel}" через Telegram-команду`);
    return;
  }

  // Owner command: /mode
  if (isOwner && rawText.startsWith('/mode')) {
    const parts = rawText.split(/\s+/);
    const targetMode = parts[1]?.trim().toLowerCase();
    if (targetMode === 'owner_only' || targetMode === 'contacts_only' || targetMode === 'all') {
      await saveTelegramAiConfig({ accessMode: targetMode as any });
      const modeLabels: Record<string, string> = {
        owner_only: '🔒 Только Я (Строго приватный)',
        contacts_only: '👥 Владелец + Доверенные контакты',
        all: '🌐 Все пользователи (с VIP-приоритетом для владельца)',
      };
      await sendTelegramChunked(token, chatId, `✅ *Режим доступа обновлен:* ${modeLabels[targetMode]}`);
      log('info', `TG: Владелец переключил режим доступа на "${targetMode}"`);
      return;
    } else {
      await sendTelegramChunked(token, chatId, '⚠️ Допустимые режимы: `/mode owner_only`, `/mode contacts_only`, `/mode all`');
      return;
    }
  }

  // Owner command: /wipe_others
  if (isOwner && rawText === '/wipe_others') {
    try {
      await sqlite.execute({
        sql: 'DELETE FROM tg_ai_chat_history WHERE chat_id != ? AND chat_id != ?',
        args: [chatId, '8160231965'],
      });
      // Also clear in-memory caches of other users
      for (const [key] of chatMemory.entries()) {
        if (key !== chatId && key !== '8160231965') {
          chatMemory.delete(key);
        }
      }
      await sendTelegramChunked(token, chatId, '🧹 *История всех сторонних пользователей полностью удалена.* Ваш контекст сохранен.');
      log('info', `TG: Владелец выполнил очистку диалогов всех сторонних пользователей`);
    } catch (err: any) {
      await sendTelegramChunked(token, chatId, `Ошибка при очистке: ${err.message}`);
    }
    return;
  }

  // Command: /start
  if (rawText === '/start') {
    if (!isOwner) {
      if (currentConfig.accessMode === 'owner_only') {
        log('warn', `TG /start: Отказано стороннему пользователю ${fromUser} (ID: ${chatId}) — режим Только Владелец`);
        if (currentConfig.unauthorizedResponse === 'reject_message') {
          await sendTelegramChunked(token, chatId, '🔒 Этот бот является персональным ассистентом владельца и работает в закрытом режиме.');
        }
        return;
      }
      if (currentConfig.accessMode === 'contacts_only' && !isContact) {
        log('warn', `TG /start: Отказано в доступе контакту вне списка: ${fromUser} (ID: ${chatId})`);
        if (currentConfig.unauthorizedResponse === 'reject_message') {
          await sendTelegramChunked(token, chatId, '🔒 Доступ к боту разрешен только контактам из списка лейбла.');
        }
        return;
      }
    }

    if (currentConfig.enabled) {
      if (isOwner) {
        const welcome =
          `👑 *Здравствуйте, Создатель!*\n\n` +
          `⚡ Ваш Telegram ID \`${chatId}\` наделен *наивысшим VIP-приоритетом*.\n` +
          `🤖 Активная модель: \`${currentConfig.model}\` (${PROVIDER_DEFAULTS[currentConfig.provider]?.name || currentConfig.provider})\n` +
          `🔒 Режим: ${currentConfig.accessMode === 'owner_only' ? 'Только для вас' : currentConfig.accessMode}\n\n` +
          `Все ваши запросы обрабатываются вне очереди с расширенным контекстом.\n\n` +
          `• \`/admin\` — панель управления и команды\n` +
          `• \`/clear\` — очистить контекст диалога\n` +
          `• Напишите любое сообщение для начала беседы.`;
        await sendTelegramChunked(token, chatId, welcome);
        log('info', `TG /start: Отправлено VIP-приветствие владельцу [${fromUser}] (ID: ${chatId})`);
      } else {
        const welcomeName = contact?.label || msg.from?.first_name || 'друг';
        const welcome =
          `👋 Здравствуйте, ${welcomeName}!\n\n` +
          `🤖 Я музыкальный ИИ-ассистент лейбла.\n` +
          `⚡ Модель: ${currentConfig.model || 'ИИ'}\n\n` +
          `Вы можете задать мне любой вопрос по музыке, дистрибуции или текстам.\n\n` +
          `• /clear — начать диалог заново\n` +
          `• /status — информация о модели\n` +
          `• /help — справка`;
        await sendTelegramChunked(token, chatId, welcome);
        log('info', `TG /start: Приветствие отправлено пользователю ${fromUser} (ID: ${chatId})`);
      }
    } else {
      const resp = isOwner 
        ? '⚠️ ИИ-бот сейчас отключен в веб-панели. Вы можете включить его или отправить /admin.' 
        : (contact ? `Приветствую, ${contact.label || ''}` : 'Отказано в доступе');
      await sendTelegramChunked(token, chatId, resp);
    }
    return;
  }

  // Command: /clear or /reset
  if (rawText === '/clear' || rawText === '/reset') {
    chatMemory.delete(chatId);
    sqlite
      .execute({
        sql: 'DELETE FROM tg_ai_chat_history WHERE chat_id = ?',
        args: [chatId],
      })
      .catch(() => {});

    await sendTelegramChunked(token, chatId, isOwner ? '🧹 Память вашего VIP-диалога очищена. Жду новых задач!' : '🧹 Память диалога очищена. Можем начать новую беседу!');
    log('info', `TG: Очищена память диалога для ${userTag} (ID: ${chatId})`);
    return;
  }

  // Command: /status or /model
  if (rawText === '/status' || rawText === '/model') {
    const statusText =
      `🤖 *Статус ИИ-Бота:*\n\n` +
      `• Состояние: ${currentConfig.enabled ? '🟢 Активен' : '🔴 Отключен'}\n` +
      `• Провайдер: ${PROVIDER_DEFAULTS[currentConfig.provider]?.name || currentConfig.provider}\n` +
      `• Модель: \`${currentConfig.model}\`\n` +
      `• Режим доступа: ${
        currentConfig.accessMode === 'owner_only' 
          ? '🔒 Приватный (Только Владелец)' 
          : currentConfig.accessMode === 'contacts_only' 
          ? '👥 Только контакты лейбла' 
          : '🌐 Открыт для всех'
      }\n` +
      (isOwner ? `• VIP-статус: 👑 Вы являетесь владельцем (ID: \`${chatId}\`)\n` : '') +
      `• Лимит контекста: ${currentConfig.historyLimit} реплик`;

    await sendTelegramChunked(token, chatId, statusText);
    return;
  }

  // Command: /help
  if (rawText === '/help') {
    const helpText = isOwner
      ? `👑 *Справка Владельца:*\n\n` +
        `• Отправьте любой вопрос или текст для получения ответа от ИИ.\n` +
        `• \`/admin\` — открыть панель управления и быструю смену настроек\n` +
        `• \`/setmodel <название>\` — сменить модель нейросети\n` +
        `• \`/mode <owner_only|contacts_only|all>\` — изменить доступ\n` +
        `• \`/wipe_others\` — стереть диалоги посторонних пользователей\n` +
        `• \`/clear\` — стереть свой контекст диалога.`
      : `ℹ️ *Справка по боту:*\n\n` +
        `Этот бот подключен к музыкальной панели управления и оснащен ИИ.\n\n` +
        `• Отправьте любое текстовое сообщение — ИИ сгенерирует развернутый ответ.\n` +
        `• /clear — стереть историю диалога.\n` +
        `• /status — посмотреть текущую нейросеть.`;

    await sendTelegramChunked(token, chatId, helpText);
    return;
  }

  // Regular text query for AI
  if (!rawText.trim()) return;

  // Check if AI Bot is enabled
  if (!currentConfig.enabled && !isOwner) {
    log('debug', `TG: Сообщение получено, но ИИ-бот отключен в настройках. От ${fromUser}: "${rawText.substring(0, 50)}"`);
    return;
  }

  // === STRICT ACCESS CONTROL FOR NON-OWNERS ===
  if (!isOwner) {
    // Mode 1: Owner only
    if (currentConfig.accessMode === 'owner_only') {
      log('warn', `TG ИИ-Бот: Отклонён посторонний запрос от ${fromUser} (ID: ${chatId}). Активен режим «Только Владелец».`);
      if (currentConfig.unauthorizedResponse === 'reject_message') {
        await sendTelegramChunked(token, chatId, '🔒 Этот бот является персональным ассистентом владельца и работает в закрытом режиме.');
      }
      return;
    }

    // Mode 2: Contacts only
    if (currentConfig.accessMode === 'contacts_only' && !isContact) {
      log('warn', `TG ИИ-Бот: Отклонён запрос от неавторизованного контакта ${fromUser} (ID: ${chatId})`);
      if (currentConfig.unauthorizedResponse === 'reject_message') {
        await sendTelegramChunked(token, chatId, '🔒 Доступ к ИИ-ассистенту разрешен только контактам из списка доверенных лиц.');
      }
      return;
    }
  }

  // 1. Send typing action
  await sendTelegramTyping(token, chatId);

  log('info', `TG ИИ-Бот: Запрос от ${userTag} (ID: ${chatId}): "${rawText.substring(0, 80)}"`);

  // 2. Retrieve history for this chatId (Owner gets x2 context memory depth)
  const maxHistorySteps = isOwner ? currentConfig.historyLimit * 4 : currentConfig.historyLimit * 2;
  let history = chatMemory.get(chatId) || [];
  if (history.length === 0) {
    try {
      const dbRes = await sqlite.execute({
        sql: 'SELECT role, content, timestamp FROM tg_ai_chat_history WHERE chat_id = ? ORDER BY id DESC LIMIT ?',
        args: [chatId, maxHistorySteps],
      });
      if (dbRes.rows && dbRes.rows.length > 0) {
        history = dbRes.rows
          .map((r) => ({
            role: r.role as any,
            content: r.content as string,
            timestamp: Number(r.timestamp),
          }))
          .reverse();
        chatMemory.set(chatId, history);
      }
    } catch (e) {}
  }

  // Prepare messages payload
  const promptMessages: { role: string; content: string }[] = [];
  const recentHistory = history.slice(-maxHistorySteps);
  for (const h of recentHistory) {
    promptMessages.push({ role: h.role, content: h.content });
  }
  promptMessages.push({ role: 'user', content: rawText });

  // 3. Call AI Engine (with VIP max tokens for owner)
  try {
    const executionConfig = isOwner
      ? { ...currentConfig, maxTokens: Math.max(currentConfig.maxTokens, 2500) }
      : currentConfig;

    const result = await executeAiCompletion(promptMessages, executionConfig);

    // 4. Send AI response back to Telegram
    await sendTelegramChunked(token, chatId, result.text);

    // 5. Update history in memory & sqlite
    const now = Date.now();
    const userMsg: ChatMessage = { role: 'user', content: rawText, timestamp: now };
    const aiMsg: ChatMessage = { role: 'assistant', content: result.text, timestamp: now + 1 };

    history.push(userMsg, aiMsg);
    if (history.length > maxHistorySteps * 2) {
      history = history.slice(-maxHistorySteps * 2);
    }
    chatMemory.set(chatId, history);

    sqlite
      .execute({
        sql: 'INSERT INTO tg_ai_chat_history (chat_id, role, content, timestamp) VALUES (?, ?, ?, ?), (?, ?, ?, ?)',
        args: [chatId, 'user', rawText, now, chatId, 'assistant', result.text, now + 1],
      })
      .catch(() => {});

    log('info', `TG ИИ-Бот: Ответ доставлен ${userTag} (${result.durationMs} мс, ${result.model})`, {
      chatId,
      isOwner,
      model: result.model,
      durationMs: result.durationMs,
      replyPreview: result.text.substring(0, 100),
    });
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    log('error', `TG ИИ-Бот: Ошибка генерации для ${userTag}: ${errMsg}`, {
      chatId,
      isOwner,
      fromUser,
      provider: currentConfig.provider,
      model: currentConfig.model,
      error: errMsg,
    });

    if (isOwner) {
      await sendTelegramChunked(
        token,
        chatId,
        `⚠️ Не удалось получить ответ от ИИ:\n${errMsg}\n\nКак владелец, вы можете изменить модель командой /setmodel или настроить API в веб-панели управления.`
      );
    } else {
      await sendTelegramChunked(
        token,
        chatId,
        `⏳ ИИ-ассистент сейчас обрабатывает большой поток запросов или провайдер временно недоступен. Пожалуйста, повторите ваш вопрос через 30-60 секунд.`
      );
    }
  }
}

/**
 * Get active chat dialogue statistics
 */
export async function getAiChatStats() {
  try {
    const res = await sqlite.execute(`
      SELECT 
        COUNT(DISTINCT chat_id) as active_chats,
        COUNT(*) as total_messages
      FROM tg_ai_chat_history
    `);
    const activeChats = Number(res.rows?.[0]?.active_chats || chatMemory.size || 0);
    const totalMessages = Number(res.rows?.[0]?.total_messages || 0);

    const recentRes = await sqlite.execute(`
      SELECT chat_id, role, content, timestamp
      FROM tg_ai_chat_history
      ORDER BY id DESC
      LIMIT 20
    `);

    return {
      activeChats,
      totalMessages,
      recentMessages: recentRes.rows || [],
    };
  } catch (e) {
    return {
      activeChats: chatMemory.size,
      totalMessages: 0,
      recentMessages: [],
    };
  }
}

/**
 * Clear all chat history
 */
export async function clearAllAiChatHistory() {
  chatMemory.clear();
  await sqlite.execute('DELETE FROM tg_ai_chat_history');
}

/**
 * Wipe only other users' chat history, leaving the owner's dialogue intact
 */
export async function wipeOtherUsersChatHistory(keepOwnerId: string = '8160231965') {
  const normOwner = keepOwnerId.trim();
  await sqlite.execute({
    sql: 'DELETE FROM tg_ai_chat_history WHERE chat_id != ? AND chat_id != ?',
    args: [normOwner, '8160231965'],
  });
  for (const [key] of chatMemory.entries()) {
    if (key !== normOwner && key !== '8160231965') {
      chatMemory.delete(key);
    }
  }
}
