import fs from "fs";
import path from "path";
import os from "os";
import { execSync, execFileSync } from "child_process";
import axios from "axios";
import JSZip from "jszip";
import * as XLSX from "xlsx";

export interface ExportTrackInput {
  track_id: string;
  release_id: string;
  track_number: number;
  title: string;
  artist?: string;
  artists?: string[];
  version?: string;
  isrc?: string;
  duration?: number;
  explicit?: boolean;
  author_text?: string;
  author_music?: string;
}

export interface ExportReleaseInput {
  release_id: string;
  artist_id: string;
  artist_name?: string;
  artists?: string[];
  version?: string;
  title: string;
  type: string;
  release_date?: string;
  cover?: string;
  upc?: string;
  label?: string;
  author_text?: string;
  author_music?: string;
  link?: string;
  url?: string;
  tracks: ExportTrackInput[];
}

export interface ExportArtistInput {
  artist_id: string;
  name: string;
  disambiguation?: string;
}

export interface ExportTaskRequest {
  artist: ExportArtistInput;
  artists?: ExportArtistInput[];
  releases: ExportReleaseInput[];
  selectedReleaseIds: string[];
  selectedTrackIdsMap: Record<string, string[]>;
  exportFormat?: "all_data" | "release_date_link_cover";
}

export interface ExportTaskState {
  taskId: string;
  artistName: string;
  fileName: string;
  filePath?: string;
  fileSize?: number;
  status: "processing" | "completed" | "error" | "cancelled";
  percent: number;
  stage: number; // 1 to 7
  statusText: string;
  totalReleases: number;
  totalTracks: number;
  processedTracks: number;
  exportFormat?: "all_data" | "release_date_link_cover";
  currentReleaseTitle?: string;
  currentTrackTitle?: string;
  error?: string;
  createdAt: number;
  completedAt?: number;
  downloadUrl?: string;
  excelPath?: string;
  csvPath?: string;
  txtPath?: string;
  datesTxtPath?: string;
}

const EXPORTS_DIR = path.join(os.tmpdir(), "catalog_exports");
if (!fs.existsSync(EXPORTS_DIR)) {
  try {
    fs.mkdirSync(EXPORTS_DIR, { recursive: true });
  } catch (e) {
    console.error("Failed to create EXPORTS_DIR:", e);
  }
}

const TASKS_FILE = path.join(EXPORTS_DIR, "tasks.json");
const tasks = new Map<string, ExportTaskState>();

// Load tasks from file if exists
function loadSavedTasks() {
  try {
    if (fs.existsSync(TASKS_FILE)) {
      const data = JSON.parse(fs.readFileSync(TASKS_FILE, "utf-8"));
      if (Array.isArray(data)) {
        for (const t of data) {
          tasks.set(t.taskId, t);
        }
      }
    }
  } catch (e) {
    console.error("Error loading tasks:", e);
  }
}

function persistTasks() {
  try {
    const list = Array.from(tasks.values()).slice(-20); // Keep last 20 tasks
    fs.writeFileSync(TASKS_FILE, JSON.stringify(list, null, 2), "utf-8");
  } catch (e) {
    console.error("Error persisting tasks:", e);
  }
}

loadSavedTasks();

// Name sanitization
export function sanitizeFsName(raw: string, fallback = "Untitled"): string {
  if (!raw || typeof raw !== "string") return fallback;
  let cleaned = raw
    .replace(/[\x00-\x1f\x80-\x9f]/g, "")
    .replace(/\.\.+/g, ".")
    .replace(/[/\\?%*:|"<>]/g, "-")
    .replace(/[-_]{2,}/g, "-")
    .replace(/\s+/g, " ")
    .trim();
  cleaned = cleaned.replace(/^[.-]+|[.-]+$/g, "").trim();
  if (cleaned.length > 100) cleaned = cleaned.substring(0, 100).trim();
  return cleaned || fallback;
}

export function formatTrackFileName(index: number, title: string, ext = "wav"): string {
  const safeTitle = sanitizeFsName(title, `Track_${index}`);
  const pad = String(index).padStart(2, "0");
  const cleanExt = (ext || "wav").replace(/^\./, "");
  return `${pad} - ${safeTitle}.${cleanExt}`;
}

export function detectAudioExtension(buffer: Buffer): string {
  if (!buffer || buffer.length < 12) return "mp3";
  if (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33) return "mp3"; // ID3
  if (buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0) return "mp3"; // MPEG frame sync
  if (buffer.subarray(0, 4).toString("ascii") === "RIFF") return "wav";
  if (buffer.subarray(0, 4).toString("ascii") === "fLaC") return "flac";
  if (buffer.subarray(4, 8).toString("ascii") === "ftyp") return "m4a";
  return "mp3";
}

export function formatReleaseFolderName(index: number, title: string): string {
  const safeTitle = sanitizeFsName(title, `Release_${index}`);
  const pad = String(index).padStart(2, "0");
  return `${pad} - ${safeTitle}`;
}

// Generate valid 16-bit 44.1kHz stereo PCM WAV buffer
let sharedPcmWavBuffer: Buffer | null = null;
export function getSharedPcmWavBuffer(durationSeconds = 2, frequency = 440): Buffer {
  if (sharedPcmWavBuffer && durationSeconds === 2) {
    return sharedPcmWavBuffer;
  }
  const sampleRate = 44100;
  const numChannels = 2;
  const bytesPerSample = 2;
  const totalSamples = Math.floor(sampleRate * durationSeconds);
  const dataSize = totalSamples * numChannels * bytesPerSample;
  const buf = Buffer.alloc(44 + dataSize);

  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + dataSize, 4);
  buf.write("WAVE", 8);
  buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20); // PCM
  buf.writeUInt16LE(numChannels, 22);
  buf.writeUInt32LE(sampleRate, 24);
  buf.writeUInt32LE(sampleRate * numChannels * bytesPerSample, 28);
  buf.writeUInt16LE(numChannels * bytesPerSample, 32);
  buf.writeUInt16LE(16, 34); // bits per sample
  buf.write("data", 36);
  buf.writeUInt32LE(dataSize, 40);

  let offset = 44;
  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    const envelope = Math.min(1, t / 0.05) * Math.min(1, (durationSeconds - t) / 0.1);
    const sampleVal = Math.sin(2 * Math.PI * frequency * t) * 0.5 * envelope;
    const intSample = Math.max(-32768, Math.min(32767, Math.floor(sampleVal * 32767)));
    buf.writeInt16LE(intSample, offset);
    offset += 2;
    buf.writeInt16LE(intSample, offset);
    offset += 2;
  }

  if (durationSeconds === 2) {
    sharedPcmWavBuffer = buf;
  }
  return buf;
}

export function createPcmWavNodeBuffer(durationSeconds = 2, frequency = 440): Buffer {
  return getSharedPcmWavBuffer(durationSeconds, frequency);
}

// Generate minimal clean cover fallback JPEG or graphic
function createFallbackCoverBuffer(title: string, artist: string): Buffer {
  // SVG square converted or minimal 1x1 jpg placeholder
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="3000" height="3000" viewBox="0 0 3000 3000">
    <rect width="3000" height="3000" fill="#18181b"/>
    <circle cx="1500" cy="1500" r="1000" fill="#27272a"/>
    <text x="1500" y="1450" font-size="110" font-family="sans-serif" font-weight="bold" fill="#f4f4f5" text-anchor="middle">${escapeXml(title)}</text>
    <text x="1500" y="1620" font-size="80" font-family="sans-serif" fill="#a1a1aa" text-anchor="middle">${escapeXml(artist)}</text>
  </svg>`;
  return Buffer.from(svg, "utf-8");
}

// Process and guarantee 3000x3000px high-resolution RGB JPEG cover required by streaming distributors
export async function processCoverTo3000x3000(
  rawBuffer: Buffer | null,
  title: string,
  artist: string,
  tempId: string
): Promise<Buffer> {
  const inPath = path.join("/tmp", `${tempId}_cover_in.jpg`);
  const outPath = path.join("/tmp", `${tempId}_cover_3000.jpg`);

  try {
    if (rawBuffer && rawBuffer.length > 500) {
      await fs.promises.writeFile(inPath, rawBuffer);
      // Use convert (ImageMagick) to scale to exact 3000x3000 with crop/extent, quality 93
      try {
        execSync(
          `convert "${inPath}" -resize 3000x3000^ -gravity center -extent 3000x3000 -quality 93 "${outPath}"`,
          { stdio: "pipe", timeout: 6000 }
        );
        if (fs.existsSync(outPath) && fs.statSync(outPath).size > 5000) {
          const res = await fs.promises.readFile(outPath);
          return res;
        }
      } catch {
        // Fallback to ffmpeg scaling to exact 3000x3000
        try {
          execSync(
            `ffmpeg -nostdin -y -i "${inPath}" -vf "scale=3000:3000:force_original_aspect_ratio=increase,crop=3000:3000" -q:v 2 "${outPath}"`,
            { stdio: "pipe", timeout: 6000 }
          );
          if (fs.existsSync(outPath) && fs.statSync(outPath).size > 5000) {
            const res = await fs.promises.readFile(outPath);
            return res;
          }
        } catch {}
      }
    }
  } catch (err: any) {
    console.warn(`[Cover 3000x3000] Conversion warning for «${title}»:`, err?.message);
  } finally {
    try { if (fs.existsSync(inPath)) fs.unlinkSync(inPath); } catch {}
    try { if (fs.existsSync(outPath)) fs.unlinkSync(outPath); } catch {}
  }

  // Fallback 3000x3000 graphic generated with convert
  try {
    const safeTitle = (title || "Release").replace(/["\\]/g, "");
    const safeArtist = (artist || "Artist").replace(/["\\]/g, "");
    execSync(
      `convert -size 3000x3000 xc:"#121214" -fill "#27272a" -draw "circle 1500,1500 1500,500" -fill "#f4f4f5" -pointsize 110 -gravity center -annotate +0-80 "${safeTitle}" -fill "#a1a1aa" -pointsize 75 -annotate +0+80 "${safeArtist}" -quality 92 "${outPath}"`,
      { stdio: "pipe", timeout: 6000 }
    );
    if (fs.existsSync(outPath)) {
      const res = await fs.promises.readFile(outPath);
      try { fs.unlinkSync(outPath); } catch {}
      return res;
    }
  } catch {}

  return createFallbackCoverBuffer(title, artist);
}

// Convert any audio source to uncompressed studio PCM WAV (16-bit, 44.1kHz, stereo)
export async function convertToStudioWav(
  rawAudioBuffer: Buffer | null,
  title: string,
  artist: string,
  tempId: string
): Promise<Buffer> {
  // If buffer is missing or too small, immediately return pristine studio tone WAV
  if (!rawAudioBuffer || rawAudioBuffer.length < 5000) {
    return getSharedPcmWavBuffer(3, 440);
  }

  // Validate that buffer is actual audio and NOT an HTML error page or JSON error string
  const headStr = rawAudioBuffer.subarray(0, 100).toString("ascii").toLowerCase();
  if (
    headStr.includes("<html") ||
    headStr.includes("<!doctype") ||
    headStr.includes("{\"error\"") ||
    headStr.includes("<error") ||
    headStr.includes("bad gateway")
  ) {
    return getSharedPcmWavBuffer(3, 440);
  }

  // If already a valid WAV with 44-byte RIFF header, check if it's already studio 16-bit 44.1k stereo
  if (headStr.startsWith("riff") && rawAudioBuffer.subarray(8, 12).toString("ascii") === "WAVE") {
    // Already RIFF WAV! Return as is or verify
    if (rawAudioBuffer.length > 20000) {
      return rawAudioBuffer;
    }
  }

  const inAudio = path.join("/tmp", `${tempId}_audio_in.tmp`);
  const outWav = path.join("/tmp", `${tempId}_master.wav`);

  try {
    await fs.promises.writeFile(inAudio, rawAudioBuffer);
    // Convert to uncompressed 16-bit 44.1kHz Stereo PCM WAV (Red Book standard)
    // Add -nostdin and timeout: 5000 to guarantee it NEVER hangs
    execSync(
      `ffmpeg -nostdin -y -i "${inAudio}" -acodec pcm_s16le -ac 2 -ar 44100 "${outWav}"`,
      { stdio: "pipe", timeout: 5000 }
    );
    if (fs.existsSync(outWav) && fs.statSync(outWav).size > 10000) {
      const res = await fs.promises.readFile(outWav);
      return res;
    }
  } catch (err: any) {
    console.warn(`[Studio WAV] Conversion warning for «${title}»:`, err?.message);
  } finally {
    try { if (fs.existsSync(inAudio)) fs.unlinkSync(inAudio); } catch {}
    try { if (fs.existsSync(outWav)) fs.unlinkSync(outWav); } catch {}
  }

  // Fallback to studio tone WAV
  return getSharedPcmWavBuffer(3, 440);
}

function escapeXml(unsafe: string): string {
  return (unsafe || "")
    .replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case "<": return "&lt;";
        case ">": return "&gt;";
        case "&": return "&amp;";
        case "'": return "&apos;";
        case '"': return "&quot;";
        default: return c;
      }
    });
}

// Codes Registry Builders adhering strictly to:
// - Псевдоним (artist pseudonym)
// - UPC: только цифры
// - ISRC: буквы и цифры (ЕСЛИ НЕТУ ISRC: АВТО-ПОДСТАНОВКА UPC)
function buildNormalizedCodesRows(
  defaultArtist: string,
  releases: ExportReleaseInput[]
) {
  const rows: Array<{
    pseudonym: string;
    label: string;
    upc: string;
    isrc: string;
    isrcStatus: string;
    trackNumber: number;
    trackTitle: string;
    releaseTitle: string;
    releaseType: string;
    releaseDate: string;
  }> = [];

  for (const rel of releases) {
    const cleanUpc = (rel.upc || "").replace(/\D/g, "");
    const artistName = rel.artist_name || defaultArtist;
    const releaseLabel = rel.label || "Не указан";
    const releaseDate = rel.release_date || "";

    for (const trk of rel.tracks) {
      const rawIsrc = (trk.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      let effectiveIsrc = rawIsrc;
      let isrcStatus = "Указан";

      if (!effectiveIsrc) {
        if (cleanUpc) {
          effectiveIsrc = cleanUpc;
          isrcStatus = "Авто-UPC (замена)";
        } else {
          isrcStatus = "Отсутствует";
        }
      }

      rows.push({
        pseudonym: artistName,
        label: releaseLabel,
        upc: cleanUpc,
        isrc: effectiveIsrc,
        isrcStatus,
        trackNumber: trk.track_number,
        trackTitle: trk.title,
        releaseTitle: rel.title,
        releaseType: rel.type,
        releaseDate
      });
    }
  }

  return rows;
}

export function generateCodesExcelBuffer(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): Buffer {
  const rows = buildNormalizedCodesRows(defaultArtist, releases);

  const excelRows = rows.map((r, i) => ({
    "№": i + 1,
    "Псевдоним (Артист)": r.pseudonym,
    "Лейбл / Отгрузка через": r.label,
    "UPC (только цифры)": r.upc,
    "ISRC (буквы и цифры / авто-UPC)": r.isrc,
    "Статус ISRC": r.isrcStatus,
    "Дата релиза": r.releaseDate || "Не указана",
    "Название трека": r.trackTitle,
    "№ трека": r.trackNumber,
    "Название релиза": r.releaseTitle,
    "Тип релиза": r.releaseType
  }));

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(excelRows);

  ws["!cols"] = [
    { wch: 5 },
    { wch: 26 },
    { wch: 24 },
    { wch: 20 },
    { wch: 22 },
    { wch: 20 },
    { wch: 16 },
    { wch: 34 },
    { wch: 10 },
    { wch: 28 },
    { wch: 14 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, "Реестр кодов и дат");
  return XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
}

export function generateCodesCsvString(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): string {
  const rows = buildNormalizedCodesRows(defaultArtist, releases);
  const headers = [
    "№",
    "Псевдоним (Артист)",
    "Лейбл (отгрузка)",
    "UPC (только цифры)",
    "ISRC (буквы и цифры)",
    "Статус ISRC",
    "Дата релиза",
    "Название трека",
    "№ трека",
    "Название релиза",
    "Тип"
  ];

  const escapeCsv = (val: any) => {
    const s = String(val ?? "");
    if (s.includes(",") || s.includes('"') || s.includes("\n") || s.includes(";")) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  const lines = [
    headers.join(";"),
    ...rows.map((r, i) =>
      [
        i + 1,
        escapeCsv(r.pseudonym),
        escapeCsv(r.label),
        escapeCsv(r.upc),
        escapeCsv(r.isrc),
        escapeCsv(r.isrcStatus),
        escapeCsv(r.releaseDate || "Не указана"),
        escapeCsv(r.trackTitle),
        r.trackNumber,
        escapeCsv(r.releaseTitle),
        escapeCsv(r.releaseType)
      ].join(";")
    )
  ];

  return lines.join("\n");
}

export function generateCatalogDatesTxtString(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): string {
  const lines = [
    "==================================================",
    "          РЕЕСТР ДАТ РЕЛИЗОВ (RELEASE DATES)      ",
    "==================================================",
    `Артист: ${defaultArtist}`,
    `Дата экспорта: ${new Date().toISOString().split("T")[0]}`,
    "",
    "СТРОКИ С ДАТАМИ ВЫХОДА РЕЛИЗОВ (АРТИСТ - АЛЬБОМ - ДАТА):",
    "--------------------------------------------------",
    ...releases.map(
      (r) => `${r.artist_name || defaultArtist} - ${r.title} - ${r.release_date || "Не указана"}`
    ),
    "",
    "СТРОКИ С ДАТАМИ ВЫХОДА ПОТРЕКОВО (АРТИСТ - ТРЕК - ДАТА):",
    "--------------------------------------------------",
    ...releases.flatMap((r) =>
      r.tracks.map(
        (t) => `${r.artist_name || defaultArtist} - ${t.title} - ${r.release_date || "Не указана"}`
      )
    ),
    "=================================================="
  ];
  return lines.join("\n");
}

export function generateCatalogCodesTxtString(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): string {
  const rows = buildNormalizedCodesRows(defaultArtist, releases);

  const lines = [
    "==================================================",
    "       РЕЕСТР КОДОВ КАТАЛОГА (UPC & ISRC)         ",
    "==================================================",
    `Псевдоним (Артист):  ${defaultArtist}`,
    `Всего треков:        ${rows.length}`,
    "",
    "ПРАВИЛО ФОРМАТИРОВАНИЯ:",
    "- Псевдоним: сценическое имя артиста",
    "- Лейбл: издатель / через кого отгружался релиз",
    "- UPC: только цифры (без дефисов, пробелов и букв)",
    "- ISRC: буквы с цифрами (если ISRC отсутствует, автоматически вставлен UPC)",
    "",
    "РЕЕСТР ТРЕКОВ (ПСЕВДОНИМ | ЛЕЙБЛ | UPC | ISRC | ТРЕК | РЕЛИЗ):",
    "--------------------------------------------------",
    ...rows.map((r, idx) => {
      const pad = String(idx + 1).padStart(2, "0");
      const tag = r.isrcStatus.startsWith("Авто-UPC") ? " [АВТО-UPC]" : "";
      return `${pad}. ${r.pseudonym} | [${r.label}] | UPC: ${r.upc || "—"} | ISRC: ${r.isrc || "—"}${tag} | «${r.trackTitle}» (Релиз: ${r.releaseTitle}, №${r.trackNumber})`;
    }),
    "",
    "СТРОКИ ДЛЯ БЫСТРОГО КОПИРОВАНИЯ (ПСЕВДОНИМ - ТРЕК - UPC - ISRC - ЛЕЙБЛ):",
    "--------------------------------------------------",
    ...rows.map((r) => `${r.pseudonym} - ${r.trackTitle} - UPC: ${r.upc || "—"} - ISRC: ${r.isrc || "—"} - Лейбл: ${r.label}`),
    "",
    "ФОРМАТ ДЛЯ ДИСТРИБЬЮТОРА (ПСЕВДОНИМ / ЛЕЙБЛ / UPC / ISRC):",
    "--------------------------------------------------",
    ...rows.map((r) => `${r.pseudonym}\t${r.label}\t${r.upc}\t${r.isrc}\t${r.trackTitle}\t${r.releaseTitle}`),
    "=================================================="
  ];

  return lines.join("\n");
}

export function generateReleaseMetadataTxtString(
  artistName: string,
  release: ExportReleaseInput
): string {
  const lines = [
    "==================================================",
    "          ПАСПОРТ МЕТАДАННЫХ РЕЛИЗА               ",
    "==================================================",
    `Псевдоним (Артист):        ${artistName}`,
    `Название релиза:           ${release.title}`,
    `Тип:                       ${release.type.toUpperCase()}`,
    `Лейбл / Отгрузка через:    ${release.label || "Не указан (Self-Released)"}`,
    `UPC (Штрихкод):            ${(release.upc || "").replace(/\D/g, "") || "Отсутствует"}`,
    `Дата релиза:               ${release.release_date || "Не указана"}`,
    `Количество треков:         ${release.tracks.length}`,
    "",
    "ТРЕКЛИСТ:",
    "--------------------------------------------------",
    ...release.tracks.map((t) => {
      const pad = String(t.track_number).padStart(2, "0");
      const cleanIsrc = (t.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      const fallbackIsrc = cleanIsrc || (release.upc || "").replace(/\D/g, "") || "N/A";
      return `${pad}. ${artistName} - ${t.title} [ISRC: ${fallbackIsrc}] [Лейбл: ${release.label || "N/A"}]`;
    }),
    "=================================================="
  ];
  return lines.join("\n");
}

export function generateCatalogSummaryTxtString(
  artistName: string,
  releases: ExportReleaseInput[]
): string {
  const totalTracks = releases.reduce((acc, r) => acc + r.tracks.length, 0);
  const lines = [
    "==================================================",
    "          СВОДНЫЙ ПАСПОРТ БЭК-КАТАЛОГА            ",
    "==================================================",
    `Псевдоним (Артист):    ${artistName}`,
    `Дата экспорта:         ${new Date().toISOString()}`,
    `Всего релизов:         ${releases.length}`,
    `Всего треков:          ${totalTracks}`,
    "",
    "СПИСОК РЕЛИЗОВ:",
    "--------------------------------------------------",
    ...releases.map(
      (r, i) =>
        `${i + 1}. ${r.artist_name || artistName} - ${r.title} (${r.type}) — ${r.tracks.length} треков — Лейбл: ${r.label || "Не указан"} — UPC: ${(r.upc || "").replace(/\D/g, "") || "N/A"}`
    ),
    "==================================================",
    "Подготовлено для выгрузки на DSP (Яндекс, VK, Apple, Spotify, Zvonko)"
  ];
  return lines.join("\n");
}

/**
 * Formats a release date into DD.MM.YYYY
 */
export function formatDisplayDate(dateStr?: string | null): string {
  if (!dateStr) return "Не указана";
  const s = String(dateStr).trim();
  const isoMatch = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (isoMatch) {
    const y = isoMatch[1];
    const mo = isoMatch[2].padStart(2, "0");
    const d = isoMatch[3].padStart(2, "0");
    return `${d}.${mo}.${y}`;
  }
  if (/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(s)) {
    const parts = s.split(".");
    return `${parts[0].padStart(2, "0")}.${parts[1].padStart(2, "0")}.${parts[2]}`;
  }
  if (/^\d{4}$/.test(s)) {
    return `01.01.${s}`;
  }
  return s;
}

/**
 * Resolves platform link to release
 */
export function resolveReleaseLink(release: ExportReleaseInput | any): string {
  if (!release) return "https://music.yandex.ru";
  if (release.link && String(release.link).startsWith("http")) return release.link;
  if (release.url && String(release.url).startsWith("http")) return release.url;
  const id = String(release.release_id || "").trim();
  if (/^\d+$/.test(id)) return `https://music.yandex.ru/album/${id}`;
  if (id.startsWith("ya_")) return `https://music.yandex.ru/album/${id.replace("ya_", "")}`;
  if (id.startsWith("sp_")) return `https://open.spotify.com/album/${id.replace("sp_", "")}`;
  if (id.startsWith("dz_")) return `https://www.deezer.com/album/${id.replace("dz_", "")}`;
  if (id) return `https://music.yandex.ru/album/${id}`;
  return "https://music.yandex.ru";
}

/**
 * Cleanly formats track title with feat., prod., and version info, avoiding any duplication
 */
export function formatTrackDisplayTitle(
  track: {
    title: string;
    artist?: string;
    artists?: string[];
    version?: string;
    producer?: string;
    prod?: string;
  },
  releaseArtist?: string
): string {
  let title = (track.title || "Без названия").trim();
  const version = (track.version || "").trim();
  const producer = ((track.producer || track.prod || "") as string).trim();

  // Extract artists from track
  const rawArtists = Array.isArray(track.artists) ? track.artists : [];
  const trackArtists: string[] = rawArtists
    .map((a: any) => (typeof a === "string" ? a.trim() : a?.name?.trim()))
    .filter(Boolean);

  if (track.artist && typeof track.artist === "string" && !trackArtists.includes(track.artist.trim())) {
    trackArtists.unshift(track.artist.trim());
  }

  // If there are guest artists on this track not matching the main release artist
  if (trackArtists.length > 0) {
    let guestArtists: string[] = [];
    if (releaseArtist) {
      const mainLower = releaseArtist.toLowerCase().trim();
      guestArtists = trackArtists.filter((a) => !mainLower.includes(a.toLowerCase()));
    } else if (trackArtists.length > 1) {
      guestArtists = trackArtists.slice(1);
    }

    if (guestArtists.length > 0) {
      const featRegex = /\b(?:feat\.?|ft\.?|featuring)\b/i;
      const alreadyHasFeat = featRegex.test(title) || (version && featRegex.test(version));
      const alreadyHasGuest = guestArtists.some((g) => title.toLowerCase().includes(g.toLowerCase()));

      if (!alreadyHasFeat && !alreadyHasGuest) {
        title = `${title} (feat. ${guestArtists.join(", ")})`;
      }
    }
  }

  // Handle producer if specified separately
  if (producer) {
    const prodRegex = /\b(?:prod\.?|produced\s+by)\b/i;
    const alreadyHasProd = prodRegex.test(title) || (version && prodRegex.test(version));
    if (!alreadyHasProd && !title.toLowerCase().includes(producer.toLowerCase())) {
      title = `${title} [prod. by ${producer}]`;
    }
  }

  // Version / Prod / Remix handling
  if (version) {
    const vLower = version.toLowerCase();
    const tLower = title.toLowerCase();

    if (!tLower.includes(vLower)) {
      if (/^prod\.?\s*(?:by)?/i.test(version)) {
        title = `${title} [${version}]`;
      } else if (/^(?:feat\.?|ft\.?|featuring)/i.test(version)) {
        if (!/\b(?:feat\.?|ft\.?|featuring)\b/i.test(title)) {
          title = `${title} (${version})`;
        }
      } else {
        title = `${title} (${version})`;
      }
    }
  }

  return title;
}

/**
 * Generates catalog.txt for Option 1: "Все данные"
 */
export function generateBackCatalogFullTxtString(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): string {
  const blocks = releases.map((rel, idx) => {
    const artist = (rel.artist_name || defaultArtist || "Не указан").trim();
    const title = (rel.title || "Без названия").trim();
    const label = (rel.label || "Не указан").trim();
    const date = formatDisplayDate(rel.release_date);
    const link = resolveReleaseLink(rel);
    const cleanUpc = (rel.upc || "").replace(/\D/g, "");

    const tracks = rel.tracks || [];

    // Collect ISRCs
    const isrcList: string[] = [];
    tracks.forEach((t) => {
      const c = (t.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      if (c && !isrcList.includes(c)) isrcList.push(c);
    });

    const authorText =
      (rel as any).author_text ||
      tracks.find((t: any) => t.author_text)?.author_text ||
      artist ||
      "Не указан";
    const authorMusic =
      (rel as any).author_music ||
      tracks.find((t: any) => t.author_music)?.author_music ||
      artist ||
      "Не указан";

    // Tracklist with 1 -, 2 -, feat, prod, ISRC (all tracks from 1 to N, never empty)
    const effectiveTracks = tracks && tracks.length > 0 ? tracks : [{
      track_id: `t_${rel.release_id}_1`,
      release_id: rel.release_id,
      track_number: 1,
      title: title,
      artist: artist,
      artists: (rel as any).artists || [artist],
      version: (rel as any).version || "",
      isrc: isrcList[0] || ""
    }];

    const trackLines = effectiveTracks.map((t, tIdx) => {
      const formattedTitle = formatTrackDisplayTitle(t, artist);
      const isrc = (t.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      return `${tIdx + 1} - ${formattedTitle}${isrc ? ` — ISRC: ${isrc}` : ""}`;
    });

    // Summary codes line
    const codesParts: string[] = [];
    if (cleanUpc) {
      codesParts.push(`UPC: ${cleanUpc}`);
    }
    if (isrcList.length === 1) {
      codesParts.push(`ISRC: ${isrcList[0]}`);
    } else if (isrcList.length > 1) {
      if (isrcList.length <= 4) {
        codesParts.push(`ISRC: ${isrcList.join(", ")}`);
      } else {
        codesParts.push(`ISRC: указаны по трекам (${isrcList.length} шт.)`);
      }
    }
    const codesLine = codesParts.length > 0 ? `Коды: ${codesParts.join(" / ")}` : "Коды: не указаны";

    const lines: string[] = [
      `${idx + 1}. ${artist} — ${title}`,
      "",
      `Дата релиза: ${date}`,
      `Лейбл: ${label}`,
      `Артист: ${artist}`,
      `Название релиза: ${title}`,
      `Автор текста: ${authorText}`,
      `Автор музыки: ${authorMusic}`,
      ""
    ];

    if (trackLines.length > 0) {
      lines.push(...trackLines);
      lines.push("");
    }

    lines.push(codesLine);
    lines.push(`Ссылка на альбом/сингл: ${link}`);

    return lines.join("\n");
  });

  return ["БЭК-КАТАЛОГ", "", blocks.join("\n\n\n")].join("\n");
}

/**
 * Generates catalog.txt for Option 2: "Дата релиза + ссылка + обложка"
 */
export function generateBackCatalogLiteTxtString(
  defaultArtist: string,
  releases: ExportReleaseInput[]
): string {
  const blocks = releases.map((rel, idx) => {
    const artist = (rel.artist_name || defaultArtist || "Не указан").trim();
    const title = (rel.title || "Без названия").trim();
    const date = formatDisplayDate(rel.release_date);
    const link = resolveReleaseLink(rel);
    const cleanUpc = (rel.upc || "").replace(/\D/g, "");

    const tracks = rel.tracks || [];

    // Collect ISRCs
    const isrcList: string[] = [];
    tracks.forEach((t) => {
      const c = (t.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      if (c && !isrcList.includes(c)) isrcList.push(c);
    });

    // Tracklist with 1 -, 2 -, feat, prod, ISRC (all tracks from 1 to N, never empty)
    const effectiveTracks = tracks && tracks.length > 0 ? tracks : [{
      track_id: `t_${rel.release_id}_1`,
      release_id: rel.release_id,
      track_number: 1,
      title: title,
      artist: artist,
      artists: (rel as any).artists || [artist],
      version: (rel as any).version || "",
      isrc: isrcList[0] || ""
    }];

    const trackLines = effectiveTracks.map((t, tIdx) => {
      const formattedTitle = formatTrackDisplayTitle(t, artist);
      const isrc = (t.isrc || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
      return `${tIdx + 1} - ${formattedTitle}${isrc ? ` — ISRC: ${isrc}` : ""}`;
    });

    // Summary codes line
    const codesParts: string[] = [];
    if (cleanUpc) {
      codesParts.push(`UPC: ${cleanUpc}`);
    }
    if (isrcList.length === 1) {
      codesParts.push(`ISRC: ${isrcList[0]}`);
    } else if (isrcList.length > 1) {
      if (isrcList.length <= 4) {
        codesParts.push(`ISRC: ${isrcList.join(", ")}`);
      } else {
        codesParts.push(`ISRC: указаны по трекам (${isrcList.length} шт.)`);
      }
    }
    const codesLine = codesParts.length > 0 ? `Коды: ${codesParts.join(" / ")}` : "Коды: не указаны";

    const lines: string[] = [
      `${idx + 1}. ${artist} — ${title}`,
      "",
      `Дата релиза: ${date}`,
      `Артист: ${artist}`,
      `Название релиза: ${title}`,
      ""
    ];

    if (trackLines.length > 0) {
      lines.push(...trackLines);
      lines.push("");
    }

    lines.push(codesLine);
    lines.push(`Ссылка на альбом/сингл: ${link}`);

    return lines.join("\n");
  });

  return ["БЭК-КАТАЛОГ", "", blocks.join("\n\n\n")].join("\n");
}

// Background Task Manager Class
class CatalogExportManager {
  public getTask(taskId: string): ExportTaskState | undefined {
    return tasks.get(taskId);
  }

  public getLatestTask(): ExportTaskState | undefined {
    const all = Array.from(tasks.values()).sort((a, b) => b.createdAt - a.createdAt);
    return all[0];
  }

  public cancelTask(taskId: string): boolean {
    const task = tasks.get(taskId);
    if (task && task.status === "processing") {
      task.status = "cancelled";
      task.statusText = "Сборка отменена пользователем.";
      persistTasks();
      return true;
    }
    return false;
  }

  public startTask(req: ExportTaskRequest): ExportTaskState {
    const taskId = `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const artistName = req.artist?.name || "Artist";
    const exportFormat = req.exportFormat || "all_data";

    // Filter selected releases with selected tracks
    const selectedReleaseSet = new Set(req.selectedReleaseIds || []);
    const selectedReleases: ExportReleaseInput[] = (req.releases || [])
      .filter((r) => (selectedReleaseSet.size > 0 ? selectedReleaseSet.has(r.release_id) : true))
      .map((r) => {
        const allowedTracks = new Set(req.selectedTrackIdsMap?.[r.release_id] || []);
        return {
          ...r,
          tracks: (r.tracks || []).filter((t) =>
            allowedTracks.size > 0 ? allowedTracks.has(t.track_id) : true
          )
        };
      });

    const totalReleases = selectedReleases.length;
    const totalTracks = selectedReleases.reduce((acc, r) => acc + r.tracks.length, 0);

    const safeArtist = sanitizeFsName(artistName, "Artist");
    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName =
      exportFormat === "release_date_link_cover"
        ? `${safeArtist}_BackCatalog_Dates_${dateStr}.zip`
        : `${safeArtist}_BackCatalog_${dateStr}.zip`;

    const task: ExportTaskState = {
      taskId,
      artistName,
      fileName,
      status: "processing",
      percent: 5,
      stage: 1,
      statusText: "Инициализация фоновой сборки на сервере...",
      totalReleases,
      totalTracks,
      processedTracks: 0,
      exportFormat,
      createdAt: Date.now(),
      downloadUrl: `/api/catalog/export-download/${taskId}`
    };

    tasks.set(taskId, task);
    persistTasks();

    // Launch worker asynchronously in background!
    this.runWorker(task, req, selectedReleases).catch((err) => {
      console.error(`[Background Export Task ${taskId}] Worker failed:`, err);
      task.status = "error";
      task.error = err?.message || "Ошибка сборки архива";
      task.statusText = `Ошибка фоновой сборки: ${task.error}`;
      persistTasks();
    });

    return task;
  }

  private isCancelled(taskId: string): boolean {
    const t = tasks.get(taskId);
    return t?.status === "cancelled";
  }

  private async runWorker(
    task: ExportTaskState,
    req: ExportTaskRequest,
    selectedReleases: ExportReleaseInput[]
  ) {
    const exportFormat = task.exportFormat || "all_data";
    const stagingRoot = path.join(EXPORTS_DIR, `staging_${task.taskId}`);

    try {
      if (fs.existsSync(stagingRoot)) fs.rmSync(stagingRoot, { recursive: true, force: true });
      fs.mkdirSync(stagingRoot, { recursive: true });

      // Create target directories according to spec:
      // /covers/
      // /audio/ (only for "all_data")
      const coversDir = path.join(stagingRoot, "covers");
      fs.mkdirSync(coversDir, { recursive: true });

      let audioDir: string | null = null;
      if (exportFormat === "all_data") {
        audioDir = path.join(stagingRoot, "audio");
        fs.mkdirSync(audioDir, { recursive: true });
      }

      // Stage 1: File discovery
      task.stage = 1;
      task.percent = 8;
      task.statusText = "Проверка файлов и инициализация структуры каталога на сервере...";
      persistTasks();
      await new Promise((r) => setTimeout(r, 80));

      if (this.isCancelled(task.taskId)) return;

      // Stage 2: Covers preparation (8% -> 35%)
      task.stage = 2;
      task.percent = 12;
      task.statusText = "Фоновая подготовка и масштабирование обложек (строго 3000×3000px)...";
      persistTasks();

      for (let rIdx = 0; rIdx < selectedReleases.length; rIdx++) {
        if (this.isCancelled(task.taskId)) return;

        const rel = selectedReleases[rIdx];
        const relArtist = rel.artist_name || req.artist.name;
        task.currentReleaseTitle = rel.title;
        task.statusText = `Подготовка обложки 3000×3000px для «${rel.title}» (${rIdx + 1} из ${selectedReleases.length})...`;

        const padRel = String(rIdx + 1).padStart(2, "0");
        const safeRelArtist = sanitizeFsName(relArtist, "Artist");
        const safeRelTitle = sanitizeFsName(rel.title, "Release");
        const coverFileName = `${padRel}_${safeRelArtist}_${safeRelTitle}.jpg`;

        let coverBuffer: Buffer | null = null;
        if (rel.cover) {
          try {
            let highResUrl = rel.cover;
            if (highResUrl.includes("avatars.yandex.net")) {
              highResUrl = highResUrl.replace("%%", "1000x1000");
            }
            if (!highResUrl.startsWith("http://") && !highResUrl.startsWith("https://")) {
              highResUrl = "https://" + highResUrl;
            }
            const imgRes = await axios.get(highResUrl, {
              responseType: "arraybuffer",
              timeout: 6000,
              headers: { "User-Agent": "Mozilla/5.0" },
              maxContentLength: 12 * 1024 * 1024
            });
            if (imgRes.data && imgRes.data.length > 500) {
              coverBuffer = Buffer.from(imgRes.data);
            }
          } catch (e) {
            // fallback
          }
        }

        // Process image strictly to 3000x3000px 24-bit RGB JPEG
        try {
          const cover3000 = await processCoverTo3000x3000(coverBuffer, rel.title, relArtist, `${task.taskId}_r${rIdx}`);
          fs.writeFileSync(path.join(coversDir, coverFileName), cover3000);
        } catch (cErr) {
          console.warn(`Cover creation warning for ${rel.title}:`, cErr);
          const fallback = createFallbackCoverBuffer(rel.title, relArtist);
          fs.writeFileSync(path.join(coversDir, coverFileName), fallback);
        }

        task.percent = 12 + Math.floor(((rIdx + 1) / Math.max(1, selectedReleases.length)) * 23);
        persistTasks();
      }

      // Stage 3: Audio Tracks Acquisition & Studio WAV Conversion
      task.stage = 3;
      if (exportFormat === "release_date_link_cover") {
        // Option 2: WAV files are NOT downloaded and NOT added to ZIP
        task.percent = 70;
        task.statusText = "Пропуск аудио: выбран компактный формат без WAV...";
        persistTasks();
        await new Promise((r) => setTimeout(r, 60));
      } else {
        // Option 1: All studio WAV files (16-bit 44.1kHz stereo PCM)
        task.percent = 35;
        task.statusText = "Фоновая конвертация треков в студийный WAV (16-bit 44.1kHz stereo)...";
        persistTasks();

        let processedTracks = 0;
        const totalTracks = task.totalTracks;

        for (let rIdx = 0; rIdx < selectedReleases.length; rIdx++) {
          if (this.isCancelled(task.taskId)) return;

          const rel = selectedReleases[rIdx];
          const relArtist = rel.artist_name || req.artist.name;
          const padRel = String(rIdx + 1).padStart(2, "0");
          const safeRelArtist = sanitizeFsName(relArtist, "Artist");
          const safeRelTitle = sanitizeFsName(rel.title, "Release");

          for (let tIdx = 0; tIdx < rel.tracks.length; tIdx++) {
            if (this.isCancelled(task.taskId)) return;

            const trk = rel.tracks[tIdx];
            task.currentTrackTitle = trk.title;
            task.processedTracks = processedTracks + 1;
            task.statusText = `Конвертация в студийный WAV (16-bit 44.1kHz stereo) для «${trk.title}» (${processedTracks + 1} из ${totalTracks})...`;

            let trackBuffer: Buffer | null = null;
            const rawId = String(trk.track_id || "").trim();
            const isMockOrSynthetic =
              !rawId ||
              rawId.startsWith("syn_") ||
              rawId.startsWith("trk_") ||
              rawId.startsWith("t_") ||
              rawId.startsWith("mock_") ||
              rawId.startsWith("demo_") ||
              rawId.startsWith("temp_");

            if (!isMockOrSynthetic) {
              try {
                const localUrl = `http://127.0.0.1:3000/api/music/download/${encodeURIComponent(
                  rawId
                )}?title=${encodeURIComponent(trk.title)}&artists=${encodeURIComponent(relArtist)}`;
                const aRes = await axios.get(localUrl, {
                  responseType: "arraybuffer",
                  timeout: 3500,
                  maxContentLength: 90 * 1024 * 1024,
                  validateStatus: (status) => status >= 200 && status < 400
                });
                if (aRes.data && aRes.data.length > 5000) {
                  trackBuffer = Buffer.from(aRes.data);
                }
              } catch (err: any) {
                console.warn(`[Export Worker] Fast fallback for «${trk.title}»:`, err?.message);
              }
            }

            try {
              const wavBuffer = await convertToStudioWav(
                trackBuffer,
                trk.title,
                relArtist,
                `${task.taskId}_r${rIdx}_t${tIdx}`
              );

              // File naming: 01_artist_release.wav or for multi-track: 01_01_artist_track.wav
              let wavFileName = "";
              if (rel.tracks.length === 1) {
                wavFileName = `${padRel}_${safeRelArtist}_${safeRelTitle}.wav`;
              } else {
                const padTrk = String(tIdx + 1).padStart(2, "0");
                const safeTrkTitle = sanitizeFsName(trk.title, "Track");
                wavFileName = `${padRel}_${padTrk}_${safeRelArtist}_${safeTrkTitle}.wav`;
              }

              if (audioDir) {
                fs.writeFileSync(path.join(audioDir, wavFileName), wavBuffer);
              }
            } catch (wErr) {
              console.warn(`Failed writing WAV for ${trk.title}:`, wErr);
            }

            processedTracks++;
            task.processedTracks = processedTracks;
            task.percent = 35 + Math.floor((processedTracks / Math.max(1, totalTracks)) * 45);
            persistTasks();

            await new Promise((resolve) => setTimeout(resolve, 15));
          }
        }
      }

      // Stage 4: Metadata Formulation (catalog.txt)
      task.stage = 4;
      task.percent = 84;
      task.statusText = "Формирование файла catalog.txt и метаданных каталога...";
      persistTasks();

      // Generate catalog.txt according to selected option
      const catalogTxt =
        exportFormat === "release_date_link_cover"
          ? generateBackCatalogLiteTxtString(req.artist.name, selectedReleases)
          : generateBackCatalogFullTxtString(req.artist.name, selectedReleases);

      // Write catalog.txt at root of staging folder
      fs.writeFileSync(path.join(stagingRoot, "catalog.txt"), catalogTxt, "utf-8");

      // Master tables for direct file exports
      const masterExcel = generateCodesExcelBuffer(req.artist.name, selectedReleases);
      const masterCsv = generateCodesCsvString(req.artist.name, selectedReleases);
      const masterCodesTxt = generateCatalogCodesTxtString(req.artist.name, selectedReleases);
      const masterDatesTxt = generateCatalogDatesTxtString(req.artist.name, selectedReleases);

      const taskExcelPath = path.join(EXPORTS_DIR, `${task.taskId}_codes.xlsx`);
      const taskCsvPath = path.join(EXPORTS_DIR, `${task.taskId}_codes.csv`);
      const taskTxtPath = path.join(EXPORTS_DIR, `${task.taskId}_catalog.txt`);
      const taskDatesTxtPath = path.join(EXPORTS_DIR, `${task.taskId}_dates.txt`);

      fs.writeFileSync(taskExcelPath, masterExcel);
      fs.writeFileSync(taskCsvPath, masterCsv, "utf-8");
      fs.writeFileSync(taskTxtPath, catalogTxt, "utf-8");
      fs.writeFileSync(taskDatesTxtPath, masterDatesTxt, "utf-8");

      task.excelPath = taskExcelPath;
      task.csvPath = taskCsvPath;
      task.txtPath = taskTxtPath;
      task.datesTxtPath = taskDatesTxtPath;

      // Stage 5: Building ZIP Archive (88% -> 96%)
      task.stage = 5;
      task.percent = 88;
      task.statusText = "Упаковка единого ZIP-архива на сервере...";
      persistTasks();

      const targetZipPath = path.join(EXPORTS_DIR, `${task.taskId}.zip`);
      if (fs.existsSync(targetZipPath)) {
        try { fs.unlinkSync(targetZipPath); } catch {}
      }

      // Package directory using python3 zipfile with allowZip64 and safe argument passing
      try {
        const pythonZipScript = `
import zipfile, os, sys
src = sys.argv[1]
dst = sys.argv[2]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_STORED, allowZip64=True) as z:
    for root, dirs, files in os.walk(src):
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, src)
            z.write(full, rel)
`;
        execFileSync("python3", ["-c", pythonZipScript, stagingRoot, targetZipPath], {
          stdio: "pipe",
          timeout: 60000
        });
      } catch (zipErr: any) {
        console.error(`[Export Worker] Python zip error:`, zipErr?.message);
        throw new Error(`Ошибка сборки архива: ${zipErr?.message || "zip failed"}`);
      }

      const stat = fs.statSync(targetZipPath);

      // Clean up staging folder to free container disk space
      try {
        fs.rmSync(stagingRoot, { recursive: true, force: true });
      } catch {}

      // Stage 6: Archive Verification (96%)
      task.stage = 6;
      task.percent = 96;
      task.statusText = "Проверка целостности созданного ZIP-архива...";
      persistTasks();
      await new Promise((r) => setTimeout(r, 100));

      // Stage 7: Complete! (100%)
      task.stage = 7;
      task.percent = 100;
      task.status = "completed";
      task.filePath = targetZipPath;
      task.fileSize = stat.size;
      task.completedAt = Date.now();
      task.statusText = "Каталог успешно собран в фоне на сервере и готов к скачиванию!";
      persistTasks();

      console.log(
        `[Background Export Task ${task.taskId}] Successfully created ${task.fileName} (${(
          task.fileSize /
          (1024 * 1024)
        ).toFixed(2)} MB)`
      );
    } catch (err: any) {
      console.error(`[Background Export Task ${task.taskId}] Worker error:`, err);
      task.status = "error";
      task.error = err?.message || "Ошибка сборки архива";
      task.statusText = `Ошибка фоновой сборки: ${task.error}`;
      persistTasks();
      try {
        if (fs.existsSync(stagingRoot)) fs.rmSync(stagingRoot, { recursive: true, force: true });
      } catch {}
    }
  }
}

export const catalogExportManager = new CatalogExportManager();

