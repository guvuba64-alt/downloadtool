/**
 * Advanced Text Sanitizer, Mojibake Detector, Unicode / URI Decoder
 * and Off-Registry Distributor Compliance Generator.
 */

/**
 * Safe version of encodeURIComponent that never throws "URIError: URI malformed".
 * Gracefully repairs unpaired surrogates and invalid Unicode code points.
 */
export function safeEncodeURIComponent(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    const wellFormed = typeof (str as any).toWellFormed === "function"
      ? (str as any).toWellFormed()
      : str.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, "\uFFFD");
    return encodeURIComponent(wellFormed);
  } catch {
    try {
      return encodeURIComponent(str.replace(/[^\x20-\x7E]/g, ""));
    } catch {
      return escape(str);
    }
  }
}

/**
 * Safe version of decodeURIComponent that never throws "URIError: URI malformed".
 * Safely decodes valid percent sequences while keeping malformed ones as literal characters.
 */
export function safeDecodeURIComponent(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    return decodeURIComponent(str.replace(/\+/g, " "));
  } catch {
    try {
      return str.replace(/%([0-9a-fA-F]{2})/g, (match, hex) => {
        try {
          return String.fromCharCode(parseInt(hex, 16));
        } catch {
          return match;
        }
      }).replace(/\+/g, " ");
    } catch {
      return str;
    }
  }
}

/**
 * Safe version of encodeURI that never throws "URIError: URI malformed".
 */
export function safeEncodeURI(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    const wellFormed = typeof (str as any).toWellFormed === "function"
      ? (str as any).toWellFormed()
      : str.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, "\uFFFD");
    return encodeURI(wellFormed);
  } catch {
    return escape(str);
  }
}

/**
 * Safe version of decodeURI that never throws "URIError: URI malformed".
 */
export function safeDecodeURI(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    return decodeURI(str);
  } catch {
    return str;
  }
}

// Decode recursive percent-encodings safely (e.g. %D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82 -> Привет)
export function decodePercentEncoded(input: string): string {
  if (!input || typeof input !== "string") return "";
  let current = input;
  let prev = "";
  let depth = 0;
  while (current !== prev && depth < 5) {
    prev = current;
    try {
      if (/%[0-9a-fA-F]{2}/.test(current)) {
        current = safeDecodeURIComponent(current.replace(/\+/g, " "));
      } else {
        break;
      }
    } catch {
      // Fallback manual percent byte conversion for malformed URI components
      current = current.replace(/%([0-9a-fA-F]{2})/g, (_, hex) => {
        try {
          return String.fromCharCode(parseInt(hex, 16));
        } catch {
          return _;
        }
      });
      break;
    }
    depth++;
  }
  return current;
}

// Decode Unicode Escape sequences (e.g. \u041f\u0440\u0438\u0432\u0435\u0442 -> Привет, \x20 -> ' ')
export function decodeUnicodeEscapes(input: string): string {
  if (!input || typeof input !== "string") return "";
  let out = input;
  try {
    // Decode \uXXXX sequences
    out = out.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
    // Decode \xXX sequences
    out = out.replace(/\\x([0-9a-fA-F]{2})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
  } catch {
    // Keep as is on error
  }
  return out;
}

// Decode HTML Entities (e.g. &quot; -> ", &amp; -> &, &#39; -> ')
export function decodeHtmlEntities(input: string): string {
  if (!input || typeof input !== "string") return "";
  return input
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#(\d+);/g, (_, num) => String.fromCharCode(parseInt(num, 10)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
}

// Strip binary headers, control characters, and zero-width artifacts (e.g. protobuf / stream garbage)
export function stripBinaryAndControlChars(input: string): string {
  if (!input || typeof input !== "string") return "";
  return input
    // Remove null bytes, non-printable control characters
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "")
    // Remove zero-width spaces, BOM, joiners
    .replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ")
    // Remove raw protobuf field prefix strings like \x08\x01\x12
    .replace(/(?:\\x0[0-9a-f]|\\x1[0-9a-f])+/gi, "")
    // Normalize excessive spaces
    .replace(/[ \t]+/g, " ")
    .trim();
}

/**
 * Normalizes Unicode styled fonts (Mathematical Alphanumeric, Fraktur, Script,
 * Fullwidth, Small Caps, Circled/Enclosed letters, HTML font/span tags, ANSI colors)
 * into standard plain characters so regex and parsers match them 100% reliably.
 */
export function normalizeUnicodeFonts(input: string): string {
  if (!input || typeof input !== "string") return "";
  let text = input;

  // 1. Strip ANSI escape sequences (terminal formatting e.g. \u001b[31m)
  text = text.replace(/\u001b\[[0-9;]*[a-zA-Z]/g, "");

  // 2. Strip HTML font tags and inline styles (<font color="...">, <span style="...">, <b>, <i>)
  text = text.replace(/<font[^>]*>(.*?)<\/font>/gi, "$1");
  text = text.replace(/<span[^>]*>(.*?)<\/span>/gi, "$1");
  text = text.replace(/<div[^>]*>(.*?)<\/div>/gi, "$1");
  text = text.replace(/<(?:b|i|u|em|strong|p|small|code|pre)[^>]*>(.*?)<\/(?:b|i|u|em|strong|p|small|code|pre)>/gi, "$1");
  text = text.replace(/<[^>]+>/g, " ");

  // 3. Strip BBCode font tags [font=...], [b], [color=...]
  text = text.replace(/\[\/?(?:font|b|i|u|color|size|style)[^\]]*\]/gi, "");

  // 4. Normalize Mathematical Alphanumeric Symbols (U+1D400 to U+1D7FF)
  // Mapping code points back to standard A-Z, a-z, 0-9
  const normalizedChars: string[] = [];
  for (let i = 0; i < text.length; i++) {
    const cp = text.codePointAt(i);
    if (!cp) continue;

    // Advance index for surrogate pairs
    if (cp > 0xffff) i++;

    let replaced = false;

    // Mathematical Bold (A-Z: 0x1D400..0x1D419, a-z: 0x1D41A..0x1D433, 0-9: 0x1D7CE..0x1D7D7)
    if (cp >= 0x1D400 && cp <= 0x1D419) { normalizedChars.push(String.fromCharCode(65 + (cp - 0x1D400))); replaced = true; }
    else if (cp >= 0x1D41A && cp <= 0x1D433) { normalizedChars.push(String.fromCharCode(97 + (cp - 0x1D41A))); replaced = true; }
    // Mathematical Italic (A-Z: 0x1D434..0x1D44D, a-z: 0x1D44E..0x1D467)
    else if (cp >= 0x1D434 && cp <= 0x1D44D) { normalizedChars.push(String.fromCharCode(65 + (cp - 0x1D434))); replaced = true; }
    else if (cp >= 0x1D44E && cp <= 0x1D467) { normalizedChars.push(String.fromCharCode(97 + (cp - 0x1D44E))); replaced = true; }
    // Mathematical Bold Italic (A-Z: 0x1D468..0x1D481, a-z: 0x1D482..0x1D49B)
    else if (cp >= 0x1D468 && cp <= 0x1D481) { normalizedChars.push(String.fromCharCode(65 + (cp - 0x1D468))); replaced = true; }
    else if (cp >= 0x1D482 && cp <= 0x1D49B) { normalizedChars.push(String.fromCharCode(97 + (cp - 0x1D482))); replaced = true; }
    // Mathematical Script & Bold Script
    else if (cp >= 0x1D49C && cp <= 0x1D4CF) {
      const offset = (cp - 0x1D49C) % 52;
      normalizedChars.push(offset < 26 ? String.fromCharCode(65 + offset) : String.fromCharCode(97 + (offset - 26)));
      replaced = true;
    }
    // Mathematical Fraktur & Bold Fraktur (0x1D504..0x1D537)
    else if (cp >= 0x1D504 && cp <= 0x1D537) {
      const offset = (cp - 0x1D504) % 52;
      normalizedChars.push(offset < 26 ? String.fromCharCode(65 + offset) : String.fromCharCode(97 + (offset - 26)));
      replaced = true;
    }
    // Mathematical Double-struck (0x1D538..0x1D56B)
    else if (cp >= 0x1D538 && cp <= 0x1D56B) {
      const offset = (cp - 0x1D538) % 52;
      normalizedChars.push(offset < 26 ? String.fromCharCode(65 + offset) : String.fromCharCode(97 + (offset - 26)));
      replaced = true;
    }
    // Mathematical Sans-serif (0x1D56C..0x1D5D3)
    else if (cp >= 0x1D56C && cp <= 0x1D5D3) {
      const offset = (cp - 0x1D56C) % 52;
      normalizedChars.push(offset < 26 ? String.fromCharCode(65 + offset) : String.fromCharCode(97 + (offset - 26)));
      replaced = true;
    }
    // Mathematical Monospace (0x1D670..0x1D6A3)
    else if (cp >= 0x1D670 && cp <= 0x1D6A3) {
      const offset = (cp - 0x1D670) % 52;
      normalizedChars.push(offset < 26 ? String.fromCharCode(65 + offset) : String.fromCharCode(97 + (offset - 26)));
      replaced = true;
    }
    // Mathematical Numbers (0x1D7CE..0x1D7FF)
    else if (cp >= 0x1D7CE && cp <= 0x1D7FF) {
      const numOffset = (cp - 0x1D7CE) % 10;
      normalizedChars.push(String(numOffset));
      replaced = true;
    }
    // Fullwidth ASCII (0xFF01..0xFF5E)
    else if (cp >= 0xFF01 && cp <= 0xFF5E) {
      normalizedChars.push(String.fromCharCode(cp - 0xFEE0));
      replaced = true;
    }
    // Circled letters A-Z (0x24B6..0x24CF) and a-z (0x24D0..0x24E9)
    else if (cp >= 0x24B6 && cp <= 0x24CF) { normalizedChars.push(String.fromCharCode(65 + (cp - 0x24B6))); replaced = true; }
    else if (cp >= 0x24D0 && cp <= 0x24E9) { normalizedChars.push(String.fromCharCode(97 + (cp - 0x24D0))); replaced = true; }
    // Negative squared uppercase letters (0x1F130..0x1F149, 0x1F170..0x1F189)
    else if (cp >= 0x1F170 && cp <= 0x1F189) { normalizedChars.push(String.fromCharCode(65 + (cp - 0x1F170))); replaced = true; }
    // Circled Numbers (0x2460..0x2473 -> 1..20, 0x24EA -> 0)
    else if (cp >= 0x2460 && cp <= 0x2468) { normalizedChars.push(String(cp - 0x245F)); replaced = true; }
    else if (cp === 0x24EA) { normalizedChars.push("0"); replaced = true; }

    if (!replaced) {
      normalizedChars.push(String.fromCodePoint(cp));
    }
  }

  text = normalizedChars.join("");

  // 5. Small Caps mapping
  const smallCapsMap: Record<string, string> = {
    'ᴀ': 'a', 'ʙ': 'b', 'ᴄ': 'c', 'ᴅ': 'd', 'ᴇ': 'e', 'ꜰ': 'f', 'ɢ': 'g', 'ʜ': 'h',
    'ɪ': 'i', 'ᴊ': 'j', 'ᴋ': 'k', 'ʟ': 'l', 'ᴍ': 'm', 'ɴ': 'n', 'ᴏ': 'o', 'ᴘ': 'p',
    'ǫ': 'q', 'ʀ': 'r', 's': 's', 'ᴛ': 't', 'ᴜ': 'u', 'ᴠ': 'v', 'ᴡ': 'w', 'x': 'x',
    'ʏ': 'y', 'ᴢ': 'z'
  };
  text = text.replace(/[ᴀ-ᴢ]/g, ch => smallCapsMap[ch] || ch);

  // 6. Normalize Copyright and Sound Recording symbols
  text = text.replace(/℗|Ⓟ|\(P\)|\(p\)/g, "℗ ");
  text = text.replace(/©|Ⓒ|\(C\)|\(c\)/g, "© ");

  return text;
}

/**
 * Fix Mojibake (corrupted Cyrillic encoding from UTF-8 misread as Latin1, CP1252, or Windows-1251)
 * E.g.: "ÐÑÐ¸Ð²ÐµÑ" -> "Привет"
 *       "РСРёРІРµС‚" -> "Привет"
 *       "ÃÂÃÂ..." -> "Привет"
 */
export function fixMojibake(input: string): string {
  if (!input || typeof input !== "string") return "";
  let str = input;

  // Check if string contains typical UTF-8 -> Latin1/CP1252 mojibake chars: Ð, Ñ, Â, Ã, etc.
  if (/[ÐÑ][\x80-\xFF]/.test(str) || /[\xC2\xC3][\x80-\xBF]/.test(str)) {
    try {
      const bytes = Buffer.from(str, "latin1");
      const decoded = bytes.toString("utf8");
      // If the decoded result contains valid Cyrillic and fewer unknown chars, use it
      if (/[а-яА-ЯёЁ]/.test(decoded)) {
        str = decoded;
      }
    } catch {}
  }

  // Check if string contains UTF-8 -> Windows-1251 double encoding (e.g. Р, Р‘, СЃ, etc.)
  if (/Р[°±²³´µ¶·ё№є»јѕї]/.test(str) || /С[‚ƒ„…†‡€‰Љ‹ЊЌЋЏ]/.test(str)) {
    try {
      const win1251Map: { [key: string]: number } = {
        'А': 0xC0, 'Б': 0xC1, 'В': 0xC2, 'Г': 0xC3, 'Д': 0xC4, 'Е': 0xC5, 'Ж': 0xC6, 'З': 0xC7,
        'И': 0xC8, 'Й': 0xC9, 'К': 0xCA, 'Л': 0xCB, 'М': 0xCC, 'Н': 0xCD, 'О': 0xCE, 'П': 0xCF,
        'Р': 0xD0, 'С': 0xD1, 'Т': 0xD2, 'У': 0xD3, 'Ф': 0xD4, 'Х': 0xD5, 'Ц': 0xD6, 'Ч': 0xD7,
        'Ш': 0xD8, 'Щ': 0xD9, 'Ъ': 0xDA, 'Ы': 0xDB, 'Ь': 0xDC, 'Э': 0xDD, 'Ю': 0xDE, 'Я': 0xDF,
        'а': 0xE0, 'б': 0xE1, 'в': 0xE2, 'г': 0xE3, 'д': 0xE4, 'е': 0xE5, 'ж': 0xE6, 'з': 0xE7,
        'и': 0xE8, 'й': 0xE9, 'к': 0xEA, 'л': 0xEB, 'м': 0xEC, 'н': 0xED, 'о': 0xEE, 'п': 0xEF,
        'р': 0xF0, 'с': 0xF1, 'т': 0xF2, 'у': 0xF3, 'ф': 0xF4, 'х': 0xF5, 'ц': 0xF6, 'ч': 0xF7,
        'ш': 0xF8, 'щ': 0xF9, 'ъ': 0xFA, 'ы': 0xFB, 'ь': 0xFC, 'э': 0xFD, 'ю': 0xFE, 'я': 0xFF,
        'Ё': 0xA8, 'ё': 0xB8, '№': 0xB9
      };
      
      const byteList: number[] = [];
      for (let i = 0; i < str.length; i++) {
        const char = str[i];
        if (win1251Map[char] !== undefined) {
          byteList.push(win1251Map[char]);
        } else {
          byteList.push(char.charCodeAt(0) & 0xFF);
        }
      }
      const buf = Buffer.from(byteList);
      const winDecoded = buf.toString("utf8");
      if (/[а-яА-ЯёЁ]/.test(winDecoded)) {
        str = winDecoded;
      }
    } catch {}
  }

  return str;
}

/**
 * Universal text cleaner that runs full sanitization pipeline:
 * URI unescaping -> Unicode escapes -> HTML entities -> Mojibake repair -> Control chars stripping
 */
export function cleanAndSanitizeText(input: any): string {
  if (input === null || input === undefined) return "";
  if (typeof input !== "string") input = String(input);
  if (!input.trim()) return "";

  let cleaned = input.trim();
  cleaned = decodePercentEncoded(cleaned);
  cleaned = decodeUnicodeEscapes(cleaned);
  cleaned = decodeHtmlEntities(cleaned);
  cleaned = fixMojibake(cleaned);
  cleaned = stripBinaryAndControlChars(cleaned);

  return cleaned;
}

/**
 * Extract and parse hidden parameters, nested JSON, Base64 blobs, and query maps
 * from DevTools strings, cURL requests, or raw network dumps.
 */
export function extractHiddenDevToolsPayload(rawInput: string): {
  cleanedText: string;
  extractedParams: Record<string, string>;
  decodedJson?: any;
  detectedBase64?: string[];
} {
  const result: {
    cleanedText: string;
    extractedParams: Record<string, string>;
    decodedJson?: any;
    detectedBase64?: string[];
  } = {
    cleanedText: cleanAndSanitizeText(rawInput),
    extractedParams: {},
    detectedBase64: [],
  };

  const input = rawInput.trim();

  // 1. Extract URL parameters
  try {
    const urlStr = input.startsWith("http") ? input : `https://dummy.local/?${input.replace(/^[^?]*\?/, "")}`;
    const urlObj = new URL(urlStr);
    urlObj.searchParams.forEach((val, key) => {
      const cleanKey = cleanAndSanitizeText(key);
      const cleanVal = cleanAndSanitizeText(val);
      result.extractedParams[cleanKey] = cleanVal;

      // Try parsing JSON embedded in query params
      if ((cleanVal.startsWith("{") && cleanVal.endsWith("}")) || (cleanVal.startsWith("[") && cleanVal.endsWith("]"))) {
        try {
          result.decodedJson = JSON.parse(cleanVal);
        } catch {}
      }
    });
  } catch {}

  // 2. Extract potential Base64 blobs
  const base64Regex = /(?:[A-Za-z0-9+/]{4}){6,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?/g;
  const matches = input.match(base64Regex);
  if (matches) {
    for (const b64 of matches) {
      if (b64.length > 24) {
        try {
          const decoded = Buffer.from(b64, "base64").toString("utf8");
          const sanitizedDecoded = cleanAndSanitizeText(decoded);
          if (sanitizedDecoded && /^[\w\sа-яА-ЯёЁ{}[\]":,.-]+$/.test(sanitizedDecoded)) {
            result.detectedBase64?.push(sanitizedDecoded);
            if (sanitizedDecoded.startsWith("{") && sanitizedDecoded.endsWith("}")) {
              try {
                result.decodedJson = result.decodedJson || JSON.parse(sanitizedDecoded);
              } catch {}
            }
          }
        } catch {}
      }
    }
  }

  return result;
}

/**
 * Standard IFPI Compliant ISRC Generator for Off-Registry / Local / Indie Tracks
 * Format: [CC]-[REG]-[YY]-[IDENT]
 * Example: RU-ZVK-25-00123
 */
export function generateCompliantIsrc(
  distributorOrLabel: string | undefined,
  trackId: string | number,
  year: number = new Date().getFullYear(),
  index: number = 0
): string {
  const countryCode = "RU";
  let regCode = "ZVK"; // Default CIS/RU distributor code

  if (distributorOrLabel) {
    const d = distributorOrLabel.toUpperCase();
    if (d.includes("ZVONKO") || d.includes("ЗВОНКО")) regCode = "ZVK";
    else if (d.includes("BELIEVE") || d.includes("БЕЛИВ")) regCode = "BLV";
    else if (d.includes("ONERPM")) regCode = "ONE";
    else if (d.includes("MULTIZA")) regCode = "MLT";
    else if (d.includes("SFEROOM")) regCode = "SFR";
    else if (d.includes("WARNER")) regCode = "WMR";
    else if (d.includes("SONY")) regCode = "SME";
    else if (d.includes("UNIVERSAL")) regCode = "UMG";
    else {
      // Pick 3 alphanumeric characters
      const clean = d.replace(/[^A-Z0-9]/g, "");
      regCode = clean.length >= 3 ? clean.substring(0, 3) : "IND";
    }
  }

  const yr = String(year).slice(-2);
  const numId = String(trackId).replace(/\D/g, "") || "10001";
  const paddedId = (parseInt(numId.slice(-4), 10) + index)
    .toString()
    .padStart(5, "0");

  return `${countryCode}-${regCode}-${yr}-${paddedId}`;
}

// Calculate standard Modulo-10 checksum digit for 12-digit EAN base
export function calculateEan13Checksum(digits12: string): number {
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = parseInt(digits12[i], 10) || 0;
    sum += i % 2 === 0 ? digit * 1 : digit * 3;
  }
  return (10 - (sum % 10)) % 10;
}

/**
 * Standard EAN-13 / UPC Barcode Generator with valid Modulo-10 Checksum
 * for Off-Registry Albums/Releases
 */
export function generateCompliantUpc(
  albumIdOrSeed: string | number,
  year: number = new Date().getFullYear(),
  distributor?: string
): string {
  const seedNum = String(albumIdOrSeed).replace(/\D/g, "") || "460000000000";
  // If distributor is Zvonko Digital / NDA, use 50638 prefix or 460 prefix
  const isZvonko = distributor && (distributor.toUpperCase().includes("ZVONKO") || distributor.toUpperCase().includes("ЗВОНКО") || distributor.toUpperCase().includes("GEEK") || distributor.toUpperCase().includes("НЦА"));
  const prefix = isZvonko ? "50638" : "460";
  const yr = String(year).slice(-2);
  
  let base12 = "";
  if (isZvonko) {
    const middle = seedNum.slice(-6).padStart(6, "0");
    base12 = `${prefix}${middle}1`.slice(0, 12).padEnd(12, "0");
  } else {
    const middle = seedNum.slice(-6).padStart(6, "0");
    base12 = `${prefix}${yr}${middle}1`.slice(0, 12).padEnd(12, "0");
  }

  const checkDigit = calculateEan13Checksum(base12);
  return `${base12}${checkDigit}`;
}

export interface DistributorMatch {
  name: string;
  category: "Major Distributor" | "Digital Aggregator" | "Indie Label / Publisher" | "Streaming Platform" | "Self-Released";
  confidence: number;
  matchedKeyword?: string;
  isrcCountry?: string;
  isrcRegistrant?: string;
}

/**
 * Accurately detects the exact specific distributor or aggregator without ambiguity.
 * NEVER returns a combined slash placeholder like "ZVONKO / Believe / ONErpm".
 */
export function detectSpecificDistributor(input: {
  label?: string;
  copyright?: string;
  major?: string;
  rawText?: string;
  isrc?: string;
  upc?: string;
}): DistributorMatch {
  const normLabel = normalizeUnicodeFonts(input.label || "").toLowerCase();
  const normCopyright = normalizeUnicodeFonts(input.copyright || "").toLowerCase();
  const normMajor = normalizeUnicodeFonts(input.major || "").toLowerCase();
  const normRaw = normalizeUnicodeFonts(input.rawText || "").toLowerCase();
  const isrcUpper = (input.isrc || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  const upcStr = (input.upc || "").trim();

  const fullSearch = `${normLabel} ${normCopyright} ${normMajor} ${normRaw}`;

  // 1. ZVONKO digital / Национальный Цифровой Агрегатор (НЦА) — Топ-1 агрегатор в России
  // Includes key Russian labels and aggregators exclusively under Zvonko Digital management:
  // Geek Records, Zion Music, Rhymes Music, Effective Records, Первое Музыкальное,
  // Национальное Музыкальное Издательство (НМИ), Студия Союз (Soyuz Music), Gamma Music, Lotus Music
  if (
    fullSearch.includes("zvonko") ||
    fullSearch.includes("звонко") ||
    fullSearch.includes("нца") ||
    fullSearch.includes("нда") ||
    fullSearch.includes("национальный цифровой агрегатор") ||
    fullSearch.includes("national digital aggregator") ||
    fullSearch.includes("geek records") ||
    fullSearch.includes("гик рекордс") ||
    fullSearch.includes("zion music") ||
    fullSearch.includes("цион мьюзик") ||
    fullSearch.includes("effective records") ||
    fullSearch.includes("эффектив рекордс") ||
    fullSearch.includes("первое музыкальное") ||
    fullSearch.includes("first music publishing") ||
    fullSearch.includes("нми") ||
    fullSearch.includes("национальное музыкальное издательство") ||
    fullSearch.includes("gamma music") ||
    fullSearch.includes("lotus music") ||
    fullSearch.includes("klever label") ||
    fullSearch.includes("make it music") ||
    upcStr.startsWith("50638") ||
    isrcUpper.startsWith("RUZVK") ||
    isrcUpper.startsWith("RUA01") ||
    isrcUpper.startsWith("RUA62")
  ) {
    let matchKw = "ZVONKO digital (Топ-1 Агрегатор РФ)";
    if (fullSearch.includes("geek records")) matchKw = "Geek Records (ZVONKO digital)";
    else if (fullSearch.includes("zion music")) matchKw = "Zion Music (ZVONKO digital)";
    else if (fullSearch.includes("effective records")) matchKw = "Effective Records (ZVONKO digital)";
    else if (upcStr.startsWith("50638")) matchKw = "UPC Префикс 50638 (ZVONKO digital)";
    return { name: "ZVONKO digital (Национальный Цифровой Агрегатор)", category: "Digital Aggregator", confidence: 99, matchedKeyword: matchKw, isrcCountry: "RU", isrcRegistrant: "ZVK" };
  }

  // 2. SP Digital / СП Диджитал (Крупный российский дистрибьютор / правообладатель)
  if (
    fullSearch.includes("sp digital") ||
    fullSearch.includes("sp_digital") ||
    fullSearch.includes("сп диджитал") ||
    fullSearch.includes("спдиджитал") ||
    fullSearch.includes("spdigital")
  ) {
    return { name: "SP Digital", category: "Digital Aggregator", confidence: 98, matchedKeyword: "SP DIGITAL", isrcCountry: "RU", isrcRegistrant: "SPD" };
  }

  // 3. Believe Digital / Believe Music
  if (
    fullSearch.includes("believe") ||
    fullSearch.includes("белив") ||
    isrcUpper.startsWith("FRX76") ||
    isrcUpper.startsWith("FR6V8") ||
    isrcUpper.startsWith("FR9W1")
  ) {
    return { name: "Believe Digital", category: "Digital Aggregator", confidence: 97, matchedKeyword: "Believe Digital", isrcCountry: "FR", isrcRegistrant: "X76" };
  }

  // 4. ONErpm
  if (
    fullSearch.includes("onerpm") ||
    fullSearch.includes("one rpm") ||
    fullSearch.includes("уанрпм") ||
    isrcUpper.startsWith("QZDA6") ||
    isrcUpper.startsWith("QZTB9")
  ) {
    return { name: "ONErpm", category: "Digital Aggregator", confidence: 96, matchedKeyword: "ONErpm", isrcCountry: "QZ", isrcRegistrant: "DA6" };
  }

  // 4. FreshTunes
  if (fullSearch.includes("freshtunes") || fullSearch.includes("фрештюнс") || fullSearch.includes("fresh tunes")) {
    return { name: "FreshTunes", category: "Digital Aggregator", confidence: 95, matchedKeyword: "FreshTunes", isrcCountry: "FR", isrcRegistrant: "6V8" };
  }

  // 5. Multiza Distribution
  if (fullSearch.includes("multiza") || fullSearch.includes("мультиза")) {
    return { name: "Multiza Distribution", category: "Digital Aggregator", confidence: 94, matchedKeyword: "Multiza", isrcCountry: "RU", isrcRegistrant: "MLT" };
  }

  // 6. Sferoom / Сферум
  if (fullSearch.includes("sferoom") || fullSearch.includes("сферум")) {
    return { name: "Sferoom Distribution", category: "Digital Aggregator", confidence: 93, matchedKeyword: "Sferoom", isrcCountry: "RU", isrcRegistrant: "SFR" };
  }

  // 7. DistroKid
  if (fullSearch.includes("distrokid") || fullSearch.includes("дистрокид") || isrcUpper.startsWith("QZHN5") || isrcUpper.startsWith("QZ22B")) {
    return { name: "DistroKid", category: "Digital Aggregator", confidence: 95, matchedKeyword: "DistroKid", isrcCountry: "QZ", isrcRegistrant: "HN5" };
  }

  // 8. TuneCore
  if (fullSearch.includes("tunecore") || fullSearch.includes("тюнкор") || isrcUpper.startsWith("TCAB2") || isrcUpper.startsWith("USCG1")) {
    return { name: "TuneCore", category: "Digital Aggregator", confidence: 95, matchedKeyword: "TuneCore", isrcCountry: "TC", isrcRegistrant: "AB2" };
  }

  // 9. CD Baby
  if (fullSearch.includes("cd baby") || fullSearch.includes("cdbaby") || isrcUpper.startsWith("USHM8")) {
    return { name: "CD Baby", category: "Digital Aggregator", confidence: 93, matchedKeyword: "CD Baby", isrcCountry: "US", isrcRegistrant: "HM8" };
  }

  // 10. Ditto Music
  if (fullSearch.includes("ditto music") || fullSearch.includes("дитто")) {
    return { name: "Ditto Music", category: "Digital Aggregator", confidence: 92, matchedKeyword: "Ditto Music", isrcCountry: "GB", isrcRegistrant: "72K" };
  }

  // 11. Warner Music Group / Atlantic / ADA
  if (
    fullSearch.includes("warner") ||
    fullSearch.includes("варнер") ||
    fullSearch.includes("atlantic") ||
    fullSearch.includes("ada music") ||
    fullSearch.includes("parlophone") ||
    isrcUpper.startsWith("USAT2") ||
    isrcUpper.startsWith("GBAYE")
  ) {
    return { name: "Warner Music Group / Atlantic", category: "Major Distributor", confidence: 98, matchedKeyword: "Warner Music", isrcCountry: "RU", isrcRegistrant: "WMR" };
  }

  // 12. Universal Music Group / UMG / Virgin / Spinnin
  if (
    fullSearch.includes("universal") ||
    fullSearch.includes("юниверсал") ||
    fullSearch.includes("umg") ||
    fullSearch.includes("virgin music") ||
    fullSearch.includes("interscope") ||
    fullSearch.includes("republic records") ||
    fullSearch.includes("geffen") ||
    fullSearch.includes("polydor") ||
    fullSearch.includes("island records") ||
    fullSearch.includes("def jam") ||
    fullSearch.includes("spinnin") ||
    isrcUpper.startsWith("USUM7") ||
    isrcUpper.startsWith("NLZ54")
  ) {
    return { name: "Universal Music Group (UMG)", category: "Major Distributor", confidence: 98, matchedKeyword: "Universal Music", isrcCountry: "RU", isrcRegistrant: "UMG" };
  }

  // 13. Sony Music Entertainment / SME / Columbia / RCA / The Orchard
  if (
    fullSearch.includes("sony music") ||
    fullSearch.includes("сони мьюзик") ||
    fullSearch.includes("sme") ||
    fullSearch.includes("the orchard") ||
    fullSearch.includes("orchard") ||
    fullSearch.includes("columbia records") ||
    fullSearch.includes("rca records") ||
    fullSearch.includes("epic records") ||
    fullSearch.includes("arista") ||
    isrcUpper.startsWith("USSM1") ||
    isrcUpper.startsWith("QZ7T1")
  ) {
    return { name: "Sony Music / The Orchard", category: "Major Distributor", confidence: 98, matchedKeyword: "Sony Music", isrcCountry: "RU", isrcRegistrant: "SME" };
  }

  // 14. Первое Музыкальное Издательство (1MM / FMI)
  if (fullSearch.includes("первое музыкальное") || fullSearch.includes("первое муз") || fullSearch.includes("1mm") || fullSearch.includes("fmi") || fullSearch.includes("pmi")) {
    return { name: "Первое Музыкальное Издательство (1MM)", category: "Indie Label / Publisher", confidence: 95, matchedKeyword: "Первое Музыкальное", isrcCountry: "RU", isrcRegistrant: "FMI" };
  }

  // 15. Студия СОЮЗ / Союз Мьюзик (Soyuz Music)
  if (fullSearch.includes("студия союз") || fullSearch.includes("союз мьюзик") || fullSearch.includes("soyuz") || (fullSearch.includes("союз") && !fullSearch.includes("союзмультфильм"))) {
    return { name: "Студия СОЮЗ / Soyuz Music", category: "Indie Label / Publisher", confidence: 94, matchedKeyword: "Студия СОЮЗ", isrcCountry: "RU", isrcRegistrant: "SOY" };
  }

  // 16. Velvet Music
  if (fullSearch.includes("velvet music") || fullSearch.includes("вельвет мьюзик") || fullSearch.includes("вельвет")) {
    return { name: "Velvet Music", category: "Indie Label / Publisher", confidence: 96, matchedKeyword: "Velvet Music", isrcCountry: "RU", isrcRegistrant: "VLV" };
  }

  // 17. Black Star Inc.
  if (fullSearch.includes("black star") || fullSearch.includes("блэк стар")) {
    return { name: "Black Star Inc.", category: "Indie Label / Publisher", confidence: 96, matchedKeyword: "Black Star", isrcCountry: "RU", isrcRegistrant: "BKS" };
  }

  // 18. Rhymes Music
  if (fullSearch.includes("rhymes music") || fullSearch.includes("раймс мьюзик") || fullSearch.includes("rhymes")) {
    return { name: "Rhymes Music", category: "Indie Label / Publisher", confidence: 95, matchedKeyword: "Rhymes Music", isrcCountry: "RU", isrcRegistrant: "RHY" };
  }

  // 19. Zion Music
  if (fullSearch.includes("zion music") || fullSearch.includes("зайон мьюзик") || fullSearch.includes("zion")) {
    return { name: "Zion Music", category: "Indie Label / Publisher", confidence: 94, matchedKeyword: "Zion Music", isrcCountry: "RU", isrcRegistrant: "ZIO" };
  }

  // 20. Effective Records
  if (fullSearch.includes("effective records") || fullSearch.includes("эффектив рекордс") || fullSearch.includes("effective")) {
    return { name: "Effective Records", category: "Indie Label / Publisher", confidence: 95, matchedKeyword: "Effective Records", isrcCountry: "RU", isrcRegistrant: "EFF" };
  }

  // 21. DNK Music
  if (fullSearch.includes("dnk music") || fullSearch.includes("днк мьюзик") || (fullSearch.includes("dnk") && !fullSearch.includes("idnk"))) {
    return { name: "DNK Music", category: "Indie Label / Publisher", confidence: 94, matchedKeyword: "DNK Music", isrcCountry: "RU", isrcRegistrant: "DNK" };
  }

  // 22. Zhara Music / Atlantic Records Russia
  if (fullSearch.includes("zhara music") || fullSearch.includes("жара мьюзик") || fullSearch.includes("zhara")) {
    return { name: "Zhara Music (Atlantic Records Russia)", category: "Indie Label / Publisher", confidence: 95, matchedKeyword: "Zhara Music", isrcCountry: "RU", isrcRegistrant: "ZHA" };
  }

  // 23. Zvuk / СберЗвук
  if (fullSearch.includes("zvuk") || fullSearch.includes("звук") || fullSearch.includes("сберзвук") || fullSearch.includes("sber")) {
    return { name: "Zvuk / СберЗвук", category: "Streaming Platform", confidence: 92, matchedKeyword: "Zvuk", isrcCountry: "RU", isrcRegistrant: "ZVK" };
  }

  // 24. BandLink / Yandex Music
  if (fullSearch.includes("bandlink") || fullSearch.includes("бэндлинк") || fullSearch.includes("yandex music") || fullSearch.includes("яндекс музыка")) {
    return { name: "BandLink / Yandex Music", category: "Streaming Platform", confidence: 90, matchedKeyword: "BandLink", isrcCountry: "RU", isrcRegistrant: "YND" };
  }

  // Fallback 1: specific major name passed
  if (input.major && input.major !== "-" && input.major !== "None") {
    return { name: input.major, category: "Digital Aggregator", confidence: 85, matchedKeyword: input.major };
  }

  // Fallback 2: specific label name passed
  if (input.label && input.label !== "-" && input.label !== "No label" && input.label.toLowerCase() !== "independent") {
    return { name: input.label, category: "Indie Label / Publisher", confidence: 80, matchedKeyword: input.label };
  }

  return {
    name: "Самостоятельный релиз (Self-Released / Independent)",
    category: "Self-Released",
    confidence: 60,
    matchedKeyword: "Independent",
    isrcCountry: "RU",
    isrcRegistrant: "IND"
  };
}

export interface DeepScanLine {
  lineIndex: number;
  raw: string;
  normalized: string;
  tags: ("isrc" | "upc" | "copyright" | "distributor" | "token" | "track_id" | "album_id" | "stream_url" | "author" | "json")[];
  extractedValue?: string;
  note?: string;
}

export interface DeepScanResult {
  totalLines: number;
  parsedLines: DeepScanLine[];
  detectedDistributor: DistributorMatch;
  isrcCodes: { code: string; lineIndex: number; context: string; verified: boolean }[];
  upcBarcodes: { code: string; lineIndex: number; context: string; validChecksum: boolean }[];
  copyrightNotices: { notice: string; type: "P-line" | "C-line" | "General"; lineIndex: number; context: string }[];
  allAuthorsAndCredits: { type: "Music" | "Lyrics" | "Performer" | "Producer" | "General"; name: string; lineIndex: number }[];
  extractedTokens: string[];
  trackIds: string[];
  albumIds: string[];
  streamUrls: string[];
  jsonEntities: any[];
}

/**
 * Deep Exhaustive Scanner:
 * Parses EVERY single line of raw input, DevTools dumps, network payloads, and headers.
 * Unpacks font styles, unicode variations, base64 payloads, JSON, and regex matches
 * to extract all codes, copyrights, and distributors with full traceability.
 */
export function deepScanDevToolsLines(rawInput: string): DeepScanResult {
  if (!rawInput || typeof rawInput !== "string") {
    return {
      totalLines: 0,
      parsedLines: [],
      detectedDistributor: detectSpecificDistributor({}),
      isrcCodes: [],
      upcBarcodes: [],
      copyrightNotices: [],
      allAuthorsAndCredits: [],
      extractedTokens: [],
      trackIds: [],
      albumIds: [],
      streamUrls: [],
      jsonEntities: [],
    };
  }

  const rawLines = rawInput.split(/\r?\n/);
  const parsedLines: DeepScanLine[] = [];
  const isrcMap = new Map<string, { code: string; lineIndex: number; context: string; verified: boolean }>();
  const upcMap = new Map<string, { code: string; lineIndex: number; context: string; validChecksum: boolean }>();
  const copyrightList: { notice: string; type: "P-line" | "C-line" | "General"; lineIndex: number; context: string }[] = [];
  const authorsList: { type: "Music" | "Lyrics" | "Performer" | "Producer" | "General"; name: string; lineIndex: number }[] = [];
  const tokenSet = new Set<string>();
  const trackIdSet = new Set<string>();
  const albumIdSet = new Set<string>();
  const streamUrlSet = new Set<string>();
  const jsonEntities: any[] = [];

  for (let i = 0; i < rawLines.length; i++) {
    const rawLine = rawLines[i];
    if (!rawLine.trim()) continue;

    // Step 1: Normalize fonts, decode URI/HTML escapes, repair mojibake
    const normalized = cleanAndSanitizeText(normalizeUnicodeFonts(rawLine));
    const tags: DeepScanLine["tags"] = [];
    let note = "";

    // 1. Scan for ISRC code (e.g. RU-A01-24-00123, QZ-DA6-23-12345, FRX762200001, "isrc": "...")
    const isrcRegex = /(?:isrc[":=\s]+|ISRC[":=\s]+)?\b([A-Z]{2})[- ]?([A-Z0-9]{3})[- ]?(\d{2})[- ]?(\d{5})\b/gi;
    let isrcMatch;
    while ((isrcMatch = isrcRegex.exec(normalized)) !== null) {
      const formattedCode = `${isrcMatch[1].toUpperCase()}-${isrcMatch[2].toUpperCase()}-${isrcMatch[3]}-${isrcMatch[4]}`;
      if (!isrcMap.has(formattedCode)) {
        isrcMap.set(formattedCode, {
          code: formattedCode,
          lineIndex: i + 1,
          context: normalized.slice(Math.max(0, isrcMatch.index - 10), isrcMatch.index + isrcMatch[0].length + 10).trim(),
          verified: true,
        });
      }
      tags.push("isrc");
      note += `[ISRC: ${formattedCode}] `;
    }

    // 2. Scan for UPC / EAN-13 Barcodes (12 or 13 digits)
    const upcRegex = /(?:upc[":=\s]+|barcode[":=\s]+|ean[":=\s]+)?\b(46\d{11}|\d{12,13})\b/gi;
    let upcMatch;
    while ((upcMatch = upcRegex.exec(normalized)) !== null) {
      const codeDigits = upcMatch[1];
      // Filter out timestamps, track IDs, tokens
      if (codeDigits.length === 12 || codeDigits.length === 13) {
        if (!codeDigits.startsWith("17") || codeDigits.length !== 13) { // skip typical unix millis
          let validCheck = false;
          if (codeDigits.length === 13) {
            const base12 = codeDigits.slice(0, 12);
            const expectedCheck = calculateEan13Checksum(base12);
            validCheck = parseInt(codeDigits[12], 10) === expectedCheck;
          }
          if (!upcMap.has(codeDigits)) {
            upcMap.set(codeDigits, {
              code: codeDigits,
              lineIndex: i + 1,
              context: normalized.slice(Math.max(0, upcMatch.index - 10), upcMatch.index + upcMatch[0].length + 10).trim(),
              validChecksum: validCheck,
            });
          }
          tags.push("upc");
          note += `[UPC/EAN: ${codeDigits}] `;
        }
      }
    }

    // 3. Scan for Copyright (℗ Sound Recording / © Copyright / Rightsholders)
    const copyrightRegex = /(?:℗|©|\(P\)|\(C\)|p_line|c_line|copyright|phonogram|правообладатель|авторские права)[:\s]*([^\r\n,;{}"]+)/gi;
    let cMatch;
    while ((cMatch = copyrightRegex.exec(normalized)) !== null) {
      const noticeText = cMatch[0].trim();
      const isPLine = /℗|\(P\)|p_line|phonogram|фонограмм/i.test(noticeText);
      const isCLine = /©|\(C\)|c_line|copyright|копирайт/i.test(noticeText);
      copyrightList.push({
        notice: noticeText,
        type: isPLine ? "P-line" : isCLine ? "C-line" : "General",
        lineIndex: i + 1,
        context: normalized,
      });
      tags.push("copyright");
      note += `[Copyright: ${noticeText}] `;
    }

    // 4. Scan for Authors / Credits (Music, Words, Composer, Lyrics)
    const authorRegex = /(?:композитор|автор музыки|автор слов|автор текста|слова|музыка|composer|lyricist|written by|music by|lyrics by)[:\s]*([^\r\n,;{}"]+)/gi;
    let aMatch;
    while ((aMatch = authorRegex.exec(normalized)) !== null) {
      const fullAuthorStr = aMatch[0].trim();
      const isMusic = /музык|композитор|composer|music/i.test(fullAuthorStr);
      const isText = /слов|текст|lyric/i.test(fullAuthorStr);
      authorsList.push({
        type: isMusic ? "Music" : isText ? "Lyrics" : "General",
        name: aMatch[1].trim(),
        lineIndex: i + 1,
      });
      tags.push("author");
    }

    // 5. Scan for Tokens
    const tokenRegex = /(y0_[A-Za-z0-9_-]{20,}|AQAAAAA[A-Za-z0-9_-]{15,})/g;
    let tMatch;
    while ((tMatch = tokenRegex.exec(normalized)) !== null) {
      tokenSet.add(tMatch[1]);
      tags.push("token");
      note += `[Token: ${tMatch[1].slice(0, 10)}...] `;
    }

    // 6. Scan for Track / Album IDs
    const trackIdRegex = /(?:track\/|tracks\/|trackId[":=\s]+)(\d{4,10})/gi;
    let trkMatch;
    while ((trkMatch = trackIdRegex.exec(normalized)) !== null) {
      trackIdSet.add(trkMatch[1]);
      tags.push("track_id");
    }

    const albumIdRegex = /(?:album\/|albums\/|albumId[":=\s]+)(\d{4,10})/gi;
    let albMatch;
    while ((albMatch = albumIdRegex.exec(normalized)) !== null) {
      albumIdSet.add(albMatch[1]);
      tags.push("album_id");
    }

    // 7. Scan for Stream / Storage URLs
    if (normalized.includes("storage.yandex.net") || normalized.includes("get-mp3") || normalized.includes(".mp3") || normalized.includes(".mp4")) {
      const urlRegex = /(https?:\/\/[^\s"'<>]+)/gi;
      let urlMatch;
      while ((urlMatch = urlRegex.exec(normalized)) !== null) {
        streamUrlSet.add(urlMatch[1]);
        tags.push("stream_url");
      }
    }

    // 8. Scan for JSON blocks
    if ((normalized.startsWith("{") && normalized.endsWith("}")) || (normalized.startsWith("[") && normalized.endsWith("]"))) {
      try {
        const parsed = JSON.parse(normalized);
        jsonEntities.push(parsed);
        tags.push("json");
      } catch {}
    }

    // Check for Distributor presence
    const lineDist = detectSpecificDistributor({ rawText: normalized });
    if (lineDist.confidence >= 90) {
      tags.push("distributor");
      note += `[Distributor: ${lineDist.name}] `;
    }

    parsedLines.push({
      lineIndex: i + 1,
      raw: rawLine,
      normalized,
      tags: Array.from(new Set(tags)),
      note: note.trim() || undefined,
    });
  }

  // Calculate overall specific distributor
  const combinedCopyright = copyrightList.map(c => c.notice).join(" ");
  const firstIsrc = Array.from(isrcMap.values())[0]?.code;
  const firstUpc = Array.from(upcMap.values())[0]?.code;

  const detectedDistributor = detectSpecificDistributor({
    rawText: rawInput,
    copyright: combinedCopyright,
    isrc: firstIsrc,
    upc: firstUpc,
  });

  return {
    totalLines: rawLines.length,
    parsedLines,
    detectedDistributor,
    isrcCodes: Array.from(isrcMap.values()),
    upcBarcodes: Array.from(upcMap.values()),
    copyrightNotices: copyrightList,
    allAuthorsAndCredits: authorsList,
    extractedTokens: Array.from(tokenSet),
    trackIds: Array.from(trackIdSet),
    albumIds: Array.from(albumIdSet),
    streamUrls: Array.from(streamUrlSet),
    jsonEntities,
  };
}
