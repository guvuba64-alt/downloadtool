import crypto from 'crypto';
import { Request, Response } from 'express';
import { getActiveBotToken, sendTelegramMessage } from './telegramBotHub';
import { sendOtpEmail } from './emailService';

export const CHIEF_OWNER_TG_ID = '8981404137';

export function maskEmail(email: string): string {
  if (!email || !email.includes('@')) return '';
  const [local, domain] = email.trim().split('@');
  if (local.length <= 2) return `${local[0]}*@${domain}`;
  const first = local[0];
  const last = local[local.length - 1];
  const stars = '•'.repeat(Math.min(6, Math.max(2, local.length - 2)));
  return `${first}${stars}${last}@${domain}`;
}

export interface AuthRequest {
  requestId: string;
  createdAt: number;
  expiresAt: number; // 5 mins
  status: 'pending_telegram' | 'awaiting_email' | 'awaiting_email_otp' | 'completed' | 'cancelled' | 'expired';
  telegramUserId?: string;
  telegramUsername?: string;
  email?: string;
  maskedEmail?: string;
  otpHash?: string;
  otpExpiresAt?: number;
  otpAttempts: number;
  otpLastSentAt?: number;
  ip: string;
  userAgent: string;
  deviceLabel: string;
}

export interface OwnerSession {
  sessionId: string;
  createdAt: number;
  lastActive: number;
  expiresAt: number; // 30 days
  email?: string;
  maskedEmail?: string;
  ip: string;
  userAgent: string;
  deviceLabel: string;
}

// In-memory registries
const authRequests = new Map<string, AuthRequest>();
const activeSessions = new Map<string, OwnerSession>();
const rateLimitByIp = new Map<string, { count: number; resetAt: number }>();

function formatDeviceLabel(userAgent: string): string {
  if (!userAgent) return 'Неизвестное устройство';
  let browser = 'Браузер';
  if (userAgent.includes('Edg/')) browser = 'Microsoft Edge';
  else if (userAgent.includes('Chrome/')) browser = 'Google Chrome';
  else if (userAgent.includes('Safari/') && !userAgent.includes('Chrome/')) browser = 'Apple Safari';
  else if (userAgent.includes('Firefox/')) browser = 'Mozilla Firefox';

  let os = 'Desktop';
  if (userAgent.includes('Android')) os = 'Android';
  else if (userAgent.includes('iPhone') || userAgent.includes('iPad')) os = 'iOS';
  else if (userAgent.includes('Windows')) os = 'Windows';
  else if (userAgent.includes('Mac OS')) os = 'macOS';
  else if (userAgent.includes('Linux')) os = 'Linux';

  return `${browser} (${os})`;
}

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitByIp.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitByIp.set(ip, { count: 1, resetAt: now + 10 * 60 * 1000 });
    return true;
  }
  if (entry.count >= 15) {
    return false;
  }
  entry.count++;
  return true;
}

function cleanupExpired() {
  const now = Date.now();
  for (const [id, req] of authRequests.entries()) {
    if (now > req.expiresAt && req.status !== 'completed') {
      authRequests.delete(id);
    }
  }
  for (const [sId, sess] of activeSessions.entries()) {
    if (now > sess.expiresAt) {
      activeSessions.delete(sId);
    }
  }
}
setInterval(cleanupExpired, 60000);

/**
 * Start a secure 2FA auth request
 * Users provide their own email address for receiving verification codes
 */
export async function startOwnerAuth(req: Request): Promise<{
  success: boolean;
  requestId?: string;
  botUsername?: string;
  botDeepLink?: string;
  expiresAt?: number;
  email?: string;
  maskedEmail?: string;
  error?: string;
}> {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'] || '';

  if (!checkRateLimit(clientIp)) {
    return {
      success: false,
      error: 'Слишком много попыток входа. Пожалуйста, подождите несколько минут.'
    };
  }

  const { email } = req.body || {};
  const cleanEmail = (typeof email === 'string' ? email.trim() : '');

  const requestId = crypto.randomBytes(16).toString('hex');
  const now = Date.now();
  const expiresAt = now + 10 * 60 * 1000; // 10 minutes

  const newRequest: AuthRequest = {
    requestId,
    createdAt: now,
    expiresAt,
    status: 'pending_telegram',
    email: cleanEmail || undefined,
    maskedEmail: cleanEmail ? maskEmail(cleanEmail) : undefined,
    otpAttempts: 0,
    ip: clientIp,
    userAgent,
    deviceLabel: formatDeviceLabel(userAgent)
  };

  authRequests.set(requestId, newRequest);

  // Get active bot info
  let botUsername = 'YourMusicBot';
  const botToken = getActiveBotToken();
  if (botToken) {
    try {
      const axios = (await import('axios')).default;
      const res = await axios.get(`https://api.telegram.org/bot${botToken}/getMe`, { timeout: 4000 });
      if (res.data?.result?.username) {
        botUsername = res.data.result.username;
      }
    } catch (e) {}
  }

  const botDeepLink = `https://t.me/${botUsername}?start=auth_${requestId}`;

  return {
    success: true,
    requestId,
    botUsername,
    botDeepLink,
    expiresAt,
    email: cleanEmail || undefined,
    maskedEmail: cleanEmail ? maskEmail(cleanEmail) : undefined
  };
}

/**
 * Get current state of an auth request
 */
export function getOwnerAuthStatus(requestId: string): {
  status: string;
  expiresAt: number;
  telegramVerified: boolean;
  email?: string;
  maskedEmail?: string;
  otpExpiresAt?: number;
  attemptsLeft?: number;
  error?: string;
} {
  const item = authRequests.get(requestId);
  if (!item) {
    return {
      status: 'expired',
      expiresAt: 0,
      telegramVerified: false,
      error: 'Сессия запроса не найдена или истекла'
    };
  }

  if (Date.now() > item.expiresAt && item.status !== 'completed') {
    item.status = 'expired';
  }

  return {
    status: item.status,
    expiresAt: item.expiresAt,
    telegramVerified: item.status === 'awaiting_email' || item.status === 'awaiting_email_otp' || item.status === 'completed',
    email: item.email,
    maskedEmail: item.maskedEmail,
    otpExpiresAt: item.otpExpiresAt,
    attemptsLeft: Math.max(0, 5 - item.otpAttempts)
  };
}

/**
 * Called by Telegram webhook when owner confirms login in bot
 */
export async function confirmTelegramAuthByBot(
  requestId: string,
  telegramUserId: string | number,
  telegramUsername?: string,
  chatIdToNotify?: string | number
): Promise<{ success: boolean; error?: string }> {
  const item = authRequests.get(requestId);
  if (!item) {
    return { success: false, error: 'Запрос на авторизацию не найден или истек' };
  }

  if (item.status !== 'pending_telegram') {
    return { success: false, error: `Запрос уже в статусе ${item.status}` };
  }

  if (Date.now() > item.expiresAt) {
    item.status = 'expired';
    return { success: false, error: 'Срок действия запроса истек' };
  }

  const cleanTgId = String(telegramUserId).trim();
  if (cleanTgId !== CHIEF_OWNER_TG_ID) {
    return {
      success: false,
      error: `Отказано. Ваш Telegram ID (${cleanTgId}) не совпадает с идентификатором главного владельца.`
    };
  }

  item.telegramUserId = cleanTgId;
  item.telegramUsername = telegramUsername;

  // If email was already supplied by user, generate and send OTP right away
  if (item.email && item.email.includes('@')) {
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    const otpHash = crypto.createHash('sha256').update(otpCode).digest('hex');
    const now = Date.now();

    item.status = 'awaiting_email_otp';
    item.otpHash = otpHash;
    item.otpExpiresAt = now + 5 * 60 * 1000;
    item.otpAttempts = 0;
    item.otpLastSentAt = now;

    // Send to user's entered email
    await sendOtpEmail(item.email, otpCode, {
      deviceLabel: item.deviceLabel,
      ip: item.ip
    });

    // Also send confirmation message to user in Telegram
    const targetChat = chatIdToNotify || cleanTgId;
    try {
      await sendTelegramMessage(
        targetChat,
        `🔐 <b>Код подтверждения входа в панель:</b>\n\n` +
        `Код: <code>${otpCode}</code>\n\n` +
        `⏱️ <i>Действует 5 минут.</i>\n` +
        `📧 <i>Отправлен на ваш email:</i> <code>${item.email}</code>\n\n` +
        `💻 <b>Устройство:</b> ${item.deviceLabel}\n` +
        `🌐 <b>IP:</b> <code>${item.ip}</code>\n\n` +
        `<i>Введите этот код на сайте для завершения входа.</i>`
      );
    } catch (err: any) {
      console.warn('[OwnerAuth] Telegram notify warning:', err.message);
    }
  } else {
    // If user hasn't typed an email yet, await user input in the UI
    item.status = 'awaiting_email';

    const targetChat = chatIdToNotify || cleanTgId;
    try {
      await sendTelegramMessage(
        targetChat,
        `✅ <b>Telegram подтверждён!</b>\n\n` +
        `Теперь введите ваш Email на сайте для получения 6-значного кода подтверждения.\n` +
        `💻 <b>Устройство:</b> ${item.deviceLabel}`
      );
    } catch (e) {}
  }

  return { success: true };
}

/**
 * Send or update Email and dispatch 6-digit OTP code to user-entered email
 */
export async function sendOwnerEmailOtp(
  requestId: string,
  userEmail: string
): Promise<{ success: boolean; maskedEmail?: string; error?: string }> {
  const item = authRequests.get(requestId);
  if (!item) {
    return { success: false, error: 'Запрос на авторизацию не найден или истек' };
  }

  const cleanEmail = (userEmail || '').trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
    return { success: false, error: 'Пожалуйста, введите корректный адрес электронной почты' };
  }

  const now = Date.now();
  if (item.otpLastSentAt && now - item.otpLastSentAt < 30000) {
    const waitSec = Math.ceil((30000 - (now - item.otpLastSentAt)) / 1000);
    return { success: false, error: `Подождите ${waitSec} сек. перед повторной отправкой` };
  }

  const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
  const otpHash = crypto.createHash('sha256').update(otpCode).digest('hex');

  item.email = cleanEmail;
  item.maskedEmail = maskEmail(cleanEmail);
  item.status = 'awaiting_email_otp';
  item.otpHash = otpHash;
  item.otpExpiresAt = now + 5 * 60 * 1000;
  item.otpAttempts = 0;
  item.otpLastSentAt = now;

  console.log(`[OwnerAuth] Sending 2FA OTP code to user email: ${cleanEmail}. Code: ${otpCode}`);

  // Send to user-entered email
  await sendOtpEmail(cleanEmail, otpCode, {
    deviceLabel: item.deviceLabel,
    ip: item.ip
  });

  // Also send push to owner's Telegram if user was verified
  if (item.telegramUserId) {
    try {
      await sendTelegramMessage(
        item.telegramUserId,
        `🔐 <b>Код подтверждения входа:</b> <code>${otpCode}</code>\n\n` +
        `📧 <i>Отправлен на адрес:</i> <code>${cleanEmail}</code>\n` +
        `⏱️ Действует 5 минут.`
      );
    } catch (e) {}
  }

  return {
    success: true,
    maskedEmail: item.maskedEmail
  };
}

/**
 * Cancel an auth request
 */
export function cancelTelegramAuthByBot(requestId: string): boolean {
  const item = authRequests.get(requestId);
  if (!item) return false;
  item.status = 'cancelled';
  return true;
}

/**
 * Resend Email OTP to the user-entered email
 */
export async function resendOwnerEmailOtp(requestId: string): Promise<{ success: boolean; error?: string }> {
  const item = authRequests.get(requestId);
  if (!item || !item.email) {
    return { success: false, error: 'Адрес электронной почты не указан' };
  }

  return sendOwnerEmailOtp(requestId, item.email);
}

/**
 * Verify 6-digit Email OTP and create server session
 */
export function verifyOwnerEmailOtp(
  requestId: string,
  userCode: string,
  res: Response
): { success: boolean; error?: string; session?: OwnerSession } {
  const item = authRequests.get(requestId);
  if (!item || item.status !== 'awaiting_email_otp') {
    return { success: false, error: 'Не удалось подтвердить вход. Сессия устарела или код не был запрошен.' };
  }

  const now = Date.now();
  if (item.otpExpiresAt && now > item.otpExpiresAt) {
    item.status = 'expired';
    return { success: false, error: 'Срок действия кода истек. Запросите новый код.' };
  }

  if (item.otpAttempts >= 5) {
    item.status = 'cancelled';
    return { success: false, error: 'Превышено максимальное число попыток ввода. Начните вход заново.' };
  }

  const cleanCode = String(userCode || '').trim().replace(/\s+/g, '');
  const testHash = crypto.createHash('sha256').update(cleanCode).digest('hex');

  if (testHash !== item.otpHash) {
    item.otpAttempts++;
    const left = 5 - item.otpAttempts;
    return {
      success: false,
      error: left > 0 ? `Неверный код. Осталось попыток: ${left}` : 'Превышен лимит попыток. Запросите новый код.'
    };
  }

  // Successful verification! Complete the auth request
  item.status = 'completed';

  const newSessionId = crypto.randomBytes(32).toString('hex');
  const sessionExpiresAt = now + 30 * 24 * 60 * 60 * 1000; // 30 days

  const newSession: OwnerSession = {
    sessionId: newSessionId,
    createdAt: now,
    lastActive: now,
    expiresAt: sessionExpiresAt,
    email: item.email,
    maskedEmail: item.maskedEmail,
    ip: item.ip,
    userAgent: item.userAgent,
    deviceLabel: item.deviceLabel
  };

  activeSessions.set(newSessionId, newSession);

  // Set HttpOnly, Secure, SameSite=Lax cookie
  res.cookie('owner_session', newSessionId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000,
    path: '/'
  });

  return { success: true, session: newSession };
}

/**
 * Validate owner session from Request
 */
export function getAuthenticatedOwnerSession(req: Request): OwnerSession | null {
  const cookieSession = req.cookies?.owner_session;
  const headerSession = (req.headers['x-owner-session'] as string) || '';
  const token = cookieSession || headerSession;

  if (!token) return null;

  const session = activeSessions.get(token);
  if (!session) return null;

  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return null;
  }

  session.lastActive = Date.now();
  return session;
}

/**
 * Terminate current session
 */
export function logoutOwner(req: Request, res: Response): boolean {
  const token = req.cookies?.owner_session || (req.headers['x-owner-session'] as string);
  if (token) {
    activeSessions.delete(token);
  }
  res.clearCookie('owner_session', { path: '/' });
  return true;
}

/**
 * List all active sessions
 */
export function listOwnerSessions(currentSessionId?: string) {
  const list: any[] = [];
  const now = Date.now();

  for (const [id, sess] of activeSessions.entries()) {
    if (now <= sess.expiresAt) {
      list.push({
        id,
        email: sess.email,
        maskedEmail: sess.maskedEmail,
        deviceLabel: sess.deviceLabel,
        ip: sess.ip,
        createdAt: sess.createdAt,
        lastActive: sess.lastActive,
        isCurrent: id === currentSessionId
      });
    }
  }

  return list.sort((a, b) => (b.lastActive || 0) - (a.lastActive || 0));
}

/**
 * Revoke specific session
 */
export function revokeOwnerSession(sessionId: string): boolean {
  return activeSessions.delete(sessionId);
}

/**
 * Revoke all sessions except current
 */
export function revokeAllOtherOwnerSessions(currentSessionId: string): number {
  let count = 0;
  for (const id of activeSessions.keys()) {
    if (id !== currentSessionId) {
      activeSessions.delete(id);
      count++;
    }
  }
  return count;
}
