import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { db } from '../src/db';
import { tokens } from '../src/db/schema';
import { eq } from 'drizzle-orm';

export interface ServerSupabaseConfig {
  url: string;
  anonKey: string;
  serviceRoleKey?: string;
  isConfigured: boolean;
  source: 'env' | 'custom' | 'none';
}

let serverClient: SupabaseClient | null = null;
let customServerConfig: { url: string; anonKey: string; serviceRoleKey?: string } | null = null;

export const DEFAULT_SUPABASE_URL = 'https://oeurpptqbkuxyqyfaahj.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_d4xsXd0ZQW8KUKWGHyOF0g_vXbj_mFo';

export function getServerSupabaseConfig(): ServerSupabaseConfig {
  const envUrl = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
  const envKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || '').trim();

  if (customServerConfig?.url && customServerConfig?.anonKey) {
    return {
      url: customServerConfig.url,
      anonKey: customServerConfig.anonKey,
      serviceRoleKey: customServerConfig.serviceRoleKey,
      isConfigured: true,
      source: 'custom'
    };
  }

  if (envUrl && envKey) {
    return {
      url: envUrl,
      anonKey: envKey,
      serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
      isConfigured: true,
      source: 'env'
    };
  }

  return {
    url: DEFAULT_SUPABASE_URL,
    anonKey: DEFAULT_SUPABASE_ANON_KEY,
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    isConfigured: true,
    source: 'env'
  };
}

export function setServerSupabaseConfig(url: string, anonKey: string, serviceRoleKey?: string) {
  customServerConfig = {
    url: url.trim(),
    anonKey: anonKey.trim(),
    serviceRoleKey: serviceRoleKey ? serviceRoleKey.trim() : undefined
  };
  serverClient = null;
}

export function getServerSupabaseClient(): SupabaseClient | null {
  const cfg = getServerSupabaseConfig();
  if (!cfg.isConfigured || !cfg.url || !cfg.anonKey) {
    return null;
  }

  if (serverClient) return serverClient;

  try {
    const keyToUse = cfg.serviceRoleKey || cfg.anonKey;
    serverClient = createClient(cfg.url, keyToUse, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      }
    });
    return serverClient;
  } catch (e) {
    console.error('Failed to create server Supabase client:', e);
    return null;
  }
}

/**
 * Sync all local server tokens (Yandex, VK, OK, Telegram) to Supabase auth_tokens table
 */
export async function syncLocalTokensToSupabase(userId: string = 'default_user') {
  const client = getServerSupabaseClient();
  if (!client) {
    throw new Error('Supabase не настроен на сервере');
  }

  const results: Record<string, any> = {};

  // 1. Yandex Token from SQLite
  try {
    const existingTokens = await db
      .select()
      .from(tokens)
      .where(eq(tokens.userId, userId))
      .limit(1);

    if (existingTokens.length > 0 && existingTokens[0].accessToken) {
      const yToken = existingTokens[0].accessToken;
      const { data, error } = await client.from('auth_tokens').upsert({
        user_id: userId,
        provider: 'yandex',
        token: yToken,
        refresh_token: existingTokens[0].refreshToken || null,
        expires_at: existingTokens[0].expiresAt || null,
        is_valid: true,
        updated_at: new Date().toISOString()
      }, { onConflict: 'user_id,provider' });

      results.yandex = { success: !error, error: error?.message };
    }
  } catch (err: any) {
    results.yandex = { success: false, error: err.message };
  }

  return results;
}

/**
 * Load tokens from Supabase auth_tokens table into local server storage
 */
export async function loadTokensFromSupabaseToServer(userId: string = 'default_user') {
  const client = getServerSupabaseClient();
  if (!client) {
    throw new Error('Supabase не настроен на сервере');
  }

  const { data, error } = await client
    .from('auth_tokens')
    .select('*')
    .eq('user_id', userId);

  if (error) {
    throw new Error(error.message);
  }

  const loaded: Record<string, any> = {};

  if (data && Array.isArray(data)) {
    for (const record of data) {
      loaded[record.provider] = {
        token: record.token,
        accountName: record.account_name,
        accountUid: record.account_uid,
        isValid: record.is_valid,
        updatedAt: record.updated_at
      };

      // If Yandex token, save to local SQLite so legacy routes also work
      if (record.provider === 'yandex' && record.token) {
        try {
          await db
            .insert(tokens)
            .values({
              userId,
              accessToken: record.token,
              refreshToken: record.refresh_token || '',
              expiresAt: record.expires_at || Math.floor(Date.now() / 1000) + 86400 * 365,
              updatedAt: Math.floor(Date.now() / 1000),
              apiCallsCount: 0,
            })
            .onConflictDoUpdate({
              target: tokens.userId,
              set: {
                accessToken: record.token,
                refreshToken: record.refresh_token || '',
                expiresAt: record.expires_at || Math.floor(Date.now() / 1000) + 86400 * 365,
                updatedAt: Math.floor(Date.now() / 1000),
              },
            });
        } catch (e) {
          console.error('Failed to sync Yandex token into SQLite:', e);
        }
      }
    }
  }

  return loaded;
}
