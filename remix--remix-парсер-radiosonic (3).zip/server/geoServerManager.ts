import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import { safeEncodeURIComponent } from './textSanitizer';

let loggerFn: ((level: string, cat: string, msg: string) => void) | null = null;

export function registerGeoLogger(fn: (level: string, cat: string, msg: string) => void) {
  loggerFn = fn;
}

function log(level: string, cat: string, msg: string) {
  if (loggerFn) {
    loggerFn(level, cat, msg);
  } else {
    console.log(`[${level.toUpperCase()}][${cat}] ${msg}`);
  }
}

export interface GeoNode {
  id: string;
  name: string;
  region: string;
  flag: string;
  type: 'direct' | 'proxy' | 'mirror' | 'custom';
  status: 'online' | 'degraded' | 'offline';
  latencyMs: number;
  failureCount: number;
  lastUsed?: number;
  urlTransformer?: (targetUrl: string) => string;
  proxyUrl?: string;
  headers?: Record<string, string>;
}

// Simulated Russian client IPs for geo-headers bypass
const RU_GEO_IPS = [
  '95.108.213.15', // Yandex Moscow range
  '178.62.204.88',  // SPB range
  '213.87.162.45',  // MTS Moscow
  '188.162.64.12',  // MegaFon RU
  '85.140.0.12',    // Beeline RU
  '94.25.170.33'    // Rostelecom
];

function getRandomRuIp(): string {
  return RU_GEO_IPS[Math.floor(Math.random() * RU_GEO_IPS.length)];
}

// Built-in Geo Nodes with multiple regions & fallback protocols
export const GEO_NODES: GeoNode[] = [
  {
    id: 'node-direct',
    name: 'Прямое подключение (Direct Node)',
    region: 'Default Cloud Region',
    flag: '⚡',
    type: 'direct',
    status: 'online',
    latencyMs: 45,
    failureCount: 0,
    headers: {
      'X-Forwarded-For': getRandomRuIp(),
      'X-Real-IP': getRandomRuIp(),
    }
  },
  {
    id: 'node-ru-mirror-1',
    name: 'Резервный RU/CIS Шлюз #1 (CodeTabs Geo-Relay)',
    region: 'CIS / RU Relay Gateway',
    flag: '🇷🇺',
    type: 'mirror',
    status: 'online',
    latencyMs: 120,
    failureCount: 0,
    urlTransformer: (url: string) => `https://api.codetabs.com/v1/proxy?quest=${safeEncodeURIComponent(url)}`,
    headers: {
      'X-Forwarded-For': getRandomRuIp(),
    }
  },
  {
    id: 'node-eu-mirror-2',
    name: 'Европейский Прокси-Зеркало #2 (AllOrigins Raw)',
    region: 'Europe Central / Global Mirror',
    flag: '🇪🇺',
    type: 'mirror',
    status: 'online',
    latencyMs: 180,
    failureCount: 0,
    urlTransformer: (url: string) => `https://api.allorigins.win/raw?url=${safeEncodeURIComponent(url)}`,
    headers: {
      'X-Forwarded-For': getRandomRuIp(),
    }
  },
  {
    id: 'node-corsproxy-3',
    name: 'Резервный Global Gateway #3 (CorsProxy IO)',
    region: 'Global Geo Relay',
    flag: '🌐',
    type: 'mirror',
    status: 'online',
    latencyMs: 210,
    failureCount: 0,
    urlTransformer: (url: string) => `https://corsproxy.io/?${safeEncodeURIComponent(url)}`,
  },
  {
    id: 'node-yandex-mobile-4',
    name: 'Мобильный шлюз Яндекс API (Android MC Protocol)',
    region: 'RU Mobile Network Bypass',
    flag: '📱',
    type: 'direct',
    status: 'online',
    latencyMs: 90,
    failureCount: 0,
    headers: {
      'X-Yandex-Music-Client': 'YandexMusicAndroid/24023621 (mc)',
      'X-Forwarded-For': '95.108.213.15',
      'X-Real-IP': '95.108.213.15',
      'User-Agent': 'Yandex-Music-API',
    }
  }
];

let customProxies: GeoNode[] = [];
let activeRoutingMode: 'auto' | 'direct_only' | 'ru_gateway' | 'eu_gateway' = 'auto';

export function getActiveGeoNodes(): GeoNode[] {
  return [...GEO_NODES, ...customProxies];
}

export function setCustomProxies(proxies: { url: string; name?: string }[]) {
  customProxies = proxies.map((p, idx) => ({
    id: `custom-proxy-${idx + 1}`,
    name: p.name || `Пользовательский сервер #${idx + 1}`,
    region: 'Custom Proxy Network',
    flag: '🛡️',
    type: 'custom',
    status: 'online',
    latencyMs: 150,
    failureCount: 0,
    proxyUrl: p.url
  }));
}

export function getRoutingMode() {
  return activeRoutingMode;
}

export function setRoutingMode(mode: 'auto' | 'direct_only' | 'ru_gateway' | 'eu_gateway') {
  activeRoutingMode = mode;
  log('info', 'system', `Режим гео-маршрутизации переключен на: ${mode}`);
}

/**
 * Intelligent Geo-Bypass Request Executor
 * Automatically retries across different geographic server nodes when geo-blocks occur.
 */
export async function executeWithGeoFailover(
  url: string,
  config: {
    token?: string;
    headers?: Record<string, string>;
    timeout?: number;
    responseType?: any;
    maxRetries?: number;
  } = {}
): Promise<{ data: any; usedNode: GeoNode; status: number }> {
  const allNodes = getActiveGeoNodes();
  const maxRetries = config.maxRetries ?? allNodes.length;
  const baseTimeout = config.timeout || 8000;
  
  let lastError: any = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const nodeIndex = attempt % allNodes.length;
    const node = allNodes[nodeIndex];

    // Build the request target URL safely
    let targetUrl = url;
    if (node.urlTransformer) {
      try {
        targetUrl = node.urlTransformer(url);
      } catch (e) {
        targetUrl = url;
      }
    }

    // Build headers including Geo spoofing and auth tokens
    const reqHeaders: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'X-Forwarded-For': getRandomRuIp(),
      'X-Real-IP': getRandomRuIp(),
      ...(config.headers || {}),
      ...(node.headers || {})
    };

    if (config.token) {
      reqHeaders['Authorization'] = `OAuth ${config.token}`;
    }

    let agent: any = undefined;
    if (node.proxyUrl) {
      try {
        agent = node.proxyUrl.startsWith('socks') 
          ? new SocksProxyAgent(node.proxyUrl) 
          : new HttpsProxyAgent(node.proxyUrl);
      } catch (e) {}
    }

    const startTime = Date.now();
    try {
      const response = await axios.get(targetUrl, {
        headers: reqHeaders,
        timeout: baseTimeout,
        responseType: config.responseType,
        httpsAgent: agent,
        httpAgent: agent,
        validateStatus: () => true // handle all statuses manually
      });

      const latency = Date.now() - startTime;
      node.latencyMs = latency;
      node.lastUsed = Date.now();

      // Check if status is a geo-block or rate-limit
      const isGeoBlocked = response.status === 451 || 
                           response.status === 403 || 
                           response.data?.error?.name === "Unavailable For Legal Reasons" ||
                           response.data?.result?.name === "track-download-info-error" ||
                           (response.data?.error && String(response.data.error).includes('no-rights'));

      const isRateLimited = response.status === 429;
      const isSuccess = response.status >= 200 && response.status < 300 && !isGeoBlocked;

      if (isSuccess && response.data) {
        node.status = 'online';
        node.failureCount = 0;
        return { data: response.data, usedNode: node, status: response.status };
      }

      // If blocked or error, log and fallback to next node
      node.failureCount++;
      if (node.failureCount > 2) node.status = 'degraded';

      const reason = isGeoBlocked ? 'HTTP 451 (Гео-блокировка/Права)' : (isRateLimited ? 'HTTP 429 (Лимит)' : `HTTP ${response.status}`);
      log('warn', 'proxy', `Сервер [${node.name}] вернул ${reason} для ${url}. Переключение на резервный гео-узел...`);
      lastError = new Error(`Node ${node.name} failed with ${reason}`);
    } catch (err: any) {
      node.failureCount++;
      node.status = 'degraded';
      const errMsg = err.code === 'ECONNABORTED' ? 'Таймаут' : (err.message || 'Ошибка сети');
      log('warn', 'proxy', `Сбой узла [${node.name}]: ${errMsg}. Авто-переключение на запасной сервер...`);
      lastError = err;
    }

    // Small delay between fallback nodes
    await new Promise(r => setTimeout(r, 400));
  }

  log('error', 'proxy', `Все ${allNodes.length} гео-серверов исчерпаны для ${url}: ${lastError?.message}`);
  throw lastError || new Error(`Не удалось получить данные через гео-серверы: ${url}`);
}
