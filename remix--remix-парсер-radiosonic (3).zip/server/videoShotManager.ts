import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import os from 'os';
import axios from 'axios';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';

const ffmpegBinary = ffmpegInstaller?.path || 'ffmpeg';

// Temporary directory for converted videoshots
const VIDEOSHOT_DIR = path.join(os.tmpdir(), 'videoshots');
if (!fs.existsSync(VIDEOSHOT_DIR)) {
  fs.mkdirSync(VIDEOSHOT_DIR, { recursive: true });
}

export interface ConvertVideoShotOptions {
  startTime?: number;
  duration?: number;
  cropMode?: 'crop_center' | 'blur_pad' | 'fit_pad' | 'scale_stretch';
  muteAudio?: boolean;
  fps?: number;
  preset?: 'yandex' | 'spotify' | 'deezer' | 'custom';
  targetWidth?: number;
  targetHeight?: number;
}

export interface VideoShotResult {
  success: boolean;
  fileName: string;
  originalName: string;
  duration: number;
  resolution: string;
  aspectRatio: string;
  codec: string;
  container: string;
  fileSizeBytes: number;
  fileSizeFormatted: string;
  streamUrl: string;
  downloadUrl: string;
}

/**
 * Converts any user uploaded video into exact Yandex Music / Spotify Canvas Video Shot specs:
 * - Format: MP4 (H.264 codec, yuv420p)
 * - Resolution: 404x720 px (9:16 vertical, customizable to Spotify 720x1280 or Deezer 1080x1920)
 * - Duration: 5 - 20 seconds (loopable)
 * - Crop/Fit: Center 9:16 crop, Blur pad, or Fit
 */
export async function convertToVideoShot(
  inputPath: string,
  originalName: string,
  options: ConvertVideoShotOptions = {}
): Promise<VideoShotResult> {
  const startTime = Math.max(0, Number(options.startTime || 0));
  // Technical specs: 5 to 20 seconds
  const rawDuration = Number(options.duration || 15);
  const duration = Math.min(20, Math.max(5, isNaN(rawDuration) ? 15 : rawDuration));
  const cropMode = options.cropMode || 'crop_center';
  const muteAudio = options.muteAudio !== false; // default muted for clean loop
  const fps = Number(options.fps || 30);

  // Resolution presets
  let targetW = 404;
  let targetH = 720;
  if (options.preset === 'spotify') {
    targetW = 720;
    targetH = 1280;
  } else if (options.preset === 'deezer') {
    targetW = 1080;
    targetH = 1920;
  } else if (options.targetWidth && options.targetHeight) {
    targetW = Math.max(200, Math.min(1920, Number(options.targetWidth)));
    targetH = Math.max(200, Math.min(1920, Number(options.targetHeight)));
  }

  // Ensure even dimensions for H.264 / yuv420p
  if (targetW % 2 !== 0) targetW += 1;
  if (targetH % 2 !== 0) targetH += 1;

  const uniqueId = `vs_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const outputFileName = `${uniqueId}.mp4`;
  const outputPath = path.join(VIDEOSHOT_DIR, outputFileName);

  return new Promise((resolve, reject) => {
    let filterArgs: string[] = [];

    if (cropMode === 'blur_pad') {
      // Background blurred, foreground centered without losing any frame content
      const complexFilter = `[0:v]scale=${targetW}:${targetH}:force_original_aspect_ratio=increase,crop=${targetW}:${targetH},boxblur=25:5[bg];[0:v]scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1`;
      filterArgs = ['-filter_complex', complexFilter];
    } else if (cropMode === 'fit_pad') {
      // Black letterbox bars
      filterArgs = [
        '-vf',
        `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease,pad=${targetW}:${targetH}:(${targetW}-iw)/2:(${targetH}-ih)/2:black,setsar=1`
      ];
    } else if (cropMode === 'scale_stretch') {
      // Direct stretch
      filterArgs = ['-vf', `scale=${targetW}:${targetH},setsar=1`];
    } else {
      // Default: crop_center (center 9:16 crop, filling entire target frame without bars)
      filterArgs = [
        '-vf',
        `scale=${targetW}:${targetH}:force_original_aspect_ratio=increase,crop=${targetW}:${targetH}:(in_w-${targetW})/2:(in_h-${targetH})/2,setsar=1`
      ];
    }

    const ffmpegArgs: string[] = [
      '-y',
      '-ss', String(startTime),
      '-t', String(duration),
      '-i', inputPath,
      ...filterArgs,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '22',
      '-pix_fmt', 'yuv420p',
      '-r', String(fps),
      '-movflags', '+faststart'
    ];

    if (muteAudio) {
      ffmpegArgs.push('-an');
    } else {
      ffmpegArgs.push('-c:a', 'aac', '-b:a', '192k');
    }

    ffmpegArgs.push(outputPath);

    console.log(`[VIDEOSHOT] Converting ${inputPath} -> ${outputPath} (target=${targetW}x${targetH}, cropMode=${cropMode}, dur=${duration}s)`);

    const proc = spawn(ffmpegBinary, ffmpegArgs);
    let stderr = '';

    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    proc.on('close', (code) => {
      if (code === 0 && fs.existsSync(outputPath)) {
        const stats = fs.statSync(outputPath);
        const sizeFormatted = (stats.size / (1024 * 1024)).toFixed(2) + ' МБ';

        resolve({
          success: true,
          fileName: outputFileName,
          originalName,
          duration,
          resolution: `${targetW}x${targetH}`,
          aspectRatio: '9:16',
          codec: 'H.264 (libx264)',
          container: 'MP4',
          fileSizeBytes: stats.size,
          fileSizeFormatted: sizeFormatted,
          streamUrl: `/api/videoshot/stream/${outputFileName}`,
          downloadUrl: `/api/videoshot/download/${outputFileName}?title=${encodeURIComponent(
            path.basename(originalName, path.extname(originalName))
          )}`
        });
      } else {
        console.error('[VIDEOSHOT ERROR]', stderr);
        reject(new Error(`Ошибка конвертации видео: ${stderr.slice(-300) || 'Код ошибки ' + code}`));
      }
    });

    proc.on('error', (err) => {
      reject(err);
    });
  });
}

/**
 * Generates an animated 9:16 vertical video snippet for Deezer/Spotify tracks that only have audio preview
 */
export async function generateSnippetVideo(
  audioUrl: string,
  coverUrl: string,
  title: string,
  artist: string
): Promise<string> {
  const safeTitle = title.replace(/[^a-zA-Z0-9а-яА-ЯёЁ _-]/g, '').trim() || 'Track';
  const uniqueId = `snippet_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const outputFileName = `${uniqueId}.mp4`;
  const outputPath = path.join(VIDEOSHOT_DIR, outputFileName);

  // Download cover and audio to temp files
  const tmpCover = path.join(os.tmpdir(), `${uniqueId}_cover.jpg`);
  const tmpAudio = path.join(os.tmpdir(), `${uniqueId}_audio.mp3`);

  try {
    const [covRes, audRes] = await Promise.all([
      axios.get(coverUrl, { responseType: 'arraybuffer', timeout: 8000 }),
      axios.get(audioUrl, { responseType: 'arraybuffer', timeout: 10000 })
    ]);
    fs.writeFileSync(tmpCover, Buffer.from(covRes.data));
    fs.writeFileSync(tmpAudio, Buffer.from(audRes.data));

    return new Promise((resolve, reject) => {
      // Generate vertical 404x720 looping snippet with cover background blur + rotating vinyl/cover art
      const filterComplex = 
        `[0:v]scale=404:720:force_original_aspect_ratio=increase,crop=404:720,boxblur=25:5[bg];` +
        `[0:v]scale=320:320,pad=324:324:2:2:white@0.3[fg];` +
        `[bg][fg]overlay=(W-w)/2:(H-h)/2-40[v]`;

      const ffmpegArgs = [
        '-y',
        '-loop', '1',
        '-i', tmpCover,
        '-i', tmpAudio,
        '-filter_complex', filterComplex,
        '-map', '[v]',
        '-map', '1:a',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '22',
        '-pix_fmt', 'yuv420p',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-t', '15',
        '-movflags', '+faststart',
        outputPath
      ];

      const proc = spawn(ffmpegBinary, ffmpegArgs);
      proc.on('close', (code) => {
        try { fs.unlinkSync(tmpCover); } catch (e) {}
        try { fs.unlinkSync(tmpAudio); } catch (e) {}

        if (code === 0 && fs.existsSync(outputPath)) {
          resolve(outputFileName);
        } else {
          reject(new Error('Не удалось сгенерировать сниппет'));
        }
      });
      proc.on('error', (err) => {
        try { fs.unlinkSync(tmpCover); } catch (e) {}
        try { fs.unlinkSync(tmpAudio); } catch (e) {}
        reject(err);
      });
    });
  } catch (err: any) {
    try { fs.unlinkSync(tmpCover); } catch (e) {}
    try { fs.unlinkSync(tmpAudio); } catch (e) {}
    throw err;
  }
}

/**
 * Fetches Spotify Canvas from public canvas mirrors / cache
 */
export async function fetchSpotifyCanvas(spotifyTrackId: string): Promise<{ canvasUrl?: string; artistName?: string } | null> {
  const cleanId = spotifyTrackId.replace(/^spotify:track:/, '').replace(/^sp_/, '').trim();
  if (!cleanId || cleanId.length < 10) return null;

  try {
    // 1. Try canvas cache mirror
    const res = await axios.get(`https://generic.wg.spotify.com/canvaz-cache/v0/canvases`, {
      params: { track: `spotify:track:${cleanId}` },
      headers: {
        'User-Agent': 'Spotify/8.8.84 Android/33 (mc)'
      },
      timeout: 3000,
      validateStatus: (s) => s < 500
    });

    if (res.data?.canvases?.[0]?.canvas_url) {
      return {
        canvasUrl: res.data.canvases[0].canvas_url,
        artistName: res.data.canvases[0].artist?.name
      };
    }
  } catch (e) {}

  // 2. Try alternative Canvas gateway
  try {
    const canvasRes = await axios.get(`https://canvas-api.deno.dev/canvas/${cleanId}`, {
      timeout: 3500,
      validateStatus: (s) => s === 200
    });
    if (canvasRes.data?.canvas_url) {
      return { canvasUrl: canvasRes.data.canvas_url };
    }
  } catch (e) {}

  return null;
}

export function getVideoshotFilePath(fileName: string): string | null {
  const clean = path.basename(fileName);
  const fullPath = path.join(VIDEOSHOT_DIR, clean);
  return fs.existsSync(fullPath) ? fullPath : null;
}
