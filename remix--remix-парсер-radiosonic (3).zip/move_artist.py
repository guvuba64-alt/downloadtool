import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

# 1. Change `{true ? (` to `{activeAppTab === "parser" && (`
content = content.replace('{true ? (', '{activeAppTab === "parser" && (')
content = content.replace(') : null}', ')}')

# 2. Extract artist block
# The block starts at `{metadataResult && metadataResult.type === "artist" ? (`
# and ends right before `</div>\n            {/* Manual Parse Block */}`
artist_start = content.find('{metadataResult && metadataResult.type === "artist" ? (')
artist_end = content.find(') : null}\n            </div>\n\n            {/* Manual Parse Block */}')

if artist_start != -1 and artist_end != -1:
    artist_block = content[artist_start:artist_end + 9] # includes `) : null}`
    
    # Remove it from the original location
    content = content[:artist_start] + content[artist_end + 10:]
    
    # We want to change metadataResult to artistResult inside artist_block
    # But wait, the original block checks `{metadataResult && metadataResult.type === "artist" ? (`
    # We will strip that ternary condition and just use the inner <div>
    
    inner_block_start = artist_block.find('<div className="flex flex-col')
    inner_block = artist_block[inner_block_start:-10] # drop `) : null}`
    inner_block = inner_block.replace('metadataResult', 'artistResult')
    
    # Construct the new Artist Tab content
    artist_tab = f"""
        {{activeAppTab === "artist" && (
          <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden">
             <div className="p-6 border-b border-zinc-100 dark:border-white/5">
                <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-zinc-50 mb-1">{{t("Artist Metadata", "Метаданные артиста")}}</h3>
                <form onSubmit={{handleFetchArtist}} className="flex flex-col gap-3">
                   <input 
                      value={{artistUrl}}
                      onChange={{(e) => setArtistUrl(e.target.value)}}
                      placeholder="https://music.yandex.ru/artist/..."
                      className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-all"
                      required
                   />
                   <button type="submit" disabled={{isFetchingArtist}} className="w-full bg-black dark:bg-white text-white dark:text-black font-semibold py-3 px-6 rounded-2xl transition-colors flex items-center justify-center">
                      {{isFetchingArtist ? <RefreshCw className="w-5 h-5 animate-spin mx-auto" /> : t("Fetch Artist", "Получить артиста")}}
                   </button>
                </form>
                {{artistError && <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg border border-red-100">{{artistError}}</div>}}
             </div>
             {{artistResult && artistResult.type === "artist" && (
                {inner_block}
             )}}
          </div>
        )}}
"""
    
    # Insert artist tab at the end of the parser block
    # The parser block ends where the old `) : null}` was, which we replaced with `)}`
    # Let's insert it before `</>` at the end of the main content block
    
    # Actually, we replaced `) : null}` with `)}` near the end of the file.
    # Let's find `          </>\n        )}`
    insert_pos = content.find('          </>\n        )}')
    if insert_pos != -1:
        content = content[:insert_pos + 23] + artist_tab + content[insert_pos + 23:]

with open('src/App.tsx', 'w') as f:
    f.write(content)
