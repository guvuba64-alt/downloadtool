const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');

const oldDownload = `  const handleDownload = async () => {
    // cover 3000x3000
    if (albumCover) {
      const highResCover = albumCover.replace(/\\/\\d+x\\d+$/, '/3000x3000');
      try {
        const res = await fetch(highResCover);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = \`\${track.title || 'cover'}_cover.jpg\`;
        a.click();
      } catch (e) {
        window.open(highResCover, '_blank');
      }
    }
    // audio as wav
    if (src) {
      try {
        const a = document.createElement('a');
        a.href = src;
        a.download = \`\${track.title || 'audio'}.wav\`;
        a.click();
      } catch (e) {
        window.open(src, '_blank');
      }
    }
  };`;

const newDownload = `  const handleDownload = async () => {
    // cover 3000x3000
    if (albumCover) {
      const cleanCover = albumCover.startsWith("http") ? albumCover : "https://" + albumCover;
      const highResCover = cleanCover.replace("%%", "3000x3000").replace(/\\/\\d+x\\d+$/, '/3000x3000');
      try {
        const res = await fetch(highResCover);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = \`\${track.title || 'cover'}_cover.jpg\`;
        a.click();
      } catch (e) {
        window.open(highResCover, '_blank');
      }
    }
    // audio as wav
    if (src) {
      try {
        const a = document.createElement('a');
        a.href = src;
        a.download = \`\${track.title || 'audio'}.wav\`;
        a.click();
      } catch (e) {
        window.open(src, '_blank');
      }
    }
  };`;

code = code.replace(oldDownload, newDownload);
fs.writeFileSync('src/components/ModernPlayer/index.tsx', code);
console.log('Fixed download URL generation');
