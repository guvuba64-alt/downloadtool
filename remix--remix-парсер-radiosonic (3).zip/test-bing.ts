import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://www.bing.com/search?q=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
});
const titleMatch = r.data.match(/<h2[^>]*><a[^>]*>(.*?)<\/a><\/h2>/) || r.data.match(/<strong>(.*?)<\/strong>/g);
console.log(r.status, "Match:", titleMatch);
