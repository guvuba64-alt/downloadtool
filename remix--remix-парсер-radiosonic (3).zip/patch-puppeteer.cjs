const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf-8');

const puppeteerFunc = `
// ============================================================================
// TRUE CDP HEADLESS NETWORK INTERCEPTOR (Automated DevTools Protocol)
// ============================================================================
async function interceptOkRuNetworkResponse(trackId: string): Promise<any> {
  const cleanId = String(trackId).replace(/^(?:okru_|dz_|it_|ya_)/, '');
  let browser;
  try {
    const activeProxy = okProxyConfig.enabled ? parseProxyString(okProxyConfig.proxyUrl) : null;
    const puppeteerArgs = [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu'
    ];
    if (activeProxy) {
      puppeteerArgs.push(activeProxy.puppeteerArg);
    }

    browser = await puppeteer.launch({ 
      args: puppeteerArgs,
      headless: true
    });
    const page = await browser.newPage();
    
    // Inject authenticated cookies to bypass login
    if (okCookies && okCookies.length > 0) {
      const pCookies = okCookies.map(c => ({
        name: c.name,
        value: c.value,
        domain: '.ok.ru',
        path: '/'
      }));
      await page.setCookie(...pCookies);
    }

    let interceptedData = null;

    // Use Chrome DevTools Protocol to intercept Network responses
    page.on('response', async (response) => {
      const url = response.url();
      if (url.includes('web-api/music/play') || url.includes('play;jsessionid')) {
        try {
          const json = await response.json();
          if (json && (json.track || json.copyrightOwnerName)) {
            interceptedData = json;
          }
        } catch (e) {}
      }
    });

    // Trigger the exact API call from within the page context to ensure pure DevTools capture
    await page.goto('https://ok.ru/music', { waitUntil: 'domcontentloaded', timeout: 15000 });
    
    // Execute the fetch in the browser context (so it's exactly like the real web app)
    interceptedData = await page.evaluate(async (tid) => {
      try {
        const res = await fetch('/web-api/music/play', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: 'trackId=' + tid
        });
        const data = await res.json();
        return data;
      } catch (e) {
        return null;
      }
    }, cleanId);

    if (interceptedData && (interceptedData.track || interceptedData.copyrightOwnerName)) {
      return interceptedData;
    }
  } catch (e) {
    console.error('CDP Intercept Error:', e);
  } finally {
    if (browser) {
      await browser.close().catch(()=>0);
    }
  }
  return null;
}
`;

// Insert the new function before getOkAudioStreamUrl
code = code.replace('export async function getOkAudioStreamUrl', puppeteerFunc + '\nexport async function getOkAudioStreamUrl');

// Update getOkAudioStreamUrl to use the new CDP interceptor FIRST
const newGetUrl = `
export async function getOkAudioStreamUrl(trackId: string | number): Promise<{ playUrl?: string; track?: any; copyrightOwnerName?: string; copyrightOwnerId?: number | string; deepScan?: any; error?: string; imageUrl?: string }> {
  await ensureAutoOkRuSession();
  const cleanId = String(trackId).replace(/^(?:okru_|dz_|it_|ya_)/, '');

  // 1. TRUE CDP HEADLESS BROWSER INTERCEPTOR (User Requested)
  const cdpData = await interceptOkRuNetworkResponse(cleanId);
  if (cdpData && (cdpData.track || cdpData.copyrightOwnerName || cdpData.play)) {
    const trackData: any = cdpData.track || {};
    const meta: any = extractTrackMetadata(trackData) || extractTrackMetadata(cdpData) || {};
    return {
      playUrl: cdpData.play || meta.playUrl || trackData.playUrl,
      track: trackData,
      copyrightOwnerName: trackData.copyrightOwnerName || meta.copyrightOwnerName || meta.copyright,
      copyrightOwnerId: trackData.copyrightOwnerId ?? meta.copyrightOwnerId,
      imageUrl: meta.coverUri || trackData.imageUrl,
      deepScan: meta.deepScan
    };
  }
`;

code = code.replace(/export async function getOkAudioStreamUrl[\s\S]*?\/\/ 1\. Primary DevTools Network Endpoint.*?try \{/m, newGetUrl + '\n  // 2. Direct HTTP Fallback\n  try {');

fs.writeFileSync('server-okru.ts', code);
