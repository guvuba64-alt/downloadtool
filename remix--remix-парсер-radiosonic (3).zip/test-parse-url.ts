import { parseOkRuUrl } from './server-okru.js';
parseOkRuUrl("https://ok.ru/music/search/Tones%20And%20I%20Dance%20Monkey").then(r => console.dir(r, {depth:null}));
