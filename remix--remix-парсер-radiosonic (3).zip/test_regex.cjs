const fs = require('fs');
let code = `
await fetch("/api/okru/login", {
await fetch(\`/api/music/download/\${track.id}\`);
await fetch('/api/token');
await fetch(coverUrl);
`;
code = code.replace(/fetch\((["'\`])\/api\//g, "fetchWithRetry($1/api/");
console.log(code);
