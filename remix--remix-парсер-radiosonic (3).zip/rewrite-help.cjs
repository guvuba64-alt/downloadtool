const fs = require('fs');

const newHelp = `import React from 'react';
import { HelpCircle, FileText, Music, Send, Key, Shield, Layers, Code, Settings, Link2 } from 'lucide-react';

export const HelpModal = ({ onClose, t }: { onClose: () => void, t: any }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        <div className="p-6 border-b border-zinc-200 dark:border-zinc-800 shrink-0 flex items-center gap-3 bg-zinc-50 dark:bg-white/5">
          <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-zinc-900 dark:text-white tracking-tight">{t("Detailed Guide", "Подробное руководство")}</h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">{t("Everything you need to know about the app", "Всё, что вам нужно знать о приложении")}</p>
          </div>
        </div>

        <div className="overflow-y-auto p-6 space-y-10 custom-scrollbar">
          
          {/* 1. Architecture */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-500" />
              1. Что за что отвечает (Архитектура)
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 leading-relaxed">
              Приложение состоит из <strong>трех главных модулей</strong>, которые работают в связке, но могут использоваться и по отдельности:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-indigo-50 dark:bg-indigo-900/10 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-900/30">
                <h4 className="font-bold text-indigo-900 dark:text-indigo-300 mb-2">1. Сбор данных (Парсеры)</h4>
                <p className="text-xs text-indigo-800 dark:text-indigo-400">Модули для поиска и извлечения метаданных (UPC, ISRC, авторы, обложки) с музыкальных площадок, таких как Яндекс Музыка, Spotify, Звук и VK.</p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                <h4 className="font-bold text-emerald-900 dark:text-emerald-300 mb-2">2. Обработка (Отчёты)</h4>
                <p className="text-xs text-emerald-800 dark:text-emerald-400">Генератор PDF-документов. Принимает сырые данные (таблицы CSV), рассчитывает формулы (проценты, роялти) и рисует красивые дизайнерские PDF-отчеты с графиками.</p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/10 p-4 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-2">3. Доставка (Telegram)</h4>
                <p className="text-xs text-blue-800 dark:text-blue-400">Система массовой рассылки. Берет сгенерированные PDF-отчеты или любые другие файлы и автоматически отправляет их артистам через вашего Telegram-бота.</p>
              </div>
            </div>
          </section>

          {/* 2. Tabs and Features */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5 text-emerald-500" />
              2. Подробно по всем вкладкам
            </h3>
            <div className="space-y-4">
              
              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Music className="w-4 h-4"/> Вкладки: Поиск и Моя Волна</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем это:</strong> Это встроенный музыкальный плеер. Он позволяет вам находить артистов, альбомы и слушать треки прямо здесь, не открывая сторонние приложения.</p>
                  <p><strong>Как работает:</strong> Ввели имя -> Нажали поиск. Приложение делает запрос к публичной базе данных и возвращает список. "Моя Волна" использует алгоритмы Яндекса для бесконечного потока рекомендаций на основе ваших прослушиваний.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><FileText className="w-4 h-4"/> Вкладка: Отчёты (PDF Генератор)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем это:</strong> Дистрибьюторы присылают огромные и сложные таблицы Excel/CSV с роялти. Артисты не умеют их читать. Этот инструмент превращает скучные цифры в понятный документ.</p>
                  <p><strong>Как работает:</strong> Вы загружаете логотип своего лейбла, подпись директора, и файл с данными. Приложение суммирует доходы по каждому треку, отрезает процент лейбла (например, 30%), и генерирует готовый PDF-акт для артиста.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Send className="w-4 h-4"/> Вкладка: Журнал (Логи Telegram)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем это:</strong> Чтобы вы точно знали, что отчет дошел до получателя. Массовая рассылка может давать сбои, если артист случайно заблокировал вашего бота.</p>
                  <p><strong>Как работает:</strong> При рассылке из вкладки "Отчёты", здесь появляются записи: "Отправлено" (Зеленый статус) или "Ошибка 400" (Красный статус). Если статус красный — значит Telegram не смог доставить сообщение (ошибка ID или блокировка).</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Link2 className="w-4 h-4"/> Вкладка: Универсальный парсер</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем это:</strong> Сбор всех кодов (ISRC, UPC) и смарт-ссылок на все площадки (VK, Spotify, Apple) в одном месте.</p>
                  <p><strong>Как работает:</strong> Вставляете ссылку на релиз Яндекса. Парсер извлекает из него авторов, названия и коды, а затем использует эти данные, чтобы сделать скрытые поисковые запросы по остальным платформам и собрать вам общую картину релиза.</p>
                </div>
              </div>

            </div>
          </section>

          {/* 3. APIs, Tokens, and Codes */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2">
              <Key className="w-5 h-5 text-amber-500" />
              3. Токены, API и Коды — что это и почему они нужны?
            </h3>
            <div className="space-y-4 text-sm text-zinc-600 dark:text-zinc-400">
              
              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border-l-4 border-amber-500 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-base mb-2">Что такое API? (Application Programming Interface)</h4>
                <p>Представьте, что <strong>API — это официант в ресторане</strong>. Вы (приложение) даете ему заказ ("Принеси мне данные о треке" или "Отправь сообщение"). Официант идет на кухню (на сервер Telegram или Spotify) и приносит вам готовое блюдо (результат). Без API программы просто не смогли бы разговаривать друг с другом.</p>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border-l-4 border-blue-500 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-base mb-2">Что такое Токен (Token / API Key)?</h4>
                <p>Возвращаясь к аналогии ресторана — это ваш <strong>VIP-пропуск</strong>. Ресторан (API) не обслуживает кого попало с улицы. Ему нужно доказательство того, что вы имеете право делать заказы. Токен — это длинный уникальный набор букв и цифр, который выдают только вам.</p>
                <p className="mt-2 text-xs opacity-80">Например, Telegram Bot Token доказывает серверам Telegram, что именно ВЫ владеете конкретным ботом, и вам разрешено рассылать от него сообщения.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="bg-zinc-100 dark:bg-white/5 p-4 rounded-xl">
                  <h5 className="font-bold text-zinc-900 dark:text-zinc-100 mb-1 flex items-center gap-1"><Code className="w-4 h-4 text-purple-500"/> ISRC и UPC коды</h5>
                  <p className="text-xs mt-1 leading-relaxed">
                    <strong>UPC (Universal Product Code)</strong> — это штрих-код всего альбома/релиза. Как штрих-код на пачке молока в магазине.<br/><br/>
                    <strong>ISRC (International Standard Recording Code)</strong> — это уникальный номер конкретного аудио-трека. По нему музыкальные площадки понимают, что "Трек А" в Альбоме 1 — это тот же самый трек, что и "Трек А" в Сборнике 2. По ним рассчитывают ваши деньги!
                  </p>
                </div>
                
                <div className="bg-zinc-100 dark:bg-white/5 p-4 rounded-xl">
                  <h5 className="font-bold text-zinc-900 dark:text-zinc-100 mb-1">Зачем мы просим ручные вводы (JSON/Cookies)?</h5>
                  <p className="text-xs mt-1 leading-relaxed">
                    Площадки вроде Одноклассников (OK.ru) или VK активно борются с ботами. Они не хотят, чтобы программы массово скачивали их музыку.<br/><br/>
                    Вводя свой <strong>Session Cookie</strong> или копируя <strong>JSON (текстовый код ответа сервера)</strong> вручную, вы помогаете нашему приложению "притвориться" вами — живым человеком, который просто зашел на сайт через свой браузер. Это легальный обход их защитных блокировок.
                  </p>
                </div>
              </div>

            </div>
          </section>

          {/* 4. Safety & Privacy */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-3 flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-500" />
              4. Безопасность и Приватность
            </h3>
            <div className="text-zinc-600 dark:text-zinc-400 space-y-2 text-sm leading-relaxed bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-red-100 dark:border-red-900/30">
              <p className="font-medium text-red-800 dark:text-red-400 mb-2">ВАЖНО: Никогда и никому не передавайте ваши токены, Client Secret или Cookies!</p>
              <ul className="list-disc pl-5 space-y-1.5 marker:text-red-400">
                <li>Все ваши ключи, токены и настройки сохраняются <strong>исключительно локально в памяти вашего браузера</strong> (технология localStorage).</li>
                <li>Мы (разработчики этого приложения) <strong>не имеем к ним доступа</strong>. У нас нет базы данных, куда они могли бы отправляться.</li>
                <li>Ваш браузер сам напрямую связывается с серверами Telegram, Spotify и Яндекса, используя ваши ключи.</li>
                <li>Если вы очистите кэш браузера или зайдете с другого компьютера — вам придется ввести все токены заново.</li>
              </ul>
            </div>
          </section>

        </div>

        <div className="p-6 border-t border-zinc-200 dark:border-zinc-800 shrink-0 bg-zinc-50 dark:bg-white/5 flex justify-end">
          <button onClick={onClose} className="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-xl transition-all hover:scale-105 active:scale-95 shadow-md shadow-blue-500/20">
            {t("Got it! Thanks", "Понятно! Спасибо")}
          </button>
        </div>
      </div>
    </div>
  );
};
`
fs.writeFileSync('src/components/HelpModal.tsx', newHelp);
console.log('HelpModal rewritten');
