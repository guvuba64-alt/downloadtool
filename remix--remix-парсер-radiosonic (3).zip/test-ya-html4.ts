import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
}).then(r => {
  const match = r.data.match(/.{0,50}Dance Monkey.{0,50}/i);
  console.log("Dance Monkey:", match ? match[0] : 'none');
}).catch(console.error);
