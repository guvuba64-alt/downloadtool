import axios from 'axios';
axios.get('https://itunes.apple.com/lookup?id=1473264640&entity=song').then(r => console.dir(r.data, {depth:null})).catch(console.error);
