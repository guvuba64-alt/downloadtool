const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');

const replacementImg = '<img src={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "400x400") : "https://" + albumCover.replace("%%", "400x400")) : "/placeholder.png"} alt="Cover" className="w-full h-full object-cover" />';
code = code.replace(/<img src=\{albumCover \|\| '\/placeholder.png'\} alt="Cover" className="w-full h-full object-cover" \/>/g, replacementImg);

const replacementViz = 'albumCover={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "400x400") : "https://" + albumCover.replace("%%", "400x400")) : undefined}';
code = code.replace(/albumCover=\{albumCover\}/g, replacementViz);

fs.writeFileSync('src/components/ModernPlayer/index.tsx', code);
console.log('Fixed cover');
