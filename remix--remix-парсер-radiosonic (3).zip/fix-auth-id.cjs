const fs = require('fs');

let content = fs.readFileSync('src/components/TgAuthGuard.tsx', 'utf8');

content = content.replace(
    '<input\n                type="text"\n                required\n                value={authId}\n                onChange={(e) => setAuthId(e.target.value)}',
    '<input\n                type="tel"\n                inputMode="numeric"\n                pattern="[0-9]*"\n                required\n                value={authId}\n                onChange={(e) => setAuthId(e.target.value.replace(/\\D/g, ""))}'
);

fs.writeFileSync('src/components/TgAuthGuard.tsx', content);
console.log('Fixed authId in TgAuthGuard.tsx');
