import re

with open("server.ts", "r", encoding="utf-8") as f:
    content = f.read()

# Remove timeout: 30000 and timeout: 20000 and timeout: 15000 in stream fetches
content = re.sub(r'timeout:\s*30000,\n?', '', content)
content = re.sub(r'timeout:\s*20000,\n?', '', content)
content = re.sub(r'timeout:\s*15000,\n?', '', content)

with open("server.ts", "w", encoding="utf-8") as f:
    f.write(content)
print("server.ts patched")

with open("server-okru.ts", "r", encoding="utf-8") as f:
    content = f.read()

content = re.sub(r'timeout:\s*20000,\n?', '', content)
content = re.sub(r'timeout:\s*60000,\n?', '', content)

with open("server-okru.ts", "w", encoding="utf-8") as f:
    f.write(content)
print("server-okru.ts patched")

