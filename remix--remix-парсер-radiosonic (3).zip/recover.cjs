const fs = require('fs');
const map = JSON.parse(fs.readFileSync('dist/server.cjs.map', 'utf8'));
const index = map.sources.findIndex(s => s === 'src/components/UnifiedParserTab.tsx' || s.includes('UnifiedParserTab.tsx'));
if (index !== -1) {
    fs.writeFileSync('src/components/UnifiedParserTab.tsx', map.sourcesContent[index]);
    console.log('Recovered UnifiedParserTab.tsx!');
} else {
    console.log('Not found in sourcemap. Sources: ', map.sources);
}
