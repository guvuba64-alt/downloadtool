const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const spotReq = `          const resSpotify = await axios.get(\`https://api.spotify.com/v1/search?q=\${encodeURIComponent(query as string)}&type=track,album,artist&limit=10\`, {
              headers: { Authorization: "Bearer " + tokenRes.data.access_token },
              timeout: 5000
          });`;

const spotReqNew = `
          let resSpotify;
          try {
            resSpotify = await axios.get(\`https://api.spotify.com/v1/search?q=\${encodeURIComponent(query as string)}&type=track,album,artist&limit=10\`, {
                headers: { Authorization: "Bearer " + tokenRes.data.access_token },
                timeout: 5000
            });
          } catch (spotErr) {
             console.log("Spotify Search error:", spotErr.message);
             return res.json({ success: true, data: { tracks: { results: [] }, albums: { results: [] }, artists: { results: [] } }, note: "Spotify search is temporarily unavailable" });
          }
`;

code = code.replace(spotReq, spotReqNew);
fs.writeFileSync('server.ts', code);
console.log("Patched Spotify search request");
