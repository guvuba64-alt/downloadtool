import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
}).then(r => {
  console.log(r.data.length);
  const m = r.data.match(/window\.Ya\.dataLayer\.push\((.*?)\);/);
  console.log("dataLayer:", m ? m[1].substring(0, 100) : 'none');
  const schema = r.data.match(/application\/ld\+json">(.*?)<\/script>/);
  console.log("schema:", schema ? schema[1].substring(0, 100) : 'none');
  const ogTitle = r.data.match(/property="og:title"\s+content="(.*?)"/i);
  console.log("og:title:", ogTitle ? ogTitle[1] : 'none');
  const dco = r.data.match(/data-chunk-object="(.*?)"/i);
  console.log("dco:", dco ? dco[1].substring(0, 100) : 'none');
}).catch(console.error);
