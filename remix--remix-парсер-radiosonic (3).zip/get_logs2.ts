import axios from 'axios';
axios.get('http://localhost:3000/api/system/logs').then(r => console.log(JSON.stringify(r.data.logs.slice(0, 10), null, 2))).catch(e => console.log(e));
