const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /  \} catch \(err: any\) \{\n    console\.log\("Search error:", err\.message\);\n    res\.status\(500\)\.json\(\{ error: err\.message \}\);\n  \}/;

const replacement = `  } catch (err: any) {
    console.log("Search error:", err.message);
    if (err.response) {
      console.log("Response data:", err.response.data);
      return res.status(err.response.status || 500).json({ error: err.message, details: err.response.data });
    }
    res.status(500).json({ error: err.message });
  }`;

code = code.replace(regex, replacement);
fs.writeFileSync('server.ts', code);
console.log("Patched error handler in search");
