const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

// Fix extractTrackMetadata
code = code.replace(/let foundCopyright = rawPline[\s\S]*?if \(!track\.upc && deepScan\.upc\) track\.upc = deepScan\.upc;/g, `
  const strictCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;

  let foundLabel = rawLabel || deepScan.label || rawPublisher || 'Правообладатель';

  if (aggregator && (!foundLabel || foundLabel === aggregator)) {
    const other = allVals.find(s => s !== aggregator);
    if (other) {
      foundLabel = other;
    }
  }

  const foundDistributor = rawOwner || deepScan.distributor || aggregator || (foundLabel && aggregator ? aggregator : undefined);

  if (track.album && track.album.year && !track.releaseDate) track.releaseDate = track.album.year;
  if (!track.releaseDate && deepScan.releaseDate) track.releaseDate = deepScan.releaseDate;
  if (!track.isrc && deepScan.isrc) track.isrc = deepScan.isrc;
  if (!track.upc && deepScan.upc) track.upc = deepScan.upc;
`);

// Also fix the return object
code = code.replace(/copyright: foundCopyright \|\| deepScan\.copyright \|\| \(foundLabel \? `℗ \$\{year\} \$\{foundLabel\}` : undefined\),\n    copyrightOwnerName: rawOwner \|\| deepScan\.copyrightOwnerName,/g, `copyright: strictCopyright,
    copyrightOwnerName: strictCopyright,`);

fs.writeFileSync('server-okru.ts', code);
