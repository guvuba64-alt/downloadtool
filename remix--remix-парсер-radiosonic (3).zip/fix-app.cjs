const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/const owner = data\?\.track\?\.copyrightOwnerName \|\| data\?\.track\?\.pLine;[\s\S]*?setMetadataResult\(\(prev: any\) =>/g, `
      const t = data?.track || data?.tracks?.[0] || {};
      const rawPline = t.pLine || '';
      const rawPublisher = t.publisher || t.publisherName || '';
      const rawOwner = t.copyrightOwnerName || t.ownerName || '';
      const rawCopyright = t.copyright || '';
      const rawLabel = t.label || t.labelName || t.album?.label || t.album?.labelName || '';
      
      const allVals = [rawPline, rawPublisher, rawOwner, rawCopyright].filter(Boolean);
      
      const aggregator = allVals.find(s => {
        const l = s.toLowerCase();
        return l.includes('национальный цифровой агрегатор') || l.includes('believe') || l.includes('zvonko') || l.includes('fuga') || l.includes('onerpm');
      });

      let finalCopyright = aggregator || rawPline || rawPublisher || rawOwner || rawCopyright || null;
      let finalLabel = rawLabel || rawOwner || rawCopyright || null;
      
      if (aggregator && (!finalLabel || finalLabel === aggregator)) {
         let other = allVals.find(s => s !== aggregator);
         if (other) finalLabel = other;
      }
      
      if (finalLabel === finalCopyright && allVals.length > 1) {
         let other = allVals.find(s => s !== finalLabel);
         if (other) finalCopyright = other;
      }
      
      if (finalCopyright || finalLabel) {
        setOkRuResult(\`Copyright: \${finalCopyright || '—'} | Label: \${finalLabel || '—'}\`);
        setMetadataResult((prev: any) =>
`);

code = code.replace(/prev \? \{ \.\.\.prev, copyright: owner \|\| prev\.copyright, label: label \|\| prev\.label \} : prev,/g, `prev ? { ...prev, copyright: finalCopyright || prev.copyright, label: finalLabel || prev.label } : prev,`);

fs.writeFileSync('src/App.tsx', code);
console.log('App.tsx manual parse updated');
