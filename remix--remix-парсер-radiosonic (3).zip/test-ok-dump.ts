import axios from 'axios';
axios.get(`https://ok.ru/web-api/music/search`, {
  params: { query: 'Король и шут кукла колдуна' },
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://ok.ru/music',
  }
}).then(r => console.dir(r.data, {depth:null})).catch(console.error);
