const fs = require('fs');

let reportTabCode = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');
reportTabCode = reportTabCode.replace(/console\.warn\(\`Rate limited \(429\). Retrying\.\.\.\`\);/g, "");
reportTabCode = reportTabCode.replace(/console\.warn\(\`Rate limited \(429\). Retrying after \$\{retryAfter\}s\.\.\.\`\);/g, "");
reportTabCode = reportTabCode.replace(/console\.warn\(\`Telegram API Response: \`, errData\?\.description\);/g, "");
reportTabCode = reportTabCode.replace(/console\.warn\(\`Failed to send to \$\{chatId\} with bot \$\{token.substring\(0,5\)\}\.\.\.\`, err\?\.message\);/g, "");
fs.writeFileSync('src/components/ReportTab.tsx', reportTabCode);

console.log('Fixed ReportTab console.warns');
