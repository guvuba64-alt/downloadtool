const fs = require('fs');

const file = fs.readFileSync('server-okru.ts', 'utf8');
const lines = file.split('\n');

const startIndex = lines.findIndex(l => l.includes('export async function parseOkRuUrl'));
const endIndex = lines.findIndex(l => l.includes('export function hasOkRuSession()'));

if (startIndex !== -1 && endIndex !== -1) {
    const newFunction = `export async function parseOkRuUrl(url: string) {
  const activeProxy = okProxyConfig.enabled ? parseProxyString(okProxyConfig.proxyUrl) : null;
  let foundCopyright: string | null = null;
  let foundLabel: string | null = null;
  let foundTrack: any = null;

  // 1. Direct HTTP parse first (OpenGraph and embedded scripts)
  try {
    const agent = getProxyAgent(activeProxy);
    const cookieHeader = (okCookies && okCookies.length > 0) ? okCookies.map(c => \`\${c.name}=\${c.value}\`).join('; ') : '';
    const headers: any = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    };
    if (cookieHeader) headers['Cookie'] = cookieHeader;

    const resOg = await axios.get(url, {
      headers,
      httpsAgent: agent,
      httpAgent: agent,
      timeout: 10000,
      validateStatus: () => true,
    });

    if (resOg.status === 200 && resOg.data) {
      const html = typeof resOg.data === 'string' ? resOg.data : JSON.stringify(resOg.data);
      const $ = cheerio.load(html);
      
      const ogTitle = $('meta[property="og:title"]').attr('content') || "";
      const ogDesc = $('meta[property="og:description"]').attr('content') || "";
      let title = "Unknown Title";
      let artists = "Unknown Artist";
      let imageUrl = $('meta[property="og:image"]').attr('content');
      
      $('script').each((_, el) => {
        const text = $(el).html() || '';
        if (text.includes('"track"') || text.includes('"pLine"') || text.includes('"copyright"')) {
          try {
            const matches = text.match(/\\{[^{}]*"(?:track|tracks|pLine|publisher|copyright)"[^{}]*\\}/g) || [];
            for (const m of matches) {
              const parsed = JSON.parse(m);
              const meta = extractTrackMetadata(parsed.track || parsed);
              if (meta && meta.track) {
                foundTrack = meta.track;
                foundCopyright = meta.copyright || foundCopyright;
                foundLabel = meta.label || foundLabel;
              }
            }
          } catch(je) {}
        }
      });

      if (!foundTrack && (ogTitle || ogDesc)) {
        if (url.includes('/album/')) {
          const match = ogTitle.match(/Альбом (.*?) - (.*?) слушать бесплатно/);
          if (match) {
            title = match[1].trim();
            artists = match[2].trim();
          } else {
            const match3 = ogTitle.match(/Альбом (.*?) слушать бесплатно/);
            if (match3) {
              title = match3[1].trim();
              artists = "";
            }
          }
        } else {
          const match = ogTitle.match(/Слушать (.*?) [–-] (.*?) бесплатно онлайн/);
          if (match) {
            artists = match[1].trim();
            title = match[2].trim();
          } else {
            const match2 = ogDesc.match(/песню (.*?) - (.*)\\. Музыка/);
            if (match2) {
              title = match2[1].trim();
              artists = match2[2].trim();
            } else {
              const match4 = ogTitle.match(/(.*?) – (.*?) - слушать/);
              if (match4) {
                artists = match4[1].trim();
                title = match4[2].trim();
              }
            }
          }
        }
        
        if (title !== "Unknown Title") {
          foundTrack = {
            id: 'okru_' + Date.now(),
            name: title,
            ensembleName: artists,
            imageUrl: imageUrl,
            playUrl: null
          };
        }
      }
    }
  } catch (e: any) {}

  if (foundTrack && (foundCopyright || foundLabel)) {
    const resObj = { copyright: foundCopyright, label: foundLabel, playUrl: foundTrack?.playUrl, track: foundTrack };
    if (resObj?.track?.id) {
       const playInfo = await getOkAudioStreamUrl(resObj.track.id);
       if (playInfo?.track?.copyrightOwnerName) {
           resObj.copyright = (typeof playInfo.track.copyrightOwnerName === 'string' && playInfo.track.copyrightOwnerName.trim().length > 0) ? playInfo.track.copyrightOwnerName.trim() : null;
           resObj.label = resObj.copyright || foundLabel;
       }
       if (playInfo?.playUrl) {
           resObj.playUrl = playInfo.playUrl;
       }
       if (playInfo?.track) {
           resObj.track = { ...resObj.track, ...playInfo.track };
       }
    }
    return resObj;
  }

  const ensureExactCopyright = async (resObj: any) => {
    const tId = resObj?.track?.id || resObj?.deepScan?.track?.id || resObj?.deepScan?.id;
    if (tId) {
      try {
        const playInfo = await getOkAudioStreamUrl(tId);
        if (playInfo && playInfo.track) {
          resObj.track = { ...(resObj.track || {}), ...playInfo.track };
          if (playInfo.copyrightOwnerName) {
            resObj.copyright = (typeof playInfo.copyrightOwnerName === 'string' && playInfo.copyrightOwnerName.trim().length > 0) ? playInfo.copyrightOwnerName.trim() : null;
          }
          if (playInfo.playUrl) {
            resObj.playUrl = playInfo.playUrl;
          }
          if (playInfo.deepScan) {
             resObj.deepScan = { ...(resObj.deepScan || {}), ...playInfo.deepScan };
          }
        }
      } catch (e) {}
    }
    return resObj;
  };

  // 2. Puppeteer browser attempt (with graceful fallback if Chrome is not installed)
  let browser;
  try {
    const puppeteerArgs = ['--no-sandbox', '--disable-setuid-sandbox'];
    if (activeProxy) {
      puppeteerArgs.push(activeProxy.puppeteerArg);
    }

    browser = await puppeteer.launch({ 
      args: puppeteerArgs,
      headless: true
    });
    const page = await browser.newPage();

    if (activeProxy && activeProxy.username) {
      await page.authenticate({
        username: activeProxy.username,
        password: activeProxy.password || '',
      });
    }

    await page.setRequestInterception(true);
    page.on('request', (req) => {
      const resourceType = req.resourceType();
      if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
        req.abort();
      } else {
        req.continue();
      }
    });

    if (okCookies && okCookies.length > 0) {
      await page.setCookie(...okCookies);
    }
    
    page.on('response', async (response) => {
      try {
        const u = response.url();
        if (u.includes('ok.ru/web-api/music') || u.includes('ok.ru/play') || u.includes('music') || u.includes('track')) {
          const text = await response.text();
          if (text.includes('"track"') || text.includes('"tracks"')) {
             try {
                 const json = JSON.parse(text);
                 if (json.track) {
                     foundTrack = json.track;
                     let rawOwner = json.track.copyrightOwnerName;
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     
                     let rawLabel = json.track.label || json.track.labelName || json.track.album?.label || json.track.album?.labelName || '';
                     foundLabel = rawLabel || foundLabel;
                     
                     if (json.track.album && json.track.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = json.track.album.year;
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     foundTrack = json.tracks[0];
                     let rawOwner = foundTrack.copyrightOwnerName;
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     
                     let rawLabel = foundTrack.label || foundTrack.labelName || foundTrack.album?.label || foundTrack.album?.labelName || '';
                     foundLabel = rawLabel || foundLabel;
                     
                     if (foundTrack.album && foundTrack.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = foundTrack.album.year;
                 }
             } catch (e) {}
          }
        }
      } catch (e) {}
    });

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(e => console.log("goto timeout, continuing", e));
    const finalUrl = page.url();
    if (finalUrl.includes('anonymLogin') || finalUrl.includes('login')) {
        console.log("OK.ru page redirected to login for this track, falling back to HTTP");
    }
    await new Promise(r => setTimeout(r, 2000));
    
    await safeEvaluate(page, () => {
        const btns = Array.from(document.querySelectorAll('.js-play, .js-track_play, [data-l="t,play_album"], .mus-album_play, .play, [data-l="t,play"], wm-play-control, .mus-tr_i'));
        if (btns.length > 0) {
            (btns[0] as HTMLElement).click();
        }
    });
    
    await new Promise(r => setTimeout(r, 3000));
    
    await safeEvaluate(page, () => {
        const tracks = Array.from(document.querySelectorAll('[data-track-id]'));
        if (tracks.length > 0) {
            (tracks[0] as HTMLElement).click();
        }
    });

    await new Promise(r => setTimeout(r, 3000));

    if (!foundTrack || (!foundCopyright && !foundLabel)) {
      const trackIdMatch = url.match(/track\\/(\\d+)/);
      if (trackIdMatch) {
         const tId = trackIdMatch[1];
         const playInfo = await getOkAudioStreamUrl(tId);
         if (playInfo && playInfo.track) {
             const playInfoOwner = (typeof playInfo.copyrightOwnerName === 'string' && playInfo.copyrightOwnerName.trim().length > 0) ? playInfo.copyrightOwnerName.trim() : null;
             return {
                copyright: playInfoOwner || foundCopyright,
                label: playInfoOwner || foundLabel,
                playUrl: playInfo.playUrl || foundTrack?.playUrl,
                track: playInfo.track,
                deepScan: playInfo.deepScan
             };
         }
      }
      
      const httpFallback = await searchOkRuViaHttp(url);
      if (httpFallback && (httpFallback.copyright || httpFallback.label || httpFallback.track)) {
        return await ensureExactCopyright({
          copyright: httpFallback.copyright || foundCopyright,
          label: httpFallback.label || foundLabel,
          playUrl: httpFallback.playUrl || foundTrack?.playUrl,
          track: httpFallback.track || foundTrack,
          isrc: httpFallback.isrc,
          upc: httpFallback.upc,
          distributor: httpFallback.distributor,
          deepScan: httpFallback.deepScan
        });
      }
    }

    return await ensureExactCopyright({ copyright: foundCopyright, label: foundLabel, playUrl: foundTrack?.playUrl, track: foundTrack });
  } catch(e: any) {
    if (e?.message?.includes('Could not find Chrome') || e?.message?.includes('spawn')) {
      console.log("Puppeteer Chrome browser unavailable for URL parse, using HTTP results");
    } else {
      console.warn("OK.ru parse notice:", e?.message);
    }
    
    const trackIdMatch = url.match(/track\\/(\\d+)/);
    if (trackIdMatch) {
       const tId = trackIdMatch[1];
       const playInfo = await getOkAudioStreamUrl(tId);
       if (playInfo && playInfo.track) {
           const playInfoOwner = (typeof playInfo.copyrightOwnerName === 'string' && playInfo.copyrightOwnerName.trim().length > 0) ? playInfo.copyrightOwnerName.trim() : null;
           return {
              copyright: playInfoOwner || foundCopyright,
              label: playInfoOwner || foundLabel,
              playUrl: playInfo.playUrl || foundTrack?.playUrl,
              track: playInfo.track,
              deepScan: playInfo.deepScan
           };
       }
    }
    
    const httpFallback = await searchOkRuViaHttp(url).catch(() => null);
    if (httpFallback && (httpFallback.copyright || httpFallback.label || httpFallback.track)) {
      return await ensureExactCopyright({
        copyright: httpFallback.copyright || foundCopyright,
        label: httpFallback.label || foundLabel,
        playUrl: httpFallback.playUrl || foundTrack?.playUrl,
        track: httpFallback.track || foundTrack,
        isrc: httpFallback.isrc,
        upc: httpFallback.upc,
        distributor: httpFallback.distributor,
        deepScan: httpFallback.deepScan
      });
    }
    return await ensureExactCopyright({ copyright: foundCopyright, label: foundLabel, playUrl: foundTrack?.playUrl, track: foundTrack });
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch (e) {}
    }
  }
}
`;

    lines.splice(startIndex, endIndex - startIndex, newFunction);
    fs.writeFileSync('server-okru.ts', lines.join('\n'));
} else {
    console.error('Could not find function boundaries');
}
