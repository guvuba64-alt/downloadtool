const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

content = content.replace(/<div className="flex gap-2">\n                      <input type="text" value=\{newContactId\} onChange=\{e => setNewContactId\(e.target.value\)\} placeholder="ID \(123456\.\.\.\)" className="flex-\[2\] rounded-xl border/g, `<div className="flex flex-col sm:flex-row gap-2">\n                      <input type="text" value={newContactId} onChange={e => setNewContactId(e.target.value)} placeholder="ID (123456...)" className="flex-[2] w-full min-w-0 rounded-xl border`);

content = content.replace(/className="flex-\[3\] rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black\/20 p-3 outline-none focus:border-blue-500 transition-colors text-sm" \/>/g, `className="flex-[3] w-full min-w-0 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors text-sm" />`);

content = content.replace(/className="px-4 py-2 bg-blue-500 text-white font-bold rounded-xl hover:bg-blue-600 transition-colors active:scale-95 flex items-center justify-center">/g, `className="w-full sm:w-auto px-4 py-3 sm:py-2 bg-blue-500 text-white font-bold rounded-xl hover:bg-blue-600 transition-colors active:scale-95 flex items-center justify-center">`);

fs.writeFileSync('src/components/ReportTab.tsx', content);
