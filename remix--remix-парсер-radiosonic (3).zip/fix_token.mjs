import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(
  'error.response?.data?.result?.name === "track-download-info-error"',
  'error.response?.data?.result?.name === "track-download-info-error" || error.response?.status === 401 || error.response?.data?.error === "Unauthorized" || error.response?.data?.name === "SessionExpiredError"'
);

fs.writeFileSync('server.ts', content);
