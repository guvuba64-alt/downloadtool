import re

with open("src/components/UnifiedParserTab.tsx", "r", encoding="utf-8") as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if 'activeSubTab === "okru_vk"' in line:
        start_idx = i
    if 'activeSubTab === "openapi"' in line:
        end_idx = i
        break

if start_idx != -1 and end_idx != -1:
    new_ui = """      {/* SUBTAB 2: OK.RU / VK & UNIVERSAL PARSER (АВТОМАТИЧЕСКИЙ SNIFFER, PLAY, COPYRIGHT, СИНГЛ/АЛЬБОМ) */}
      {activeSubTab === "okru_vk" && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#EE8208]/15 text-[#EE8208] flex items-center justify-center font-bold shrink-0">
                  <Radio className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg sm:text-xl font-bold text-zinc-900 dark:text-zinc-50 tracking-wide uppercase">
                      OK.RU COPYRIGHT PARSER
                    </h3>
                  </div>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Автоматический перехват ответов Network (\`play;jsessionid=...\` / \`/web-api/music/play\`) и мгновенное извлечение <code className="text-orange-500 font-mono">copyrightOwnerName</code>, ℗/©, ISRC, UPC и аудиопотоков без ручной вставки JSON.
                  </p>
                </div>
              </div>
            </div>

            {/* OK.ru Search Bar */}
            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={okSearchQuery}
                  onChange={e => setOkSearchQuery(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleExecuteOkSearch()}
                  placeholder="Ссылка / название / альбом / релиз..."
                  className="w-full h-12 pl-11 pr-4 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-zinc-800 text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#EE8208]/40 font-medium"
                />
                <Search className="w-5 h-5 text-zinc-400 absolute left-3.5 top-3.5" />
              </div>

              <button
                onClick={() => handleExecuteOkSearch()}
                disabled={okSearching || !okSearchQuery.trim()}
                className="h-12 px-6 rounded-2xl bg-[#EE8208] hover:bg-[#d67304] active:scale-95 text-white font-bold text-sm shadow-md shadow-[#EE8208]/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 shrink-0"
              >
                {okSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                <span>Найти и автоматически проверить</span>
              </button>
            </div>
            
            {/* Quick Test Preset Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] font-bold text-zinc-400 mr-1">Быстрый тест:</span>
              {[
                { label: "YOURE TOO SLOW (SP DIGITAL)", q: "Whybaby_ff, Odetari - YOURE TOO SLOW" },
                { label: "Regression (miHoYo)", q: "miHoYo - Regression" },
                { label: "No Dazzle No Break (ZVONKO)", q: "Geek Music - No Dazzle No Break" },
                { label: "Queen — Greatest Hits", q: "Queen - Bohemian Rhapsody" },
                { label: "Яндекс.Музыка Релиз", q: "https://music.yandex.ru/album/34850543" },
                { label: "Волна Моя", q: "Моя волна (radio)" }
              ].map(chip => (
                <button
                  key={chip.label}
                  onClick={() => {
                    setOkSearchQuery(chip.q);
                    handleExecuteOkSearch(chip.q);
                  }}
                  className="px-2.5 py-1 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800/80 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 text-[11px] font-semibold transition-all hover:scale-105 active:scale-95"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Automated Pipeline Progress Bar */}
            <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/60">
              <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-2.5 flex items-center justify-between">
                <span>Статус автоматического перехвата:</span>
                <span className="font-mono text-xs font-semibold text-zinc-500">
                  {parserStage === "idle" && "● Ожидание"}
                  {parserStage === "searching" && "🔍 Поиск трека"}
                  {parserStage === "found" && "🎵 Трек найден"}
                  {parserStage === "playing" && "⚡ Запуск воспроизведения"}
                  {parserStage === "intercepting" && "📡 Перехват Network"}
                  {parserStage === "parsed" && "📦 Получен metadata response"}
                  {parserStage === "success" && "✓ Copyright найден"}
                  {parserStage === "warning" && "⚠ Metadata получены, но copyrightOwnerName отсутствует"}
                  {parserStage === "error" && "❌ Ошибка поиска / недоступно"}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {[
                  {
                    key: "searching",
                    num: "1",
                    title: "Поиск трека",
                    active: ["searching", "found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage),
                    done: ["found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage)
                  },
                  {
                    key: "found",
                    num: "2",
                    title: "Трек найден",
                    active: ["found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage),
                    done: ["playing", "intercepting", "parsed", "success", "warning"].includes(parserStage)
                  },
                  {
                    key: "playing",
                    num: "3",
                    title: "Воспроизведение",
                    active: ["playing", "intercepting", "parsed", "success", "warning"].includes(parserStage),
                    done: ["intercepting", "parsed", "success", "warning"].includes(parserStage)
                  },
                  {
                    key: "intercepting",
                    num: "4",
                    title: "Network Sniffer",
                    active: ["intercepting", "parsed", "success", "warning"].includes(parserStage),
                    done: ["parsed", "success", "warning"].includes(parserStage)
                  },
                  {
                    key: "parsed",
                    num: "5",
                    title: "Анализ JSON",
                    active: ["parsed", "success", "warning"].includes(parserStage),
                    done: ["success", "warning"].includes(parserStage)
                  },
                  {
                    key: "success",
                    num: "6",
                    title: "Copyright OK",
                    active: ["success", "warning"].includes(parserStage),
                    done: parserStage === "success"
                  }
                ].map(step => (
                  <div
                    key={step.key}
                    className={`p-2.5 rounded-xl border text-xs flex items-center gap-2 transition-all ${
                      step.done
                        ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-bold"
                        : step.active
                        ? "bg-[#EE8208]/10 border-[#EE8208]/40 text-[#EE8208] font-bold animate-pulse"
                        : "bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-400"
                    }`}
                  >
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] shrink-0 ${
                      step.done ? "bg-emerald-500 text-white" : step.active ? "bg-[#EE8208] text-white" : "bg-zinc-200 dark:bg-zinc-800 text-zinc-500"
                    }`}>
                      {step.done ? "✓" : step.num}
                    </span>
                    <span className="truncate">{step.title}</span>
                  </div>
                ))}
              </div>
            </div>

            {okSearchError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{okSearchError}</span>
              </div>
            )}
          </div>

          {/* OK.ru Structured Search Result Card with Strict Field Separation */}
          {okSearchResult && (
            <div className="bg-white/90 dark:bg-[#111520]/90 backdrop-blur-xl border border-zinc-200/80 dark:border-white/10 rounded-[32px] p-6 sm:p-8 shadow-md animate-in fade-in slide-in-from-bottom-4 max-w-4xl mx-auto space-y-6">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-zinc-50 dark:bg-zinc-900/60 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">TRACK</div>
                  <div className="font-bold text-lg text-zinc-900 dark:text-zinc-50">{okSearchResult.title || "-"}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">ARTIST</div>
                  <div className="font-semibold text-zinc-800 dark:text-zinc-200">{okSearchResult.artists || "-"}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">ALBUM</div>
                  <div className="font-medium text-zinc-700 dark:text-zinc-300">{okSearchResult.albumTitle || okSearchResult.title || "-"}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">TRACK ID</div>
                  <div className="font-mono text-sm text-zinc-600 dark:text-zinc-400">{okSearchResult.track?.id || okSearchResult.idForDownload || okSearchResult.id || "-"}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">ALBUM ID</div>
                  <div className="font-mono text-sm text-zinc-600 dark:text-zinc-400">{okSearchResult.track?.albumId || okSearchResult.albumId || "-"}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">RELEASE ID</div>
                  <div className="font-mono text-sm text-zinc-600 dark:text-zinc-400">{okSearchResult.track?.releaseId || okSearchResult.releaseId || "-"}</div>
                </div>
                <div className="bg-orange-500/5 dark:bg-orange-500/10 p-3 rounded-xl border border-orange-500/20">
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">COPYRIGHT (OK.RU)</div>
                  <div className="font-bold text-orange-600 dark:text-orange-400">{okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || okSearchResult.copyright || "Не найден"}</div>
                </div>
                <div className="bg-zinc-100 dark:bg-zinc-800/80 p-3 rounded-xl border border-zinc-200 dark:border-zinc-700">
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">COPYRIGHT OWNER ID</div>
                  <div className="font-mono text-sm text-zinc-700 dark:text-zinc-300">{okSearchResult.track?.copyrightOwnerId || okSearchResult.copyrightOwnerId || "-"}</div>
                </div>

                <div className="col-span-1 sm:col-span-2 mt-2 pt-4 border-t border-zinc-200 dark:border-zinc-800 flex flex-col gap-1.5">
                  <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider">STATUS</div>
                  {okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || okSearchResult.copyright ? (
                    <span className="self-start px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-xs flex items-center gap-1.5 border border-emerald-500/20">
                      <CheckCheck className="w-4 h-4" />
                      ✓ Найден на OK.ru
                    </span>
                  ) : (
                    <span className="self-start px-3 py-1 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 font-bold text-xs flex items-center gap-1.5 border border-rose-500/20">
                      <AlertCircle className="w-4 h-4" />
                      ⚠ Metadata получены, но copyrightOwnerName отсутствует
                    </span>
                  )}
                </div>
                
                {okSearchResult.pLine && okSearchResult.pLine !== okSearchResult.copyrightOwnerName && (
                   <div className="col-span-1 sm:col-span-2 mt-1">
                     <div className="text-[11px] uppercase font-bold text-zinc-500 tracking-wider mb-1">P-LINE / ℗ (Альтернативный источник)</div>
                     <div className="font-semibold text-zinc-500 dark:text-zinc-400">{okSearchResult.pLine}</div>
                   </div>
                )}
              </div>

              {/* Quick Action Buttons */}
              <div className="bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 flex flex-wrap items-center gap-2.5">
                {okSearchResult.coverUri && (
                  <button
                    onClick={() => handleDownloadCover3000(okSearchResult.coverUri, okSearchResult.title, okSearchResult.artists)}
                    disabled={isDownloadingCover3000}
                    className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                    title="Скачать обложку в оригинальном разрешении 3000x3000px"
                  >
                    {isDownloadingCover3000 ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : cover3000Success ? (
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                    ) : (
                      <ImageIcon className="w-3.5 h-3.5" />
                    )}
                    <span>{isDownloadingCover3000 ? "Генерация 3000x3000px..." : cover3000Success ? "Обложка скачана!" : "Обложка (3000x3000px)"}</span>
                  </button>
                )}

                <button
                  onClick={() => handleDownloadWavTrack({
                    idForDownload: okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track",
                    title: okSearchResult.title,
                    artists: okSearchResult.artists,
                    upc: okSearchResult.upc,
                    isrc: okSearchResult.isrc
                  })}
                  disabled={downloadingWavTrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track")}
                  className="px-3.5 py-2 rounded-xl bg-[#EE8208] hover:bg-[#d67304] active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                  title="Конвертировать и скачать аудио в Lossless WAV"
                >
                  {downloadingWavTrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track") ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FileAudio className="w-3.5 h-3.5" />
                  )}
                  <span>{downloadingWavTrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track") ? "Конвертация WAV..." : "Скачать WAV (Lossless)"}</span>
                </button>

                <button
                  onClick={() => handleDownloadMp3Track({
                    idForDownload: okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track",
                    title: okSearchResult.title,
                    artists: okSearchResult.artists,
                    upc: okSearchResult.upc,
                    isrc: okSearchResult.isrc,
                    playUrl: okSearchResult.playUrl
                  })}
                  disabled={downloadingMp3TrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track")}
                  className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 dark:bg-zinc-700 dark:hover:bg-zinc-600 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                  title="Скачать трек в MP3 (320 kbps)"
                >
                  {downloadingMp3TrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track") ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Download className="w-3.5 h-3.5" />
                  )}
                  <span>{downloadingMp3TrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track") ? "Скачивание MP3..." : "Скачать MP3"}</span>
                </button>

                {okSearchResult.playUrl && (
                  <button
                    onClick={handleToggleOkPlay}
                    className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
                    title="Слушать поток"
                  >
                    {okPlayingTrack && okPlayingTrackId === "main" ? (
                      <Pause className="w-3.5 h-3.5" />
                    ) : (
                      <Play className="w-3.5 h-3.5" />
                    )}
                    <span>{okPlayingTrack && okPlayingTrackId === "main" ? "Пауза" : "Воспроизвести"}</span>
                  </button>
                )}
                
                <button
                  onClick={() => handleDownloadAlbumZip('wav')}
                  disabled={isDownloadingZipAlbum}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                  title="Скачать весь релиз в ZIP (все треки WAV + обложка 3000x3000 + метаданные)"
                >
                  {isDownloadingZipAlbum ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FolderArchive className="w-3.5 h-3.5" />
                  )}
                  <span>{isDownloadingZipAlbum ? "Сборка архива ZIP..." : "Скачать весь альбом (ZIP с WAV)"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
"""
    # Replace
    new_lines = lines[:start_idx - 1] + [new_ui] + lines[end_idx - 1:]
    with open("src/components/UnifiedParserTab.tsx", "w", encoding="utf-8") as f:
        f.writelines(new_lines)
    print("UI Patched.")
else:
    print("Could not find start/end indices")

