const fs = require('fs');
const ts = require('typescript');
const code = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ReportTab.tsx', code, ts.ScriptTarget.Latest, true);
let found = false;
function visit(node) {
    if (node.kind === ts.SyntaxKind.JsxExpression) {
        // console.log(node.getText());
    }
    ts.forEachChild(node, visit);
}
visit(sourceFile);
console.log("AST built successfully?");
