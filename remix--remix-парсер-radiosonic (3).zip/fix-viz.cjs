const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/Visualizer.tsx', 'utf8');
code = code.replace(`style={{ animationDuration: "20s" }}" />`, `style={{ animationDuration: "20s" }} />`);
fs.writeFileSync('src/components/ModernPlayer/Visualizer.tsx', code);
