import { searchOkRu } from './server-okru.js';
searchOkRu('Joniveli Tee tästä hitti').then(console.log).catch(console.error);
