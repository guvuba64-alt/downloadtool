const fs = require('fs');
const axios = require('axios');
axios.get('https://ok.ru/music/search/Tones%20And%20I%20Dance%20Monkey', {
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
  }
}).then(r => {
  fs.writeFileSync('ok_search_dance.html', r.data);
  console.log("Saved ok_search_dance.html");
}).catch(console.error);
