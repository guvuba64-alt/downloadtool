const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Rename parserTheme to appTheme
code = code.replace(/parserTheme/g, 'appTheme');
code = code.replace(/setParserTheme/g, 'setAppTheme');

// 2. Remove the dropdown from the parser tab
const dropdownRegex = /\{\/\* Theme Settings Dropdown \*\/\}[\s\S]*?<\/div>\s*<div className=\{\`overflow-hidden transition-all duration-500[^\}]+\`\}>/m;
const dropdownMatch = code.match(dropdownRegex);
if(dropdownMatch) {
    // Just replace it with a standard div that inherits, or maybe keep some parser-specific styling if needed.
    // Actually we can just remove the dropdown and keep the div with a generic class for the content container.
    // Since the theme applies globally, the content container in parser should probably just be a standard card or transparent depending on theme.
    
    code = code.replace(dropdownRegex, `<div className="overflow-hidden transition-all duration-500 bg-white/50 dark:bg-black/50 backdrop-blur-sm border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm">`);
}

// 3. Update the main app wrapper
// Currently: <div className="min-h-screen bg-[#f5f5f7] dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans p-6 sm:p-12">
const mainWrapperRegex = /<div className="min-h-screen bg-\[\#f5f5f7\] dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans p-6 sm:p-12">/m;
const newMainWrapper = `<div className={\`min-h-screen p-6 sm:p-12 transition-all duration-700 ease-in-out \${
      appTheme === 'minimalism' ? 'bg-white dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans' : 
      appTheme === 'anime' ? 'bg-gradient-to-br from-pink-100 via-purple-100 to-indigo-100 dark:from-pink-950 dark:via-purple-900 dark:to-indigo-950 text-indigo-900 dark:text-pink-100 font-sans' : 
      appTheme === 'designer' ? 'bg-[#e0e5ec] dark:bg-[#1a1b1e] text-zinc-800 dark:text-zinc-200 font-sans bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/40 via-transparent to-transparent dark:from-white/5' : 
      appTheme === 'cyberpunk' ? 'bg-zinc-950 text-yellow-400 font-mono bg-[linear-gradient(rgba(250,204,21,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(250,204,21,0.05)_1px,transparent_1px)] bg-[size:20px_20px]' :
      appTheme === 'brutalism' ? 'bg-[#f4f4f0] dark:bg-zinc-900 text-black dark:text-white font-mono' :
      'bg-[#f5f5f7] dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans'
    }\`}>`;

code = code.replace(mainWrapperRegex, newMainWrapper);

// 4. Inject the theme dropdown into the main header
// Find: <div className="flex justify-between items-start mb-6">
const headerRegex = /<div className="flex justify-between items-start mb-6">/m;
const newHeader = `<div className="flex justify-between items-start mb-6 transition-all duration-500">
          <div className="flex flex-col gap-2">
            {/* Theme Settings Dropdown */}
            <div className="flex items-center gap-2 text-sm z-50">
              <span className="text-current opacity-60 font-medium">{t("Theme:", "Тема:")}</span>
              <select
                value={appTheme}
                onChange={(e) => setAppTheme(e.target.value)}
                className="bg-black/5 dark:bg-white/10 text-current px-3 py-1.5 rounded-lg border-0 cursor-pointer focus:ring-2 focus:ring-current outline-none transition-all duration-300"
              >
                <option value="default">Стандартная</option>
                <option value="minimalism">Минимализм (Clean)</option>
                <option value="anime">Аниме (Kawaii & Neon)</option>
                <option value="designer">Дизайнерская (Glass)</option>
                <option value="cyberpunk">Киберпанк (High Tech)</option>
                <option value="brutalism">Брутализм (Bold)</option>
              </select>
            </div>
          </div>`;

// Wait, the header already has content inside:
// <div className="flex justify-between items-start mb-6">
//   <div>
//     <h1 className="text-3xl font-bold tracking-tight mb-1">{t("Dashboard", "Панель управления")}</h1>

fs.writeFileSync('src/App.tsx', code);
console.log('Done replacement part 1');
