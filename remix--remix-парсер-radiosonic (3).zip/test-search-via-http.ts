import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp('Tones And I Dance Monkey').then(r => console.dir(r, {depth: null})).catch(console.error);
