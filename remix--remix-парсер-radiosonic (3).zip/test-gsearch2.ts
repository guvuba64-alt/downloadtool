import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://www.google.com/search?q=${url}&hl=en`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  validateStatus: () => true
});
const matches = r.data.match(/<h3[^>]*>(.*?)<\/h3>/g);
console.log(r.status, matches ? matches : r.data.substring(0, 300));
