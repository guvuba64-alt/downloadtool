const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex1 = /const okOwnerName = deep\.copyrightOwnerName \|\| okResult\?\.copyrightOwnerName \|\| okResult\?\.track\?\.copyrightOwnerName \|\| null;/;
const replacement1 = `const okOwnerName = deep.copyrightOwnerName || okResult?.copyrightOwnerName || okResult?.copyright || okResult?.track?.copyrightOwnerName || null;`;

const regex2 = /let finalCopyright = okOwnerName \|\| null;/;
const replacement2 = `let finalCopyright = okOwnerName || okResult?.copyright || null;`;

code = code.replace(regex1, replacement1);
code = code.replace(regex2, replacement2);
fs.writeFileSync('server-okru.ts', code);
