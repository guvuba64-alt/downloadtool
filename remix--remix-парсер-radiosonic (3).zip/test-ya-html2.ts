import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const matchTitle = r.data.match(/<title>(.*?)<\/title>/);
  console.log("Title tag:", matchTitle ? matchTitle[1] : 'none');
  const dMonkey = r.data.match(/Dance Monkey/i);
  console.log("Has Dance Monkey:", !!dMonkey);
}).catch(console.error);
