const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetRender = `        {(activeAppTab === "parser" || activeAppTab === "yandex") && (
          <UnifiedParserTab
            onPlayTrack={handlePlayTrackGlobally}
            onSelectAlbum={(id) => {
              handleOpenAlbumModal(id);
            }}
            onSelectArtist={(id) => {
              setCurrentArtistId(id);
              setActiveAppTab("artist");
            }}
            t={t}
            appTheme={appTheme}
          />
        )}`;

const replacementRender = `        {activeAppTab === "yandex" && (
          <YandexMusicTab
            onPlayTrack={handlePlayTrackGlobally}
            onSelectAlbum={(id) => {
              handleOpenAlbumModal(id);
            }}
            onSelectArtist={(id) => {
              setCurrentArtistId(id);
              setActiveAppTab("artist");
            }}
            t={t}
          />
        )}`;

code = code.replace(targetRender, replacementRender);

// Also remove import of UnifiedParserTab
code = code.replace('import { UnifiedParserTab } from "./components/UnifiedParserTab";\n', '');

fs.writeFileSync('src/App.tsx', code);
console.log("Restored YandexMusicTab and removed UnifiedParserTab.");
