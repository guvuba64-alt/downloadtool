const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const importGemini = `import { GoogleGenAI } from "@google/genai";\n`;
if (!code.includes('@google/genai')) {
  code = importGemini + code;
}

const endpointCode = `
app.post('/api/generate-naming', express.json(), async (req, res) => {
  try {
    const { type, inputs } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured' });
    }

    const ai = new GoogleGenAI({ apiKey });

    let systemPrompt = '';
    let userPrompt = '';

    if (type === 'label') {
      systemPrompt = \`# MASTER PROMPT: НЕЙМИНГ МЕЖДУНАРОДНОЙ MEDIA / ENTERTAINMENT GROUP

## 1. ТВОЯ РОЛЬ
Ты — senior-level brand strategist и специалист по международному корпоративному неймингу.
Ты занимаешься созданием названий для музыкальных компаний, лейблов, entertainment-компаний, media groups, production companies, publishing companies, холдингов и технологических и контентных компаний.
Твоя задача — создать название потенциального международного холдинга, а не название маленького музыкального лейбла.

## 2. КОНТЕКСТ КОМПАНИИ
Компания представляет собой международную media / entertainment group.
В её структуру входит музыкальный лейбл.
Компания работает с: артистами, музыкальными релизами, каталогами, интеллектуальной собственностью, медиа-контентом, entertainment-направлениями.

## 3. ОСНОВНЫЕ ЦЕЛИ БРЕНДА
Название должно восприниматься как крупная международная компания, которая потенциально может существовать десятилетиями.
Оно должно быть: статусным, уверенным, профессиональным, международным, масштабируемым, запоминающимся.

## 4. ЯЗЫК
Название должно быть только на английском языке либо представлять собой искусственно созданное слово, которое естественно воспринимается в международной англоязычной среде.

## 5. ИЗБЕГАЙ КЛИШЕ
Категорически не злоупотребляй словами и корнями вроде: Nova, Prime, Apex, Vertex, Meridian, Zenith, Nexus, Horizon, Vision, Global, Future, Digital, Infinity, Universal, United, Origin, One, Unite.

## 6. КОЛИЧЕСТВО ВАРИАНТОВ
Предложи 5-7 наиболее сильных вариантов. Выдели TOP 3. Выбери ОДИН абсолютный победитель.\`;
      
      userPrompt = \`Сгенерируй названия для музыкального лейбла/медиа группы.
Входные данные: \${inputs}\`;

    } else {
      systemPrompt = \`# MASTER PROMPT: ПРОФЕССИОНАЛЬНЫЙ НЕЙМИНГ ПСЕВДОНИМА АРТИСТА

## 1. ТВОЯ РОЛЬ
Ты — профессиональный стратег по неймингу в музыкальной индустрии, специалист по созданию сценических имён, артистических брендов и музыкальных идентичностей.
Твоя задача — найти такое имя, которое может стать полноценным брендом артиста и нормально существовать в музыкальной индустрии долгие годы.

## 2. ГЛАВНАЯ ЦЕЛЬ
Создай не просто псевдоним, а сильную артистическую торговую марку.
Приоритет: сильная идентичность > уникальность > простота > модность.

## 3. ЖЁСТКИЙ ФИЛЬТР
Удали варианты, которые: звучат банально, напоминают случайный ник, слишком похожи на уже известные артистические имена, используют избитые слова.

## 4. КОЛИЧЕСТВО И ОЦЕНКА
Предложи 5-7 действительно разных вариантов. Для каждого оцени запоминаемость, уникальность, бренд-потенциал (от 1 до 10). Выдели TOP 3 и выбери 1 победителя.\`;

      userPrompt = \`Сгенерируй псевдоним для артиста.
Входные данные: \${inputs}\`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    res.json({ result: response.text });
  } catch (error) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: 'Failed to generate naming' });
  }
});
`;

code = code.replace(
  `app.post('/api/tg/webhook/:token', express.json(), async (req, res) => {`,
  endpointCode + `\napp.post('/api/tg/webhook/:token', express.json(), async (req, res) => {`
);

fs.writeFileSync('server.ts', code);
console.log('Added gemini endpoint');
