const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');

const startStr = '{isInfoOpen && (';
const start = code.indexOf(startStr);
const endStr = '</AnimatePresence>';
const end = code.indexOf(endStr, start);

const newModal = `{menuState !== 'none' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-end justify-center sm:items-center sm:p-6"
            onClick={() => setMenuState('none')}
          >
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full sm:max-w-md bg-[#12091F] rounded-t-[24px] sm:rounded-[24px] overflow-hidden relative flex flex-col max-h-[90vh]"
              onClick={e => e.stopPropagation()}
            >
               {menuState === 'main' ? (
                 <div className="flex flex-col p-4">
                   {/* Main Menu State */}
                   
                   {/* Header Row: Cover + Title + Duration */}
                   <div className="flex items-center gap-4 mb-6">
                     <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-white/5">
                        {albumCover && <ProxyImage src={albumCover.startsWith("http") ? albumCover.replace("%%", "200x200") : "https://" + albumCover.replace("%%", "200x200")} className="w-full h-full object-cover" />}
                     </div>
                     <div className="flex-1 min-w-0 flex flex-col justify-center">
                        <div className="flex items-center gap-2">
                           <h3 className="text-xl font-bold text-white truncate">{track.title}</h3>
                           {track.explicit && <div className="w-4 h-4 rounded-sm bg-white/20 text-[9px] flex items-center justify-center font-bold text-white">E</div>}
                        </div>
                        {track.duration > 0 && (
                          <div className="text-white/50 text-sm mt-0.5">
                            {Math.floor(track.duration / 60)}:{String(Math.floor(track.duration % 60)).padStart(2, '0')}
                          </div>
                        )}
                     </div>
                     <ChevronRight className="w-6 h-6 text-white/30" />
                   </div>
                   
                   {/* Artist Row */}
                   <div className="flex items-center gap-4 mb-4">
                     <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 bg-white/5">
                       {artistAvatarUri && <ProxyImage src={artistAvatarUri} className="w-full h-full object-cover" />}
                     </div>
                     <div className="flex-1 min-w-0">
                       <p className="text-lg font-bold text-white truncate">{albumArtists || track.artists}</p>
                     </div>
                   </div>
                   
                   {/* Age Restriction */}
                   {track.explicit && (
                     <div className="text-white/50 text-sm mb-6">
                       Возрастное ограничение 18+
                     </div>
                   )}
                   
                   {/* My Vibe Button */}
                   <button className="w-full mb-6 relative overflow-hidden rounded-2xl h-16 group transition-transform active:scale-95">
                     <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-transparent" />
                     <div className="absolute inset-0 flex flex-col items-center justify-center">
                       <span className="text-white/60 text-xs uppercase tracking-widest font-medium mb-1">Моя волна по треку</span>
                       <div className="flex items-center gap-2 text-white">
                         <Play className="w-4 h-4 fill-white" />
                         <span className="font-bold">{track.title}</span>
                       </div>
                     </div>
                   </button>
                   
                   <div className="h-px bg-white/10 w-full mb-4" />
                   
                   <div className="flex justify-around items-center py-2">
                     <button 
                       onClick={() => {
                          const url = "/api/music/stream/" + track.id + "?download=true";
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = track.title + ".wav";
                          a.click();
                       }}
                       className="flex flex-col items-center justify-center gap-2 text-white/60 hover:text-white transition-colors"
                     >
                       <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                         <Download className="w-7 h-7" />
                       </div>
                       <span className="text-xs font-medium">Скачать WAV</span>
                     </button>
                   </div>
                   
                   <div className="h-px bg-white/10 w-full mt-4 mb-2" />
                   
                   <button onClick={() => setMenuState('info')} className="flex items-center gap-4 p-4 text-white hover:bg-white/5 rounded-xl transition-colors">
                     <Info className="w-6 h-6 text-white/50" />
                     <span className="font-medium">О треке</span>
                   </button>
                   
                 </div>
               ) : (
                 <div className="flex flex-col p-6 h-full overflow-y-auto overflow-x-hidden">
                   {/* Info State */}
                   <div className="flex items-center justify-center relative mb-8">
                     <div className="flex flex-col items-center text-center">
                       <div className="flex items-center gap-2 mb-1">
                         <h3 className="text-2xl font-bold text-white truncate max-w-[280px]">{trackDetails?.title || track.title}</h3>
                         {track.explicit && <div className="w-4 h-4 rounded-sm bg-white/20 text-[9px] flex items-center justify-center font-bold text-white">E</div>}
                       </div>
                       <p className="text-white/50 text-sm">
                         {albumArtists || track.artists} • {track.duration > 0 ? \`\${Math.floor(track.duration / 60)}:\${String(Math.floor(track.duration % 60)).padStart(2, '0')}\` : ''}
                       </p>
                     </div>
                   </div>
                   
                   <div className="space-y-6">
                     {(trackDetails?.label || trackDetails?.copyright) && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">ЛЕЙБЛ</p>
                       <p className="text-white font-medium">{trackDetails?.label || trackDetails?.copyright}</p>
                     </div>
                     )}
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">ИСПОЛНИТЕЛЬ</p>
                       <p className="text-white font-medium">{albumArtists || track.artists}</p>
                     </div>
                     {(trackDetails?.copyright) && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">ИСТОЧНИК ФОНОГРАММЫ</p>
                       <p className="text-white font-medium">{trackDetails.copyright}</p>
                     </div>
                     )}
                     {trackDetails?.releaseDate && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">ДАТА ВЫХОДА</p>
                       <p className="text-white font-medium">{new Date(trackDetails.releaseDate).toLocaleDateString('ru-RU')}</p>
                     </div>
                     )}
                     {trackDetails?.upc && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">UPC</p>
                       <p className="text-white font-mono text-sm">{trackDetails.upc}</p>
                     </div>
                     )}
                     {trackDetails?.isrc && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">ISRC</p>
                       <p className="text-white font-mono text-sm">{trackDetails.isrc}</p>
                     </div>
                     )}
                     {trackDetails?.authorsMusic && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">АВТОРЫ МУЗЫКИ</p>
                       <p className="text-white font-medium">{trackDetails.authorsMusic}</p>
                     </div>
                     )}
                     {trackDetails?.authorsText && (
                     <div>
                       <p className="text-white/40 text-xs uppercase tracking-wider mb-1">АВТОРЫ ТЕКСТА</p>
                       <p className="text-white font-medium">{trackDetails.authorsText}</p>
                     </div>
                     )}
                   </div>
                 </div>
               )}
               
               <div className="absolute top-2 w-full flex justify-center">
                 <div className="w-12 h-1 bg-white/20 rounded-full mt-2" />
               </div>
            </motion.div>
          </motion.div>
        )}
`;

code = code.substring(0, start) + newModal + code.substring(end);
fs.writeFileSync('src/components/ModernPlayer/index.tsx', code);
