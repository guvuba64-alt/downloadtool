const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetTabsContainer = `<div className="flex flex-wrap gap-2 p-2 bg-white/40 dark:bg-black/20 backdrop-blur-md rounded-2xl border border-zinc-200/50 dark:border-white/10 shadow-sm w-full md:w-auto overflow-x-auto">`;
const replacementTabsContainer = `<div className={\`flex flex-wrap gap-2 p-2 shadow-sm w-full md:w-auto overflow-x-auto transition-all duration-500 \${
            appTheme === 'minimalism' ? 'bg-transparent border-b border-zinc-200 dark:border-white/10 rounded-none' : 
            appTheme === 'anime' ? 'bg-white/60 dark:bg-pink-900/40 backdrop-blur-md rounded-[2rem] border-2 border-pink-200 dark:border-pink-800 shadow-pink-200/50' : 
            appTheme === 'designer' ? 'bg-white/40 dark:bg-black/20 backdrop-blur-xl rounded-3xl border border-white/40 dark:border-white/10 shadow-lg' : 
            appTheme === 'cyberpunk' ? 'bg-black/80 border border-yellow-400 rounded-none font-mono shadow-[0_0_10px_rgba(250,204,21,0.2)]' :
            appTheme === 'brutalism' ? 'bg-white dark:bg-zinc-900 border-4 border-black dark:border-white rounded-none shadow-[4px_4px_0_0_rgba(0,0,0,1)] dark:shadow-[4px_4px_0_0_rgba(255,255,255,1)]' :
            'bg-white/40 dark:bg-black/20 backdrop-blur-md rounded-2xl border border-zinc-200/50 dark:border-white/10'
          }\`}>`;

code = code.replace(targetTabsContainer, replacementTabsContainer);

const targetTabButton = `className={\`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 \${activeAppTab === tab.id ? "bg-black dark:bg-white text-white dark:text-black shadow-md scale-105" : "hover:bg-black/5 dark:hover:bg-white/10 text-zinc-600 dark:text-zinc-400"}\`}`;
const replacementTabButton = `className={\`px-5 py-2.5 text-sm font-semibold transition-all duration-300 \${
                    appTheme === 'minimalism' ? (activeAppTab === tab.id ? "text-black dark:text-white border-b-2 border-black dark:border-white" : "text-zinc-500 hover:text-black dark:hover:text-white") :
                    appTheme === 'anime' ? (activeAppTab === tab.id ? "bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-2xl shadow-md scale-105" : "hover:bg-pink-100 dark:hover:bg-pink-900/50 text-pink-700 dark:text-pink-300 rounded-2xl") :
                    appTheme === 'cyberpunk' ? (activeAppTab === tab.id ? "bg-yellow-400 text-black rounded-none shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-yellow-600 hover:text-yellow-400 hover:bg-yellow-400/10 rounded-none") :
                    appTheme === 'brutalism' ? (activeAppTab === tab.id ? "bg-black dark:bg-white text-white dark:text-black rounded-none" : "hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-none") :
                    (activeAppTab === tab.id ? "bg-black dark:bg-white text-white dark:text-black shadow-md scale-105 rounded-xl" : "hover:bg-black/5 dark:hover:bg-white/10 text-zinc-600 dark:text-zinc-400 rounded-xl")
                  }\`}`;

code = code.replace(targetTabButton, replacementTabButton);

fs.writeFileSync('src/App.tsx', code);
console.log('Tabs styled');
