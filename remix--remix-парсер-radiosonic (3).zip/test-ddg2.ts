import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru "album/7542918/track/53066380"');
axios.get(`https://html.duckduckgo.com/html/?q=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
  validateStatus: () => true
}).then(r => console.log(r.data.match(/<a class="result__snippet[^>]+>(.*?)<\/a>/s)?.[1] || r.data.substring(0, 500)));
