const fs = require('fs');

let content = fs.readFileSync('src/components/TgAuthGuard.tsx', 'utf8');

content = content.replace(
    'onChange={(e) => setAuthCode(e.target.value)}',
    'onChange={(e) => setAuthCode(e.target.value.replace(/\\D/g, ""))} inputMode="numeric" pattern="[0-9]*" type="tel"'
);

// also fix type="text" specifically for authCode to avoid conflict with the type="tel" I just injected
content = content.replace(
    '<input\n                type="text"\n                required\n                value={authCode}',
    '<input\n                required\n                value={authCode}'
);

fs.writeFileSync('src/components/TgAuthGuard.tsx', content);
console.log('Fixed TgAuthGuard.tsx');
