const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

const targetUIStart = '<div className="flex items-center justify-end gap-2">';
const targetUIEnd = 'Парсить JSON</span>\n              </button>\n            </div>';

let startIdx = code.indexOf(targetUIStart);
let endIdx = code.indexOf(targetUIEnd, startIdx);

if (startIdx !== -1 && endIdx !== -1) {
  const newUI = `<div className="flex items-center justify-end gap-2">
              {isParsingOkRuJson ? (
                <div className="flex items-center gap-2 text-emerald-500 font-semibold text-xs px-3 py-2 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Автоматический парсинг...</span>
                </div>
              ) : (
                <button
                  onClick={handleParseOkRuJson}
                  disabled={!okRuJson.trim()}
                  className="hidden"
                >
                  Parse
                </button>
              )}
            </div>`;
  code = code.substring(0, startIdx) + newUI + code.substring(endIdx + targetUIEnd.length);
  fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
  console.log('Updated UnifiedParser UI');
} else {
  console.log('UI block not found');
}
