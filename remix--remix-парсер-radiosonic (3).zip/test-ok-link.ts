import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse("https://ok.ru/music/track/122396349601366").then(x => console.dir(x, {depth: null})).catch(console.error);
