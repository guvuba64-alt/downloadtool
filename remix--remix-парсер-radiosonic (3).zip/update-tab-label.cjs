const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  `{ id: "prompts", label: t("Prompts", "Промпты") }`,
  `{ id: "prompts", label: t("Creation", "Создание") }`
);

fs.writeFileSync('src/App.tsx', code);
console.log('Updated tab label');
