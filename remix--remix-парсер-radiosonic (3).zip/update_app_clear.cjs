const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `    setIsParsingOkRuJson(false);
  };`;

const replacement = `    setIsParsingOkRuJson(false);
    setOkRuJson(""); // Auto-clear to reset parser
  };`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/App.tsx', code);
  console.log('App.tsx clear updated');
} else {
  console.log('App.tsx target not found');
}
