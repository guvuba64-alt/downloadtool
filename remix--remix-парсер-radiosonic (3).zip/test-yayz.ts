import axios from 'axios';
const tlds = ['kz', 'by', 'uz', 'com', 'com.tr'];
for (const tld of tlds) {
  try {
    const res = await axios.get(`https://api.music.yandex.${tld}/tracks/53066380`, {
      headers: { 'User-Agent': 'Yandex-Music-API' },
      validateStatus: () => true,
      timeout: 3000
    });
    console.log(`yandex.${tld} -> ${res.status}`);
  } catch(e) {
    console.log(`yandex.${tld} -> ${e.message}`);
  }
}
