import axios from 'axios';
axios.get('https://album.link/i/1440936235', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("Keys:", Object.keys(data.props?.pageProps?.pageData || {}));
    console.log("entityData:", data.props?.pageProps?.pageData?.entityData);
  }
}).catch(console.error);
