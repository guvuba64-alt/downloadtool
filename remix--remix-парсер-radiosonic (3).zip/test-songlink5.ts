import axios from 'axios';
axios.get('https://song.link/ya/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("ya/7542918 entityData:", data.props?.pageProps?.pageData?.entityData);
  }
}).catch(console.error);

axios.get('https://album.link/ya/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("album.link/ya/7542918 entityData:", data.props?.pageProps?.pageData?.entityData);
  }
}).catch(console.error);
