const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(`                </form>
              </div>
            </div>

            {metadataResult && metadataResult.type === "artist" ? (`, `                </form>
              </div>

            {metadataResult && metadataResult.type === "artist" ? (`);

fs.writeFileSync('src/App.tsx', content);
console.log("Fixed div!");
