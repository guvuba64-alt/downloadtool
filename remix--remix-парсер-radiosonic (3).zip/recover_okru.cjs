const fs = require('fs');
const map = JSON.parse(fs.readFileSync('dist/server.cjs.map', 'utf8'));
const index = map.sources.findIndex(s => s === 'server-okru.ts' || s.includes('server-okru.ts'));
if (index !== -1) {
    fs.writeFileSync('server-okru.ts', map.sourcesContent[index]);
    console.log('Recovered server-okru.ts!');
} else {
    console.log('Not found in sourcemap. Sources: ', map.sources);
}
