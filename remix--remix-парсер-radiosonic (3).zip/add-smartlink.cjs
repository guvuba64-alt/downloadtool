const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetStr = `{metadataResult.links && Object.keys(metadataResult.links).length > 0 ? (`;
const replacementStr = `{metadataResult.links && Object.keys(metadataResult.links).length > 0 ? (
                         <>
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold text-zinc-900 dark:text-zinc-50">{t("Available Platforms", "Доступные площадки")}</h3>
                            <button
                              onClick={(e) => {
                                const btn = e.currentTarget;
                                const originalText = btn.innerHTML;
                                const linksText = Object.entries(metadataResult.links)
                                  .map(([platform, link]) => \`\${platform.replace(/([A-Z])/g, ' $1').trim()}: \${link.url}\`)
                                  .join('\\n');
                                const smartLink = \`\${metadataResult.title}\\n\\n\${t("Listen on:", "Слушать на:")}\\n\${linksText}\`;
                                navigator.clipboard.writeText(smartLink);
                                btn.innerHTML = \`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="20 6 9 17 4 12"></polyline></svg> \${t("Copied!", "Скопировано!")}\`;
                                setTimeout(() => {
                                  btn.innerHTML = originalText;
                                }, 2000);
                              }}
                              className="px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl text-sm font-semibold hover:bg-zinc-800 dark:hover:bg-zinc-100 transition-all flex items-center gap-2 shadow-sm"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                              {t("Copy SmartLink", "Скопировать SmartLink")}
                            </button>
                         </div>
                         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">`;

code = code.replace(`{metadataResult.links && Object.keys(metadataResult.links).length > 0 ? (
                         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">`, replacementStr);

fs.writeFileSync('src/App.tsx', code);
console.log('SmartLink added');
