import axios from 'axios';
axios.get('https://music.yandex.ru/iframe/#track/53066380/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.data.substring(0, 300)));
