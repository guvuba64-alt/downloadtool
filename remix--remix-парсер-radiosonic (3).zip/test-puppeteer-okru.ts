import { addExtra } from 'puppeteer-extra';
import vanillaPuppeteer from 'puppeteer';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
const puppeteer = addExtra(vanillaPuppeteer);
puppeteer.use(StealthPlugin());

async function run() {
  console.log('Testing puppeteer compilation');
}
run();
