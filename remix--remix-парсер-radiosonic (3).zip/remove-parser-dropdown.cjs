const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const regexToRemove = /\{\/\* Theme Settings Dropdown \*\/\}\s*<div className="mb-4 flex items-center justify-end gap-2 text-sm">[\s\S]*?<\/div>/m;
code = code.replace(regexToRemove, '');

// Also let's fix the parser container to reflect the theme appropriately.
// Currently it's:
const parserContainerOld = `<div className={\`overflow-hidden transition-all duration-500 \${
            appTheme === 'minimalism' ? 'bg-transparent border-0 shadow-none font-sans' : 
            appTheme === 'anime' ? 'bg-gradient-to-br from-pink-50 to-purple-50 dark:from-pink-950 dark:to-purple-950 border-2 border-pink-300 dark:border-pink-800 rounded-[2rem] shadow-[0_0_20px_rgba(236,72,153,0.15)] font-sans' : 
            appTheme === 'designer' ? 'bg-white/60 dark:bg-black/60 backdrop-blur-xl border border-white/40 dark:border-white/10 rounded-3xl shadow-[0_8px_32px_rgba(0,0,0,0.08)]' : 
            appTheme === 'cyberpunk' ? 'bg-black border-l-4 border-r-4 border-y border-yellow-400 font-mono shadow-[0_0_15px_rgba(250,204,21,0.2)] rounded-none text-yellow-400' :
            appTheme === 'brutalism' ? 'bg-white dark:bg-zinc-900 border-4 border-black dark:border-white rounded-none shadow-[8px_8px_0_0_rgba(0,0,0,1)] dark:shadow-[8px_8px_0_0_rgba(255,255,255,1)] font-mono' :
            'bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm'
          }\`}>`;

const parserContainerNew = `<div className={\`overflow-hidden transition-all duration-500 \${
            appTheme === 'minimalism' ? 'bg-transparent border-0 shadow-none' : 
            appTheme === 'anime' ? 'bg-white/60 dark:bg-pink-900/40 backdrop-blur-md rounded-[2rem] border-2 border-pink-200 dark:border-pink-800 shadow-pink-200/50' : 
            appTheme === 'designer' ? 'bg-white/40 dark:bg-black/20 backdrop-blur-xl border border-white/40 dark:border-white/10 rounded-3xl shadow-lg' : 
            appTheme === 'cyberpunk' ? 'bg-black/80 border border-yellow-400 rounded-none shadow-[0_0_15px_rgba(250,204,21,0.2)]' :
            appTheme === 'brutalism' ? 'bg-white dark:bg-zinc-900 border-4 border-black dark:border-white rounded-none shadow-[8px_8px_0_0_rgba(0,0,0,1)] dark:shadow-[8px_8px_0_0_rgba(255,255,255,1)]' :
            'bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm'
          }\`}>`;

code = code.replace(parserContainerOld, parserContainerNew);

fs.writeFileSync('src/App.tsx', code);
console.log('Parser dropdown removed and container styled.');
