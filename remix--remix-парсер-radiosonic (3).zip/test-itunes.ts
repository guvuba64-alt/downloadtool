import axios from 'axios';
axios.get('https://itunes.apple.com/search?term=Joniveli%20Tee%20t%C3%A4st%C3%A4%20hitti&entity=song&limit=1').then(r => console.log(r.data.results[0])).catch(console.error);
