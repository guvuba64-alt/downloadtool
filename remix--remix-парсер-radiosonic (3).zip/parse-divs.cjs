const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');
const startIndex = code.indexOf('{activeResultTab === "platforms" && (');
const endIndex = code.indexOf('{/* Actions / Audio Section */}');
let block = code.substring(startIndex, endIndex);

let opens = (block.match(/<div/g) || []).length;
let closes = (block.match(/<\/div>/g) || []).length;
console.log('Opens:', opens, 'Closes:', closes);
