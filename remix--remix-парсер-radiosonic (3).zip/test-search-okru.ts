import axios from 'axios';
const q = "Tones And I Dance Monkey";
const res = await axios.get(`https://ok.ru/web-api/music/search`, {
  params: { query: q },
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://ok.ru/music',
  }
});
console.log(res.data.tracks?.length);
