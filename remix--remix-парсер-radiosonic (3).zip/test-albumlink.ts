import axios from 'axios';
axios.get('https://album.link/yandex/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("Keys:", Object.keys(data.props?.pageProps?.pageData || {}));
    if (data.props?.pageProps?.pageData?.entityData) {
      console.log(data.props?.pageProps?.pageData?.entityData);
    } else {
      console.log("Entities:", Object.keys(data.props?.pageProps?.pageData?.entitiesByUniqueId || {}));
      console.log(data.props?.pageProps?.pageData?.entitiesByUniqueId?.['YANDEX_MUSIC_ALBUM::7542918']);
    }
  }
}).catch(console.error);
