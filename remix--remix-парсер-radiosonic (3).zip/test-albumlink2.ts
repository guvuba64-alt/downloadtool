import axios from 'axios';
axios.get('https://album.link/https://music.yandex.ru/album/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  console.log(r.status);
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("entityData:", data.props?.pageProps?.pageData?.entityData);
  }
}).catch(console.error);
