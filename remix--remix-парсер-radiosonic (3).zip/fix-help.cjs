const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Add import
if (!content.includes('import { HelpModal }')) {
  content = content.replace('import { SettingsTab } from "./components/SettingsTab";', 'import { SettingsTab } from "./components/SettingsTab";\nimport { HelpModal } from "./components/HelpModal";');
  // Just in case SettingsTab doesn't exist:
  if (!content.includes('import { HelpModal }')) {
     content = content.replace('import { ReportTab } from "./components/ReportTab";', 'import { ReportTab } from "./components/ReportTab";\nimport { HelpModal } from "./components/HelpModal";');
  }
}

// 2. Add state
if (!content.includes('const [showHelpModal, setShowHelpModal] = useState(false)')) {
  content = content.replace('const [activeTab, setActiveTab] = useState("parser");', 'const [activeTab, setActiveTab] = useState("parser");\n  const [showHelpModal, setShowHelpModal] = useState(false);');
}

// 3. Add HelpModal button to header
// Search for Settings button in the header and insert Help button next to it
const headerBtnRegex = /<button\s+onClick=\{\(\) => setActiveTab\('settings'\)\}[\s\S]*?<\/button>/;
const helpBtn = `<button onClick={() => setShowHelpModal(true)} className="p-2 sm:px-4 sm:py-2 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 dark:hover:bg-blue-900/40 transition-colors flex items-center gap-2 font-medium text-sm">
              <HelpCircle className="w-5 h-5" />
              <span className="hidden sm:inline">{t("Guide", "Руководство")}</span>
            </button>`;

if (content.match(headerBtnRegex)) {
  content = content.replace(headerBtnRegex, match => helpBtn + '\n            ' + match);
} else {
  // alternative location - next to Theme toggle?
  const themeRegex = /<button\s+onClick=\{toggleTheme\}[\s\S]*?<\/button>/;
  if (content.match(themeRegex)) {
    content = content.replace(themeRegex, match => helpBtn + '\n            ' + match);
  }
}

// 4. Remove old inline parser help
content = content.replace(/<button onClick=\{\(\) => \{ setShowParserHelp\(!showParserHelp\); localStorage.setItem\('parserHelpSeen', 'true'\); \}\} className="text-sm text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 font-medium flex items-center gap-1">[\s\S]*?<\/button>/, '');
content = content.replace(/\{showParserHelp && \([\s\S]*?\}\)/, '');

// 5. Append Modal right inside the main <div className="min-h-screen"> (at the very bottom of the return)
// The last closing tags are `</div>    </ErrorBoundary>  );` (or similar)
const modalHtml = `\n      <HelpModal isOpen={showHelpModal} onClose={() => setShowHelpModal(false)} t={t} />\n    </div>`;
content = content.replace(/<\/div>\s*<\/ErrorBoundary>\s*\);\s*\}\s*export default App;/, match => `      <HelpModal isOpen={showHelpModal} onClose={() => setShowHelpModal(false)} t={t} />\n` + match);
content = content.replace(/<\/div>\s*\);\s*\}\s*export default App;/, match => `      <HelpModal isOpen={showHelpModal} onClose={() => setShowHelpModal(false)} t={t} />\n` + match);


fs.writeFileSync('src/App.tsx', content);
