const fs = require('fs');

const newHelp = `import React from 'react';
import { HelpCircle, FileText, Music, Send, Key, Shield, Layers, Code, Settings, Link2, Clock, PlayCircle } from 'lucide-react';

export const HelpModal = ({ onClose, t }: { onClose: () => void, t: any }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        <div className="p-6 border-b border-zinc-200 dark:border-zinc-800 shrink-0 flex items-center gap-3 bg-zinc-50 dark:bg-white/5">
          <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
            <HelpCircle className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-zinc-900 dark:text-white tracking-tight">{t("Detailed Guide & Knowledge Base", "Расширенное руководство и База знаний")}</h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">{t("Everything you need to know about the app", "Полная документация: от архитектуры до работы каждого кода и API")}</p>
          </div>
        </div>

        <div className="overflow-y-auto p-6 space-y-12 custom-scrollbar">
          
          {/* 1. Architecture */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2">
              <Layers className="w-5 h-5 text-indigo-500" />
              1. Архитектура: Что за что отвечает?
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 leading-relaxed">
              Наше приложение — это комплексная платформа (швейцарский нож) для музыкальных менеджеров, артистов и лейблов. Оно состоит из <strong>трёх независимых модулей</strong>, которые образуют единый конвейер.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-indigo-50 dark:bg-indigo-900/10 p-5 rounded-2xl border border-indigo-100 dark:border-indigo-900/30">
                <h4 className="font-bold text-indigo-900 dark:text-indigo-300 mb-2">1. Модуль Парсинга (Сбор данных)</h4>
                <p className="text-xs text-indigo-800 dark:text-indigo-400">Этот блок отвечает за извлечение информации. Он делает скрытые запросы к API Яндекс Музыки, Spotify, VK и Одноклассников, чтобы собрать метаданные треков (коды, обложки, авторов) без необходимости вручную заходить на каждый сайт.</p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-900/10 p-5 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                <h4 className="font-bold text-emerald-900 dark:text-emerald-300 mb-2">2. Модуль Процессинга (Отчёты)</h4>
                <p className="text-xs text-emerald-800 dark:text-emerald-400">Финансовое ядро. Загружает сырые таблицы (Excel/CSV) от дистрибьюторов, вычисляет доходы каждого артиста по заранее заданным формулам (удержание % лейбла) и генерирует красивые PDF-акты.</p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/10 p-5 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-2">3. Модуль Доставки (Telegram)</h4>
                <p className="text-xs text-blue-800 dark:text-blue-400">Модуль связи. Берет готовые PDF-отчеты из Процессинга и, используя ваш Telegram-бот, автоматически рассылает их сотням артистов в личные сообщения по их уникальным Chat ID.</p>
              </div>
            </div>
          </section>

          {/* 2. Tabs and Features */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2">
              <Settings className="w-5 h-5 text-emerald-500" />
              2. Полный обзор всех вкладок и функций
            </h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              
              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Music className="w-4 h-4"/> Поиск (Плеер)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Встроенный стриминг внутри панели управления. Вам не нужно открывать сторонние плееры, чтобы проверить, как звучит релиз.</p>
                  <p><strong>Как работает:</strong> Работает через интеграцию с публичными API. Вы ищете трек или артиста, мы показываем официальные данные и обложки.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><PlayCircle className="w-4 h-4"/> Моя Волна (Vibe)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Бесконечный поток музыки на основе ИИ-рекомендаций.</p>
                  <p><strong>Как работает:</strong> Использует алгоритмы Яндекс Музыки (через защищенный токен), чтобы подбирать треки похожие на то, что вы слушаете прямо сейчас.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Clock className="w-4 h-4"/> История прослушиваний</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Сохраняет треки, которые вы недавно включали, чтобы к ним можно было быстро вернуться.</p>
                  <p><strong>Как работает:</strong> Записывает список треков в локальную память вашего браузера (Local Storage).</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Link2 className="w-4 h-4"/> Универсальный парсер</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Это инструмент для менеджеров, чтобы собрать все ссылки на альбом на всех мировых площадках (SmartLink) и проверить технические коды релиза.</p>
                  <p><strong>Как работает:</strong> Вы вставляете одну ссылку из Яндекса, программа забирает название и авторов, а затем автоматически в фоновом режиме делает поисковые запросы по ВК, Spotify, Звук и т.д., чтобы найти точные копии этого релиза.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800 lg:col-span-2">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><FileText className="w-4 h-4"/> Отчёты (Финансовый модуль)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Автоматизация выплаты роялти артистам. Обычно дистрибьютор выдает огромный CSV-файл со всеми прослушиваниями. Артистам такое не отправишь.</p>
                  <p><strong>Как работает:</strong> 1) Вы вводите настройки (название лейбла, ваш процент удержания). 2) Загружаете CSV. 3) Приложение фильтрует файл, группирует доходы по артистам, отнимает процент лейбла. 4) Создает красивые PDF-акты. 5) Отправляет PDF артисту в Telegram, используя Chat ID из специальной таблицы.</p>
                </div>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800 lg:col-span-2">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-2 flex items-center gap-2"><Send className="w-4 h-4"/> Журнал (Telegram Логи)</h4>
                <div className="text-sm text-zinc-600 dark:text-zinc-400 space-y-2">
                  <p><strong>Зачем:</strong> Отслеживание массовой рассылки документов.</p>
                  <p><strong>Как работает:</strong> Показывает статус каждого отправленного сообщения: <span className="text-emerald-500 font-bold">Отправлено (Успех)</span> или <span className="text-red-500 font-bold">Ошибка (Провал)</span>. Если артист удалил свой аккаунт или заблокировал бота, вы увидите ошибку 400 (Bad Request). Если мы отправили слишком много файлов за раз, система покажет ошибку 429 (Rate Limit) и автоматически подождет пару секунд перед повторной отправкой.</p>
                </div>
              </div>

            </div>
          </section>

          {/* 3. Коды */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2">
              <Code className="w-5 h-5 text-purple-500" />
              3. Музыкальные коды (UPC, ISRC): Что это и почему они нужны?
            </h3>
            <div className="space-y-4 text-sm text-zinc-600 dark:text-zinc-400">
              
              <div className="bg-purple-50 dark:bg-purple-900/10 p-5 rounded-2xl border border-purple-100 dark:border-purple-900/30">
                <h4 className="font-bold text-purple-900 dark:text-purple-300 text-base mb-2">UPC (Universal Product Code) — Код Релиза</h4>
                <p><strong>Что это:</strong> Это уникальный цифровой штрих-код всего вашего релиза (сингла, EP или альбома целиком). Точно такой же штрих-код вы видите на пачках молока в супермаркете.</p>
                <p className="mt-2"><strong>Почему он нужен:</strong> Когда лейбл или агрегатор загружает музыку на платформу, UPC используется для учета продаж всего альбома как единого товара. Именно по нему формируются общие финансовые отчеты за весь релиз.</p>
              </div>

              <div className="bg-pink-50 dark:bg-pink-900/10 p-5 rounded-2xl border border-pink-100 dark:border-pink-900/30">
                <h4 className="font-bold text-pink-900 dark:text-pink-300 text-base mb-2">ISRC (International Standard Recording Code) — Код Трека</h4>
                <p><strong>Что это:</strong> Это "Паспорт" конкретной звукозаписи (например: <code>RU-A1B-23-00001</code>). В одном альбоме (с одним UPC) может быть 10 треков, и у каждого будет свой уникальный ISRC.</p>
                <p className="mt-2"><strong>Почему он нужен (КРИТИЧЕСКИ ВАЖНО):</strong> Музыкальные площадки и дистрибьюторы выплачивают роялти (деньги) именно по ISRC! Если трек выйдет на сборнике, в составе альбома или синглом — пока у него один и тот же ISRC, все прослушивания будут суммироваться в одну корзину. Универсальный парсер извлекает эти коды, чтобы вы могли проверить, правильно ли дистрибьютор загрузил ваши треки, и не потеряете ли вы деньги.</p>
              </div>

            </div>
          </section>

          {/* 4. APIs, Tokens, and Codes */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-4 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2">
              <Key className="w-5 h-5 text-amber-500" />
              4. Токены, API, JSON и Cookies — зачем всё это?
            </h3>
            <div className="space-y-4 text-sm text-zinc-600 dark:text-zinc-400">
              
              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border-l-4 border-amber-500 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-base mb-2">Что такое API? (Application Programming Interface)</h4>
                <p>Представьте, что <strong>API — это официант в ресторане</strong>. Вы (наше приложение) даете ему заказ ("Принеси мне данные о треке" или "Отправь сообщение"). Официант идет на закрытую кухню (на сервер Telegram или Spotify) и приносит вам готовое блюдо (результат в виде кода). Без API наше приложение не могло бы общаться с серверами других компаний.</p>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border-l-4 border-blue-500 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-base mb-2">Что такое Токен (API Key / Bot Token)?</h4>
                <p>Возвращаясь к аналогии ресторана — это ваш <strong>VIP-пропуск</strong>. Ресторан (API) не обслуживает кого попало. Ему нужно доказательство того, что вы имеете право делать заказы. Токен — это длинный криптографический пароль, который выдают только вам.</p>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  <li><strong>Telegram Bot Token:</strong> Доказывает Telegram, что вы владелец бота, и разрешает отправлять PDF-отчеты от его имени.</li>
                  <li><strong>Spotify Client ID/Secret:</strong> Дает приложению легальное право делать поисковые запросы по базе Spotify.</li>
                </ul>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border-l-4 border-emerald-500 shadow-sm">
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-base mb-2">Зачем нужны ручные Cookie и ввод JSON ответов?</h4>
                <p>Многие площадки (например, VK Музыка или Одноклассники) очень закрытые. Они не дают публичного API "официанта", потому что боятся пиратов.</p>
                <p className="mt-2"><strong>Cookie:</strong> Это слепок вашей активной сессии. Когда вы заходите в Одноклассники в браузере, сайт дает вам невидимую печать (Cookie). Если вы вставите эту печать в наше приложение, парсер сможет "притвориться" вами и зайти на сайт, чтобы легально прочитать названия треков, не вызывая подозрений у защиты от ботов.</p>
                <p className="mt-2"><strong>Ввод JSON:</strong> JSON — это текстовый формат данных (например: <code>{"title": "Track Name"}</code>). Иногда парсер не может зайти на сайт сам из-за капчи. Тогда мы просим вас открыть панель разработчика браузера, скопировать ответ сервера вручную (этот самый JSON) и вставить в программу. Приложение само его расшифрует и извлечет нужные UPC/ISRC.</p>
              </div>

            </div>
          </section>

          {/* 5. Safety & Privacy */}
          <section>
            <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50 mb-3 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2">
              <Shield className="w-5 h-5 text-red-500" />
              5. Безопасность и Приватность
            </h3>
            <div className="text-zinc-600 dark:text-zinc-400 space-y-2 text-sm leading-relaxed bg-zinc-50 dark:bg-white/5 p-5 rounded-2xl border border-red-100 dark:border-red-900/30">
              <p className="font-bold text-red-800 dark:text-red-400 mb-2 uppercase">Никогда и никому не передавайте ваши токены, ключи API или Cookies!</p>
              <ul className="list-disc pl-5 space-y-1.5 marker:text-red-400">
                <li>Все ваши ключи, токены и конфиденциальные настройки сохраняются <strong>ИСКЛЮЧИТЕЛЬНО в памяти вашего браузера</strong> (в Local Storage).</li>
                <li>Наше приложение работает <strong>без серверной базы данных</strong>. У нас нет серверов, куда эти ключи могли бы "утечь".</li>
                <li>Ваш браузер сам напрямую стучится в Telegram, Spotify или Яндекс. Приложение — это просто интерфейс (оболочка), выполняющая код на вашем компьютере.</li>
                <li>Если вы очистите историю браузера, все ключи удалятся безвозвратно.</li>
              </ul>
            </div>
          </section>

        </div>

        <div className="p-6 border-t border-zinc-200 dark:border-zinc-800 shrink-0 bg-zinc-50 dark:bg-white/5 flex justify-end">
          <button onClick={onClose} className="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-xl transition-all hover:scale-105 active:scale-95 shadow-md shadow-blue-500/20">
            {t("Got it! Thanks", "Понятно, спасибо, я всё изучил")}
          </button>
        </div>
      </div>
    </div>
  );
};
`
fs.writeFileSync('src/components/HelpModal.tsx', newHelp);
console.log('HelpModal dramatically expanded');
