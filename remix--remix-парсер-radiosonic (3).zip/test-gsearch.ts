import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru "album/7542918/track/53066380"');
const r = await axios.get(`https://www.google.com/search?q=${url}&hl=en`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
});
const match = r.data.match(/<h3[^>]*>(.*?)<\/h3>/);
console.log(r.status, "Match:", match ? match[1] : 'none');
