import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://music.yandex.ru/album/7542918/track/53066380', 'auto').then(r => console.dir(r, {depth:null})).catch(console.error);
