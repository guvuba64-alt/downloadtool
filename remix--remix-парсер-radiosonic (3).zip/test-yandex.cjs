const axios = require('axios');
async function test() {
  try {
    const token = "y0__xCK7-OYBRje-AYgpby9wRYw6a7F7wddxnj7HXeOAc7Jw0Hgrw8ZXN3M3A";
    const res = await axios.get('https://api.music.yandex.net/tracks/53066380', {
      headers: { 'User-Agent': 'Yandex-Music-API', 'Authorization': `OAuth ${token}` }
    });
    console.log("SUCCESS:", res.data.result[0].title);
  } catch (e) {
    console.log("ERROR:", e.response?.status, e.response?.data);
  }
}
test();
