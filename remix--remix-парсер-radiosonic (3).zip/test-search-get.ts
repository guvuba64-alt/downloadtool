import { searchOkRu } from './server-okru.js';
searchOkRu("Dance Monkey").then(console.dir);
