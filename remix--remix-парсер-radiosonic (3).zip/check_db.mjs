import { sqlite } from './src/db/index.js';

async function run() {
  try {
    const res = await sqlite.execute('SELECT * FROM tokens');
    console.log(res.rows);
  } catch (err) {
    console.error(err);
  }
}
run();
