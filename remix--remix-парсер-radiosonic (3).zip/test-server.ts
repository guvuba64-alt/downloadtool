import axios from 'axios';
axios.post('http://localhost:3000/api/music/universal-parse', { url: 'https://music.yandex.ru/album/28416827/track/119932131' }).then(r => console.dir(r.data, {depth:null})).catch(console.error);
