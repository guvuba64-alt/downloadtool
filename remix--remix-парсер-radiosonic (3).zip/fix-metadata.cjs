const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex = /const strictCopyright = \(typeof rawOwner === 'string' && rawOwner\.trim\(\)\.length > 0\) \? rawOwner\.trim\(\) : null;[\s\S]*?return \{[\s\S]*?copyright: strictCopyright,[\s\S]*?copyrightOwnerName: strictCopyright,/;

const replacement = `const strictCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
  
  let foundLabel = rawLabel || deepScan.label || rawPublisher || 'Правообладатель';
  if (aggregator && (!foundLabel || foundLabel === aggregator)) {
    const other = allVals.find(s => s !== aggregator);
    if (other) {
      foundLabel = other;
    }
  }

  const foundCopyright = aggregator || strictCopyright || rawPline || rawPublisher || rawCopyright || null;
  const foundDistributor = rawOwner || deepScan.distributor || aggregator || (foundLabel && aggregator ? aggregator : undefined);
  
  if (track.album && track.album.year && !track.releaseDate) track.releaseDate = track.album.year;
  if (!track.releaseDate && deepScan.releaseDate) track.releaseDate = deepScan.releaseDate;
  if (!track.isrc && deepScan.isrc) track.isrc = deepScan.isrc;
  if (!track.upc && deepScan.upc) track.upc = deepScan.upc;

  return {
    copyright: foundCopyright,
    copyrightOwnerName: foundCopyright,`;

code = code.replace(regex, replacement);
fs.writeFileSync('server-okru.ts', code);
