import { safeDecodeURIComponent } from './server/textSanitizer';
import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import { sqlite } from './src/db/index';

export interface VkUser {
  id: number;
  firstName: string;
  lastName: string;
  photo?: string;
  screenName?: string;
}

export interface VkSessionData {
  token?: string;
  cookies?: string;
  user?: VkUser;
  updatedAt?: number;
}

export interface VkProxyConfig {
  enabled: boolean;
  proxyUrl: string;
}

let vkSession: VkSessionData = {};
let vkProxyConfig: VkProxyConfig = { enabled: false, proxyUrl: '' };

export function parseVkProxy(raw: string) {
  if (!raw || !raw.trim()) return null;
  const str = raw.trim();
  try {
    if (str.includes('://')) {
      const url = new URL(str);
      const rawProto = url.protocol.replace(':', '').toLowerCase();
      const protocol = rawProto.startsWith('socks') ? 'socks5' : 'http';
      const host = url.hostname;
      const port = parseInt(url.port || (protocol === 'http' ? '80' : '1080'), 10);
      const username = url.username ? safeDecodeURIComponent(url.username) : undefined;
      const password = url.password ? safeDecodeURIComponent(url.password) : undefined;
      return { protocol, host, port, username, password, server: `${protocol}://${host}:${port}` };
    }
    const parts = str.split(':');
    if (parts.length === 4) {
      return { protocol: 'http', host: parts[0], port: parseInt(parts[1], 10), username: parts[2], password: parts[3], server: `http://${parts[0]}:${parts[1]}` };
    }
    if (str.includes('@')) {
      const [auth, hostPort] = str.split('@');
      const [user, pass] = auth.split(':');
      const [host, portStr] = hostPort.split(':');
      return { protocol: 'http', host, port: parseInt(portStr, 10), username: user, password: pass, server: `http://${host}:${portStr}` };
    }
    if (parts.length === 2) {
      return { protocol: 'http', host: parts[0], port: parseInt(parts[1], 10), server: `http://${parts[0]}:${parts[1]}` };
    }
  } catch (e) {}
  return null;
}

export function getVkProxyAgent() {
  if (!vkProxyConfig.enabled || !vkProxyConfig.proxyUrl) return undefined;
  const parsed = parseVkProxy(vkProxyConfig.proxyUrl);
  if (!parsed) return undefined;
  let authStr = '';
  if (parsed.username) {
    authStr = `${encodeURIComponent(parsed.username)}:${encodeURIComponent(parsed.password || '')}@`;
  }
  const fullUrl = `${parsed.protocol}://${authStr}${parsed.host}:${parsed.port}`;
  if (parsed.protocol.startsWith('socks')) {
    return new SocksProxyAgent(fullUrl);
  }
  return new HttpsProxyAgent(fullUrl);
}

export async function loadVkProxy() {
  try {
    const res = await sqlite.execute('SELECT enabled, proxy_url FROM vk_proxy WHERE id = 1');
    if (res.rows && res.rows.length > 0) {
      const row = res.rows[0];
      vkProxyConfig = {
        enabled: Boolean(row.enabled),
        proxyUrl: String(row.proxy_url || '')
      };
    }
  } catch (e) {}
  return vkProxyConfig;
}

export async function saveVkProxy(enabled: boolean, proxyUrl: string) {
  vkProxyConfig = { enabled, proxyUrl: proxyUrl.trim() };
  try {
    await sqlite.execute({
      sql: 'INSERT INTO vk_proxy (id, enabled, proxy_url) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET enabled = excluded.enabled, proxy_url = excluded.proxy_url',
      args: [enabled ? 1 : 0, proxyUrl.trim()]
    });
  } catch (e) {}
  return vkProxyConfig;
}

export async function loadVkSession(): Promise<VkSessionData> {
  try {
    const res = await sqlite.execute('SELECT token, cookies, user_info, updated_at FROM vk_session WHERE id = 1');
    if (res.rows && res.rows.length > 0) {
      const row = res.rows[0];
      const token = row.token ? String(row.token) : undefined;
      const cookies = row.cookies ? String(row.cookies) : undefined;
      let user: VkUser | undefined;
      if (row.user_info) {
        try {
          user = JSON.parse(String(row.user_info));
        } catch (e) {}
      }
      vkSession = { token, cookies, user, updatedAt: Number(row.updated_at || Date.now()) };
    }
  } catch (e) {}
  return vkSession;
}

export function hasVkSession(): boolean {
  return Boolean(vkSession.token || vkSession.cookies);
}

export function getVkSession(): VkSessionData {
  return vkSession;
}

export interface VkClientProfile {
  id: string;
  name: string;
  secret: string;
  userAgent: string;
}

export const VK_CLIENT_PROFILES: VkClientProfile[] = [
  {
    id: '2274003', // VK Official Android
    name: 'VK Android Official',
    secret: 'hHbvxMEXQ7qvftGRm5Kq',
    userAgent: 'VKAndroidApp/8.55-17482 (Android 14; SDK 34; arm64-v8a; Google Pixel 8; ru)'
  },
  {
    id: '6121396', // VK Admin
    name: 'VK Admin',
    secret: '84WY4tEv9w9Z5vHLnDhP',
    userAgent: 'VKAdmin/1.0 (Android 14; SDK 34; ru)'
  },
  {
    id: '3140623', // VK Official iPhone
    name: 'VK iPhone Official',
    secret: 'VeWdmVclK5aAEt2ug0Bi',
    userAgent: 'VKClient/8.55 (iPhone; iOS 17.5; Scale/3.00)'
  },
  {
    id: '3697615', // VK Messenger Desktop
    name: 'VK Messenger',
    secret: 'AlVXZFMudYrN8biqflRE',
    userAgent: 'VKDesktopApp/5.0.0'
  },
  {
    id: '3502557', // VK Windows Phone
    name: 'VK Windows Phone',
    secret: 'lxh77OlZuAEieFEURMJB',
    userAgent: 'VKClient/4.3 (Windows Phone 8.1; ARM; Microsoft; Lumia 640)'
  },
  {
    id: '2685278', // Kate Mobile
    name: 'Kate Mobile',
    secret: 'lxh77OlZuAEieFEURMJB',
    userAgent: 'KateMobileAndroid/110.1 lite-535 (Android 14; SDK 34; arm64-v8a; Google Pixel 8; ru)'
  }
];

/**
 * Direct Login via VK OAuth Client
 */
export async function loginToVkWithCredentials(
  login: string,
  pass: string,
  code2fa?: string,
  customClientId?: string,
  customClientSecret?: string
): Promise<{ success: boolean; token?: string; user?: VkUser; need2fa?: boolean; error?: string }> {
  try {
    const agent = getVkProxyAgent();
    
    // Choose primary client profile
    const clientId = customClientId?.trim() || '2274003';
    const clientSecret = customClientSecret?.trim() || 'hHbvxMEXQ7qvftGRm5Kq';
    const userAgent = 'VKAndroidApp/8.55-17482 (Android 14; SDK 34; arm64-v8a; Google Pixel 8; ru)';

    try {
      const params = new URLSearchParams({
        grant_type: 'password',
        client_id: clientId,
        client_secret: clientSecret,
        username: login.trim(),
        password: pass,
        scope: 'audio,offline,status',
        v: '5.199',
        '2fa_supported': '1'
      });

      if (code2fa) {
        params.append('code', code2fa.trim());
      }

      const res = await axios.get(`https://oauth.vk.com/token?${params.toString()}`, {
        httpsAgent: agent,
        httpAgent: agent,
        headers: {
          'User-Agent': userAgent
        },
        timeout: 15000
      });

      if (res.data?.error === 'need_validation' || res.data?.error === 'need_auth_code') {
        return { success: false, need2fa: true, error: 'Требуется код двухфакторной аутентификации (2FA / SMS)' };
      }

      if (res.data?.access_token) {
        const token = res.data.access_token;
        const userId = res.data.user_id;
        
        // Fetch user profile
        const userRes = await axios.get(`https://api.vk.com/method/users.get`, {
          params: {
            user_ids: userId,
            fields: 'photo_100,screen_name',
            access_token: token,
            v: '5.199'
          },
          httpsAgent: agent,
          timeout: 10000
        });

        let user: VkUser | undefined;
        const u = userRes.data?.response?.[0];
        if (u) {
          user = {
            id: u.id,
            firstName: u.first_name,
            lastName: u.last_name,
            photo: u.photo_100,
            screenName: u.screen_name
          };
        } else {
          user = { id: userId, firstName: `VK ID ${userId}`, lastName: '' };
        }

        vkSession = { token, user, updatedAt: Date.now() };

        await sqlite.execute({
          sql: 'INSERT INTO vk_session (id, token, cookies, user_info, updated_at) VALUES (1, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET token = excluded.token, user_info = excluded.user_info, updated_at = excluded.updated_at',
          args: [token, vkSession.cookies || null, JSON.stringify(user), Date.now()]
        });

        return { success: true, token, user };
      }

      if (res.data?.error_description || res.data?.error) {
        const desc = res.data.error_description || res.data.error;
        if (desc.toLowerCase().includes('15 seconds') || desc.toLowerCase().includes('too many')) {
          return {
            success: false,
            error: 'VK временно ограничил прямой вход по логину/паролю (Too many requests). Пожалуйста, воспользуйтесь вкладкой «Токен VK» (в 1 клик) — это работает мгновенно и без ограничений.'
          };
        }
        return { success: false, error: desc };
      }
    } catch (err: any) {
      const data = err.response?.data;
      if (data?.error === 'need_validation' || data?.error === 'need_auth_code') {
        return { success: false, need2fa: true, error: 'Требуется код 2FA из приложения VK или SMS' };
      }
      const desc = data?.error_description || data?.error || err.message || '';
      if (desc.toLowerCase().includes('15 seconds') || desc.toLowerCase().includes('too many')) {
        return {
          success: false,
          error: 'VK временно ограничил запросы по паролю (Too many requests per 15 seconds). Пожалуйста, перейдите на вкладку «Токен VK» и нажмите «Получить токен VK».'
        };
      }
      if (desc.toLowerCase().includes('client_secret') || desc.toLowerCase().includes('invalid_client')) {
        return {
          success: false,
          error: 'VK заблокировал прямой вход по паролю через этот App ID. Используйте безопасную авторизацию по токену (вкладка «Токен VK») или по Cookie.'
        };
      }
      return { success: false, error: desc || 'Ошибка авторизации VK. Рекомендуется вход через Токен или Куки.' };
    }

    return { success: false, error: 'Не удалось авторизоваться в VK. Используйте вкладку «Токен VK» или «Куки».' };
  } catch (err: any) {
    return { success: false, error: err.message || 'Ошибка подключения к VK' };
  }
}

/**
 * Set and verify VK Access Token directly (e.g. vk1.a... or OAuth token)
 */
export async function setVkToken(token: string): Promise<{ success: boolean; user?: VkUser; error?: string }> {
  try {
    const cleanToken = token.trim();
    if (!cleanToken) return { success: false, error: 'Укажите токен VK' };

    const agent = getVkProxyAgent();
    const userRes = await axios.get(`https://api.vk.com/method/users.get`, {
      params: {
        fields: 'photo_100,screen_name',
        access_token: cleanToken,
        v: '5.199'
      },
      httpsAgent: agent,
      timeout: 10000
    });

    if (userRes.data?.error) {
      return { success: false, error: userRes.data.error.error_msg || 'Недействительный токен VK' };
    }

    const u = userRes.data?.response?.[0];
    const user: VkUser = u ? {
      id: u.id,
      firstName: u.first_name,
      lastName: u.last_name,
      photo: u.photo_100,
      screenName: u.screen_name
    } : { id: 0, firstName: 'VK User', lastName: '' };

    vkSession = { token: cleanToken, user, updatedAt: Date.now() };

    await sqlite.execute({
      sql: 'INSERT INTO vk_session (id, token, cookies, user_info, updated_at) VALUES (1, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET token = excluded.token, user_info = excluded.user_info, updated_at = excluded.updated_at',
      args: [cleanToken, vkSession.cookies || null, JSON.stringify(user), Date.now()]
    });

    return { success: true, user };
  } catch (e: any) {
    return { success: false, error: e.message || 'Ошибка проверки токена' };
  }
}

/**
 * Set VK Cookies from string (e.g. remixsid=...; remixnsid=...) or JSON
 */
export async function setVkCookiesFromString(cookieStr: string): Promise<{ success: boolean; user?: VkUser; error?: string }> {
  try {
    const raw = cookieStr.trim();
    if (!raw) return { success: false, error: 'Строка куки пуста' };

    let formattedCookie = raw;
    if (raw.startsWith('[') && raw.endsWith(']')) {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          formattedCookie = parsed.map((c: any) => `${c.name}=${c.value}`).join('; ');
        }
      } catch (e) {}
    }

    const agent = getVkProxyAgent();
    // Test cookies against vk.com
    const res = await axios.get('https://vk.com/feed', {
      httpsAgent: agent,
      headers: {
        'Cookie': formattedCookie,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
      },
      timeout: 12000,
      maxRedirects: 5
    });

    let userName = 'VK Session';
    let userId = 0;
    const bodyText = res.data?.toString() || '';

    // Extract user ID or name if in page
    const idMatch = bodyText.match(/"id":(\d+)/) || bodyText.match(/id=(\d+)/) || bodyText.match(/"user_id":(\d+)/);
    if (idMatch) userId = parseInt(idMatch[1], 10);

    const nameMatch = bodyText.match(/<title>([^<]+)<\/title>/i);
    if (nameMatch && !nameMatch[1].includes('Вход') && !nameMatch[1].includes('Добро пожаловать')) {
      userName = nameMatch[1].replace(' | ВКонтакте', '').replace(' | VK', '').trim();
    }

    const user: VkUser = {
      id: userId,
      firstName: userName,
      lastName: ''
    };

    vkSession = {
      cookies: formattedCookie,
      user,
      updatedAt: Date.now()
    };

    await sqlite.execute({
      sql: 'INSERT INTO vk_session (id, token, cookies, user_info, updated_at) VALUES (1, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET cookies = excluded.cookies, user_info = excluded.user_info, updated_at = excluded.updated_at',
      args: [vkSession.token || null, formattedCookie, JSON.stringify(user), Date.now()]
    });

    return { success: true, user };
  } catch (e: any) {
    return { success: false, error: e.message || 'Ошибка проверки куки VK' };
  }
}

/**
 * Verify current VK session
 */
export async function verifyVkSession(): Promise<{ valid: boolean; user?: VkUser; error?: string }> {
  if (!vkSession.token && !vkSession.cookies) {
    await loadVkSession();
  }

  if (vkSession.token) {
    const res = await setVkToken(vkSession.token);
    return { valid: res.success, user: res.user, error: res.error };
  }

  if (vkSession.cookies) {
    const res = await setVkCookiesFromString(vkSession.cookies);
    return { valid: res.success, user: res.user, error: res.error };
  }

  return { valid: false, error: 'Сессия VK не найдена' };
}

/**
 * Disconnect and clear VK session
 */
export async function clearVkSession() {
  vkSession = {};
  try {
    await sqlite.execute('DELETE FROM vk_session WHERE id = 1');
  } catch (e) {}
  return true;
}

/**
 * Search audio on VK with session/token
 */
export async function searchVkAudio(query: string, count: number = 20) {
  if (!query || !query.trim()) return [];
  const agent = getVkProxyAgent();

  if (vkSession.token) {
    try {
      const res = await axios.get('https://api.vk.com/method/audio.search', {
        params: {
          q: query.trim(),
          count,
          access_token: vkSession.token,
          v: '5.199'
        },
        httpsAgent: agent,
        timeout: 12000
      });
      if (res.data?.response?.items) {
        return res.data.response.items.map((item: any) => ({
          id: `vk_${item.owner_id}_${item.id}`,
          title: item.title,
          artist: item.artist,
          duration: item.duration,
          url: item.url,
          isrc: item.isrc || null,
          album: item.album ? { title: item.album.title, id: item.album.id, thumb: item.album.thumb?.photo_300 || item.album.thumb?.photo_600 } : null
        }));
      }
    } catch (e: any) {}
  }

  return [];
}

// Auto-load on module init
loadVkProxy();
loadVkSession();
