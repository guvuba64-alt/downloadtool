import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp('Daft Punk Harder Better').then(r => console.log(r)).catch(console.error);
