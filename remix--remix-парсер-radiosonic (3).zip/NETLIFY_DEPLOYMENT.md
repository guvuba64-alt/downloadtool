# Cloud Music Suite — Деплой на Netlify + Облако Supabase + Сервер Google Cloud

Проект полностью оптимизирован для экспорта в виде **ZIP архива**, распаковки и запуска на [Netlify](https://www.netlify.com/) с подключением собственного домена, облачной базы данных Supabase и маршрутизацией API на сервер Google Cloud Run.

---

## ⚡ Быстрый запуск на Netlify (2 простых способа)

### Способ 1. Мгновенный запуск через Netlify Drop (без Git и команд)
1. Скачайте ZIP-архив проекта и распакуйте его на компьютере.
2. В терминале папки проекта выполните:
   ```bash
   npm install
   npm run build
   ```
3. Откройте [Netlify Drop](https://app.netlify.com/drop) в браузере.
4. Перетащите готовую папку `dist` прямо в окно браузера.
5. Ваш сайт мгновенно развёрнут и доступен по адресу `https://<ваш-проект>.netlify.app`!

---

### Способ 2. Авто-деплой через Git (GitHub / GitLab)
1. Загрузите код проекта в свой репозиторий GitHub или GitLab.
2. В панели Netlify нажмите **Add new site &rarr; Import an existing project**.
3. Выберите ваш репозиторий. Netlify автоматически определит параметры из `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
   - **Node version:** `20`
4. Нажмите **Deploy site**.

---

## 🔑 Переменные окружения (Environment Variables в Netlify)

В панели проекта Netlify перейдите в **Site configuration &rarr; Environment variables &rarr; Add a variable** и укажите:

| Переменная | Значение по умолчанию | Описание |
|:---|:---|:---|
| `VITE_SUPABASE_URL` | `https://oeurpptqbkuxyqyfaahj.supabase.co` | URL облачной базы данных Supabase |
| `VITE_SUPABASE_ANON_KEY` | `sb_publishable_d4xsXd0ZQW8KUKWGHyOF0g_vXbj_mFo` | Публичный ключ Supabase для клиента |
| `BACKEND_API_URL` | `https://ais-dev-i7wri7sns2xsauvagu3rfk-535024170731.europe-west2.run.app` | Сервер Google Cloud Run для фонового парсинга и 2FA |

---

## 🌐 Подключение своего домена (Custom Domain)

1. В панели Netlify откройте **Domain management &rarr; Add a domain**.
2. Введите ваше доменное имя (например, `music.yourdomain.com` или корневой домен `yourdomain.com`).
3. В панели вашего регистратора DNS добавьте запись:
   - **Type:** `CNAME`
   - **Name:** `music` (или `@`)
   - **Value:** `<ваш-проект>.netlify.app`
4. Netlify автоматически активирует бесплатный SSL-сертификат Let's Encrypt (HTTPS).

---

## 🏗 Архитектура облака

```text
  [ Пользователь / Ваш Домен ]
               │
               ▼
     [ Netlify Edge CDN ]  ◄── Раздача фронтенда (React 19 + Tailwind v4)
          │          │
          │          └──► Прямое чтение токенов из [ Supabase PostgreSQL ]
          ▼
   [ /api/* Redirect ] ──► [ Google Cloud Run ] (Парсер OK.RU CDP, 2FA OTP, FFmpeg)
```

- **Редиректы и проксирование:** Конфигурации `netlify.toml` и `public/_redirects` автоматически передают все запросы `/api/*` на защищенный бэкенд Google Cloud с сохранением заголовков сессии и 2FA.
- **SPA Fallback:** Любые маршруты фронтенда отдают `index.html` без ошибок 404 при обновлении страниц.
