import { db } from './src/db';
import { tokens } from './src/db/schema';
import { eq } from 'drizzle-orm';
import axios from 'axios';

async function test() {
  const existingToken = await db.select().from(tokens).where(eq(tokens.userId, "default_user")).limit(1);
  const token = existingToken[0].accessToken;
  const trackId = '114948834'; // 30 sec track? wait, if they don't have plus, maybe the API gives 30 sec preview directly from another track? No, they downloaded their own track.
  try {
    const res = await axios.get("https://api.music.yandex.net/tracks/" + trackId + "/download-info", {
      headers: { 'Authorization': "OAuth " + token }
    });
    console.log(JSON.stringify(res.data.result, null, 2));
  } catch(e: any) {
    console.log(e.message);
  }
}
test();
