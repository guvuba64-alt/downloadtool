import axios from 'axios';
axios.get('https://music.yandex.com/api/v2.1/handlers/track/53066380/web-track-main', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data)).catch(console.error);
