const axios = require('axios');
axios.get('https://api.deezer.com/album/upc:4062851148870')
  .then(r => console.log(r.data.tracks.data.slice(0, 5).map(t => t.title)))
  .catch(e => console.log(e.message));
