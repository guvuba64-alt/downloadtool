const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex = /if \(res\.data && \(res\.data\.play \|\| res\.data\.track\)\) \{[\s\S]*?return \{[\s\S]*?playUrl: res\.data\.play \|\| deep\.playUrl \|\| trackData\.playUrl,[\s\S]*?track: trackData,[\s\S]*?copyrightOwnerName: trackData\.copyrightOwnerName \|\| deep\.copyrightOwnerName,[\s\S]*?copyrightOwnerId: trackData\.copyrightOwnerId \|\| deep\.copyrightOwnerId,[\s\S]*?imageUrl: trackData\.imageUrl \|\| deep\.imageUrl,[\s\S]*?deepScan: deep[\s\S]*?\};/;

const replacement = `if (res.data && (res.data.play || res.data.track)) {
      const trackData = res.data.track || {};
      const meta = extractTrackMetadata(trackData) || extractTrackMetadata(res.data) || {};
      
      return {
        playUrl: res.data.play || meta.playUrl || trackData.playUrl,
        track: trackData,
        copyrightOwnerName: meta.copyrightOwnerName || meta.copyright || trackData.copyrightOwnerName,
        copyrightOwnerId: meta.copyrightOwnerId || trackData.copyrightOwnerId,
        imageUrl: meta.coverUri || trackData.imageUrl,
        deepScan: meta.deepScan
      };`;

code = code.replace(regex, replacement);
fs.writeFileSync('server-okru.ts', code);
