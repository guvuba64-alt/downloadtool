const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  /if \(\!resolvedAudioUrl && \!isUpcBarcode && \!isIsrcCode && \/\^\\d\{3,10\}\$\/\.test\(id\)\) \{/,
  `if (!resolvedAudioUrl && !isUpcBarcode && !isIsrcCode && /^(ya_)?\\d{3,10}$/.test(id)) {`
);

code = code.replace(
  /\`https:\/\/api\.music\.yandex\.net\/tracks\/\$\{id\}\/download-info\`,/,
  `\`https://api.music.yandex.net/tracks/\${id.replace('ya_', '')}/download-info\`,`,
);

const deezerLogic = `
    // 2b. Direct Deezer Numeric track ID (if starts with dz_)
    if (!resolvedAudioUrl && id.startsWith("dz_")) {
      try {
        const dTrk = await axios.get(\`https://api.deezer.com/track/\${id.replace('dz_', '')}\`, { timeout: 3500 });
        if (dTrk.data?.preview) {
          resolvedAudioUrl = dTrk.data.preview;
          if (!trackTitle) trackTitle = dTrk.data.title;
          if (!trackArtists) trackArtists = dTrk.data.artist?.name;
        }
      } catch (e: any) {}
    }
`;

code = code.replace(
  /(\/\/ 3\. Fallback: Lookup Deezer Registry by UPC \/ ISRC)/,
  deezerLogic + "\n    $1"
);

fs.writeFileSync('server.ts', code);
console.log("Patched server.ts");
