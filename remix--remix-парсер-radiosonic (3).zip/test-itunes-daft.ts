import axios from 'axios';
axios.get('https://itunes.apple.com/search?term=Daft%20Punk%20Harder%20Better&entity=song&limit=1').then(r => console.log(r.data.results[0])).catch(console.error);
