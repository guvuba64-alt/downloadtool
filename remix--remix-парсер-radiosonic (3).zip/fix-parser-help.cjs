const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// add state
content = content.replace(/const \[tgLogs, setTgLogs\] = useState<any\[\]>\(\[\]\);/, `const [tgLogs, setTgLogs] = useState<any[]>([]);\n  const [showParserHelp, setShowParserHelp] = useState(!localStorage.getItem('parserHelpSeen'));`);

// add help UI
const helpUI = `
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-zinc-50">{t("Universal Music Parser", "Универсальный музыкальный парсер")}</h3>
                  <button onClick={() => { setShowParserHelp(!showParserHelp); localStorage.setItem('parserHelpSeen', 'true'); }} className="text-sm text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 font-medium flex items-center gap-1">
                    <HelpCircle className="w-4 h-4" /> {t("How it works", "Как это работает")}
                  </button>
                </div>
                
                {showParserHelp && (
                  <div className="mb-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl p-4 text-sm text-blue-800 dark:text-blue-200">
                    <h4 className="font-bold mb-2 flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      {t("Quick Guide", "Краткое руководство")}
                    </h4>
                    <p className="mb-2">
                      {t("The Parser is the core tool of this app. It requires a Yandex Music URL as its primary input to understand what to search for across all other platforms.", 
                         "Парсер — основной инструмент приложения. Для работы ему ОБЯЗАТЕЛЬНО нужна ссылка из Яндекс Музыки (на трек, альбом или артиста). По этой ссылке он поймёт, что именно искать на всех остальных площадках.")}
                    </p>
                    <ul className="list-disc pl-5 space-y-1 opacity-90">
                      <li>{t("Find a track, album, or artist on Yandex Music", "Найдите нужный трек, альбом или артиста в Яндекс Музыке.")}</li>
                      <li>{t("Copy the link (e.g., https://music.yandex.ru/track/12345)", "Скопируйте ссылку (напр. https://music.yandex.ru/track/...)")}</li>
                      <li>{t("Paste it into the field below and click 'Fetch Data'", "Вставьте её в поле ниже и нажмите «Получить данные»")}</li>
                    </ul>
                  </div>
                )}
`;

content = content.replace(/<h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-zinc-50 mb-1">\{t\("Universal Music Parser", "Универсальный музыкальный парсер"\)\}<\/h3>/, helpUI);

fs.writeFileSync('src/App.tsx', content);
