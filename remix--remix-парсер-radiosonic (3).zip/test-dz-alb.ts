import axios from 'axios';
axios.get('https://api.deezer.com/album/643621').then(r => console.log(r.data)).catch(console.error);
