import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('Tones And I - Dance Monkey', 'auto').then(r => console.dir(r, {depth:null}));
