const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

// Replace handleParseOkRuJson
const oldHandle = `  const handleParseOkRuJson = async () => {
    if (!okRuJson.trim()) return;
    setIsParsingOkRuJson(true);
    setOkRuResult(null);
    try {
      const res = await fetch("/api/okru/parse-json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawJson: okRuJson })
      });
      const data = await res.json();
      setOkRuResult(data);
      if (data.success) {
        setOkSearchResult({
          success: true,
          found: true,
          entityType: 'single',
          platform: 'okru',
          title: data.title || 'Unknown',
          artists: data.artists || 'Unknown',
          copyright: data.copyright,
          copyrightOwnerName: data.copyrightOwnerName,
          copyrightOwnerId: data.copyrightOwnerId,
          label: data.label,
          distributor: data.distributor,
          distributorMatch: data.distributorMatch,
          isrc: data.isrc,
          upc: data.upc,
          playUrl: data.playUrl,
          releaseId: data.releaseId,
          idForDownload: data.idForDownload,
          rawJson: data.deepScan || data,
          tracks: []
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (e: any) {
      setOkRuResult({ error: e?.message || "Ошибка парсинга" });
    } finally {
      setIsParsingOkRuJson(false);
    }
  };`;

const newHandle = `  const handleParseOkRuJson = async () => {
    if (!okRuJson.trim()) return;
    setIsParsingOkRuJson(true);
    setOkRuResult(null);
    try {
      const res = await fetch("/api/okru/parse-json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawJson: okRuJson })
      });
      const data = await res.json();
      setOkRuResult(data);
      if (data.success) {
        setOkSearchResult({
          success: true,
          found: true,
          entityType: 'single',
          platform: 'okru',
          title: data.title || 'Unknown',
          artists: data.artists || 'Unknown',
          copyright: data.copyright,
          copyrightOwnerName: data.copyrightOwnerName,
          copyrightOwnerId: data.copyrightOwnerId,
          label: data.label,
          distributor: data.distributor,
          distributorMatch: data.distributorMatch,
          isrc: data.isrc,
          upc: data.upc,
          playUrl: data.playUrl,
          releaseId: data.releaseId,
          idForDownload: data.idForDownload,
          rawJson: data.deepScan || data,
          tracks: []
        });
        setOkRuJson(""); // Auto-clear on success
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (e: any) {
      setOkRuResult({ error: e?.message || "Ошибка парсинга" });
    } finally {
      setIsParsingOkRuJson(false);
    }
  };`;

code = code.replace(oldHandle, newHandle);

// Now update the UI for DevTools Network Dump Парсер
const oldUI = `<div className="flex items-center justify-end gap-2">
              <button
                onClick={handleParseOkRuJson}
                disabled={isParsingOkRuJson || !okRuJson.trim()}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs flex items-center gap-2 transition-all disabled:opacity-50"
              >
                {isParsingOkRuJson ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                <span>Парсить JSON</span>
              </button>
            </div>
            {okRuResult && (
              <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-64 border border-zinc-800">
                <code>{JSON.stringify(okRuResult, null, 2)}</code>
              </pre>
            )}`;

const newUI = `<div className="flex items-center justify-end gap-2">
              {isParsingOkRuJson && (
                <div className="flex items-center gap-2 text-emerald-500 font-semibold text-xs px-3 py-2 bg-emerald-500/10 rounded-lg">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Автоматический парсинг...</span>
                </div>
              )}
            </div>
            {okRuResult && okRuResult.error && (
              <div className="p-4 rounded-2xl bg-red-500/10 text-red-500 font-mono text-xs border border-red-500/20">
                Ошибка: {okRuResult.error}
              </div>
            )}`;

code = code.replace(oldUI, newUI);

fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
console.log('Updated UnifiedParserTab');
