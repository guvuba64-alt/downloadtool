import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)' },
  validateStatus: () => true
}).then(r => {
  const ogTitle = r.data.match(/<meta property="og:title"\s*content="([^"]*)"/i);
  console.log("og:title:", ogTitle ? ogTitle[1] : 'none');
  const title = r.data.match(/<title>(.*?)<\/title>/i);
  console.log("title:", title ? title[1] : 'none');
}).catch(console.error);
