const fs = require('fs');
let code = fs.readFileSync('src/index.css', 'utf8');

// Remove previously added themes
code = code.split('@layer base {')[0];

const properThemes = `
@layer base {
  [data-theme="ocean"] {
    --color-zinc-50: #e0f2fe;
    --color-zinc-100: #bae6fd;
    --color-zinc-200: #7dd3fc;
    --color-zinc-800: #0c4a6e;
    --color-zinc-900: #082f49;
    --color-blue-500: #0ea5e9;
    --color-blue-600: #0284c7;
    background-color: var(--color-zinc-50);
  }
  .dark[data-theme="ocean"] {
    background-color: var(--color-zinc-900);
  }
  
  [data-theme="forest"] {
    --color-zinc-50: #ecfdf5;
    --color-zinc-100: #d1fae5;
    --color-zinc-200: #a7f3d0;
    --color-zinc-800: #065f46;
    --color-zinc-900: #064e3b;
    --color-blue-500: #10b981;
    --color-blue-600: #059669;
    background-color: var(--color-zinc-50);
  }
  .dark[data-theme="forest"] {
    background-color: var(--color-zinc-900);
  }

  [data-theme="cyberpunk"] {
    --color-zinc-50: #fdf4ff;
    --color-zinc-100: #fae8ff;
    --color-zinc-200: #f5d0fe;
    --color-zinc-800: #701a75;
    --color-zinc-900: #4a044e;
    --color-blue-500: #d946ef;
    --color-blue-600: #c026d3;
    background-color: var(--color-zinc-50);
  }
  .dark[data-theme="cyberpunk"] {
    background-color: var(--color-zinc-900);
  }

  [data-theme="hacker"] {
    --color-zinc-50: #000000;
    --color-zinc-100: #050505;
    --color-zinc-200: #111111;
    --color-zinc-300: #1a1a1a;
    --color-zinc-800: #0a0a0a;
    --color-zinc-900: #000000;
    --color-blue-500: #22c55e;
    --color-blue-600: #16a34a;
    background-color: var(--color-zinc-900);
  }
  .dark[data-theme="hacker"] {
    background-color: var(--color-zinc-900);
  }
  
  body[data-theme="ocean"], body[data-theme="forest"], body[data-theme="cyberpunk"], body[data-theme="hacker"] {
    transition: background-color 0.5s ease;
  }
}
`;

fs.writeFileSync('src/index.css', code + properThemes);
console.log('fixed css themes');
