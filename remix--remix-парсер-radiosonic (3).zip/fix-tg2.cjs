const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const badLines = `const url = offset ? \\\`https://api.telegram.org/bot\${token}/getUpdates?offset=\${offset}&timeout=15\\\` : \\\`https://api.telegram.org/bot\${token}/getUpdates?offset=-1&timeout=15\\\`;
        const res = await fetch(\\\`https://api.telegram.org/bot\${token}/getUpdates?offset=\${offset}&timeout=15\\\`);`;

content = content.replace(/const url = .*?\n.*?const res = await fetch.*?;\n/, 'const res = await fetch(offset ? `https://api.telegram.org/bot${token}/getUpdates?offset=${offset}&timeout=15` : `https://api.telegram.org/bot${token}/getUpdates?offset=-1&timeout=15`);\n');

fs.writeFileSync('server.ts', content);
