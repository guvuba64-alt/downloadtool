import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://archive.org/wayback/available?url=${url}`, {
  validateStatus: () => true
});
console.log(r.status, r.data);
