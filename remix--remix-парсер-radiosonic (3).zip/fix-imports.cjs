const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace(/Music, Moon, Sun, Key/, "HelpCircle, Info, Music, Moon, Sun, Key");
fs.writeFileSync('src/App.tsx', content);
