import axios from 'axios';
const url = encodeURIComponent('https://api.music.yandex.net/tracks/53066380');
const r = await axios.get(`https://api.codetabs.com/v1/proxy?quest=${url}`, {
  headers: { 'User-Agent': 'Yandex-Music-API' },
  validateStatus: () => true
});
console.log(r.status, typeof r.data === 'string' ? r.data.substring(0, 200) : JSON.stringify(r.data).substring(0, 200));
