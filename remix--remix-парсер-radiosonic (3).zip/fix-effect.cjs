const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `  useEffect(() => {
    document.body.setAttribute('data-theme', colorTheme);
    localStorage.setItem('app-color-theme', colorTheme);
    if (colorTheme === 'hacker') {
      setTheme('dark'); // Hacker is always dark
    }
  }, [colorTheme]);`;

const replacement = `  useEffect(() => {
    document.body.setAttribute('data-theme', colorTheme);
    localStorage.setItem('app-color-theme', colorTheme);
  }, [colorTheme]);`;

code = code.replace(target, replacement);
fs.writeFileSync('src/App.tsx', code);
console.log('fixed useeffect');
