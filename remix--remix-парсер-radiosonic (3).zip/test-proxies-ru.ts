import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';

async function test() {
  const proxyList = [
    '178.208.131.250:3128',
    '31.184.238.25:3128',
    '185.253.116.14:3128',
    '213.109.206.12:3128'
  ];
  for (const proxy of proxyList) {
    try {
      const agent = new HttpsProxyAgent(`http://${proxy}`);
      const r = await axios.get('https://api.music.yandex.net/tracks/53066380', {
        httpAgent: agent, httpsAgent: agent,
        timeout: 4000, validateStatus: () => true
      });
      console.log(`Proxy ${proxy} returned ${r.status}`);
      if (r.status === 200) {
        console.log(r.data);
        break;
      }
    } catch (e) {
      // console.error(e.message);
    }
  }
}
test();
