const { GoogleGenAI } = require("@google/genai");
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey });
ai.models.list().then(res => {
  console.log(res);
}).catch(console.error);
