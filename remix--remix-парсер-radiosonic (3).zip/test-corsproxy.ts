import axios from 'axios';
const url = encodeURIComponent('https://api.music.yandex.net/tracks/53066380');
axios.get(`https://corsproxy.io/?url=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data)).catch(console.error);
