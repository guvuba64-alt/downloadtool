import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://ok.ru/music/track/123429066867960').then(r => console.dir(r, {depth:null}));
