const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const retryFunc = `
const fetchWithRetry = async (url: string, options: any = {}, retries = 3, backoff = 500): Promise<Response> => {
  try {
    const response = await fetch(url, options);
    if (!response.ok && response.status >= 500 && retries > 0) {
      throw new Error("Server error: " + response.status);
    }
    return response;
  } catch (err) {
    if (retries > 0) {
      console.log(\`Fetch failed for \${url}, retrying in \${backoff}ms...\`);
      await new Promise(res => setTimeout(res, backoff));
      return fetchWithRetry(url, options, retries - 1, backoff * 2);
    }
    throw err;
  }
};
`;

if (!code.includes("fetchWithRetry")) {
  code = code.replace("const playTickSound = () => {", retryFunc + "\nconst playTickSound = () => {");
  code = code.replace(/fetch\((["'\`])\/api\//g, "fetchWithRetry($1/api/");
  fs.writeFileSync('src/App.tsx', code);
}
