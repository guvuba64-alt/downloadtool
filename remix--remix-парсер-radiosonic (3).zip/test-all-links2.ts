import { universalMusicSearchAndParse } from './server-okru.js';

async function testUrl(url: string) {
  const r = await universalMusicSearchAndParse(url);
  console.log(`URL: ${url}`);
  console.log(`Title: ${r.title}, Artists: ${r.artists}, Error: ${r.notFound ? 'NotFound' : 'None'}, Message: ${r.message}`);
  console.log('---');
}

(async () => {
  await testUrl('https://music.apple.com/us/album/dance-monkey/1473264639?i=1473264640');
  await testUrl('https://music.yandex.ru/album/7542918/track/53066380');
})();
