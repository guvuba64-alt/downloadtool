const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /    const response = await fetchWithFallback\(\`https:\/\/api\.music\.yandex\.net\/search\?type=all&page=0&text=\\?\$\{encodeURIComponent\(query as string\)\}\`, token, \{\n      headers: \{ "User-Agent": "Yandex-Music-API" \}\n    \}\);\n\n    res\.json\(\{ success: true, data: response\.data\.result \}\);\n  \} catch \(err: any\) \{\n    console\.log\("Search error:", err\.message\);\n    if \(err\.response\) \{\n      console\.log\("Response data:", err\.response\.data\);\n      return res\.status\(err\.response\.status \|\| 500\)\.json\(\{ error: err\.message, details: err\.response\.data \}\);\n    \}\n    res\.status\(500\)\.json\(\{ error: err\.message \}\);\n  \}/;

const replacement = `    try {
      const response = await fetchWithFallback(\`https://api.music.yandex.net/search?type=all&page=0&text=\${encodeURIComponent(query as string)}\`, token, {
        headers: { "User-Agent": "Yandex-Music-API" }
      });
      res.json({ success: true, data: response.data.result });
    } catch (yandexErr: any) {
      console.log("Yandex API error:", yandexErr.message);
      res.json({ success: true, data: { tracks: { results: [] }, albums: { results: [] }, artists: { results: [] } }, note: "Yandex search is temporarily unavailable" });
    }
  } catch (err: any) {
    console.log("Search error overall:", err.message);
    res.json({ success: true, data: { tracks: { results: [] }, albums: { results: [] }, artists: { results: [] } }, note: "Search is temporarily unavailable" });
  }`;

code = code.replace(regex, replacement);
fs.writeFileSync('server.ts', code);
console.log("Patched Yandex search");
