const fs = require('fs');
let content = fs.readFileSync('src/lib/pdfGenerator.ts', 'utf8');

// Undo the safeText replacement
content = content.replace(/safeText\(/g, "doc.text(");
content = content.replace(/const safeText = \([\s\S]*?y\);\n    \}\n  \};\n/m, "");

// Let's manually wrap things. But first let's see why it failed. 
// "doc.text(" -> we can use a wrapper that is defined EARLY.

const wrapper = `
  const _safeText = (val: any, x: number, y: number) => {
    if (Array.isArray(val)) {
       doc.text(val.map(v => v !== undefined && v !== null ? String(v) : ''), x, y);
    } else {
       doc.text(val !== undefined && val !== null ? String(val) : '', x, y);
    }
  };
`;

content = content.replace("  const t = translations[lang] || translations.ru;", "  const t = translations[lang] || translations.ru;\n" + wrapper);

// Now replace `doc.text` with `_safeText` everywhere inside the function
// Wait, we need to make sure we don't replace doc.text inside _safeText
content = content.replace(/doc\.text\(/g, "_safeText(");
content = content.replace(/_safeText\(val\.map/g, "doc.text(val.map");
content = content.replace(/_safeText\(val !== undefined/g, "doc.text(val !== undefined");

fs.writeFileSync('src/lib/pdfGenerator.ts', content);
