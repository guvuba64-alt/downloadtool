const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

// Remove startup polling
content = content.replace(
  "tgConfig.tokens.forEach(t => startBotPolling(t));",
  "console.log('Not starting polling on startup, relying on Webhooks.');"
);

// In startBotPolling, add a fix so offset=0 doesn't fetch the whole history, but this function is only used locally anyway.
const pollRegex = /const offset = offsets\[token\] \|\| 0;/;
content = content.replace(pollRegex, "const offset = offsets[token]; // if undefined, it doesn't fetch old ones?\n        const url = offset ? `https://api.telegram.org/bot${token}/getUpdates?offset=${offset}&timeout=15` : `https://api.telegram.org/bot${token}/getUpdates?offset=-1&timeout=15`;");

fs.writeFileSync('server.ts', content);
console.log("Fixed long polling");
