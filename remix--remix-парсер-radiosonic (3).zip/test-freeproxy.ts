import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';

async function test() {
  const proxyList = await axios.get('https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/ru.txt');
  const proxies = proxyList.data.split('\n').filter(p => p.trim());
  console.log(`Found ${proxies.length} RU proxies`);
  
  for (let i = 0; i < 5; i++) {
    const proxy = proxies[i];
    console.log("Testing proxy:", proxy);
    try {
      const agent = new HttpsProxyAgent(`http://${proxy}`);
      const r = await axios.get('https://api.music.yandex.net/tracks/53066380', {
        httpsAgent: agent,
        httpAgent: agent,
        timeout: 5000,
        validateStatus: () => true
      });
      console.log(r.status, r.data.result?.[0]?.title);
      if (r.status === 200) break;
    } catch (e) {
      console.log(e.message);
    }
  }
}
test();
