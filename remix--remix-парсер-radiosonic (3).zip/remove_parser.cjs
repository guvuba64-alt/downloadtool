const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Change default tab
code = code.replace(
  'const [activeAppTab, setActiveAppTab] = useState<"parser" | "search" | "history" | "vibe" | "artist" | "report" | "creator" | "logs" | "prompts" | "transfer" | "yandex">("parser");',
  'const [activeAppTab, setActiveAppTab] = useState<"parser" | "search" | "history" | "vibe" | "artist" | "report" | "creator" | "logs" | "prompts" | "transfer" | "yandex">("search");'
);

// Remove the tab button from the header
code = code.replace(
  '              { id: "parser", label: t("Universal Parser", "Универсальный парсер") },\n',
  ''
);

// Remove the UnifiedParserTab rendering
const targetRender = `        {(activeAppTab === "parser" || activeAppTab === "yandex") && (
          <UnifiedParserTab
            unifiedJson={okRuJson}
            setUnifiedJson={setOkRuJson}
          />
        )}`;

code = code.replace(targetRender, '');

// Also remove the "Manual Parse Block" from the search tab which is labeled "Universal Parser"
// Actually, they probably just meant the big tab I just added. 
// But let's also rename the manual block back to "OK.ru JSON" just in case so it doesn't say "Универсальный парсер".

code = code.replace(
  '{t("Universal Parser", "Универсальный парсер")}',
  '{t("OK.ru JSON Parser", "OK.ru JSON Парсер")}'
);

fs.writeFileSync('src/App.tsx', code);
console.log("Removed Universal Parser tab and renamed OK.ru manual block.");
