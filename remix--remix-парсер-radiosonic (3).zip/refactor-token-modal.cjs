const fs = require('fs');

const componentCode = `import React from 'react';
import { X, Key, Info } from 'lucide-react';

export const TokenSettingsModal = ({ 
  isTokenModalOpen, 
  setIsTokenModalOpen, 
  status, 
  code, 
  setCode, 
  isSubmitting, 
  error, 
  onSubmitAuth, 
  t 
}: any) => {
  if (!isTokenModalOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1c1c1e] w-full max-w-lg rounded-3xl shadow-xl overflow-hidden border border-zinc-200/50 dark:border-white/10 flex flex-col animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-100 dark:border-white/5 flex justify-between items-center">
          <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-50 flex items-center gap-2"><Key className="w-5 h-5 text-blue-500" /> {t("API Token Settings", "Настройки API Токена")}</h3>
          <button onClick={() => setIsTokenModalOpen(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 flex-1 overflow-y-auto">
          {status?.connected ? (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 dark:bg-green-500/10 rounded-2xl border border-green-200 dark:border-green-500/20 flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5 animate-pulse shrink-0"></div>
                <div>
                  <h4 className="font-semibold text-green-900 dark:text-green-400 mb-1">{t("Connected to Desktop Bridge", "Подключено к Desktop Bridge")}</h4>
                  <p className="text-sm text-green-700 dark:text-green-500/80 mb-2">
                    {t("The application is successfully paired with your Desktop host. All backend operations will be routed securely.", "Приложение успешно связано с вашим Desktop хостом. Все бэкенд операции будут маршрутизироваться безопасно.")}
                  </p>
                  <button 
                    onClick={() => {
                      localStorage.removeItem('api_key');
                      window.location.reload();
                    }}
                    className="text-xs font-medium text-red-600 dark:text-red-400 hover:underline"
                  >
                    {t("Disconnect / Reset Token", "Отключить / Сбросить токен")}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-500/10 rounded-2xl border border-blue-200 dark:border-blue-500/20 mb-6">
                <h4 className="font-semibold text-blue-900 dark:text-blue-400 flex items-center gap-2 mb-2">
                  <Info className="w-4 h-4" /> {t("How to get your token", "Как получить токен")}
                </h4>
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  {t("Run the desktop application on your computer. It will generate a unique pairing token. Enter it below to bridge this web app to your local system.", "Запустите десктопное приложение на вашем компьютере. Оно сгенерирует уникальный токен сопряжения. Введите его ниже, чтобы связать это веб-приложение с вашей локальной системой.")}
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">{t("Pairing Token", "Токен сопряжения")}</label>
                <input 
                  type="text" 
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  placeholder={t("Paste token here...", "Вставьте токен сюда...")}
                  className="w-full px-4 py-3 bg-zinc-100 dark:bg-black/50 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                />
                {error && <p className="text-red-500 text-sm mt-2 font-medium">{error}</p>}
              </div>

              <button 
                onClick={onSubmitAuth}
                disabled={isSubmitting || !code}
                className="w-full mt-4 py-3 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                {isSubmitting ? t("Connecting...", "Подключение...") : t("Connect", "Подключить")}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
`;

fs.writeFileSync('src/components/TokenSettingsModal.tsx', componentCode);

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// Insert import
const importIndex = appCode.indexOf('import { BotInfoModal }');
appCode = appCode.slice(0, importIndex) + "import { TokenSettingsModal } from './components/TokenSettingsModal';\n" + appCode.slice(importIndex);

const targetBlockStart = '{isTokenModalOpen && (';
const startIdx = appCode.indexOf(targetBlockStart);
if (startIdx !== -1) {
  // find end of modal block
  let endIdx = startIdx;
  let braceCount = 0;
  let foundFirst = false;
  
  for(let i = startIdx; i < appCode.length; i++) {
    if (appCode[i] === '{') braceCount++;
    if (appCode[i] === '}') {
      braceCount--;
      foundFirst = true;
    }
    if (foundFirst && braceCount === 0) {
      endIdx = i + 1;
      break;
    }
  }
  
  const targetBlock = appCode.substring(startIdx, endIdx);
  const replacement = `<TokenSettingsModal 
        isTokenModalOpen={isTokenModalOpen} 
        setIsTokenModalOpen={setIsTokenModalOpen} 
        status={status} 
        code={code} 
        setCode={setCode} 
        isSubmitting={isSubmitting} 
        error={error} 
        onSubmitAuth={onSubmitAuth} 
        t={t} 
      />`;
      
  appCode = appCode.replace(targetBlock, replacement);
  fs.writeFileSync('src/App.tsx', appCode);
  console.log('Refactored TokenSettingsModal into separate component');
} else {
  console.log('Could not find isTokenModalOpen block in App.tsx');
}
