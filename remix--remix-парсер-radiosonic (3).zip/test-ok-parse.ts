import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp("Король и шут кукла колдуна").then(r => console.dir(r, {depth:null})).catch(console.error);
