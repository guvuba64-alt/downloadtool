const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const anchor = "  const { url, title } = req.body;";
const replacement = `app.post('/api/tg/set-webapp', express.json(), async (req, res) => {
  const { url, title } = req.body;`;

if(content.includes(anchor) && !content.includes("app.post('/api/tg/set-webapp'")) {
    content = content.replace(anchor, replacement);
    fs.writeFileSync('server.ts', content);
    console.log("Restored set-webapp route header.");
}
