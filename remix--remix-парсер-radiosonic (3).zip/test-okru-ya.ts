import { searchOkRu } from './server-okru.js';
searchOkRu("https://music.yandex.ru/album/7542918/track/53066380").then(r => console.dir(r, {depth:null}));
