import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse("https://music.yandex.ru/album/28416827/track/119932131").then(r => console.dir(r, {depth:null})).catch(console.error);
