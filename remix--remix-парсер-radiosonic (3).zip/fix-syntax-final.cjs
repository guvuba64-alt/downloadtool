const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

content = content.replace('                </div>\n                )}\n              </div>', '                </div>\n              </div>');
content = content.replace('                </div>\n                )}\n              </div>', '                </div>\n              </div>'); // Just in case there are multiple

fs.writeFileSync('src/components/ReportTab.tsx', content);
