import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";

const TARGET_BACKEND = process.env.BACKEND_API_URL || process.env.APP_URL || 'https://ais-dev-i7wri7sns2xsauvagu3rfk-535024170731.europe-west2.run.app';

export const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  const corsHeaders: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-owner-session, x-csrf-token',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  // Health check endpoint
  if (event.path.endsWith('/health') || event.path.endsWith('/ping')) {
    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'ok',
        platform: 'Netlify Functions',
        backend: TARGET_BACKEND,
        supabase: 'https://oeurpptqbkuxyqyfaahj.supabase.co',
        timestamp: new Date().toISOString()
      })
    };
  }

  try {
    const rawPath = event.path.replace(/^\/\.netlify\/functions\/api/, '/api');
    const queryString = event.rawQuery ? `?${event.rawQuery}` : '';
    const targetUrl = new URL(rawPath + queryString, TARGET_BACKEND);

    const headers: Record<string, string> = {};
    for (const [key, value] of Object.entries(event.headers)) {
      if (key.toLowerCase() !== 'host' && typeof value === 'string') {
        headers[key] = value;
      }
    }

    const fetchOptions: RequestInit = {
      method: event.httpMethod,
      headers: {
        ...headers,
        'x-netlify-deployment': 'true'
      },
      redirect: 'follow'
    };

    if (event.body && !['GET', 'HEAD'].includes(event.httpMethod)) {
      fetchOptions.body = event.isBase64Encoded ? Buffer.from(event.body, 'base64') : event.body;
      if (!headers['content-type']) {
        (fetchOptions.headers as any)['content-type'] = 'application/json';
      }
    }

    const backendRes = await fetch(targetUrl.toString(), fetchOptions);
    const contentType = backendRes.headers.get('content-type') || '';
    const buffer = Buffer.from(await backendRes.arrayBuffer());

    return {
      statusCode: backendRes.status,
      headers: {
        ...corsHeaders,
        'Content-Type': contentType
      },
      isBase64Encoded: true,
      body: buffer.toString('base64')
    };
  } catch (err: any) {
    return {
      statusCode: 502,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Ошибка Netlify Functions Gateway',
        message: err.message,
        targetBackend: TARGET_BACKEND
      })
    };
  }
};
