import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  timeout: 5000,
  validateStatus: () => true
}).then(r => {
  const html = r.data;
  const match = html.match(/<title>([^<]+)<\/title>/);
  console.log(match ? match[1] : 'No title');
});
