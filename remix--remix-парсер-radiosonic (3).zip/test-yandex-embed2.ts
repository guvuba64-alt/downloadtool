import axios from 'axios';
axios.get('https://music.yandex.ru/iframe/#track/53066380/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const match = r.data.match(/var Ya = (.*?);\n/);
  if (match) {
    console.log("Found Ya config, length:", match[1].length);
  }
  const trackMatch = r.data.match(/"title":"(.*?)"/);
  console.log("Track Title match:", trackMatch ? trackMatch[1] : 'none');
  const embedMatch = r.data.match(/class="[^"]*title[^"]*".*?>(.*?)<\//);
  console.log("Embed match:", embedMatch ? embedMatch[1] : 'none');
});
