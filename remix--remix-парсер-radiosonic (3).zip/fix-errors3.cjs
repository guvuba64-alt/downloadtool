const fs = require('fs');

let report = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

report = report.replace(
  "} catch(err) {",
  `  if (!success) {
                  updateTgLogs(prev => prev.map(l => l.chatId === chatId && l.status === 'queued' ? { ...l, status: 'error', errorMessage: 'Rate limit exceeded (429)' } : l));
              }
            } catch(err) {`
);

fs.writeFileSync('src/components/ReportTab.tsx', report);
console.log('Fixed');
