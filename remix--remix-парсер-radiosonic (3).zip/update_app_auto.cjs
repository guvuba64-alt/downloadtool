const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetBtn = `<button
                      type="submit"
                      id="hidden-parse-btn"
                      disabled={!okRuJson.trim() || isParsingOkRuJson}
                      className="bg-[#EE8208] hover:bg-[#d87405] text-white shadow-sm font-semibold py-2.5 px-6 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50 text-sm cursor-pointer"
                    >
                      {isParsingOkRuJson ? (
                         <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                         <Search className="w-4 h-4" />
                      )}
                      {isParsingOkRuJson ? t("Extracting...", "Извлечение...") : t("Extract Copyright & Metadata", "Извлечь копирайт и данные")}
                    </button>`;

const newBtn = `                  {isParsingOkRuJson ? (
                    <div className="flex items-center gap-2 text-[#EE8208] font-semibold text-xs px-4 py-2.5 bg-[#EE8208]/10 rounded-xl border border-[#EE8208]/20">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{t("Extracting...", "Автоматическое извлечение...")}</span>
                    </div>
                  ) : (
                    <button
                      type="submit"
                      id="hidden-parse-btn"
                      disabled={!okRuJson.trim()}
                      className="hidden" // Hiding the button because it should be completely automatic
                    >
                      Parse
                    </button>
                  )}`;

if (code.includes(targetBtn)) {
  code = code.replace(targetBtn, newBtn);
  fs.writeFileSync('src/App.tsx', code);
  console.log('App.tsx updated');
} else {
  console.log('App.tsx button not found');
}
