const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');
content = content.replace('                </div>\n              )}', '                </div>\n              )}');
// Actually, let's just use regex to find the bad ')}' block and replace it correctly
content = content.replace(/\{localStorage.getItem\('adminTgId'\) === '8160231965' && \([\s\S]*?\}\)/g, function(match) {
    if (match.endsWith(")}")) {
        // Find if there's a missing div closure
        // We know we messed up the string replacement
        return match;
    }
    return match;
});
