import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru "album/7542918/track/53066380"');
const r = await axios.get(`https://html.duckduckgo.com/html/?q=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
});
console.log(r.status, r.data.substring(0, 500));
