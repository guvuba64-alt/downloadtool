import { parseOkRuUrl, universalMusicSearchAndParse } from './server-okru';
async function test() {
  const res = await universalMusicSearchAndParse('YOURE TOO SLOW Whybaby_ff');
  console.log(JSON.stringify(res, null, 2));
}
test();
