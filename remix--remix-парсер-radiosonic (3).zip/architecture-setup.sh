mkdir -p src/hooks
mkdir -p src/utils
mkdir -p src/types
mkdir -p src/services
mkdir -p src/store
mkdir -p src/assets
echo "Architecture folders created."
