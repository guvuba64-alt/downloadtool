const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex = /      const isTrkResolved = resolved && resolved\.copyrightStatus === 'found' && resolved\.copyrightOwnerName;/;

const replacement = `      if (!t.isrc && t.id) {
        try {
          if (t.id.startsWith('dz_')) {
            const trRes = await axios.get(\`https://api.deezer.com/track/\${t.id.replace('dz_', '')}\`, { timeout: 3000 }).catch(()=>null);
            if (trRes && trRes.data && trRes.data.isrc) {
               t.isrc = trRes.data.isrc;
            }
          } else if (t.id.startsWith('ya_')) {
            const yaId = t.id.replace('ya_', '');
            const fallbackToken = process.env.YANDEX_MUSIC_TOKEN || "y0__xCK7-OYBRje-AYgpby9wRYw6a7F7wddxnj7HXeOAc7Jw0Hgrw8ZXN3M3A";
            const trRes = await axios.get(\`https://api.music.yandex.net/tracks/\${yaId}\`, { 
               headers: { 'Authorization': \`OAuth \${fallbackToken}\`, 'User-Agent': 'Yandex-Music-API' }, timeout: 3000 
            }).catch(()=>null);
            if (trRes && trRes.data && trRes.data.result && trRes.data.result[0] && trRes.data.result[0].isrc) {
               t.isrc = trRes.data.result[0].isrc;
            }
          }
        } catch(e) {}
      }

      const isTrkResolved = resolved && resolved.copyrightStatus === 'found' && resolved.copyrightOwnerName;`;

code = code.replace(regex, replacement);
fs.writeFileSync('server-okru.ts', code);
console.log("Patched server-okru.ts");
