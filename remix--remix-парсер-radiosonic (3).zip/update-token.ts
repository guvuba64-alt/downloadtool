import { db } from './src/db/index';
import { tokens } from './src/db/schema';
import { eq } from 'drizzle-orm';

async function run() {
  const token = "y0__xCK7-OYBRje-AYgpby9wRYw6a7F7wddxnj7HXeOAc7Jw0Hgrw8ZXN3M3A";
  
  const existing = await db.select().from(tokens).where(eq(tokens.userId, "default_user"));
  if (existing.length > 0) {
    await db.update(tokens).set({ accessToken: token, refreshToken: "", expiresAt: Math.floor(Date.now() / 1000) + 30948983, updatedAt: Math.floor(Date.now() / 1000) }).where(eq(tokens.userId, "default_user"));
  } else {
    await db.insert(tokens).values({ userId: "default_user", accessToken: token, refreshToken: "", expiresAt: Math.floor(Date.now() / 1000) + 30948983, updatedAt: Math.floor(Date.now() / 1000) });
  }
  console.log("Token updated");
}
run();
