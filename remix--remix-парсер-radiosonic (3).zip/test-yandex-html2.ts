import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  timeout: 5000,
  validateStatus: () => true
}).then(r => {
  const html = r.data;
  console.log(html.substring(0, 1000));
  const ogTitle = html.match(/<meta property="og:title" content="([^"]+)"/);
  console.log("ogTitle:", ogTitle ? ogTitle[1] : 'none');
  const d = html.match(/window\.Ya\.Server\.init\(\{.*?\}\);/s);
  console.log("data:", d ? 'yes' : 'no');
});
