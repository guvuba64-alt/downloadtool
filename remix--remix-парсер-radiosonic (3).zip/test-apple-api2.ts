import axios from 'axios';
axios.get('https://itunes.apple.com/lookup?id=1473264640&entity=song&country=us').then(r => console.dir(r.data.resultCount, {depth:null})).catch(console.error);
