const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const badBlock = `                 if (json.track) {
                     foundTrack = json.track;
                     let rawOwner = json.track.copyrightOwnerName;
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     
                     let rawLabel = json.track.label || json.track.labelName || json.track.album?.label || json.track.album?.labelName || '';
                     foundLabel = rawLabel || foundLabel;
                     
                     if (json.track.album && json.track.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = json.track.album.year;
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     foundTrack = json.tracks[0];
                     let rawOwner = foundTrack.copyrightOwnerName;
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     
                     let rawLabel = foundTrack.label || foundTrack.labelName || foundTrack.album?.label || foundTrack.album?.labelName || '';
                     foundLabel = rawLabel || foundLabel;
                     
                     if (foundTrack.album && foundTrack.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = foundTrack.album.year;
                 }`;

const goodBlock = `                 if (json.track) {
                     const meta = extractTrackMetadata(json.track);
                     if (meta && meta.track) {
                       foundTrack = meta.track;
                       foundCopyright = meta.copyright || foundCopyright;
                       foundLabel = meta.label || foundLabel;
                     }
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     const meta = extractTrackMetadata(json.tracks[0]);
                     if (meta && meta.track) {
                       foundTrack = meta.track;
                       foundCopyright = meta.copyright || foundCopyright;
                       foundLabel = meta.label || foundLabel;
                     }
                 }`;

code = code.replace(badBlock, goodBlock);
fs.writeFileSync('server-okru.ts', code);
