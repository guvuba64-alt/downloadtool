import axios from 'axios';
axios.get('https://ok.ru/web-api/music/search', {
  params: { query: 'Tones And I Dance Monkey' },
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://ok.ru/music'
  }
})
  .then(res => { console.log("Status:", res.status); console.log("Data:", typeof res.data, res.data.length ? res.data.substring(0, 100) : res.data); })
  .catch(console.error);
