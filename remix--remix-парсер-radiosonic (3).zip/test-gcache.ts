import axios from 'axios';
const url = 'https://webcache.googleusercontent.com/search?q=cache:music.yandex.ru/album/7542918/track/53066380';
axios.get(url, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data.substring(0, 100)));
