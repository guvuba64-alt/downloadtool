import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://open.spotify.com/track/1rgnBhdG2JDFTbYkYRZAku', 'auto').then(r => console.dir(r, {depth:null})).catch(console.error);
