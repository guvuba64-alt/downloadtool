import axios from 'axios';
axios.get('https://song.link/ya/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log("JSON parsed successfully");
    console.log(data.props.pageProps.pageData.entityUniqueId);
    console.log(Object.keys(data.props.pageProps.pageData.entitiesByUniqueId).length);
    const entity = data.props.pageProps.pageData.entitiesByUniqueId['YANDEX_MUSIC_SONG::53066380'];
    if (entity) {
       console.log("Title:", entity.title);
       console.log("Artist:", entity.artistName);
    } else {
       console.log("Entity not found, available keys:", Object.keys(data.props.pageProps.pageData.entitiesByUniqueId));
       // check the first one
       const firstKey = Object.keys(data.props.pageProps.pageData.entitiesByUniqueId)[0];
       console.log(data.props.pageProps.pageData.entitiesByUniqueId[firstKey]);
    }
  }
}).catch(console.error);
