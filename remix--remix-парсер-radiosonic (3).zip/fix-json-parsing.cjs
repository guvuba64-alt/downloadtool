const fs = require('fs');
let code = fs.readFileSync('src/components/PromptTab/index.tsx', 'utf8');

code = code.replace(
  `const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate');
      }`,
  `let data;
      const text = await response.text();
      try {
        data = JSON.parse(text);
      } catch (e) {
        throw new Error("Invalid response format: " + text.substring(0, 100));
      }
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate');
      }`
);

fs.writeFileSync('src/components/PromptTab/index.tsx', code);
console.log('Fixed json parsing logic');
