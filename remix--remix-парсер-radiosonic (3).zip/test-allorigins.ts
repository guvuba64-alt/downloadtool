import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
axios.get(`https://api.allorigins.win/get?url=${url}`).then(r => console.log(r.data.contents.match(/<title>(.*?)<\/title>/)?.[1] || r.data.contents.substring(0, 100)));
