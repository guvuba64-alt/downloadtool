import axios from 'axios';
axios.get('https://itunes.apple.com/search?term=dance+monkey&entity=song&limit=1').then(r => console.log(r.data.results[0]?.trackId)).catch(console.error);
