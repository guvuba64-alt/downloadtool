import axios from 'axios';
axios.get('https://music.yandex.com/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  const ogTitle = r.data.match(/<meta property="og:title" content="(.*?)"/);
  console.log("Com Title:", ogTitle ? ogTitle[1] : 'none');
});
