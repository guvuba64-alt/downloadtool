import axios from 'axios';
const q = encodeURIComponent("Dance Monkey");
axios.get(`https://ok.ru/music/search/${q}`).then(res => {
  console.log("HTML length:", res.data.length);
  const tracks = res.data.match(/\{[^{}]*"(?:track|tracks|pLine|publisher|copyright)"[^{}]*\}/g);
  console.log("Tracks found:", tracks?.length);
});
