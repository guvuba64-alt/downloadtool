const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');
code = code.replace(/\\/g, ''); // just remove all backslashes! wait, there might be legitimate backslashes...
fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
