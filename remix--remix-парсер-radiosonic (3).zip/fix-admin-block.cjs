const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

// I am trying to wrap it but I didn't actually wrap it right.
content = content.replace(/\{localStorage\.getItem\('adminTgId'\) === '8160231965' && \(\n<div className="space-y-4 pt-4 border-t border-zinc-200 dark:border-zinc-800 pb-24 lg:pb-8">/, '<div className="space-y-4 pt-4 border-t border-zinc-200 dark:border-zinc-800 pb-24 lg:pb-8">');

content = content.replace(/                \)\}\n              <\/div>\n              \{\/\* Right Column - Preview PDF \*\/\}/, '              </div>\n              {/* Right Column - Preview PDF */}');

fs.writeFileSync('src/components/ReportTab.tsx', content);
