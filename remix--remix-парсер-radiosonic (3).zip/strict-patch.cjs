const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf-8');

// 1. In `enrichExtractedTracks`, remove the fallback block for okOwnerName
const fallbackRegex = /if \(!okOwnerName\) \{[\s\S]*?okOwnerName = extractedArtists;\s*\}\s*\}/;
code = code.replace(fallbackRegex, '');

// 2. In `enrichExtractedTracks`, inside the `extractedTracks.map` loop, remove fallback to `cleanOkOwner`
code = code.replace(
  /const tOwnerName = isTrkResolved \? resolved\.copyrightOwnerName : \(cleanOkOwner \|\| null\);/,
  'const tOwnerName = isTrkResolved ? resolved.copyrightOwnerName : null;'
);
code = code.replace(
  /const tOwnerId = isTrkResolved \? \(resolved\.copyrightOwnerId \?\? null\) : \(okOwnerId \|\| null\);/,
  'const tOwnerId = isTrkResolved ? (resolved.copyrightOwnerId ?? null) : null;'
);
code = code.replace(
  /let tCopyright = isTrkResolved \? resolved\.copyright : \(cleanOkOwner \|\| null\);/,
  'let tCopyright = isTrkResolved ? resolved.copyright : null;'
);
code = code.replace(
  /copyrightStatus: \(isTrkResolved \|\| cleanOkOwner\) \? 'found' : 'not_found',/,
  "copyrightStatus: isTrkResolved ? 'found' : 'not_found',"
);

// 3. Remove fallback in the final return object for the album
code = code.replace(
  /copyrightOwnerName: cleanOkOwner \|\| null,/,
  'copyrightOwnerName: okOwnerName || null,'
);
code = code.replace(
  /copyrightStatus: cleanOkOwner \? 'found' : 'not_found',/,
  "copyrightStatus: okOwnerName ? 'found' : 'not_found',"
);

fs.writeFileSync('server-okru.ts', code);
