import axios from 'axios';
const url = encodeURIComponent('https://api.music.yandex.net/tracks/53066380');
axios.get(`https://api.codetabs.com/v1/proxy?quest=${url}`, {
  headers: { 'User-Agent': 'Yandex-Music-API' },
  validateStatus: () => true
}).then(r => console.log(r.status, typeof r.data === 'string' ? r.data.substring(0, 200) : r.data)).catch(console.error);
