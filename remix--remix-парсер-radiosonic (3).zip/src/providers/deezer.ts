export async function searchDeezer(query: string) {
    return { source: 'deezer', status: 'not_implemented' };
}
