// In-memory cache for track copyright lookups
const okruClientCache = new Map<string, any>();

function getCacheKeys(track: any): string[] {
  const keys: string[] = [];
  if (track.id) keys.push(`ok_${track.id}`);
  if (track.okruTrackId || track.matchedTrackId) keys.push(`ok_${track.okruTrackId || track.matchedTrackId}`);
  if (track.isrc) keys.push(`isrc_${String(track.isrc).trim().toUpperCase()}`);

  const title = (track.title || '').trim().toLowerCase();
  let artists = '';
  if (Array.isArray(track.artists)) {
    artists = track.artists.filter(Boolean).join(' ').toLowerCase();
  } else if (typeof track.artists === 'string') {
    artists = track.artists.trim().toLowerCase();
  } else if (typeof track.artist === 'string') {
    artists = track.artist.trim().toLowerCase();
  }

  if (title) {
    keys.push(`meta_${title}_${artists}`);
  }
  return keys;
}

export async function resolveTrackCopyright(track: {
  id?: string | number;
  title: string;
  artists?: string[] | string;
  artist?: string;
  album?: string;
  duration?: number;
  durationMs?: number;
  isrc?: string;
  year?: number | string;
  [key: string]: any;
}) {
  const keys = getCacheKeys(track);
  for (const k of keys) {
    if (okruClientCache.has(k)) {
      return okruClientCache.get(k);
    }
  }

  try {
    const res = await fetch("/api/okru/resolve-copyright", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ track })
    });
    if (!res.ok) return { copyright: null, copyrightOwnerId: null, copyrightOwnerName: null, copyrightStatus: 'not_found', source: 'OK.RU' };
    const data = await res.json();
    for (const k of keys) {
      okruClientCache.set(k, data);
    }
    if (data.matchedTrackId) {
      okruClientCache.set(`ok_${data.matchedTrackId}`, data);
    }
    return data;
  } catch (e: any) {
    return { copyright: null, copyrightOwnerId: null, copyrightOwnerName: null, copyrightStatus: 'not_found', source: 'OK.RU', error: e.message };
  }
}

export async function resolveUniversalTracksCopyright(params: {
  source?: string;
  tracks: Array<{
    id?: string | number;
    title: string;
    artists?: string[] | string;
    artist?: string;
    album?: string;
    duration?: number;
    durationMs?: number;
    isrc?: string;
    year?: number | string;
    [key: string]: any;
  }>;
  concurrency?: number;
}) {
  try {
    const res = await fetch("/api/okru/resolve-tracks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params)
    });
    if (!res.ok) return { source: params.source || 'universal', tracks: params.tracks, total: params.tracks.length, foundCount: 0 };
    const data = await res.json();
    if (data && Array.isArray(data.tracks)) {
      for (const t of data.tracks) {
        if (t && (t.copyrightOwnerName || t.copyright)) {
          const keys = getCacheKeys(t);
          for (const k of keys) {
            okruClientCache.set(k, t);
          }
        }
      }
    }
    return data;
  } catch (e: any) {
    return { source: params.source || 'universal', tracks: params.tracks, total: params.tracks.length, foundCount: 0, error: e.message };
  }
}
