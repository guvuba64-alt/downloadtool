export async function searchYandex(query: string) {
    return { source: 'yandex', status: 'not_implemented' };
}
