export async function searchApple(query: string) {
    return { source: 'apple', status: 'not_implemented' };
}
