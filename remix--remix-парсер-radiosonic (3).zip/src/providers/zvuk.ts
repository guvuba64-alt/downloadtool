export async function searchZvuk(query: string) {
    return { source: 'zvuk', status: 'not_implemented' };
}
