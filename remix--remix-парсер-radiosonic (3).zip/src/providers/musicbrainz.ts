export async function searchMusicBrainz(query: string) {
    return { source: 'musicbrainz', status: 'not_implemented' };
}
