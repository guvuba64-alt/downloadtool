export async function searchSpotify(query: string) {
    return { source: 'spotify', status: 'not_implemented' };
}
