export async function searchVK(query: string) {
    return { source: 'vk', status: 'not_implemented' };
}
