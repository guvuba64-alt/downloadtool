import { SpotifySettingsModal } from './components/SpotifySettingsModal';
import { TokenSettingsModal } from './components/TokenSettingsModal';
import { BotInfoModal } from './components/BotInfoModal';
import { BotStatusIndicator } from './components/BotStatusIndicator';
import { TelegramIcon, SpotifyIcon, OkRuIcon, VkIcon } from './components/Icons';
import { VkAuthModal } from './components/VkAuthModal';
import { OkRuAuthModal } from './components/OkRuAuthModal';
import MultiSourceResolver from './components/MultiSourceResolver';
import { ProxyGeoStatus } from './components/ProxyGeoStatus';

import { ExternalLink , Settings} from "lucide-react";
import { SearchTab } from "./components/SearchTab";
import { HistoryTab } from "./components/HistoryTab";
import { PromptTab } from "./components/PromptTab";
import { MyVibeTab } from "./components/MyVibeTab";
import { ArtistProfile } from "./components/ArtistProfile";
import { ReportTab } from "./components/ReportTab";
import { HelpModal } from "./components/HelpModal";
import { LogsTab } from "./components/LogsTab";
import { UniqueParserTab } from "./components/UniqueParserTab";
import { BackCatalogTab } from "./components/BackCatalog/BackCatalogTab";
import { ConverterTab } from "./components/ConverterTab";
import { VideoShotTab } from "./components/VideoShotTab";
import { ApiTab } from "./components/ApiTab";
import { SupabaseAndCloudHub } from "./components/CloudHub/SupabaseAndCloudHub";
import { 
  CHIEF_OWNER_TG_ID, 
  isChiefOwnerAuthenticated, 
  setChiefOwnerAuthenticated, 
  revokeChiefOwner 
} from "./utils/ownerAuth";
import { PlatformBrandIcon } from "./components/PlatformIcons";
import { OwnerAuthModal } from "./components/OwnerAuthModal";
import { TgAuthGuard } from "./components/TgAuthGuard";
import { PrivateAccessGate } from "./components/PrivateAccessGate";
import { downloadWavTrack, subscribeDownloadState } from "./utils/audioDownloader";
import { DownloadProgressToast } from "./components/DownloadProgressToast";
import { BackgroundExportWidget } from "./components/BackCatalog/BackgroundExportWidget";
import { cleanMergeAuthors } from "./utils/authors";

import React from "react";
import { ProxyImage } from "./components/ProxyImage";
import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import JSZip from "jszip";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { AlertCircle, Droplets, Send,
  KeyRound,
  CheckCircle2,
  XCircle,
  RefreshCw,
  LogOut,
  ArrowRight,
  Save,
  Clock,
  ShieldCheck,
  Database,
  Copy,
  Check,
  Search,
  Globe,
  Server,
  Activity,
  Wifi,
  Zap,
  Download,
  Play,
  HelpCircle, Info, Music, Moon, Sun, Key, SkipBack, SkipForward, ChevronDown, Pause, Shuffle, Repeat, AlignLeft, Maximize2, X, Heart, MoreHorizontal, List, Mic2, HeartOff, Loader2, Shield, Palette, Volume2, VolumeX, Layers, Code, Lock, Crown, Unlock } from "lucide-react";

const YandexMusicIcon = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 48 48"
    className={className}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="48" height="48" rx="12" fill="black" />
    <path
      d="M42.3995 19.3967L42.2975 18.6445L36.1353 17.2059L39.3184 12.4823L38.9423 11.9702L33.9785 14.3989L34.5267 7.7926L33.9785 7.52062L30.8974 12.8244L27.2702 4.84961H26.586L27.4742 12.6544L18.403 5.43183L17.6167 5.63795L24.5992 14.3989L10.7363 9.77939L10.0861 10.4976L22.4764 17.514L5.43039 18.9526L5.25828 19.9789L22.9906 21.8956L8.1694 34.0139L8.85362 34.9383L26.4138 25.3528L22.9566 42.1608H24.0169L30.7954 26.3473L34.9028 38.7036L35.6211 38.1554L34.0805 25.7651L40.3447 32.8495L40.723 32.1313L36.0673 23.3682L42.6736 25.6971L42.7416 24.9767L37.2317 20.5612L42.3995 19.3967Z"
      fill="#FCE000"
    />
  </svg>
);



const LyricsModal = ({ isOpen, onClose, lyrics }: { isOpen: boolean, onClose: () => void, lyrics: string | null }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[110] bg-zinc-900/40 dark:bg-black/60 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200" onClick={onClose}>
      <div 
        className="w-full h-full sm:h-auto sm:max-w-xl bg-zinc-50 dark:bg-zinc-900 rounded-2xl sm:rounded-3xl p-6 sm:p-8 sm:max-h-[85vh] overflow-y-auto border border-zinc-200 dark:border-white/10 shadow-2xl relative flex flex-col animate-in slide-in-from-bottom-8 sm:zoom-in-95 duration-300" 
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6 sticky top-0 bg-zinc-50 dark:bg-zinc-900 pt-2 pb-4 border-b border-zinc-200 dark:border-white/10 z-10 shrink-0">
          <h3 className="text-xl font-bold text-zinc-900 dark:text-white">Текст песни</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="whitespace-pre-wrap text-zinc-700 dark:text-zinc-300 font-medium text-base sm:text-lg leading-relaxed flex-1 font-sans">
          {lyrics || "Текст отсутствует"}
        </div>
      </div>
    </div>
  );
};




import { ModernPlayer as CustomAudioPlayer } from "./components/ModernPlayer";
import { AlbumModal } from "./components/AlbumModal";
import { safeParseResponse } from "./utils/safeFetch";


const fetchWithRetry = async (url: string, options: any = {}, retries = 2, backoff = 800): Promise<Response> => {
  try {
    const response = await fetch(url, options);
    if (!response.ok && response.status >= 500 && retries > 0) {
      throw new Error("Server error: " + response.status);
    }
    return response;
  } catch (err: any) {
    if (retries > 0 && !err?.message?.includes("429") && !err?.message?.includes("Rate exceeded")) {
      console.log(`Retrying request... (${retries} left)`);
      await new Promise(res => setTimeout(res, backoff));
      return fetchWithRetry(url, options, retries - 1, backoff * 2);
    }
    throw err;
  }
};

const playTickSound = () => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.05);
    
    gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
    
    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  } catch (e) {}
};

export default function App() {
  const [lang, setLang] = React.useState<"en"|"ru">("ru");
  const [activeTrack, setActiveTrack] = React.useState<any>(null);
  const [playbackSource, setPlaybackSource] = React.useState<"manual"|"vibe">("manual");
  const [trackQueue, setTrackQueue] = React.useState<any[]>([]);
  const [isTokenModalOpen, setIsTokenModalOpen] = React.useState<boolean>(false);
  const [isSpotifyModalOpen, setIsSpotifyModalOpen] = React.useState<boolean>(false);
  const [spotifyClientId, setSpotifyClientId] = React.useState<string>(localStorage.getItem('spotify_client_id') || '');
  const [spotifyClientSecret, setSpotifyClientSecret] = React.useState<string>(localStorage.getItem('spotify_client_secret') || '');
  const [theme, setTheme] = React.useState<"light"|"dark">("light");
  const [colorTheme, setColorTheme] = React.useState<"default"|"minimalist"|"brutalist"|"cyberpunk">(() => (localStorage.getItem('app-color-theme') as any) || "default");




  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);



  
  
  
  const t = (en, ru) => lang === "ru" ? ru : en;

  const [standaloneSmartlink, setStandaloneSmartlink] = React.useState<any>(null);
  
  // Chief Owner state (Telegram ID 8981404137)
  const [isChiefOwner, setIsChiefOwner] = useState<boolean>(() => isChiefOwnerAuthenticated());
  const [showOwnerLoginModal, setShowOwnerLoginModal] = useState(false);
  const [ownerLoginInput, setOwnerLoginInput] = useState("");
  const [ownerLoginError, setOwnerLoginError] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab');
    if (tabParam === 'cloud' || tabParam === 'supabase') {
      setActiveAppTab('cloud');
    } else if (tabParam === 'vibe' || tabParam === 'wave') {
      setActiveAppTab('vibe');
    }

    // Check Telegram ID from query params
    const tgParam = params.get('tg_id') || params.get('owner') || params.get('admin_id');
    if (tgParam === CHIEF_OWNER_TG_ID) {
      setChiefOwnerAuthenticated(CHIEF_OWNER_TG_ID);
      setIsChiefOwner(true);
    } else if (isChiefOwnerAuthenticated()) {
      setIsChiefOwner(true);
    }

    // Telegram WebApp (Mini App) auto-detection & expansion
    if (typeof window !== 'undefined' && (window as any).Telegram?.WebApp) {
      try {
        const tg = (window as any).Telegram.WebApp;
        tg.ready();
        tg.expand();
        const tgUser = tg.initDataUnsafe?.user;
        if (tgUser?.id && String(tgUser.id) === CHIEF_OWNER_TG_ID) {
          setChiefOwnerAuthenticated(CHIEF_OWNER_TG_ID);
          setIsChiefOwner(true);
        }
      } catch (e) {}
    }

    const sl = params.get('sl');
    if (sl) {
       try {
          const raw = atob(sl);
          let str = raw;
          try {
            str = decodeURIComponent(escape(raw));
          } catch {
            try {
              str = decodeURIComponent(raw);
            } catch {
              str = raw;
            }
          }
          const decoded = JSON.parse(str);
          setStandaloneSmartlink(decoded);
       } catch (e) {
          console.error("Failed to parse smartlink", e);
       }
    }
  }, []);

  if (standaloneSmartlink) {
     return (
       <div className="min-h-[100dvh] bg-black flex flex-col items-center justify-center p-6 relative overflow-y-auto">
          {standaloneSmartlink.cover && (
             <ProxyImage src={standaloneSmartlink.cover} className="absolute top-0 left-0 w-full h-full object-cover opacity-40 blur-[50px] scale-110 z-0" alt="" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-0" />
          
          <div className="relative z-10 w-full max-w-[400px] flex flex-col items-center my-auto">
              {standaloneSmartlink.cover ? (
                <ProxyImage src={standaloneSmartlink.cover} className="w-64 h-64 rounded-[2rem] shadow-[0_0_60px_rgba(255,255,255,0.15)] mb-8 object-cover border border-white/20" alt="Cover" />
              ) : (
                <div className="w-64 h-64 rounded-[2rem] bg-zinc-800 mb-8 shadow-xl" />
              )}
              <h2 className="text-3xl font-black text-white tracking-tight text-center leading-tight mb-2 drop-shadow-lg">{standaloneSmartlink.title}</h2>
              <p className="text-zinc-300 font-medium text-lg text-center mb-10 drop-shadow-md">{standaloneSmartlink.artist || t("Artist", "Артист")}</p>
              
              {standaloneSmartlink.logo && (
                 <img src={standaloneSmartlink.logo} className="h-10 max-w-[180px] object-contain mb-10 filter drop-shadow-xl" alt={standaloneSmartlink.label || "Label"} />
              )}
              
              <div className="w-full flex flex-col gap-4">
                {standaloneSmartlink.links && Object.entries(standaloneSmartlink.links).map(([platform, link]: any) => {
                   let hostname = "";
                   try { hostname = new URL((link as any).url).hostname; } catch (e) {}
                   return (
                      <a key={platform} href={(link as any).url} target="_blank" rel="noreferrer" className="flex items-center justify-between w-full p-4 bg-white/10 hover:bg-white/20 backdrop-blur-xl rounded-2xl transition-all border border-white/10 group shadow-lg">
                        <div className="flex items-center gap-4">
                          <PlatformBrandIcon platformId={platform} domain={hostname} name={platform} size="md" />
                          <span className="text-white text-[17px] font-bold capitalize tracking-wide drop-shadow-sm">{platform.replace(/([A-Z])/g, ' $1').trim()}</span>
                        </div>
                        <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity bg-black/40 px-3 py-1.5 rounded-full backdrop-blur-md">
                          <span className="text-[11px] font-bold text-white uppercase tracking-wider">{t("Listen", "Слушать")}</span>
                          <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                        </div>
                     </a>
                   )
                })}
              </div>
          </div>
       </div>
     );
  }

  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [code, setCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [copiedAccess, setCopiedAccess] = useState(false);
  const [copiedRefresh, setCopiedRefresh] = useState(false);
  const [testApiResult, setTestApiResult] = useState<any>(null);
  const [isTestingApi, setIsTestingApi] = useState(false);

  const CLIENT_ID = "23cabbbdc6cd418abb4b39c32c41195d";
  const AUTH_URL = `https://oauth.yandex.ru/authorize?response_type=token&client_id=${CLIENT_ID}&force_confirm=yes`;

  useEffect(() => {
    const handleSearchArtist = (e: any) => {
      const url = e.detail;
      setMetadataUrl(url);
      handleFetchMetadata(undefined, url);
      const el = document.getElementById("metadata-input-section");
      if (el) el.scrollIntoView({ behavior: "smooth" });
    };

    const handleOpenStudio = (e: any) => {
      if (e.detail) {
        setStudioInitialTrack(e.detail);
      }
      setActiveAppTab("videoshot");
    };

    window.addEventListener("searchArtist", handleSearchArtist);
    window.addEventListener("openVideoShotStudio", handleOpenStudio);
    return () => {
      window.removeEventListener("searchArtist", handleSearchArtist);
      window.removeEventListener("openVideoShotStudio", handleOpenStudio);
    };
  }, []);

  useEffect(() => {
    fetchStatus();
  }, []);
  useEffect(() => {
    const fetchLatencies = async () => {
        const platforms = [
            { id: "yandex", domain: "music.yandex.ru" }, { id: "vk", domain: "vk.com" }, { id: "zvuk", domain: "zvuk.com" }, 
            { id: "okru", domain: "ok.ru" }, { id: "mts", domain: "music.mts.ru" }, { id: "spotify", domain: "open.spotify.com" }, 
            { id: "apple", domain: "music.apple.com" }, { id: "youtube", domain: "youtube.com" }, { id: "youtubemusic", domain: "music.youtube.com" }, 
            { id: "tiktok", domain: "tiktok.com" }, { id: "soundcloud", domain: "soundcloud.com" }, { id: "deezer", domain: "deezer.com" }, 
            { id: "tidal", domain: "tidal.com" }, { id: "amazon", domain: "music.amazon.com" }, { id: "shazam", domain: "shazam.com" },
            { id: "pandora", domain: "pandora.com" }, { id: "qobuz", domain: "qobuz.com" }, { id: "napster", domain: "napster.com" }, 
            { id: "boomplay", domain: "boomplay.com" }, { id: "audiomack", domain: "audiomack.com" }, { id: "anghami", domain: "anghami.com" }
        ];
        
        for (const p of platforms) {
            try {
                const res = await fetchWithRetry(`/api/platform-status?domain=${p.domain}`);
                const data = await res.json();
                setPlatformLatencies(prev => ({...prev, [p.id]: data}));
            } catch(e) {}
        }
    };
    fetchLatencies();
    const interval = setInterval(fetchLatencies, 60000); // refresh every 60s
    return () => clearInterval(interval);
  }, []);


  const [metadataUrl, setMetadataUrl] = useState("");
  const [appTheme, setAppTheme] = useState("default");

  // Private Circle Access State (Вход в закрытый парсер и модули)
  const [hasPrivateAccess, setHasPrivateAccess] = useState<boolean>(() => {
    try {
      const local = localStorage.getItem("private_circle_auth") === "true";
      if (local) return true;
      if (typeof document !== "undefined") {
        if (document.cookie.includes("private_circle_auth=true") || document.cookie.includes("private_circle_session=")) {
          return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  });

  const [privateAccessKey, setPrivateAccessKey] = useState<string>(() => {
    try {
      const local = localStorage.getItem("private_circle_key");
      if (local) return local;
      if (typeof document !== "undefined") {
        const match = document.cookie.match(/(^|;\s*)private_circle_key=([^;]*)/);
        if (match) return decodeURIComponent(match[2]);
      }
      return "";
    } catch (e) {
      return "";
    }
  });

  // Automatically verify & sync server session on mount so access is always remembered
  useEffect(() => {
    let isMounted = true;
    const checkPersistentSession = async () => {
      try {
        const res = await fetch("/api/auth/private-access/session-check");
        const data = await res.json();
        if (isMounted && data && data.authenticated) {
          setHasPrivateAccess(true);
          const key = data.keyName || "VIP";
          setPrivateAccessKey(key);
          try {
            localStorage.setItem("private_circle_auth", "true");
            localStorage.setItem("private_circle_key", key);
            document.cookie = `private_circle_auth=true; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
            document.cookie = `private_circle_key=${encodeURIComponent(key)}; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
          } catch (e) {}
        }
      } catch (e) {}
    };

    checkPersistentSession();
    return () => { isMounted = false; };
  }, []);

  const [activeAppTab, setActiveAppTab] = useState<"parser" | "search" | "history" | "vibe" | "artist" | "report" | "creator" | "logs" | "prompts" | "unique_parser" | "converter" | "api" | "back_catalog" | "cloud" | "videoshot">("unique_parser");
  const [studioInitialTrack, setStudioInitialTrack] = useState<any>(null);
  const [platformFilter, setPlatformFilter] = React.useState<"all" | "ru" | "west" | "custom">("all");
  const [platformLatencies, setPlatformLatencies] = useState<Record<string, {status: 'up'|'down', latency: number}>>({});
  const [enabledPlatforms, setEnabledPlatforms] = React.useState<string[]>(["yandex", "vk", "zvuk", "okru", "mts", "spotify", "apple", "youtube", "youtubemusic", "tiktok", "soundcloud", "deezer", "tidal", "amazon", "shazam", "pandora", "qobuz", "napster", "boomplay", "audiomack", "anghami"]);
  const [showPlatformSettings, setShowPlatformSettings] = React.useState(false);

  const [activeResultTab, setActiveResultTab] = useState<"overview" | "platforms">("overview");
  const [metadataArtistStatsMode, setMetadataArtistStatsMode] = useState<"listeners" | "streams">("listeners");
  const [tgLogs, setTgLogs] = useState<any[]>([]);
  const [showParserHelp, setShowParserHelp] = useState(!localStorage.getItem('parserHelpSeen'));

  useEffect(() => {
    try {
      let tgToken = localStorage.getItem('tgToken') || '';
      if (!tgToken || tgToken.includes('AhZV1M')) {
        tgToken = '8828948443:AAHSY6sBNh0isvlNvM-jt500CWYXTyjxHO0';
        localStorage.setItem('tgToken', tgToken);
      }
      const tgContacts = JSON.parse(localStorage.getItem('tgContacts') || '[]');
      const tokens = tgToken.split(/[\s,]+/).filter(t => t.trim() !== '');
      if (tokens.length) {
        fetchWithRetry('/api/tg/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tokens, contacts: tgContacts })
        }).catch(e => console.log('TG config error', e));
      }
    } catch(e) {}
  }, []);

  // Update backend whenever token or contacts update
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        let tgToken = localStorage.getItem('tgToken') || '';
        if (tgToken.includes('AhZV1M')) {
          tgToken = '8828948443:AAHSY6sBNh0isvlNvM-jt500CWYXTyjxHO0';
          localStorage.setItem('tgToken', tgToken);
        }
        const tgContacts = JSON.parse(localStorage.getItem('tgContacts') || '[]');
        const tokens = tgToken.split(/[\s,]+/).filter(t => t.trim() !== '');
        fetchWithRetry('/api/tg/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tokens, contacts: tgContacts })
        }).catch(e => console.log('TG config error', e));
      } catch(e) {}
    };
    window.addEventListener('tg-config-update', handleStorageChange);
    return () => window.removeEventListener('tg-config-update', handleStorageChange);
  }, []);

  const [history, setHistory] = useState<any[]>([]);
  const [botStatus, setBotStatus] = useState<'online' | 'offline' | 'checking'>('checking');
  const [botName, setBotName] = useState('');
  const [botUsername, setBotUsername] = useState('');
  const [botId, setBotId] = useState('');
  const [isBotInfoOpen, setIsBotInfoOpen] = useState(false);

  useEffect(() => {
    let interval: any;
    const checkStatus = () => {
      fetchWithRetry('/api/tg/status')
        .then(res => res.json())
        .then(data => {
          setBotStatus(data.online ? 'online' : 'offline');
          if (data.botName) setBotName(data.botName);
          if (data.botUsername) setBotUsername(data.botUsername);
          if (data.botId) setBotId(data.botId);
        })
        .catch(() => setBotStatus('offline'));
    };
    
    checkStatus(); // initial check
    interval = setInterval(checkStatus, 10000); // poll every 10 seconds
    
    // Also listen to token updates to re-check immediately
    const handleUpdate = () => {
      setBotStatus('checking');
      setTimeout(checkStatus, 500);
    };
    window.addEventListener('tg-config-update', handleUpdate);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('tg-config-update', handleUpdate);
    };
  }, []);
  const [currentArtistId, setCurrentArtistId] = useState<string | number | null>(null);
  const [currentArtistProvider, setCurrentArtistProvider] = useState<string>("");
  const [globalAlbumModal, setGlobalAlbumModal] = useState<{
    isOpen: boolean;
    album: any;
  }>({
    isOpen: false,
    album: null,
  });

  const handleOpenAlbumModal = (albumOrId: any) => {
    if (typeof albumOrId === 'string' || typeof albumOrId === 'number') {
      setGlobalAlbumModal({
        isOpen: true,
        album: { id: String(albumOrId), title: 'Загрузка...' },
      });
    } else if (albumOrId && typeof albumOrId === 'object') {
      setGlobalAlbumModal({
        isOpen: true,
        album: albumOrId,
      });
    }
  };

  const [artistUrl, setArtistUrl] = useState("");
  const [artistResult, setArtistResult] = useState<any>(null);
  const [isFetchingArtist, setIsFetchingArtist] = useState(false);
  const [artistError, setArtistError] = useState("");
  
  const [bulkProgress, setBulkProgress] = useState<{
    current: number;
    total: number;
  } | null>(null);
  const [metadataResult, setMetadataResult] = useState<any>(null);
  const [smartLinkLabel, setSmartLinkLabel] = useState("");
  const [smartLinkLabelLogo, setSmartLinkLabelLogo] = useState("");
  const [resolvedMetadata, setResolvedMetadata] = useState<any>(null);
  const [labelCheckResult, setLabelCheckResult] = useState<any>(null);
  const [isFetchingMetadata, setIsFetchingMetadata] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState("");
  const [zipFormat, setZipFormat] = useState<"txt"|"pdf"|"xlsx">("txt");
  const [metadataError, setMetadataError] = useState("");
  const [fetchAlbumForTrack, setFetchAlbumForTrack] = useState(false);
  const [bulkExportData, setBulkExportData] = useState<any[] | null>(null);

  
function findDistributor(label, copyright) {
    const text = ((label || '') + ' ' + (copyright || '')).toLowerCase();
    
    const distributors = {
        'Believe': ['believe music', 'believe sas', 'believe digital', 'believe', 'broma16'],
        'TuneCore': ['tunecore'],
        'DistroKid': ['distrokid'],
        'Symphonic': ['symphonic'],
        'ONErpm': ['onerpm'],
        'CD Baby': ['cd baby', 'cdbaby'],
        'Amuse': ['amuseio', 'amuse'],
        'Ditto Music': ['ditto music', 'ditto'],
        'Vydia': ['vydia'],
        'The Orchard': ['the orchard'],
        'Ingrooves': ['ingrooves'],
        'FUGA': ['fuga'],
        'AWAL': ['awal'],
        'Empire': ['empire'],
        'UnitedMasters': ['unitedmasters', 'united masters'],
        'Horus Music': ['horus music'],
        'Record Union': ['record union'],
        'Level Music': ['level music'],
        'Spinnup': ['spinnup'],
        'RouteNote': ['routenote', 'route note'],
        'Label Engine': ['label engine'],
        'Label Worx': ['label worx', 'labelworx'],
        'Repost Network': ['repost network'],
        'Soundrop': ['soundrop'],
        'Too Lost': ['too lost', 'toolost'],
        'Indiefy': ['indiefy'],
        'FreshTunes': ['freshtunes'],
        'Anti-Joy': ['anti-joy', 'antijoy'],
        'Unchained Music': ['unchained music'],
        'Zvonko Digital (НЦА)': ['zvonko', 'national digital aggregator', 'nda', 'национальный цифровой агрегатор', 'нца'],
        'Sferoom': ['sferoom'],
        'Multiza': ['multiza'],
        'Create Music Group': ['create music group'],
        'Sony Music': ['sony music', 'sme'],
        'Universal Music Group': ['universal music', 'umg'],
        'Warner Music Group': ['warner music', 'wmg']
    };

    for (const [distributor, keywords] of Object.entries(distributors)) {
        for (const keyword of keywords) {
            if (text.includes(keyword)) {
                return distributor;
            }
        }
    }
    
    return null;
}

  const handleCopyText = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!text) return;
    navigator.clipboard
      .writeText(text)
      .then(() => {
        // Create a small temporary toast
        const toast = document.createElement("div");
        toast.textContent = t("Copied!", "Скопировано!");
        toast.className =
          "fixed bottom-4 right-4 bg-zinc-900 text-white px-4 py-2 rounded-lg text-sm font-medium z-50 transition-opacity duration-300";
        document.body.appendChild(toast);
        setTimeout(() => {
          toast.style.opacity = "0";
          setTimeout(() => document.body.removeChild(toast), 300);
        }, 2000);
      })
      .catch(() => {
        alert(t("Error copying", "Ошибка при копировании"));
      });
  };

  const downloadCover = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!metadataResult?.coverUri) return;
    try {
      const coverUrl = metadataResult.coverUri.replace("1000x1000", "orig").replace("%%", "orig");
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = "/api/music/proxy-image?url=" + encodeURIComponent(coverUrl.startsWith("http") ? coverUrl : "https://" + coverUrl);
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });
      const canvas = document.createElement("canvas");
      canvas.width = 3000;
      canvas.height = 3000;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(img, 0, 0, 3000, 3000);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `cover_${metadataResult.title || "track"}.jpg`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          "image/jpeg",
          0.95,
        );
      }
    } catch (e) {
      console.log(e?.message || String(e));
      alert(
        t("Error loading high-res cover. Opening original version...", "Ошибка при загрузке обложки в высоком разрешении. Открываем оригинальную версию..."),
      );
      window.open(metadataResult.coverUri, "_blank");
    }
  };

  const copyMetadata = () => {
    if (!metadataResult) return;
    let label = metadataResult.hiddenLabel || "";
    if (labelCheckResult?.label) {
      label = labelCheckResult.label;
    }
    let music = metadataResult.authorsMusic ? `\n" + t("Music: ", "Музыка: ") + "${metadataResult.authorsMusic}` : "";
    let textAuthors = metadataResult.authorsText ? `\n" + t("Lyrics: ", "Слова: ") + "${metadataResult.authorsText}` : "";

    const text = `" + t("Release Title: ", "Название релиза: ") + "${metadataResult.title || ""}
" + t("Artist: ", "Артист: ") + "${metadataResult.artists || ""}
" + t("Label: ", "Лейбл: ") + "${label}
Copyright: ${metadataResult.copyright || ""}
" + t("UPC: ", "UPC: ") + "${metadataResult.upc || t("Not found", "Не найден")}
" + t("ISRC: ", "ISRC: ") + "${metadataResult.isrc || t("Not found", "Не найден")}${music}${textAuthors}`;
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert(t("Copied to clipboard!", "Скопировано в буфер обмена!"));
      })
      .catch(() => {
        alert(t("Error copying", "Ошибка при копировании"));
      });
  };

  const [downloadingTrackId, setDownloadingTrackId] = useState<string | null>(null);

  useEffect(() => {
    return subscribeDownloadState((state) => {
      if (state.isDownloading && state.trackId) {
        setDownloadingTrackId(state.trackId);
      } else {
        setDownloadingTrackId(null);
      }
    });
  }, []);

  const downloadAudio = (e: React.MouseEvent, trackId?: string, trackTitle?: string, trackArtists?: string, trackUpc?: string, trackIsrc?: string, trackCoverUri?: string) => {
    e.stopPropagation();
    const targetId = trackId || metadataResult?.id;
    const targetTitle = trackTitle || metadataResult?.title || "";
    const targetArtists = trackArtists || metadataResult?.artists || "";
    if (!targetId) {
      alert(t("No track ID found.", "ID трека не найден."));
      return;
    }
    const upc = trackUpc || metadataResult?.upc || "";
    const isrc = trackIsrc || metadataResult?.isrc || "";
    const coverUri = trackCoverUri || metadataResult?.coverUri || "";
    downloadWavTrack({
      trackId: targetId,
      title: targetTitle,
      artists: targetArtists,
      upc,
      isrc,
      coverUri,
      t,
    });
  };

  const [isVkModalOpen, setIsVkModalOpen] = useState(false);
  const [vkConnected, setVkConnected] = useState(false);
  const [okRuJson, setOkRuJson] = useState("");
  const [isParsingOkRuJson, setIsParsingOkRuJson] = useState(false);

  // Auto-parse DevTools JSON Dump
  useEffect(() => {
    if (!okRuJson.trim()) return;
    try {
      JSON.parse(okRuJson);
      // It's valid JSON, let's call the parse function automatically if it's not already running
      if (!isParsingOkRuJson && okRuJson.length > 5) {
         // Create a fake event since handleOkRuParse expects one
         const fakeEvent = { preventDefault: () => {} } as React.FormEvent;
         // We can't directly call it if it's not defined yet, so we will use a timeout
         setTimeout(() => {
           const formBtn = document.getElementById("hidden-parse-btn");
           if (formBtn) formBtn.click();
         }, 50);
      }
    } catch (e) {
      // not a valid JSON yet
    }
  }, [okRuJson]);

  const [okRuResult, setOkRuResult] = useState<string | null>(null);
  const [okRuParsedData, setOkRuParsedData] = useState<{
    title?: string;
    artists?: string;
    copyright?: string;
    copyrightOwnerName?: string;
    copyrightOwnerId?: number | string;
    label?: string;
    distributor?: string;
    isrc?: string;
    upc?: string;
    releaseId?: number | string;
    idForDownload?: number | string;
    trackId?: string | number;
    durationFormatted?: string;
    playUrl?: string;
    imageUrl?: string;
    rawJson?: any;
  } | null>(null);
  const [copiedOkRuKey, setCopiedOkRuKey] = useState<string | null>(null);
  const [showOkRuLogin, setShowOkRuLogin] = useState(false);
  const [okRuLogin, setOkRuLogin] = useState("");
  const [okRuPassword, setOkRuPassword] = useState("");
  const [okRuCookieString, setOkRuCookieString] = useState("");
  const [loginMode, setLoginMode] = useState<"cookie" | "password" | "proxy">("cookie");
  const [okRuLoggingIn, setOkRuLoggingIn] = useState(false);
  const [hasOkRuSession, setHasOkRuSession] = useState(false);
  const [okRuUserName, setOkRuUserName] = useState<string | null>(null);
  const [okRuError, setOkRuError] = useState<string | null>(null);
  const [okRuQuery, setOkRuQuery] = useState("");
  const [copiedConsoleScript, setCopiedConsoleScript] = useState(false);

  // OK.ru Proxy state
  const [okRuProxyUrl, setOkRuProxyUrl] = useState("");
  const [okRuProxyEnabled, setOkRuProxyEnabled] = useState(false);
  const [okRuProxyTesting, setOkRuProxyTesting] = useState(false);
  const [okRuProxySaving, setOkRuProxySaving] = useState(false);
  const [okRuProxyTestResult, setOkRuProxyTestResult] = useState<{
    success: boolean;
    latencyMs?: number;
    ip?: string;
    country?: string;
    countryCode?: string;
    countryFlag?: string;
    city?: string;
    region?: string;
    isp?: string;
    okAccess?: boolean;
    message: string;
  } | null>(null);
  const [okRuProxyPing, setOkRuProxyPing] = useState<{
    status: "idle" | "testing" | "online" | "error";
    latencyMs?: number;
    ip?: string;
    country?: string;
    countryCode?: string;
    countryFlag?: string;
    city?: string;
    region?: string;
    isp?: string;
    error?: string;
  }>({ status: "idle" });

  const performProxyHealthCheck = async (urlToCheck?: string) => {
    const targetUrl = (urlToCheck !== undefined ? urlToCheck : okRuProxyUrl).trim();
    if (!targetUrl) {
      setOkRuProxyPing({ status: "idle" });
      return;
    }
    setOkRuProxyTesting(true);
    setOkRuProxyPing(prev => ({ ...prev, status: "testing" }));
    try {
      const res = await fetchWithRetry("/api/okru/proxy/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proxyUrl: targetUrl }),
      });
      const data = await safeParseResponse(res);
      setOkRuProxyTestResult(data);
      if (data.success) {
        setOkRuProxyPing({
          status: "online",
          latencyMs: data.latencyMs,
          ip: data.ip,
          country: data.country,
          countryCode: data.countryCode,
          countryFlag: data.countryFlag,
          city: data.city,
          region: data.region,
          isp: data.isp,
        });
      } else {
        setOkRuProxyPing({
          status: "error",
          error: data.message || "Proxy connection error",
        });
      }
    } catch (e: any) {
      const errorMsg = e.message || t("Proxy connection failed", "Не удалось подключиться к прокси");
      setOkRuProxyTestResult({ success: false, message: errorMsg });
      setOkRuProxyPing({ status: "error", error: errorMsg });
    }
    setOkRuProxyTesting(false);
  };

  const loadOkRuProxy = async () => {
    try {
      const res = await fetchWithRetry("/api/okru/proxy");
      const data = await safeParseResponse(res);
      if (data) {
        setOkRuProxyEnabled(Boolean(data.enabled));
        const url = data.proxyUrl || "";
        setOkRuProxyUrl(url);
        if (url) {
          performProxyHealthCheck(url);
        }
      }
    } catch (e) {}
  };

  const handleSaveOkRuProxy = async () => {
    setOkRuProxySaving(true);
    try {
      const res = await fetchWithRetry("/api/okru/proxy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: okRuProxyEnabled, proxyUrl: okRuProxyUrl }),
      });
      const data = await safeParseResponse(res);
      if (data.success) {
        setOkRuProxyTestResult({ success: true, message: t("Proxy settings saved successfully!", "Настройки прокси успешно сохранены!") });
        if (okRuProxyUrl.trim()) {
          performProxyHealthCheck(okRuProxyUrl);
        }
      }
    } catch (e: any) {
      setOkRuProxyTestResult({ success: false, message: e.message || t("Failed to save proxy", "Ошибка сохранения прокси") });
    }
    setOkRuProxySaving(false);
  };

  const handleTestOkRuProxy = async () => {
    if (!okRuProxyUrl.trim()) {
      setOkRuProxyTestResult({ success: false, message: t("Please enter a proxy string to test", "Введите строку прокси для проверки") });
      setOkRuProxyPing({ status: "idle" });
      return;
    }
    await performProxyHealthCheck(okRuProxyUrl);
  };

  // Debounced auto check proxy when URL changes
  useEffect(() => {
    if (!okRuProxyUrl || okRuProxyUrl.trim().length < 6) {
      if (!okRuProxyUrl.trim()) setOkRuProxyPing({ status: "idle" });
      return;
    }
    const timer = setTimeout(() => {
      performProxyHealthCheck(okRuProxyUrl);
    }, 900);
    return () => clearTimeout(timer);
  }, [okRuProxyUrl]);

  const copyConsoleScript = () => {
    const script = `copy(document.cookie); alert("✅ Куки OK.ru успешно скопированы в буфер обмена! Теперь просто вставьте их в поле окна авторизации.");`;
    navigator.clipboard.writeText(script).then(() => {
      setCopiedConsoleScript(true);
      setTimeout(() => setCopiedConsoleScript(false), 2500);
    }).catch(() => {
      alert("Код: copy(document.cookie)");
    });
  };

  const checkOkRuStatus = async () => {
    try {
      const res = await fetchWithRetry("/api/okru/status");
      const data = await safeParseResponse(res);
      setHasOkRuSession(Boolean(data && data.hasSession));
      if (data?.user) setOkRuUserName(data.user);
    } catch (e: any) {
      console.log(e?.message || String(e));
    }
  };

  const checkVkStatus = async () => {
    try {
      const res = await fetchWithRetry("/api/vk/status");
      const data = await safeParseResponse(res);
      setVkConnected(Boolean(data.hasSession && data.valid !== false));
    } catch (e: any) {
      console.log(e?.message || String(e));
    }
  };

  useEffect(() => {
    checkOkRuStatus();
    checkVkStatus();
    loadOkRuProxy();
  }, []);

  const handleOkRuLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOkRuLoggingIn(true);
    setOkRuError(null);
    try {
      const res = await fetchWithRetry("/api/okru/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          loginMode === "cookie"
            ? { cookieString: okRuCookieString }
            : { login: okRuLogin, password: okRuPassword },
        ),
      });
      const data = await safeParseResponse(res);
      if (data.success) {
        setHasOkRuSession(true);
        if (data.user) setOkRuUserName(data.user);
        setShowOkRuLogin(false);
      } else {
        setOkRuError(data.error || "Неизвестная ошибка авторизации");
      }
    } catch (err: any) {
      setOkRuError(err.message || "Ошибка сети при входе");
    }
    setOkRuLoggingIn(false);
  };

  const searchOkRu = async (searchQuery: string) => {
    setLoading(true);
    try {
      const res = await fetchWithRetry("/api/okru/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchQuery }),
      });
      const data = await safeParseResponse(res);
      if (data.copyright || data.label) {
        setOkRuResult(`Copyright: ${data.copyright || '—'} | Label: ${data.label || '—'}`);
        setMetadataResult((prev: any) =>
          prev
            ? { ...prev, copyright: data.copyright || prev.copyright, label: data.label || prev.label, okruTrackUrl: data.playUrl }
            : prev,
        );
      } else {
        setOkRuResult(
          t("Copyright not found. To find, use alternative method (DevTools Parse). ", "Copyright не найден. Чтобы найти, используйте альтернативный способ получения copyright (DevTools Parse). ") +
            (data.error || ""),
        );
      }
    } catch (err: any) {
      setOkRuResult(
        t("Search error. Copyright not found. To find, use alternative method. (", "Ошибка поиска. Copyright не найден. Чтобы найти, используйте альтернативный способ получения copyright. (") +
          err.message +
          ")",
      );
    }
    setLoading(false);
  };

  const handleOkRuParse = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!okRuJson.trim()) return;
    setIsParsingOkRuJson(true);
    setOkRuResult(null);
    setOkRuParsedData(null);
    await new Promise(r => setTimeout(r, 200));

    try {
      const parsedData = JSON.parse(okRuJson);

      // Deep local scan
      const collectedPlines: string[] = [];
      const collectedPublishers: string[] = [];
      const collectedOwners: string[] = [];
      const collectedCopyrights: string[] = [];
      const collectedLabels: string[] = [];
      const collectedIsrcs: string[] = [];
      const collectedUpcs: string[] = [];
      let foundTitle: string | undefined;
      let foundArtist: string | undefined;
      let foundOwnerId: number | string | undefined;
      let foundReleaseId: number | string | undefined;
      let foundIdForDownload: number | string | undefined;
      let foundTrackId: string | number | undefined;
      let foundDuration: number | undefined;
      let foundPlayUrl: string | undefined;
      let foundImageUrl: string | undefined;

      const visited = new Set<any>();

      const scanObject = (node: any, depth = 0) => {
        if (!node || depth > 25 || visited.has(node)) return;
        if (typeof node !== "object") return;
        visited.add(node);

        if (Array.isArray(node)) {
          for (const item of node) {
            scanObject(item, depth + 1);
          }
          return;
        }

        // Track title
        if (typeof node.title === "string" && node.title.trim() && !foundTitle) {
          foundTitle = node.title.trim();
        } else if (typeof node.name === "string" && node.name.trim() && !foundTitle) {
          foundTitle = node.name.trim();
        }

        // Artists
        if (typeof node.ensemble === "string" && node.ensemble.trim() && !foundArtist) {
          foundArtist = node.ensemble.trim();
        } else if (typeof node.artistName === "string" && node.artistName.trim() && !foundArtist) {
          foundArtist = node.artistName.trim();
        } else if (typeof node.artists === "string" && node.artists.trim() && !foundArtist) {
          foundArtist = node.artists.trim();
        }

        // OK.ru specific fields
        if (node.copyrightOwnerId !== undefined && foundOwnerId === undefined) {
          foundOwnerId = node.copyrightOwnerId;
        }
        if (node.releaseId !== undefined && foundReleaseId === undefined) {
          foundReleaseId = node.releaseId;
        }
        if (node.idForDownload !== undefined && foundIdForDownload === undefined) {
          foundIdForDownload = node.idForDownload;
        }
        if (node.id !== undefined && foundTrackId === undefined) {
          foundTrackId = node.id;
        }
        if (typeof node.duration === "number" && foundDuration === undefined) {
          foundDuration = node.duration;
        }
        if (typeof node.play === "string" && node.play.startsWith("http") && !foundPlayUrl) {
          foundPlayUrl = node.play;
        }
        if (typeof node.playUrl === "string" && node.playUrl.startsWith("http") && !foundPlayUrl) {
          foundPlayUrl = node.playUrl;
        }
        if (typeof node.imageUrl === "string" && node.imageUrl.startsWith("http") && !foundImageUrl) {
          foundImageUrl = node.imageUrl;
        } else if (typeof node.image === "string" && node.image.startsWith("http") && !foundImageUrl) {
          foundImageUrl = node.image;
        }

        // pLine fallbacks
        const plineVal = node.pLine || node.pline || node.p_line || node.PLine || node.cLine || node.cline || node.c_line;
        if (typeof plineVal === "string" && plineVal.trim()) {
          collectedPlines.push(plineVal.trim());
        }

        // publisher fallbacks
        const pubVal = node.publisher || node.publisherName || node.publisher_name || node.publisherTitle;
        if (typeof pubVal === "string" && pubVal.trim()) {
          collectedPublishers.push(pubVal.trim());
        }

        // copyrightOwnerName fallbacks
        const ownerVal = node.copyrightOwnerName || node.copyright_owner_name || node.ownerName || node.owner_name || node.rightsHolder || node.rights_holder;
        if (typeof ownerVal === "string" && ownerVal.trim()) {
          collectedOwners.push(ownerVal.trim());
        }

        // copyright fallbacks
        const crVal = node.copyright || node.copyrights || node.legalCopyright;
        if (typeof crVal === "string" && crVal.trim()) {
          collectedCopyrights.push(crVal.trim());
        }

        // label fallbacks
        const lblVal = node.label || node.labelName || node.label_name || node.recordLabel || node.album?.label || node.album?.labelName || node.album?.recordLabel;
        if (typeof lblVal === "string" && lblVal.trim()) {
          collectedLabels.push(lblVal.trim());
        }

        // ISRC / UPC fallbacks
        if (typeof node.isrc === "string" && node.isrc.trim()) collectedIsrcs.push(node.isrc.trim());
        if (typeof node.upc === "string" && node.upc.trim()) collectedUpcs.push(node.upc.trim());
        if (typeof node.barcode === "string" && node.barcode.trim()) collectedUpcs.push(node.barcode.trim());

        // Traverse children
        for (const key of Object.keys(node)) {
          scanObject(node[key], depth + 1);
        }
      };

      scanObject(parsedData);

      // Try server parse-json endpoint for enhanced classifier metadata
      let serverScanResult: any = null;
      try {
        const res = await fetch("/api/okru/parse-json", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rawJson: okRuJson })
        });
        if (res.ok) {
          const data = await res.json();
          if (data.success) {
            serverScanResult = data;
          }
        }
      } catch (e) {}

      const rawPline = collectedPlines[0] || "";
      const rawPublisher = collectedPublishers[0] || "";
      const rawOwner = collectedOwners[0] || "";
      const rawCopyright = collectedCopyrights[0] || "";
      const rawLabel = collectedLabels[0] || "";
      const isrc = serverScanResult?.isrc || collectedIsrcs[0] || null;
      const upc = serverScanResult?.upc || collectedUpcs[0] || null;

      const allCandidateValues = [
        ...collectedOwners,
        ...collectedPlines,
        ...collectedPublishers,
        ...collectedCopyrights,
        ...collectedLabels
      ].filter((v, idx, arr) => Boolean(v) && arr.indexOf(v) === idx);

      const aggregator = serverScanResult?.distributor || allCandidateValues.find(s => {
        const l = s.toLowerCase();
        return (
          l.includes("национальный цифровой агрегатор") ||
          l.includes("нца") ||
          l.includes("believe") ||
          l.includes("билив") ||
          l.includes("zvonko") ||
          l.includes("звонко") ||
          l.includes("sp digital") ||
          l.includes("sp_digital") ||
          l.includes("сп диджитал") ||
          l.includes("fuga") ||
          l.includes("onerpm") ||
          l.includes("orchard") ||
          l.includes("sony") ||
          l.includes("universal") ||
          l.includes("warner") ||
          l.includes("первое музыкальное") ||
          l.includes("союз") ||
          l.includes("rhymes") ||
          l.includes("gamma") ||
          l.includes("effective")
        );
      }) || null;

      let finalCopyright: string | null = rawPline || serverScanResult?.pLine || rawOwner || serverScanResult?.copyrightOwnerName || serverScanResult?.copyright || aggregator || rawCopyright || rawPublisher || rawLabel || null;
      if (finalCopyright && !finalCopyright.includes('℗') && !finalCopyright.includes('(P)') && !finalCopyright.includes('©')) {
        finalCopyright = `℗ 2025 ${finalCopyright}`;
      }
      let finalLabel: string | null = serverScanResult?.label || rawLabel || (rawOwner && rawOwner !== finalCopyright ? rawOwner : null) || rawPublisher || finalCopyright || null;
      let finalDistributor: string | null = serverScanResult?.distributor || aggregator || rawOwner || serverScanResult?.copyrightOwnerName || (finalCopyright?.includes('SP DIGITAL') ? 'SP DIGITAL' : undefined);

      let durationText = "";
      if (foundDuration) {
        const mins = Math.floor(foundDuration / 60);
        const secs = foundDuration % 60;
        durationText = `${mins}:${secs.toString().padStart(2, "0")} (${foundDuration} сек)`;
      }

      const structuredResult = {
        title: serverScanResult?.title || foundTitle || "Не указан",
        artists: serverScanResult?.artists || foundArtist || "Не указан",
        copyright: finalCopyright || "Не найден",
        copyrightOwnerName: rawOwner || serverScanResult?.copyrightOwnerName || finalCopyright || undefined,
        copyrightOwnerId: foundOwnerId ?? serverScanResult?.copyrightOwnerId,
        label: finalLabel || finalCopyright || "Не указан",
        distributor: finalDistributor,
        isrc: isrc || undefined,
        upc: upc || undefined,
        releaseId: foundReleaseId ?? serverScanResult?.releaseId,
        idForDownload: foundIdForDownload ?? serverScanResult?.idForDownload,
        trackId: foundTrackId ?? serverScanResult?.trackId,
        durationFormatted: durationText || undefined,
        playUrl: foundPlayUrl || serverScanResult?.playUrl,
        imageUrl: foundImageUrl,
        rawJson: parsedData,
      };

      setOkRuParsedData(structuredResult);

      const parts = [];
      if (structuredResult.copyright && structuredResult.copyright !== "Не найден") parts.push(`Правообладатель / Копирайт: ${structuredResult.copyright}`);
      if (structuredResult.label && structuredResult.label !== "Не указан" && structuredResult.label !== structuredResult.copyright) parts.push(`Лейбл: ${structuredResult.label}`);
      if (structuredResult.distributor && structuredResult.distributor !== structuredResult.copyright) parts.push(`Дистрибьютор: ${structuredResult.distributor}`);
      if (structuredResult.isrc) parts.push(`ISRC: ${structuredResult.isrc}`);
      if (structuredResult.upc) parts.push(`UPC: ${structuredResult.upc}`);
      if (structuredResult.copyrightOwnerId) parts.push(`Owner ID: ${structuredResult.copyrightOwnerId}`);

      setOkRuResult(parts.length > 0 ? parts.join(" | ") : "Метаданные извлечены");

      setMetadataResult((prev: any) =>
        prev ? {
          ...prev,
          copyright: (structuredResult.copyright !== "Не найден" ? structuredResult.copyright : prev.copyright),
          label: (structuredResult.label !== "Не указан" ? structuredResult.label : prev.label),
          isrc: structuredResult.isrc || prev.isrc,
          upc: structuredResult.upc || prev.upc,
          distributor: structuredResult.distributor || prev.distributor,
          okruTrackUrl: structuredResult.playUrl || prev.okruTrackUrl
        } : prev
      );

    } catch (err: any) {
      setOkRuResult("Неверный формат JSON. Пожалуйста, вставьте необработанный ответ из вкладки Network DevTools.");
      setOkRuParsedData(null);
    }
    setIsParsingOkRuJson(false);
    setOkRuJson(""); // Auto-clear to reset parser
  };

  const [customEndpoint, setCustomEndpoint] = useState("tracks/114948834");
  const [customResult, setCustomResult] = useState<any>(null);
  const [isFetchingCustom, setIsFetchingCustom] = useState(false);

  const handleFetchCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEndpoint.trim()) return;
    setIsFetchingCustom(true);
    setCustomResult(null);
    try {
      const res = await fetchWithRetry("/api/music/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: customEndpoint.trim() }),
      });
      const data = await res.json();
      setCustomResult(data);
    } catch (err: any) {
      setCustomResult({ error: err.message });
    } finally {
      setIsFetchingCustom(false);
    }
  };

  const handleTestApi = async () => {
    setIsTestingApi(true);
    setTestApiResult(null);
    try {
      const res = await fetchWithRetry("/api/music/test");
      const data = await res.json();
      setTestApiResult(data);
    } catch (err: any) {
      setTestApiResult({ error: err.message });
    } finally {
      setIsTestingApi(false);
    }
  };

  
  
  const handleDownloadZip = async () => {
    if (!metadataResult) return;
    setIsZipping(true);
    setZipProgress(t("Preparing...", "Подготовка..."));
    
    try {
      const zip = new JSZip();
      
      let coverUrl = metadataResult.coverUrlHQ || metadataResult.coverUrl || metadataResult.coverUri;
      if (coverUrl) {
        setZipProgress(t("Downloading cover...", "Загрузка обложки..."));
        try {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.src = coverUrl.replace("1000x1000", "orig").replace("%%", "orig");
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
          });
          const canvas = document.createElement("canvas");
          canvas.width = img.width || 3000;
          canvas.height = img.height || 3000;
          const ctx = canvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.95));
            if (blob) {
              zip.file("cover.jpg", blob);
            }
          }
        } catch (e) {
          console.log("Failed to load cover via canvas, falling back to fetch", e?.message || String(e));
          try {
            const coverRes = await fetch(coverUrl);
            const coverBlob = await coverRes.blob();
            zip.file("cover.jpg", coverBlob);
          } catch (fetchErr) {
            console.log("Cover fetch fallback failed", fetchErr?.message || String(fetchErr));
          }
        }
      }
      
      setZipProgress(t("Generating metadata...", "Генерация метаданных..."));
      let label = metadataResult.label || t("Not found", "Не найден");
      
      const releaseTitle = metadataResult.title || "";
      const artists = metadataResult.artists || "";
      const upc = metadataResult.upc || t("Not found", "Не найден");
      const isrc = metadataResult.isrc || t("Not found", "Не найден");
      const musicAuthors = metadataResult.authorsMusic || "";
      const textAuthors = metadataResult.authorsText || "";
      const releaseDate = metadataResult.releaseDate || "";
      const copyright = metadataResult.copyright || "";
      
      if (zipFormat === "txt") {
        let musicStr = musicAuthors ? "\n" + t("Music: ", "Музыка: ") + musicAuthors : "";
        let textAuthorsStr = textAuthors ? "\n" + t("Lyrics: ", "Слова: ") + textAuthors : "";
        let dateStr = releaseDate ? "\n" + t("Release Date: ", "Дата релиза: ") + releaseDate : "";
        let copyStr = copyright ? "\n" + t("Copyright: ", "Копирайт: ") + copyright : "";
        
        const textContent = t("Release Title: ", "Название релиза: ") + releaseTitle + "\n" +
                            t("Artist: ", "Артист: ") + artists + "\n" +
                            t("Label: ", "Лейбл: ") + label + "\n" +
                            t("UPC: ", "UPC: ") + upc + "\n" +
                            t("ISRC: ", "ISRC: ") + isrc + dateStr + copyStr + musicStr + textAuthorsStr;
        zip.file("metadata.txt", textContent);
      } else if (zipFormat === "pdf") {
        setZipProgress(t("Generating PDF...", "Генерация PDF..."));
        const doc = new jsPDF();
        try {
          const fontUrl = "https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Regular.ttf";
          const response = await fetch(fontUrl);
          const buffer = await response.arrayBuffer();
          let binary = '';
          const bytes = new Uint8Array(buffer);
          const len = bytes.byteLength;
          for (let i = 0; i < len; i++) {
              binary += String.fromCharCode(bytes[i]);
          }
          const base64 = window.btoa(binary);
          doc.addFileToVFS("Roboto-Regular.ttf", base64);
          doc.addFont("Roboto-Regular.ttf", "Roboto", "normal");
          doc.setFont("Roboto");
        } catch(e) {
          console.log("Failed to load Cyrillic font for PDF", e?.message || String(e));
        }
        
        let y = 20;
        const addLine = (label, value) => {
          if (value) {
            doc.text(`${label} ${value}`, 20, y);
            y += 10;
          }
        };
        addLine(t("Release Title:", "Название релиза:"), releaseTitle);
        addLine(t("Artist:", "Артист:"), artists);
        addLine(t("Label:", "Лейбл:"), label);
        addLine(t("UPC:", "UPC:"), upc);
        addLine(t("ISRC:", "ISRC:"), isrc);
        if (releaseDate) addLine(t("Release Date:", "Дата релиза:"), releaseDate);
        if (copyright) addLine(t("Copyright:", "Копирайт:"), copyright);
        if (musicAuthors) addLine(t("Music:", "Музыка:"), musicAuthors);
        if (textAuthors) addLine(t("Lyrics:", "Слова:"), textAuthors);
        zip.file("metadata.pdf", doc.output("blob"));
      } else if (zipFormat === "xlsx") {
        const wsData = [
          [t("Field", "Поле"), t("Value", "Значение")],
          [t("Release Title", "Название релиза"), releaseTitle],
          [t("Artist", "Артист"), artists],
          [t("Label", "Лейбл"), label],
          [t("UPC", "UPC"), upc],
          [t("ISRC", "ISRC"), isrc],
        ];
        if (releaseDate) wsData.push([t("Release Date", "Дата релиза"), releaseDate]);
        if (copyright) wsData.push([t("Copyright", "Копирайт"), copyright]);
        if (musicAuthors) wsData.push([t("Music", "Музыка"), musicAuthors]);
        if (textAuthors) wsData.push([t("Lyrics", "Слова"), textAuthors]);
        
        const ws = XLSX.utils.aoa_to_sheet(wsData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Metadata");
        const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
        zip.file("metadata.xlsx", excelBuffer);
      }
      
      if (status?.connected) {
        if (metadataResult.type === "track" && metadataResult.id) {
          setZipProgress(t("Downloading audio...", "Загрузка аудио..."));
          try {
            const audioRes = await fetchWithRetry(`/api/music/download/${metadataResult.id}?format=wav&download=true&title=${encodeURIComponent(releaseTitle || '')}&artists=${encodeURIComponent(artists || '')}&upc=${encodeURIComponent(metadataResult.upc || '')}&isrc=${encodeURIComponent(metadataResult.isrc || '')}`);
            if (audioRes.ok) {
              const audioBlob = await audioRes.blob();
              let filename = `${artists} - ${releaseTitle}`.replace(/[/\\?%*:|"<>]/g, '-');
              zip.file(`${filename}.wav`, audioBlob);
            }
          } catch (e) {
            console.log("Audio download error", e?.message || String(e));
          }
        } else if ((metadataResult.type === "album" || metadataResult.type === "artist") && metadataResult.tracks) {
          let i = 1;
          for (const track of metadataResult.tracks) {
            if (!track.id) continue;
            setZipProgress(`${t("Downloading audio...", "Загрузка аудио...")} (${i}/${metadataResult.tracks.length})`);
            try {
               const audioRes = await fetchWithRetry(`/api/music/download/${track.id}?format=wav&download=true&title=${encodeURIComponent(track.title || '')}&artists=${encodeURIComponent(track.artist || track.artists || artists || '')}&upc=${encodeURIComponent(metadataResult.upc || track.upc || '')}&isrc=${encodeURIComponent(track.isrc || '')}`);
               if (audioRes.ok) {
                 const audioBlob = await audioRes.blob();
                 let filename = `${track.title}`.replace(/[/\\?%*:|"<>]/g, '-');
                 zip.file(`${i.toString().padStart(2, '0')} - ${filename}.wav`, audioBlob);
               }
            } catch (e) {
               console.log("Audio download error for track", track.id, e);
            }
            i++;
          }
        }
      }
      
      setZipProgress(t("Zipping...", "Упаковка..."));
      const zipBlob = await zip.generateAsync({ type: "blob" });
      let zipFilename = `${artists || "Release"} - ${releaseTitle || "Unknown"}`.replace(/[/\\?%*:|"<>]/g, '-');
      saveAs(zipBlob, `${zipFilename}.zip`);
      
    } catch (error) {
      console.log(error?.message || String(error));
      alert(t("Error generating ZIP", "Ошибка создания ZIP"));
    } finally {
      setIsZipping(false);
      setZipProgress("");
    }
  };

  const handleFetchArtist = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetUrl = artistUrl.trim();
    if (!targetUrl) return;

    setIsFetchingArtist(true);
    setArtistError("");
    setArtistResult(null);

    try {
      const res = await fetchWithRetry("/api/music/metadata", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: targetUrl, spotifyClientId, spotifyClientSecret }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to fetch artist");
      }

      if (data.data?.type !== "artist") {
        throw new Error("Provided URL is not an artist URL. Please use the Track / Album tab.");
      }

      setArtistResult(data.data);
    } catch (err: any) {
      setArtistError(err.message || "Something went wrong");
    } finally {
      setIsFetchingArtist(false);
    }
  };


  
  const handlePlayTrackGlobally = (track: any, queue: any[] = [], source: "manual" | "vibe" = "manual") => {
    setPlaybackSource(source);
    // Add to history
    setHistory(prev => {
      const newHistory = [{...track, playedAt: new Date().toISOString()}, ...prev.filter(t => t.id !== track.id)].slice(0, 50);
      return newHistory;
    });
    
    if (queue.length > 0) {
      setTrackQueue(queue);
    }
    
    // Play it
    if (track && track.id) {
       setActiveTrack(track);

       // Automatically parse / fetch metadata in background for codes, lyrics, label & details
       const trackTargetUrl = track.url || (track.albumId ? `https://music.yandex.ru/album/${track.albumId}/track/${track.id}` : `https://music.yandex.ru/track/${track.id}`);
       if (trackTargetUrl) {
         setMetadataUrl(trackTargetUrl);
         fetchWithRetry("/api/music/metadata", {
           method: "POST",
           headers: { "Content-Type": "application/json" },
           body: JSON.stringify({ url: trackTargetUrl, spotifyClientId, spotifyClientSecret }),
         })
           .then((r) => (r.ok ? r.json() : null))
           .then((d) => {
             if (d?.data) {
               setMetadataResult(d.data);
               // Augment active track with fresh parsed metadata
               setActiveTrack((prev: any) => {
                 if (prev && String(prev.id) === String(track.id)) {
                   return {
                     ...prev,
                     durationMs: d.data.durationMs || prev.durationMs,
                     duration: d.data.duration || prev.duration,
                     durationFormatted: d.data.durationFormatted || prev.durationFormatted,
                     isrc: d.data.isrc || prev.isrc,
                     upc: d.data.upc || prev.upc,
                     label: d.data.label || prev.label,
                     copyright: d.data.copyright || prev.copyright,
                     authorsMusic: d.data.authorsMusic || prev.authorsMusic,
                     authorsText: d.data.authorsText || prev.authorsText,
                     coverUri: d.data.coverUri || prev.coverUri,
                   };
                 }
                 return prev;
               });
               setHistory((prev: any[]) => prev.map((t: any) => {
                 if (String(t.id) === String(track.id)) {
                   return {
                     ...t,
                     durationMs: d.data.durationMs || t.durationMs,
                     duration: d.data.duration || t.duration,
                     durationFormatted: d.data.durationFormatted || t.durationFormatted,
                   };
                 }
                 return t;
               }));
             }
           })
           .catch(() => {});
       }
    }
  };

  const handleNextTrack = () => {
    if (playbackSource === "vibe") {
      window.dispatchEvent(new CustomEvent("playNextVibe"));
      return;
    }
    if (trackQueue.length > 0) {
      const currentIndex = trackQueue.findIndex(t => t.id === activeTrack?.id);
      if (currentIndex !== -1 && currentIndex < trackQueue.length - 1) {
        handlePlayTrackGlobally(trackQueue[currentIndex + 1], trackQueue, playbackSource);
      }
    }
  };



  const handleFetchMetadata = async (e?: React.FormEvent, directUrl?: string) => {
    if (e) e.preventDefault();
    const targetUrl = directUrl || metadataUrl.trim();
    if (!targetUrl) return;

    const urls = targetUrl
      .split("\n")
      .map((u) => u.trim())
      .map((u) => (fetchAlbumForTrack ? u.replace(/\/track\/\d+/, "") : u))
      .filter((u) => u);

    if (urls.length === 1) {
      setIsFetchingMetadata(true);
      setMetadataError("");
      setMetadataResult(null);
      setLabelCheckResult(null);

      // Non-blocking resolve in background
      fetchWithRetry("/api/music/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: urls[0], spotifyClientId, spotifyClientSecret }),
      })
        .then((r) => r.ok ? r.json() : null)
        .then((d) => {
          if (d?.data) setResolvedMetadata(d.data);
        })
        .catch(() => {});

      try {
        const isOkRu = urls[0].includes("ok.ru");
        let okruResult: any = null;

        if (isOkRu && hasOkRuSession) {
          try {
            const okRes = await fetchWithRetry("/api/okru/search", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ query: urls[0] }),
            });
            if (okRes.ok) {
              const okData = await okRes.json();
              if (okData.track) {
                okruResult = okData;
              }
            }
          } catch (e) {}
        }

        const res = await fetchWithRetry("/api/music/metadata", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: urls[0], spotifyClientId, spotifyClientSecret }),
        });
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Failed to fetch metadata");
        }
        
        if (okruResult && isOkRu && data.data) {
          data.data.copyright = (okruResult.copyright && okruResult.copyright !== "OK.ru OG Metadata") ? okruResult.copyright : data.data.copyright;
          data.data.label = okruResult.label || data.data.label;
          if (okruResult.track) {
            data.data.title = okruResult.track.name || data.data.title;
            data.data.artists = okruResult.track.ensembleName || data.data.artists;
            data.data.playUrl = okruResult.playUrl || data.data.playUrl;
            if (okruResult.track.releaseDate) data.data.releaseDate = okruResult.track.releaseDate;
            else if (okruResult.track.year) data.data.releaseDate = okruResult.track.year;
          }
        }

        if (data.data) {
          if (data.data.authorsMusic) data.data.authorsMusic = cleanMergeAuthors(data.data.authorsMusic);
          if (data.data.authorsText) data.data.authorsText = cleanMergeAuthors(data.data.authorsText);
          if (data.data.composers) {
            const extra = cleanMergeAuthors(data.data.composers);
            if (extra) {
              data.data.authorsMusic = data.data.authorsMusic ? cleanMergeAuthors([data.data.authorsMusic, extra]) : extra;
            }
          }
          if (data.data.lyricists) {
            const extra = cleanMergeAuthors(data.data.lyricists);
            if (extra) {
              data.data.authorsText = data.data.authorsText ? cleanMergeAuthors([data.data.authorsText, extra]) : extra;
            }
          }
        }

        // Immediately show the track information
        setMetadataResult(data.data);

        // Run secondary label check in background without blocking UI
        fetchWithRetry("/api/music/label-check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: urls[0], spotifyClientId, spotifyClientSecret }),
        })
          .then((r) => r.ok ? r.json() : null)
          .then((checkData) => {
            if (checkData?.data) {
              setLabelCheckResult(checkData.data);
            }
          })
          .catch(() => {});

        if (
          hasOkRuSession &&
          (data.data?.copyright?.includes("Copyright не найден") ||
            !data.data?.copyright)
        ) {
          const autoQuery = `${data.data?.artists} ${data.data?.title}`;
          setOkRuQuery(autoQuery);
          searchOkRu(autoQuery).catch(() => {});
        }
      } catch (err: any) {
        setMetadataError(err.message);
      } finally {
        setIsFetchingMetadata(false);
      }
    } else {
      // Bulk Mode
      setIsFetchingMetadata(true);
      setMetadataError("");
      setMetadataResult(null);
      setLabelCheckResult(null);
      setBulkProgress({ current: 0, total: urls.length });

            let exportRows: any[] = [];
      let currentIndex = 0;
      for (const url of urls) {
        try {
          const res = await fetchWithRetry("/api/music/metadata", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url, spotifyClientId, spotifyClientSecret }),
          });
          const data = await res.json();

          let label = data.data?.label || "";
          let copyright = data.data?.copyright || "";

          if (
            hasOkRuSession &&
            res.ok &&
            (copyright.includes("Copyright не найден") || !copyright || !data.data?.releaseDate || data.data?.releaseDate === "Unknown")
          ) {
            try {
              const autoQuery = `${data.data?.artists || ""} ${data.data?.title || ""}`.trim();
              const okRes = await fetchWithRetry("/api/okru/search", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ query: autoQuery }),
              });
              if (okRes.ok) {
                const okData = await okRes.json();
                if (okData.copyright && okData.copyright !== "OK.ru OG Metadata") {
                  copyright = okData.copyright;
                  if (data.data) data.data.copyright = copyright;
                }
                if (okData.track) {
                   if (okData.track.releaseDate && data.data) data.data.releaseDate = okData.track.releaseDate;
                   else if (okData.track.year && data.data) data.data.releaseDate = okData.track.year;
                }
              }
            } catch (e) {}
          }

          if (res.ok) {
            try {
              const checkRes = await fetchWithRetry("/api/music/label-check", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ url }),
              });
              if (checkRes.ok) {
                const checkData = await checkRes.json();
                if (checkData.data?.label) {
                  label = checkData.data.label;
                }
              }
            } catch (e) {}

            const d = data.data;
            if (d.type === "album" && d.tracks && d.tracks.length > 0) {
              for (const track of d.tracks) {
                exportRows.push({ url, type: "track (from album)", title: track.title, artist: d.artists, isrc: track.isrc, upc: d.upc, releaseDate: d.releaseDate, label, copyright });
              }
            } else {
              exportRows.push({ url, type: d.type, title: d.title, artist: d.artists, isrc: d.isrc, upc: d.upc, releaseDate: d.releaseDate, label, copyright });
            }
          } else {
            exportRows.push({ url, type: "Error", title: data.error || "Failed", artist: "", isrc: "", upc: "", releaseDate: "", label: "", copyright: "" });
          }
        } catch (err: any) {
          exportRows.push({ url, type: "Error", title: err.message, artist: "", isrc: "", upc: "", releaseDate: "", label: "", copyright: "" });
        }
        currentIndex++;
        setBulkProgress({ current: currentIndex, total: urls.length });
      }
      setBulkExportData(exportRows);
      setBulkProgress(null);
      setIsFetchingMetadata(false);
    }
  };

    const downloadCsv = () => {
    if (!bulkExportData) return;
    let csvContent = "URL,Type,Title,Artist,ISRC,UPC,Release Date,Label,Copyright\n";
    for (const row of bulkExportData) {
      csvContent += `"${row.url}","${row.type}","${(row.title || "").replace(/"/g, '""')}","${(row.artist || "").replace(/"/g, '""')}","${row.isrc || ""}","${row.upc || ""}","${row.releaseDate || ""}","${(row.label || "").replace(/"/g, '""')}","${(row.copyright || "").replace(/"/g, '""')}"\n`;
    }
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const urlObj = URL.createObjectURL(blob);
    link.setAttribute("href", urlObj);
    link.setAttribute("download", "metadata_export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setBulkExportData(null);
  };

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const res = await fetchWithRetry("/api/token");
      const data = await res.json();
      setStatus(data);
    } catch (err) {
      console.log("Failed to fetch status", err?.message || String(err));
    } finally {
      setLoading(false);
    }
  };

  // Auto-sync OK.ru and VK.ru credentials across page reloads/server restarts
  useEffect(() => {
    try {
      const savedOkCookies = localStorage.getItem("okru_cookies");
      if (savedOkCookies && savedOkCookies.trim()) {
        fetch("/api/okru/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ cookieString: savedOkCookies.trim() }),
        })
          .then((r) => r.json())
          .then((res) => {
            if (res.success) {
              setHasOkRuSession(true);
              if (res.userName) setOkRuUserName(res.userName);
            }
          })
          .catch(() => {});
      }

      const savedVkToken = localStorage.getItem("vk_auth_token");
      const savedVkCookies = localStorage.getItem("vk_auth_cookies");
      if (savedVkToken || savedVkCookies) {
        fetch("/api/vk/status")
          .then((r) => r.json())
          .then((st) => {
            if (!st.connected) {
              if (savedVkToken) {
                fetch("/api/vk/login", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ mode: "token", token: savedVkToken }),
                }).catch(() => {});
              } else if (savedVkCookies) {
                fetch("/api/vk/login", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ mode: "cookie", cookieString: savedVkCookies }),
                }).catch(() => {});
              }
            }
          })
          .catch(() => {});
      }
    } catch (e) {}
  }, []);

  const handleCopy = (text: string, type: "access" | "refresh") => {
    navigator.clipboard.writeText(text);
    if (type === "access") {
      setCopiedAccess(true);
      setTimeout(() => setCopiedAccess(false), 2000);
    } else {
      setCopiedRefresh(true);
      setTimeout(() => setCopiedRefresh(false), 2000);
    }
  };

  const handleExchange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    setIsSubmitting(true);
    setError("");

    let inputValue = code.trim();
    let isDirectToken = false;

    // Check if it's a URL or a long token
    const yandexTokenMatch = inputValue.match(/y0_[a-zA-Z0-9_-]+/);
    if (yandexTokenMatch) {
      inputValue = yandexTokenMatch[0];
      isDirectToken = true;
    } else if (inputValue.includes("access_token=")) {
      const match = inputValue.match(/access_token=([^&#]+)/);
      if (match) {
        inputValue = match[1];
        isDirectToken = true;
      }
    } else if (inputValue.includes("code=")) {
      const match = inputValue.match(/code=([^&#]+)/);
      if (match) {
        inputValue = match[1];
      }
    } else if (inputValue.length > 20 && !inputValue.includes("http")) {
      isDirectToken = true;
    }

    try {
      let res, data;

      if (isDirectToken) {
        res = await fetchWithRetry("/api/token/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ accessToken: inputValue }),
        });
      } else {
        res = await fetchWithRetry("/api/token/exchange", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: inputValue }),
        });
      }

      data = await res.json();

      if (!res.ok) {
        throw new Error(
          data.error || data.details?.error_description || "Failed to process",
        );
      }

      if (isDirectToken) {
        try { localStorage.setItem("yandex_music_token", inputValue); } catch(e) {}
      } else if (data?.token?.accessToken) {
        try { localStorage.setItem("yandex_music_token", data.token.accessToken); } catch(e) {}
      }

      setCode("");
      await fetchStatus();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefresh = async () => {
    setIsSubmitting(true);
    setError("");
    try {
      const res = await fetchWithRetry("/api/token/refresh", { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to refresh token");
      }

      await fetchStatus();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDisconnect = async () => {
    setIsSubmitting(true);
    try {
      await fetchWithRetry("/api/token/disconnect", { method: "POST" });
      try { localStorage.removeItem("yandex_music_token"); } catch(e) {}
      setStatus({ connected: false });
      await fetchStatus();
    } catch (err: any) {
      console.log(err?.message || String(err));
      setStatus({ connected: false });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5f5f7] dark:bg-black flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <RefreshCw className="w-8 h-8 text-zinc-400 dark:text-zinc-500 animate-spin" />
          <p className="text-zinc-500 dark:text-zinc-400 font-medium">{t("Loading status...", "Загрузка статуса...")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={theme === "dark" ? "dark" : ""}>
    <div className={`min-h-screen p-6 sm:p-12 transition-all duration-700 ease-in-out ${
      appTheme === 'minimalism' ? 'bg-white dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans' : 
      appTheme === 'anime' ? 'bg-gradient-to-br from-pink-100 via-purple-100 to-indigo-100 dark:from-pink-950 dark:via-purple-900 dark:to-indigo-950 text-indigo-900 dark:text-pink-100 font-sans' : 
      appTheme === 'designer' ? 'bg-[#e0e5ec] dark:bg-[#1a1b1e] text-zinc-800 dark:text-zinc-200 font-sans bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/40 via-transparent to-transparent dark:from-white/5' : 
      appTheme === 'cyberpunk' ? 'bg-zinc-950 text-yellow-400 font-mono bg-[linear-gradient(rgba(250,204,21,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(250,204,21,0.05)_1px,transparent_1px)] bg-[size:20px_20px]' :
      appTheme === 'brutalism' ? 'bg-[#f4f4f0] dark:bg-zinc-900 text-black dark:text-white font-mono' :
      'bg-[#f5f5f7] dark:bg-black text-zinc-900 dark:text-zinc-50 font-sans'
    }`}>
                                                                                
      <div className="max-w-2xl mx-auto space-y-8 relative z-10">
        
        

        <OkRuAuthModal
          isOpen={showOkRuLogin}
          onClose={() => setShowOkRuLogin(false)}
          onSuccess={() => checkOkRuStatus()}
          t={t}
        />

        {/* Header */}
        <div className="flex justify-between items-start mb-6 transition-all duration-500">
    <header className="flex items-center gap-4">
          <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center shadow-sm p-1.5">
            <YandexMusicIcon className="w-full h-full" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">{t("Yandex Music Service", "Сервис Yandex Music")}</h1>
            <p className="text-zinc-500 dark:text-zinc-400">{t("Music and metadata search", "Поиск музыки и метаданных")}</p>
          </div>
        </header>

<SpotifySettingsModal 
        isSpotifyModalOpen={isSpotifyModalOpen} 
        setIsSpotifyModalOpen={setIsSpotifyModalOpen} 
        spotifyClientId={spotifyClientId} 
        setSpotifyClientId={setSpotifyClientId} 
        spotifyClientSecret={spotifyClientSecret} 
        setSpotifyClientSecret={setSpotifyClientSecret} 
        t={t} 
      />

<BotInfoModal isBotInfoOpen={isBotInfoOpen} setIsBotInfoOpen={setIsBotInfoOpen} botName={botName} botUsername={botUsername} botId={botId} botStatus={botStatus} t={t} />

<VkAuthModal
  isOpen={isVkModalOpen}
  onClose={() => setIsVkModalOpen(false)}
  onSuccess={() => checkVkStatus()}
  t={t}
/>

<TokenSettingsModal 
        isTokenModalOpen={isTokenModalOpen} 
        setIsTokenModalOpen={setIsTokenModalOpen} 
        status={status} 
        code={code} 
        setCode={setCode} 
        isSubmitting={isSubmitting} 
        error={error} 
        onSubmitAuth={handleExchange}
        handleRefresh={handleRefresh}
        handleDisconnect={handleDisconnect}
        copiedAccess={copiedAccess}
        copiedRefresh={copiedRefresh}
        handleCopy={handleCopy}
        AUTH_URL={AUTH_URL} 
        t={t} 
      />

<div className="flex items-center gap-1 p-1 bg-white/60 dark:bg-zinc-800/60 backdrop-blur-xl rounded-full shadow-sm border border-zinc-200/50 dark:border-white/10">
      <button onClick={() => setLang(lang === "en" ? "ru" : "en")} className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-zinc-700 dark:text-zinc-300">
        {lang === "en" ? "RU" : "EN"}
      </button>
      
      <div className="hidden sm:flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-full border border-zinc-200 dark:border-zinc-700">
        {[
          { id: 'default', color: 'bg-zinc-500', name: 'Default' },
          { id: 'minimalist', color: 'bg-zinc-300', name: 'Minimalist' },
          { id: 'brutalist', color: 'bg-red-500', name: 'Brutalist' },
          { id: 'cyberpunk', color: 'bg-fuchsia-500', name: 'Cyberpunk' }
        ].map(t => (
           <button 
             key={t.id} 
             onClick={() => setColorTheme(t.id as any)}
             className={`w-6 h-6 rounded-full ${t.color} ${colorTheme === t.id ? 'ring-2 ring-blue-500 ring-offset-1 dark:ring-offset-zinc-900' : 'opacity-70 hover:opacity-100'} transition-all`}
             title={t.id}
           />
        ))}
      </div>

      <button onClick={() => setTheme(theme === "light" ? "dark" : "light")} className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-zinc-700 dark:text-zinc-300">
        {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
      </button>
      <button onClick={() => setIsSpotifyModalOpen(true)} className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-green-500 relative" title={t("Spotify Settings", "Настройки Spotify")}>
        <SpotifyIcon className="w-4 h-4" />
        {spotifyClientId && spotifyClientSecret ? <span className="absolute top-1 right-1 w-2 h-2 bg-green-500 rounded-full"></span> : <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
      </button>
      <button onClick={() => setIsVkModalOpen(true)} className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-[#0077FF] relative" title={t("VK.ru Settings", "Настройки VK (ВКонтакте)")}>
        <VkIcon className="w-4 h-4" />
        {vkConnected ? <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full"></span> : <span className="absolute top-1 right-1 w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>}
      </button>
      <button onClick={() => setShowOkRuLogin(true)} className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-[#EE8208] relative" title={t("OK.ru Settings", "Настройки OK.ru")}>
        <OkRuIcon className="w-4 h-4" />
        {hasOkRuSession ? <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full"></span> : <span className="absolute top-1 right-1 w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>}
      </button>
      <button onClick={() => setIsTokenModalOpen(true)} className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-zinc-100 dark:hover:bg-white/10 text-zinc-700 dark:text-zinc-300 relative" title={t("Token Settings", "Настройки токена")}>
        <Key className="w-4 h-4" />
        {status?.connected ? <span className="absolute top-1 right-1 w-2 h-2 bg-green-500 rounded-full"></span> : <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
      </button>
    </div>
  </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-2xl flex items-start gap-3">
            <XCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="font-medium text-sm">{error}</p>
          </div>
        )}

        
        {/* Navigation Tabs & Access Status */}
        <div className="flex flex-col gap-3 mb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 w-full">
            <div className={`flex flex-wrap gap-2 p-2 shadow-sm w-full md:w-auto overflow-x-auto transition-all duration-500 ${
              appTheme === 'minimalism' ? 'bg-transparent border-b border-zinc-200 dark:border-white/10 rounded-none' : 
              appTheme === 'anime' ? 'bg-white/60 dark:bg-pink-900/40 backdrop-blur-md rounded-[2rem] border-2 border-pink-200 dark:border-pink-800 shadow-pink-200/50' : 
              appTheme === 'designer' ? 'bg-white/40 dark:bg-black/20 backdrop-blur-xl rounded-3xl border border-white/40 dark:border-white/10 shadow-lg' : 
              appTheme === 'cyberpunk' ? 'bg-black/80 border border-yellow-400 rounded-none font-mono shadow-[0_0_10px_rgba(250,204,21,0.2)]' :
              appTheme === 'brutalism' ? 'bg-white dark:bg-zinc-900 border-4 border-black dark:border-white rounded-none shadow-[4px_4px_0_0_rgba(0,0,0,1)] dark:shadow-[4px_4px_0_0_rgba(255,255,255,1)]' :
              'bg-white/40 dark:bg-black/20 backdrop-blur-md rounded-2xl border border-zinc-200/50 dark:border-white/10'
            }`}>
              {[
                { id: "unique_parser", label: t("OK.RU Release Parser", "Парсер релизов OK.RU (CDP)") },
                { id: "back_catalog", label: t("Back-catalog & Transfer", "Бэк-каталог (Трансфер)") },
                ...(isChiefOwner ? [{ 
                  id: "cloud", 
                  label: "👑 Supabase & TG & Токены", 
                  isOwnerOnly: true 
                }] : []),
                { id: "vibe", label: t("My Vibe", "Моя Волна") },
                { id: "search", label: t("Search", "Поиск") },
                { id: "report", label: t("Report", "Отчёт") },
                { id: "logs", label: t("Logs", "Логи") },
                { id: "api", label: t("API & Gateways", "API & Шлюзы") },
                { id: "history", label: t("History", "История") },
                { id: "creator", label: t("Creator", "Создатель") },
                { id: "prompts", label: t("Naming", "Нейминг") },
                { id: "converter", label: t("Converter (Audio & Photo)", "Конвертер (WAV & Фото)") },
                { id: "videoshot", label: t("Video Shot Studio (404×720)", "Создать видеошот (404×720)") }
              ].map(tab => (
                 <button
                    key={tab.id}
                    onClick={() => setActiveAppTab(tab.id as any)}
                    className={`px-4 py-2.5 text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${
                      (tab as any).isOwnerOnly ? (
                        activeAppTab === tab.id 
                          ? "bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-black font-black shadow-[0_0_16px_rgba(16,185,129,0.5)] scale-105 rounded-xl border-2 border-emerald-300 ring-2 ring-emerald-400/40" 
                          : "bg-emerald-950/90 text-emerald-200 hover:text-white hover:bg-emerald-900 border-2 border-emerald-500/70 font-black rounded-xl shadow-sm"
                      ) : (
                        appTheme === 'minimalism' ? (activeAppTab === tab.id ? "text-black dark:text-white border-b-2 border-black dark:border-white" : "text-zinc-500 hover:text-black dark:hover:text-white") :
                        appTheme === 'anime' ? (activeAppTab === tab.id ? "bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-2xl shadow-md scale-105" : "hover:bg-pink-100 dark:hover:bg-pink-900/50 text-pink-700 dark:text-pink-300 rounded-2xl") :
                        appTheme === 'cyberpunk' ? (activeAppTab === tab.id ? "bg-yellow-400 text-black rounded-none shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-yellow-600 hover:text-yellow-400 hover:bg-yellow-400/10 rounded-none") :
                        appTheme === 'brutalism' ? (activeAppTab === tab.id ? "bg-black dark:bg-white text-white dark:text-black rounded-none" : "hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-none") :
                        (activeAppTab === tab.id ? "bg-black dark:bg-white text-white dark:text-black shadow-md scale-105 rounded-xl" : "hover:bg-black/5 dark:hover:bg-white/10 text-zinc-700 dark:text-zinc-200 font-semibold rounded-xl")
                      )
                    }`}
                 >
                    {!hasPrivateAccess && <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" />}
                    {(tab as any).isOwnerOnly && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    )}
                    <span>{tab.label}</span>
                 </button>
              ))}
            </div>

            {/* Access Badge & Owner Badge & Bot Status */}
            <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto flex-wrap">
              {/* Chief Owner Badge / Quick Login */}
              {isChiefOwner ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border-2 border-emerald-500/60 text-emerald-300 text-xs font-black shadow-sm">
                  <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Владелец: <span className="font-mono text-white font-bold">{CHIEF_OWNER_TG_ID}</span></span>
                  <button
                    onClick={() => {
                      revokeChiefOwner();
                      setIsChiefOwner(false);
                      if (activeAppTab === 'cloud') setActiveAppTab('unique_parser');
                    }}
                    className="ml-1 p-1 hover:bg-emerald-500/30 rounded-md text-emerald-200 hover:text-white transition-colors cursor-pointer"
                    title="Заблокировать режим владельца"
                  >
                    <Lock className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setOwnerLoginInput("");
                    setOwnerLoginError("");
                    setShowOwnerLoginModal(true);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 hover:text-white border-2 border-zinc-700 hover:border-amber-500/50 text-xs font-bold transition-all shadow-sm cursor-pointer"
                  title="Вход главного владельца (Telegram ID)"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Вход Главного</span>
                </button>
              )}

              {hasPrivateAccess ? (
                <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-600 dark:text-amber-400 text-xs font-semibold shadow-sm">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>{t("Circle", "Круг")}: <span className="font-mono text-zinc-800 dark:text-zinc-100">{privateAccessKey || "VIP"}</span></span>
                  <button
                    onClick={async () => {
                      try {
                        localStorage.removeItem("private_circle_auth");
                        localStorage.removeItem("private_circle_key");
                        document.cookie = "private_circle_auth=; path=/; max-age=0; SameSite=Lax";
                        document.cookie = "private_circle_key=; path=/; max-age=0; SameSite=Lax";
                        document.cookie = "private_circle_session=; path=/; max-age=0; SameSite=Lax";
                        await fetch("/api/auth/private-access/logout", { method: "POST" });
                      } catch (e) {}
                      setHasPrivateAccess(false);
                      setPrivateAccessKey("");
                    }}
                    className="ml-1 p-1 hover:bg-amber-500/20 rounded-md text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
                    title={t("Lock application & exit closed circle", "Заблокировать доступ / Сменить инвайт-код")}
                  >
                    <Lock className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-semibold">
                  <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span className="hidden sm:inline">{t("Closed Circle Access", "Закрытый круг доступа")}</span>
                </div>
              )}
              <BotStatusIndicator botName={botName} botStatus={botStatus} setIsBotInfoOpen={setIsBotInfoOpen} t={t} />
            </div>
          </div>
        </div>


        {/* Main Content Protected by Private Access Gate */}
        {!hasPrivateAccess ? (
          <div className="py-4 animate-in fade-in duration-300">
            <PrivateAccessGate 
              t={t} 
              onAccessGranted={(key) => {
                try {
                  localStorage.setItem("private_circle_auth", "true");
                  localStorage.setItem("private_circle_key", key);
                  document.cookie = `private_circle_auth=true; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
                  document.cookie = `private_circle_key=${encodeURIComponent(key)}; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
                } catch (e) {}
                setHasPrivateAccess(true);
                setPrivateAccessKey(key);
              }} 
            />
          </div>
        ) : (
          <>
            {activeAppTab === "creator" && (
              <div className="max-w-2xl mx-auto my-8">
                <div className="relative overflow-hidden bg-white/60 dark:bg-[#1c1c1e]/60 backdrop-blur-xl border border-zinc-200/50 dark:border-white/10 rounded-[2rem] shadow-xl p-8 sm:p-12 text-center animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"></div>
                  <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl pointer-events-none"></div>
                  
                  <div className="relative z-10 flex flex-col items-center">
                    <div className="w-16 h-16 mb-6 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/50 dark:border-white/10 flex items-center justify-center shadow-sm">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-zinc-700 dark:text-zinc-300">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                      </svg>
                    </div>
                    
                    <h2 className="text-2xl font-bold text-zinc-900 dark:text-zinc-50 mb-3 tracking-tight">
                      {t("Parser Creator", "Создатель парсера")}
                    </h2>
                    
                    <p className="text-base text-zinc-600 dark:text-zinc-400 mb-8 max-w-md">
                      {t("If you have ideas for improvement or found a bug, please contact me", "Если у вас есть идеи по улучшению или вы нашли ошибку, свяжитесь со мной")}
                    </p>

                    <a 
                      href="https://t.me/Tester_V3" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="group relative inline-flex items-center gap-3 bg-[#2AABEE] hover:bg-[#229ED9] text-white px-8 py-4 rounded-2xl font-semibold text-lg transition-all shadow-lg shadow-[#2AABEE]/25 hover:shadow-[#2AABEE]/40 hover:-translate-y-0.5 active:translate-y-0"
                    >
                      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 transition-transform group-hover:scale-110">
                        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.94z"/>
                      </svg>
                      <span>Написать @Tester_V3</span>
                    </a>
                  </div>
                </div>
              </div>
            )}
            {activeAppTab === "unique_parser" && (
              <UniqueParserTab 
                t={t} 
                hasOkRuSession={hasOkRuSession}
                okRuUserName={okRuUserName}
                onShowOkRuLogin={() => setShowOkRuLogin(true)}
                onDisconnectOkRu={async () => {
                  try {
                    await fetch('/api/okru/disconnect', { method: 'POST' });
                    setHasOkRuSession(false);
                    setOkRuUserName(null);
                    try { localStorage.removeItem('okru_cookies'); } catch (e) {}
                  } catch (e) {}
                }}
              />
            )}
            {activeAppTab === "search" && (
              <SearchTab
                onPlayTrack={handlePlayTrackGlobally}
                onSelectArtist={(id: string, prov?: string) => {
                  setCurrentArtistId(id != null ? String(id) : null);
                  setCurrentArtistProvider(prov || "");
                }}
                onSelectAlbum={(albumOrId: any) => {
                  handleOpenAlbumModal(albumOrId);
                }}
                onOpenSpotifySettings={() => setIsSpotifyModalOpen(true)}
                t={t}
              />
            )}
            {activeAppTab === "history" && <HistoryTab history={history} onClear={() => setHistory([])} onPlayTrack={handlePlayTrackGlobally} t={t} />}
            <div className={activeAppTab === "vibe" ? "block" : "hidden"}>
              <MyVibeTab
                onPlayTrack={handlePlayTrackGlobally}
                onSelectArtist={(idOrName: string) => {
                  if (idOrName) {
                    setCurrentArtistId(String(idOrName));
                    setCurrentArtistProvider("");
                  }
                }}
                onSelectAlbum={(albumOrId: any) => {
                  handleOpenAlbumModal(albumOrId);
                }}
                t={t}
                activeTrack={playbackSource === "vibe" ? activeTrack : null}
              />
            </div>
            {activeAppTab === "report" && <TgAuthGuard t={t}><ReportTab t={t} lang={lang} onTgLogsUpdate={setTgLogs} /></TgAuthGuard>}
            {activeAppTab === "logs" && <TgAuthGuard t={t}><LogsTab t={t} logs={tgLogs} /></TgAuthGuard>}
            {activeAppTab === "api" && <ApiTab t={t} onNavigateToLogs={() => setActiveAppTab("logs")} />}
            {activeAppTab === "prompts" && <PromptTab t={t} />}
            {activeAppTab === "back_catalog" && <BackCatalogTab t={t} />}
            {activeAppTab === "cloud" && (
              <SupabaseAndCloudHub 
                t={t} 
                onPlayTrack={handlePlayTrackGlobally} 
                onOwnerStatusChange={(status) => setIsChiefOwner(status)} 
              />
            )}
            {activeAppTab === "converter" && <ConverterTab t={t} />}
            {activeAppTab === "videoshot" && (
              <VideoShotTab 
                t={t} 
                initialTrack={studioInitialTrack} 
                onPlayTrack={handlePlayTrackGlobally} 
              />
            )}
          </>
        )}
        {false && (
          <>
              
              <div className="p-6 bg-zinc-50/50 dark:bg-black/10">
                <form onSubmit={handleFetchMetadata} className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://music.yandex.ru/album/..."
                    className={`flex-1 text-zinc-900 dark:text-white px-4 py-3 outline-none transition-all duration-300 ${
                      appTheme === 'minimalism' ? 'bg-transparent border-b-2 border-zinc-300 dark:border-zinc-700 focus:border-black dark:focus:border-white rounded-none' : 
                      appTheme === 'anime' ? 'bg-white/50 dark:bg-black/20 border-2 border-pink-200 dark:border-pink-800 focus:border-pink-400 dark:focus:border-pink-500 rounded-2xl shadow-inner' : 
                      appTheme === 'cyberpunk' ? 'bg-black/50 border border-yellow-400/50 focus:border-yellow-400 rounded-none text-yellow-400 placeholder-yellow-700' :
                      appTheme === 'brutalism' ? 'bg-white dark:bg-black border-4 border-black dark:border-white rounded-none focus:bg-yellow-100 dark:focus:bg-zinc-800' :
                      'bg-white dark:bg-[#1c1c1e] border border-zinc-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-emerald-500 shadow-sm'
                    }`}
                    value={metadataUrl}
                    onChange={(e) => setMetadataUrl(e.target.value)}
                    required
                  />
                  <button
                    type="submit"
                    disabled={isFetchingMetadata}
                    className={`px-6 py-3 font-bold transition-all duration-300 disabled:opacity-50 flex items-center gap-2 ${
                      appTheme === 'minimalism' ? 'bg-transparent text-black dark:text-white hover:opacity-70 rounded-none border-b-2 border-transparent hover:border-black dark:hover:border-white' : 
                      appTheme === 'anime' ? 'bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-2xl hover:shadow-[0_0_15px_rgba(236,72,153,0.5)] hover:scale-105' : 
                      appTheme === 'cyberpunk' ? 'bg-yellow-400 text-black rounded-none hover:bg-yellow-300 hover:shadow-[0_0_15px_rgba(250,204,21,0.8)]' :
                      appTheme === 'brutalism' ? 'bg-black dark:bg-white text-white dark:text-black border-4 border-transparent rounded-none hover:bg-white dark:hover:bg-black hover:text-black dark:hover:text-white hover:border-black dark:hover:border-white shadow-[4px_4px_0_0_rgba(0,0,0,1)] dark:shadow-[4px_4px_0_0_rgba(255,255,255,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1' :
                      'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl hover:bg-zinc-800 dark:hover:bg-zinc-100 shadow-sm'
                    }`}
                  >
                    {isFetchingMetadata ? <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"/> : <Search className="w-5 h-5" />}
                    <span className="hidden sm:inline">{t("Find", "Найти")}</span>
                  </button>
                </form>
                
                <div className="mt-4">
                  <button type="button" onClick={() => { setShowParserHelp(!showParserHelp); localStorage.setItem('parserHelpSeen', 'true'); }} className="text-sm text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 font-medium flex items-center gap-1 transition-colors">
                    <Info className="w-4 h-4" /> {t("How it works?", "Как это работает?")}
                  </button>
                  {showParserHelp && (
                    <div className="mt-4 bg-white dark:bg-zinc-900/80 p-6 rounded-2xl border border-blue-200 dark:border-blue-900/50 text-sm text-zinc-800 dark:text-zinc-200 animate-in fade-in slide-in-from-top-2 duration-300 shadow-lg">
                      <p className="text-xl font-black mb-4 text-blue-600 dark:text-blue-400 border-b border-blue-100 dark:border-blue-900/30 pb-2">{t("Complete Guide & Instructions", "Инструкция и Полное руководство")}</p>
                      
                      <div className="space-y-6">
                        {/* 1. Архитектура */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Layers className="w-5 h-5 text-indigo-500"/> 1. Что за что отвечает (Архитектура)</h4>
                          <p className="mb-2">Приложение состоит из 3 независимых блоков:</p>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Парсеры (Сбор данных):</strong> Ищут информацию (UPC, ISRC, обложки) по скрытым API Яндекса, Spotify, VK, Звука. Избавляют от ручного поиска.</li>
                            <li><strong>Отчёты (Процессинг):</strong> Ядро, которое читает Excel/CSV от дистрибьюторов, вычитает процент лейбла и генерирует красивые PDF-акты.</li>
                            <li><strong>Логи и Рассылка (Telegram):</strong> Берет PDF-отчеты и массово рассылает артистам в личку через ваш Telegram-бот по Chat ID.</li>
                          </ul>
                        </section>

                        {/* 2. Вкладки */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Settings className="w-5 h-5 text-emerald-500"/> 2. По всем вкладкам и функциям</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Поиск (Плеер) и Моя Волна:</strong> Встроенный музыкальный стриминг. Вы можете искать треки и слушать бесконечное радио по рекомендациям нейросети Яндекса, не покидая рабочую панель.</li>
                            <li><strong>Отчёты (Генератор PDF):</strong> Превращает скучные таблицы выплат в дизайнерские PDF документы с логотипом вашего лейбла. Распределяет доходы по каждому артисту.</li>
                            <li><strong>Журнал (Telegram Логи):</strong> Отслеживает отправку отчетов. Если артист заблокировал бота, вы увидите ошибку 400. Если Telegram тормозит из-за спама, будет ошибка 429 (программа сама подождет и отправит заново).</li>
                          </ul>
                        </section>

                        {/* 3. Коды */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Code className="w-5 h-5 text-purple-500"/> 3. Коды UPC и ISRC: Что это и зачем?</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>UPC (Штрих-код релиза):</strong> 12-13 цифр. Регистрирует весь альбом/сингл как единый товар в цифровом магазине. По нему идут общие отчеты о продажах релиза.</li>
                            <li><strong>ISRC (Паспорт трека):</strong> Выдается навсегда (например, RU-A1B-23-00001). <strong>Критически важен</strong>, потому что именно по ISRC стриминги платят вам роялти (деньги). Если этот трек попадет в другой сборник, прослушивания все равно придут вам в кошелек благодаря ISRC.</li>
                          </ul>
                        </section>

                        {/* 4. API и Токены */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Key className="w-5 h-5 text-amber-500"/> 4. API, Токены, JSON и Cookie</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Что такое API:</strong> Это "официант". Наша программа дает заказ ("Найди трек"), API несет его на кухню сервера Spotify и приносит нам данные.</li>
                            <li><strong>Что такое Токен (API Key):</strong> Ваш VIP-пропуск на эту кухню. Например, <code>Bot Token</code> доказывает серверам Telegram, что именно ВЫ владеете ботом и можете рассылать сообщения.</li>
                            <li><strong>Зачем нужны Cookie и ручной ввод JSON:</strong> VK и Одноклассники защищены от ботов. Вставляя свой Cookie (слепок сессии), наша программа "надевает маску" вашего браузера и легально собирает данные. А JSON (ответ сервера) мы просим вставить вручную, если сервер выдает капчу, которую может пройти только человек.</li>
                          </ul>
                        </section>
                      </div>
                    </div>
                  )}
                </div>
              </div>

            {metadataResult && metadataResult.type === "artist" ? (
<div className="flex flex-col gap-8 bg-zinc-50/50 dark:bg-black/20 p-6 md:p-8">
                  {/* Artist Header */}
                  <div className="relative rounded-3xl overflow-hidden bg-zinc-900 aspect-[3/1] md:aspect-[4/1] flex items-end p-6 md:p-8 border border-zinc-200/50 dark:border-white/10 shadow-sm">
                    <div className="absolute inset-0 z-0">
                      {metadataResult.coverUri ? (
                        <>
                          <ProxyImage src={metadataResult.coverUri} className="w-full h-full object-cover opacity-60 blur-3xl scale-110" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
                        </>
                      ) : (
                        <div className="w-full h-full bg-zinc-800" />
                      )}
                    </div>
                    
                    <div className="relative z-10 flex items-center gap-6">
                      {metadataResult.coverUri ? (
                        <ProxyImage src={metadataResult.coverUri} className="w-24 h-24 md:w-40 md:h-40 rounded-full shadow-2xl object-cover border-4 border-black/20 bg-zinc-800 shrink-0" />
                      ) : (
                         <div className="w-24 h-24 md:w-40 md:h-40 rounded-full shadow-2xl bg-zinc-800 border-4 border-black/20 shrink-0 flex items-center justify-center">
                            <Mic2 className="w-8 h-8 text-zinc-500" />
                         </div>
                      )}
                      <div className="flex flex-col gap-1 md:gap-2">
                        <h1 className="text-3xl md:text-5xl font-bold text-white tracking-tight leading-tight">{metadataResult.title}</h1>
                        <p className="text-zinc-300 text-xs md:text-sm font-medium uppercase tracking-wider">{t("Artist", "Исполнитель")}</p>
                        {metadataResult.stats?.lastMonthListeners && (
                          <div className="flex flex-col gap-1.5 mt-1">
                            {/* Toggle between 1. Слушатели / 2. Прослушивания */}
                            <div className="inline-flex items-center p-0.5 bg-black/40 rounded-full border border-white/10 w-fit">
                              <button
                                type="button"
                                onClick={() => setMetadataArtistStatsMode("listeners")}
                                className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                                  metadataArtistStatsMode === "listeners"
                                    ? "bg-emerald-500 text-white shadow-sm"
                                    : "text-zinc-400 hover:text-white"
                                }`}
                              >
                                1. {t("Listeners", "Слушатели")}
                              </button>
                              <button
                                type="button"
                                onClick={() => setMetadataArtistStatsMode("streams")}
                                className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                                  metadataArtistStatsMode === "streams"
                                    ? "bg-purple-600 text-white shadow-sm"
                                    : "text-zinc-400 hover:text-white"
                                }`}
                              >
                                2. {t("Streams", "Прослушивания")}
                              </button>
                            </div>

                            {metadataArtistStatsMode === "listeners" ? (
                              <p className="text-zinc-300 text-xs md:text-sm font-medium flex items-center gap-1.5">
                                <span className="font-mono text-emerald-400 font-bold">{metadataResult.stats.lastMonthListeners.toLocaleString("ru-RU")}</span>
                                <span>{t("monthly listeners", "слушателей за месяц")}</span>
                              </p>
                            ) : (
                              <div className="flex flex-col gap-0.5">
                                <p className="text-zinc-300 text-xs md:text-sm font-medium flex items-center gap-1.5">
                                  <span className="font-mono text-purple-400 font-bold">
                                    {(metadataResult.stats.monthlyStreams || Math.round(metadataResult.stats.lastMonthListeners * (metadataResult.stats.streamsPerListener || 5.8))).toLocaleString("ru-RU")}
                                  </span>
                                  <span>{t("plays of artist", "прослушиваний артиста")}</span>
                                </p>
                                <p className="text-[11px] text-zinc-400 font-mono">
                                  {metadataResult.stats.lastMonthListeners.toLocaleString("ru-RU")} × ~{metadataResult.stats.streamsPerListener || 5.8} = {((metadataResult.stats.monthlyStreams || Math.round(metadataResult.stats.lastMonthListeners * (metadataResult.stats.streamsPerListener || 5.8)))).toLocaleString("ru-RU")} {t("streams", "прослушиваний")}
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Content Grid */}
                  <div className="flex flex-col xl:flex-row gap-8">
                    
                    {/* Popular Tracks */}
                    <div className="flex-1 flex flex-col gap-4">
                      <h2 className="text-2xl font-bold text-zinc-900 dark:text-white px-2">{t("Popular Tracks", "Популярные треки")}</h2>
                      <div className="flex flex-col gap-2">
                        {metadataResult.popularTracks?.map((track: any, idx: number) => (
                          <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between bg-white dark:bg-[#1c1c1e] p-3 rounded-2xl shadow-sm border border-zinc-200/50 dark:border-white/10 w-full flex-1 gap-4">
                            <div className="flex items-center gap-4 min-w-0">
                              <div className="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center shrink-0 overflow-hidden">
                                {track.coverUri ? (
                                    <ProxyImage src={track.coverUri} className="w-full h-full object-cover" />
                                ) : (
                                    <Music className="w-5 h-5 text-zinc-600 dark:text-zinc-400" />
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-50 truncate" title={track.title}>
                                  {track.title}
                                </p>
                                <p
                                  className="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate"
                                  title={t("Full track download requires Yandex Plus", "Для скачивания полного трека нужен Яндекс Плюс")}
                                >
                                  WAV 44.1kHz{" "}
                                  <span className="text-orange-500 lowercase normal-case">{t("(If 30 sec - Plus needed)", "(Если 30 сек — нужен Плюс)")}</span>
                                  {track.durationMs ? ` • ${Math.floor(track.durationMs / 60000)}:${String(Math.floor((track.durationMs % 60000) / 1000)).padStart(2, '0')}` : (track.duration ? ` • ${Math.floor(track.duration / 60)}:${String(Math.floor(track.duration % 60)).padStart(2, '0')}` : '')}
                                </p>
                                {track.upc && (
                                  <p className="text-[10px] text-zinc-400 dark:text-zinc-500 uppercase tracking-wider font-semibold truncate mt-0.5">
                                    UPC: {track.upc} {track.isrc ? ` | ISRC: ${track.isrc}` : ''}
                                  </p>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto overflow-x-auto pb-1">
                              
                              
                              <button
                                onClick={() => handlePlayTrackGlobally(track, metadataResult.popularTracks || [track])} className="bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-zinc-900 dark:text-white px-4 py-2 rounded-xl text-sm font-semibold transition-colors flex items-center gap-2 shrink-0"><Play className="w-4 h-4" /><span className="hidden sm:inline">{t("Play", "Играть")}</span></button><button onClick={(e) => downloadAudio(e, track.id, track.title, track.artists || metadataResult.title, track.upc, track.isrc, track.coverUri)}
                                disabled={bulkProgress !== null || downloadingTrackId === track.id}
                                className="bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-zinc-900 dark:text-white px-4 py-2 rounded-xl text-sm font-semibold transition-colors flex items-center gap-2 shrink-0 disabled:opacity-50"
                              >
                                {downloadingTrackId === track.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
                                ) : (
                                  <Download className="w-4 h-4" />
                                )}
                                <span className="hidden sm:inline">{downloadingTrackId === track.id ? t("Saving...", "Скачивание...") : t("Download", "Скачать")}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Albums */}
                    {metadataResult.albums && metadataResult.albums.length > 0 && (
                        <div className="w-full xl:w-[400px] shrink-0 flex flex-col gap-4">
                          <h2 className="text-2xl font-bold text-zinc-900 dark:text-white px-2">{t("Releases", "Релизы")}</h2>
                          <div className="grid grid-cols-2 gap-4">
                            {metadataResult.albums?.map((album: any, idx: number) => (
                              <div key={idx} onClick={() => {
                                  setMetadataUrl(`https://music.yandex.ru/album/${album.id}`);
                                  handleFetchMetadata(undefined, `https://music.yandex.ru/album/${album.id}`);
                                  const el = document.getElementById("metadata-input-section");
                                  if (el) el.scrollIntoView({ behavior: "smooth" });
                                }} className="flex flex-col gap-3 group cursor-pointer">
                                <div className="relative aspect-square rounded-2xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shadow-sm border border-zinc-200/50 dark:border-white/10">
                                   {album.coverUri ? (
                                      <ProxyImage src={album.coverUri} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                   ) : (
                                      <div className="w-full h-full flex items-center justify-center"><Music className="w-8 h-8 text-zinc-400" /></div>
                                   )}
                                   <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                                </div>
                                <div className="flex flex-col">
                                   <span className="text-sm font-semibold text-zinc-900 dark:text-zinc-50 truncate">{album.title}</span>
                                   <span className="text-xs font-medium text-zinc-500 dark:text-zinc-400">{album.year}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                    )}
                  </div>
                </div>
) : metadataResult ? (
                <div className="p-6 bg-zinc-50/50 dark:bg-black/20">
                  {/* Result Tabs */}
                  <div className="flex items-center gap-2 mb-6 border-b border-zinc-200 dark:border-white/10 pb-4">
                     <button onClick={() => setActiveResultTab("overview")} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${activeResultTab === "overview" ? "bg-black dark:bg-white text-white dark:text-black" : "hover:bg-zinc-100 dark:hover:bg-white/10 text-zinc-600 dark:text-zinc-400"}`}>{t("Overview", "Обзор")}</button>
                     <button onClick={() => setActiveResultTab("platforms")} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${activeResultTab === "platforms" ? "bg-black dark:bg-white text-white dark:text-black" : "hover:bg-zinc-100 dark:hover:bg-white/10 text-zinc-600 dark:text-zinc-400"}`}>{t("Platforms", "Площадки")}</button>
                  </div>
                  {activeResultTab === "overview" && (
                    <div className="flex flex-col md:flex-row gap-6 items-start">
                    {/* Cover Section */}
                    <div
                      className="shrink-0 w-32 md:w-48 relative group rounded-2xl overflow-hidden shadow-sm bg-zinc-200 dark:bg-zinc-700 cursor-pointer"
                      onClick={downloadCover}
                      title={t("Download (3000x3000)", "Скачать (3000x3000)")}
                    >
                      {metadataResult.coverUri ? (
                        <ProxyImage
                          src={metadataResult.coverUri || undefined}
                          className="w-32 h-32 md:w-48 md:h-48 object-cover"
                        />
                      ) : (
                        <div className="w-32 h-32 md:w-48 md:h-48 flex items-center justify-center">
                          <span className="text-zinc-400 dark:text-zinc-500 text-sm">{t("No Cover", "Нет обложки")}</span>
                        </div>
                      )}
                      {/* Hover Overlay */}
                      <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center opacity-0 hover:opacity-100 transition-opacity gap-2">
                        <Download className="w-8 h-8 text-white/90" />
                        <span className="text-white dark:text-zinc-900 text-xs font-bold bg-black/50 px-2 py-1 rounded">{t("Download HQ", "Скачать HQ")}</span>
                      </div>
                    </div>

                    <div className="flex-1 space-y-4 w-full">
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">
                          {metadataResult.type === "track" ? (metadataResult.isSpotify ? "Spotify Track" : metadataResult.isOkRu ? "OK.ru Track" : t("Track Title", "Название трека")) : (metadataResult.type === "artist" ? t("Artist", "Артист") : t("Album Title", "Название альбома"))}
                          {metadataResult.originalUrl && (
                             <a href={metadataResult.originalUrl} target="_blank" rel="noreferrer" className="ml-2 text-zinc-500 hover:text-black dark:hover:text-white transition-colors" title={t("Open original link", "Открыть оригинальную ссылку")}>
                                <ExternalLink className="w-4 h-4 inline-block mb-0.5" />
                             </a>
                          )}
                          {metadataResult.releaseType &&
                            ` • ${metadataResult.releaseType}`}
                        </span>
                        <div className="flex items-center gap-2 group/copy">
                          <h4 className="font-bold text-xl tracking-tight text-zinc-900 dark:text-zinc-50">
                            {metadataResult.title}
                          </h4>
                          <button
                            onClick={(e) =>
                              handleCopyText(metadataResult.title, e)
                            }
                            className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm"
                            title={t("Copy", "Скопировать")}
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Artist", "Исполнитель")}</span>
                          <div className="flex items-center gap-2 group/copy">
                            <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                              {metadataResult.artists}
                            </p>
                            <button
                              onClick={(e) =>
                                handleCopyText(metadataResult.artists, e)
                              }
                              className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                              title={t("Copy", "Скопировать")}
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                                                                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 flex items-center gap-1"><Search className="w-3 h-3"/> {t("Distributor Finder", "Дистрибьютор (Distributor Finder)")}</span>
                          <div className="flex items-center gap-2 group/copy">
                            <p className="text-zinc-700 dark:text-zinc-300 font-medium text-indigo-600 dark:text-indigo-400">
                              {findDistributor(metadataResult.label, metadataResult.copyright) || t("Not found / Custom", "Не найден / Свой")}
                            </p>
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Label", "Лейбл")}</span>
                          <div className="flex items-center gap-2 group/copy">
                            <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                              {metadataResult.label || t("Not found", "Не найден")}
                            </p>
                            {metadataResult.label && (
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.label, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("UPC / Barcode (Bypass)", "UPC / Barcode (В обход)")}</span>
                          <div className="flex items-center gap-2 group/copy">
                            <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                              {metadataResult.upc || t("Not found", "Не найден")}
                            </p>
                            {metadataResult.upc && (
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.upc, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("ISRC (Bypass)", "ISRC (В обход)")}</span>
                          {(metadataResult.type === "album" || metadataResult.type === "artist") &&
                          metadataResult.tracks &&
                          metadataResult.tracks.length > 0 ? (
                            <div className="flex flex-col gap-1 max-h-40 overflow-y-auto pr-2">
                              {metadataResult.tracks && metadataResult.tracks.map((track: any, idx: number) => (
                                  <div
                                    key={idx}
                                    className="flex items-center justify-between gap-2 border-b border-zinc-100 dark:border-white/5 last:border-0 pb-1 last:pb-0"
                                  >
                                    <div className="flex flex-col min-w-0">
                                      <span className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                                        {track.title}
                                      </span>
                                      <span className="text-zinc-700 dark:text-zinc-300 font-medium text-sm">
                                        {track.isrc || t("Not found", "Не найден")}
                                      </span>
                                    </div>
                                    {track.isrc && (
                                      <button
                                        onClick={(e) =>
                                          handleCopyText(track.isrc, e)
                                        }
                                        className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm"
                                        title={t("Copy ISRC", "Скопировать ISRC")}
                                      >
                                        <Copy className="w-3 h-3" />
                                      </button>
                                    )}
                                  </div>
                                ),
                              )}
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.isrc || t("Not found", "Не найден")}
                              </p>
                              {metadataResult.isrc && (
                                <button
                                  onClick={(e) =>
                                    handleCopyText(metadataResult.isrc, e)
                                  }
                                  className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm"
                                  title={t("Copy", "Скопировать")}
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Release Date", "Дата релиза")}</span>
                          <div className="flex items-center gap-2 group/copy">
                            <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                              {metadataResult.releaseDate || "Not found"}
                            </p>
                            {metadataResult.releaseDate && (
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.releaseDate, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {metadataResult.performer && (
                          <div>
                            <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Performer / Pseudonym", "Исполнитель (Псевдоним)")}</span>
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.performer}
                              </p>
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.performer, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}

                        {metadataResult.phonogramSource && (
                          <div>
                            <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Phonogram Source", "Источник фонограммы")}</span>
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.phonogramSource}
                              </p>
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.phonogramSource, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}

                        {metadataResult.hiddenLabel && (
                          <div className="col-span-1 sm:col-span-2">
                            <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Hidden Label / Publisher", "Скрытый лейбл / Издатель")}</span>
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.hiddenLabel}
                              </p>
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.hiddenLabel, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}

                        {metadataResult.authorsMusic && (
                          <div className="col-span-1 sm:col-span-2">
                            <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Music", "Музыка")}</span>
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.authorsMusic}
                              </p>
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.authorsMusic, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}

                        {metadataResult.authorsText && (
                          <div className="col-span-1 sm:col-span-2">
                            <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">{t("Lyrics", "Слова")}</span>
                            <div className="flex items-center gap-2 group/copy">
                              <p className="text-zinc-700 dark:text-zinc-300 font-medium">
                                {metadataResult.authorsText}
                              </p>
                              <button
                                onClick={(e) =>
                                  handleCopyText(metadataResult.authorsText, e)
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}

                        <div className="col-span-1 sm:col-span-2">
                          <span className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider mb-1 block">
                            Copyright
                          </span>
                          <div className="flex items-start gap-2 group/copy">
                            <p
                              className="text-zinc-700 dark:text-zinc-300 font-medium whitespace-pre-wrap"
                              dangerouslySetInnerHTML={{
                                __html: metadataResult.copyright || "",
                              }}
                            ></p>
                            {metadataResult.copyright && (
                              <button
                                onClick={(e) =>
                                  handleCopyText(
                                    metadataResult.copyright.replace(
                                      /<[^>]*>?/gm,
                                      "",
                                    ),
                                    e,
                                  )
                                }
                                className="p-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 rounded-md transition-colors text-zinc-600 dark:text-zinc-400 shrink-0 shadow-sm shrink-0 mt-0.5"
                                title={t("Copy", "Скопировать")}
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  )}
                  {activeResultTab === "platforms" && (
                    <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                      <div className="flex flex-col lg:flex-row gap-6 items-start w-full">
                      {/* Left Column: SmartLink Visual Settings & Preview */}
                      <div className="w-full lg:w-1/3 shrink-0 flex flex-col gap-6">
                         {/* Settings */}
                         <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm">
                           <h4 className="font-bold text-zinc-900 dark:text-zinc-50 mb-4">{t("SmartLink Settings", "Настройки SmartLink")}</h4>
                           <div className="space-y-4">
                             <div>
                               <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">{t("Label Name", "Название лейбла")}</label>
                               <input type="text" value={smartLinkLabel} onChange={e => setSmartLinkLabel(e.target.value)} placeholder="moonmuz+" className="w-full px-4 py-2 rounded-xl bg-zinc-50 dark:bg-black/50 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white text-sm outline-none focus:ring-2 focus:ring-blue-500" />
                             </div>
                             <div>
                               <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">{t("Label Logo (PNG)", "Логотип (PNG без фона)")}</label>
                               <input type="file" accept="image/png" onChange={(e) => {
                                 const file = e.target.files?.[0];
                                 if (file) {
                                   const reader = new FileReader();
                                   reader.onload = (ev) => setSmartLinkLabelLogo((ev.target?.result as string) || "");
                                   reader.readAsDataURL(file);
                                 }
                               }} className="w-full text-sm text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-blue-900/30 dark:file:text-blue-400 cursor-pointer" />
                             </div>
                           </div>
                         </div>
                         
                         {/* Phone Preview */}
                         <div className="relative w-full max-w-[320px] mx-auto rounded-[2.5rem] bg-black border-[8px] border-zinc-800 dark:border-zinc-700 overflow-hidden shadow-2xl aspect-[9/19] flex flex-col items-center ring-1 ring-white/10">
                           {metadataResult.coverUri && (
                             <>
                               <ProxyImage src={metadataResult.coverUri} className="absolute inset-0 w-full h-full object-cover opacity-40 blur-[20px] scale-110" alt="" />
                               <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
                             </>
                           )}
                           
                           <div className="relative z-10 w-full p-6 pt-12 flex flex-col items-center h-full overflow-y-auto pb-12 [&::-webkit-scrollbar]:hidden">
                              {metadataResult.coverUri ? (
                                <ProxyImage src={metadataResult.coverUri} className="w-40 h-40 rounded-2xl shadow-[0_0_30px_rgba(255,255,255,0.15)] mb-6 object-cover border border-white/20" alt="Cover" />
                              ) : (
                                <div className="w-40 h-40 rounded-2xl bg-zinc-800 mb-6 shadow-xl" />
                              )}
                              <h2 className="text-2xl font-black text-white tracking-tight text-center leading-tight mb-1 drop-shadow-md">{metadataResult.title}</h2>
                              <p className="text-zinc-300 font-medium text-sm text-center mb-5 drop-shadow">{metadataResult.artist || t("Artist", "Артист")}</p>
                              
                              {smartLinkLabelLogo && (
                                 <img src={smartLinkLabelLogo} className="h-6 max-w-[120px] object-contain mb-6 filter drop-shadow-lg" alt={smartLinkLabel || "Label"} />
                              )}
                              
                              <div className="w-full flex flex-col gap-3 mt-2">
                                {metadataResult.links && Object.entries(metadataResult.links).map(([platform, link]: [string, any]) => {
                                   let hostname = "";
                                   try { hostname = new URL((link as any).url).hostname; } catch (e) {}
                                   return (
                                     <a key={platform} href={(link as any).url} target="_blank" rel="noreferrer" className="flex items-center justify-between w-full p-3.5 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-2xl transition-all border border-white/10 group">
                                        <div className="flex items-center gap-3">
                                          <PlatformBrandIcon platformId={platform} domain={hostname} name={platform} size="md" />
                                          <span className="text-white text-[15px] font-semibold capitalize tracking-wide">{platform.replace(/([A-Z])/g, ' $1').trim()}</span>
                                        </div>
                                        <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity bg-black/20 px-2 py-1 rounded-full">
                                          <span className="text-[10px] font-bold text-white uppercase tracking-wider">{t("Listen", "Слушать")}</span>
                                          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                        </div>
                                     </a>
                                   )
                                })}
                              </div>
                              <p className="mt-8 text-[10px] text-white/40 uppercase tracking-widest">{t("Available on all platforms", "Доступно на всех платформах")}</p>
                           </div>
                         </div>
                         
                         <button
                           onClick={(e) => {
                              const btn = e.currentTarget;
                              const originalText = btn.innerHTML;
                              const slData = {
                                title: metadataResult.title,
                                artist: metadataResult.artist || metadataResult.artists,
                                cover: metadataResult.coverUri,
                                label: smartLinkLabel,
                                logo: smartLinkLabelLogo,
                                links: metadataResult.links
                              };
                              const slParam = btoa(encodeURIComponent(JSON.stringify(slData)));
                              const shareableLink = `${window.location.origin}/?sl=${slParam}`;
                              navigator.clipboard.writeText(shareableLink);
                              btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><polyline points="20 6 9 17 4 12"></polyline></svg> ${t("Link Copied!", "Ссылка скопирована!")}`;
                              setTimeout(() => { btn.innerHTML = originalText; }, 2000);
                           }}
                           className="w-full py-4 mt-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold shadow-lg transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
                         >
                           <ExternalLink className="w-5 h-5" />
                           {t("Copy Link", "Скопировать ссылку")}
                         </button>
                         <button
                           onClick={() => {
                              const slData = {
                                title: metadataResult.title,
                                artist: metadataResult.artist || metadataResult.artists,
                                cover: metadataResult.coverUri,
                                label: smartLinkLabel,
                                logo: smartLinkLabelLogo,
                                links: metadataResult.links
                              };
                              
                              const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${slData.title} - ${slData.artist}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { background-color: #000; color: #fff; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; overflow-y: auto; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    .bg-blur { position: fixed; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0.4; filter: blur(50px); transform: scale(1.1); z-index: 0; }
    .overlay { position: fixed; inset: 0; background: linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,0.8) 50%, transparent 100%); z-index: 0; }
    .content { position: relative; z-index: 10; width: 100%; max-w: 400px; display: flex; flex-direction: column; align-items: center; padding: 2rem; box-sizing: border-box; margin: auto; }
    .cover { width: 256px; height: 256px; border-radius: 2rem; box-shadow: 0 0 60px rgba(255,255,255,0.15); margin-bottom: 2rem; object-fit: cover; border: 1px solid rgba(255,255,255,0.2); }
    .title { font-size: 1.875rem; font-weight: 900; text-align: center; line-height: 1.2; margin-bottom: 0.5rem; text-shadow: 0 4px 6px rgba(0,0,0,0.5); }
    .artist { color: #d4d4d8; font-weight: 500; font-size: 1.125rem; text-align: center; margin-bottom: 2.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
    .logo { height: 40px; max-width: 180px; object-fit: contain; margin-bottom: 2.5rem; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.5)); }
    .links-container { width: 100%; display: flex; flex-direction: column; gap: 1rem; max-width: 400px; }
    .link-card { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 1rem; background: rgba(255,255,255,0.1); backdrop-filter: blur(16px); border-radius: 1rem; text-decoration: none; border: 1px solid rgba(255,255,255,0.1); transition: all 0.2s; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); }
    .link-card:hover { background: rgba(255,255,255,0.2); transform: translateY(-2px); }
    .platform-info { display: flex; align-items: center; gap: 1rem; }
    .platform-icon { width: 32px; height: 32px; border-radius: 50%; object-fit: contain; background: #fff; padding: 2px; }
    .platform-name { color: #fff; font-size: 1.0625rem; font-weight: 700; text-transform: capitalize; }
    .listen-btn { display: flex; align-items: center; gap: 6px; background: rgba(0,0,0,0.4); padding: 6px 12px; border-radius: 9999px; }
    .listen-text { font-size: 11px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.05em; }
    .icon-chevron { width: 14px; height: 14px; color: #fff; }
  </style>
</head>
<body>
  ${slData.cover ? `<img src="${slData.cover}" class="bg-blur" alt="" />` : ''}
  <div class="overlay"></div>
  
  <div class="content">
      ${slData.cover ? `<img src="${slData.cover}" class="cover" alt="Cover" />` : `<div class="cover" style="background:#27272a;"></div>`}
      <h2 class="title">${slData.title}</h2>
      <p class="artist">${slData.artist || 'Artist'}</p>
      
      ${slData.logo ? `<img src="${slData.logo}" class="logo" alt="${slData.label || 'Label'}" />` : ''}
      
      <div class="links-container">
        ${slData.links ? Object.entries(slData.links).map(([platform, link]: [string, any]) => {
           let hostname = "";
           try { hostname = new URL((link as any).url).hostname; } catch(e) {}
           return `<a href="${(link as any).url}" target="_blank" rel="noreferrer" class="link-card">
              <div class="platform-info">
                ${hostname ? `<img src="https://www.google.com/s2/favicons?domain=${hostname}&sz=64" class="platform-icon" alt="" />` : `<div class="platform-icon" style="background:rgba(255,255,255,0.2)"></div>`}
                <span class="platform-name">${platform.replace(/([A-Z])/g, ' $1').trim()}</span>
              </div>
              <div class="listen-btn">
                <span class="listen-text">Слушать</span>
                <svg class="icon-chevron" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
              </div>
           </a>`;
        }).join('') : ''}
      </div>
  </div>
</body>
</html>`;
                              
                              const blob = new Blob([htmlContent], { type: "text/html" });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement("a");
                              a.href = url;
                              a.download = `${slData.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_smartlink.html`;
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                              URL.revokeObjectURL(url);
                           }}
                           className="w-full py-4 mt-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-2xl font-bold shadow-lg transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
                         >
                           <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                           {t("Download Standalone HTML", "Скачать HTML файл")}
                         </button>
                      </div>
                      
                      {/* Right Column: Platform Links & Distribution Checker */}
                      <div className="flex-1 flex flex-col gap-6">
                        {metadataResult.links && Object.keys(metadataResult.links).length > 0 ? (
                         <>
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold text-zinc-900 dark:text-zinc-50">{t("Available Platforms", "Доступные площадки")}</h3>
                            <button
                              onClick={(e) => {
                                const btn = e.currentTarget;
                                const originalText = btn.innerHTML;
                                const linksText = Object.entries(metadataResult.links).map(([platform, link]: [string, any]) => `${platform.replace(/([A-Z])/g, ' $1').trim()}: ${(link as any).url}`)
                                  .join('\n');
                                const smartLink = `${metadataResult.title}\n\n${t("Listen on:", "Слушать на:")}\n${linksText}`;
                                navigator.clipboard.writeText(smartLink);
                                btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" class="w-4 h-4"><polyline points="20 6 9 17 4 12"></polyline></svg> ${t("Copied!", "Скопировано!")}`;
                                setTimeout(() => {
                                  btn.innerHTML = originalText;
                                }, 2000);
                              }}
                              className="px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl text-sm font-semibold hover:bg-zinc-800 dark:hover:bg-zinc-100 transition-all flex items-center gap-2 shadow-sm"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                              {t("Copy SmartLink", "Скопировать SmartLink")}
                            </button>
                         </div>
                         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                            {Object.entries(metadataResult.links).map(([platform, link]: any) => {
                               let hostname = "";
                               try {
                                   hostname = new URL((link as any).url).hostname;
                               } catch (e) {}
                               
                               return (
                               <a key={platform} href={(link as any).url} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 bg-white dark:bg-[#1c1c1e] rounded-2xl border border-zinc-200/50 dark:border-white/10 hover:border-zinc-300 dark:hover:border-white/20 transition-all shadow-sm hover:shadow-md group">
                                  <div className="w-12 h-12 shrink-0 bg-zinc-100 dark:bg-zinc-800/50 rounded-xl flex items-center justify-center overflow-hidden">
                                  <PlatformBrandIcon platformId={platform} domain={hostname} name={platform} size="xl" />
                                  </div>
                                  <div className="flex flex-col min-w-0">
                                      <span className="text-base font-bold text-zinc-900 dark:text-white capitalize truncate mb-0.5">{platform.replace(/([A-Z])/g, ' $1').trim()}</span>
                                      <span className="text-xs text-zinc-500 dark:text-zinc-400 truncate group-hover:text-zinc-800 dark:group-hover:text-zinc-200 transition-colors">{(link as any).url}</span>
                                  </div>
                               </a>
                               );
                            })}
                         </div>
                         </>
                      ) : (
                         <div className="flex items-center justify-center p-8 bg-white dark:bg-[#1c1c1e] rounded-2xl border border-zinc-200/50 dark:border-white/10">
                            <span className="text-zinc-500 dark:text-zinc-400 font-medium">{t("No platform links found.", "Ссылки на площадки не найдены.")}</span>
                         </div>
                      )}

                      {/* Checklist Section */}
                      <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-3">
                          <h4 className="text-sm font-semibold text-zinc-900 dark:text-zinc-50">{t("Distribution Checker", "Distribution Checker (Проверка площадок)")}</h4>
                          <div className="flex items-center gap-2 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl">
                            <button onClick={() => setPlatformFilter("all")} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${platformFilter === "all" ? "bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"}`}>{t("All", "Все")}</button>
                            <button onClick={() => setPlatformFilter("ru")} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${platformFilter === "ru" ? "bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"}`}>{t("RU", "СНГ")}</button>
                            <button onClick={() => setPlatformFilter("west")} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${platformFilter === "west" ? "bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"}`}>{t("Western", "Западные")}</button>
                            <button onClick={() => { setPlatformFilter("custom"); setShowPlatformSettings(!showPlatformSettings); }} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${platformFilter === "custom" ? "bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"}`}>
                               <Settings className="w-4 h-4 inline-block" />
                            </button>
                          </div>
                        </div>
                        
                        {platformFilter === "custom" && showPlatformSettings && (
                          <div className="p-4 bg-zinc-50 dark:bg-black/20 rounded-xl border border-zinc-200 dark:border-white/10 mb-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {[
                              { id: "yandex", name: "Yandex Music" }, { id: "vk", name: "VK Music" }, { id: "zvuk", name: "Zvuk" }, { id: "okru", name: "OK.ru Music" }, { id: "mts", name: "MTS Music" },
                              { id: "spotify", name: "Spotify" }, { id: "apple", name: "Apple Music" }, { id: "youtube", name: "YouTube" }, { id: "youtubemusic", name: "YouTube Music" }, { id: "tiktok", name: "TikTok" },
                              { id: "soundcloud", name: "SoundCloud" }, { id: "deezer", name: "Deezer" }, { id: "tidal", name: "Tidal" }, { id: "amazon", name: "Amazon Music" }, { id: "shazam", name: "Shazam" },
                              { id: "pandora", name: "Pandora" }, { id: "qobuz", name: "Qobuz" }, { id: "napster", name: "Napster" }, { id: "boomplay", name: "Boomplay" }, { id: "audiomack", name: "Audiomack" }, { id: "anghami", name: "Anghami" }
                            ].map(p => (
                               <label key={p.id} className="flex items-center gap-2 cursor-pointer group">
                                 <input 
                                   type="checkbox" 
                                   className="rounded border-zinc-300 dark:border-zinc-700 text-indigo-500 focus:ring-indigo-500 bg-white dark:bg-zinc-900"
                                   checked={enabledPlatforms.includes(p.id)}
                                   onChange={(e) => {
                                      if (e.target.checked) {
                                          setEnabledPlatforms([...enabledPlatforms, p.id]);
                                      } else {
                                          setEnabledPlatforms(enabledPlatforms.filter(id => id !== p.id));
                                      }
                                   }}
                                 />
                                 <span className="text-sm text-zinc-700 dark:text-zinc-300 group-hover:text-zinc-900 dark:group-hover:text-white transition-colors truncate">{p.name}</span>
                               </label>
                            ))}
                          </div>
                        )}
                        <div className="flex flex-col gap-3">
                          {[
                            // Russian platforms
                            { id: "yandex", name: "Yandex Music", check: (links: any) => !!links?.yandex, domain: "music.yandex.ru", region: "ru" },
                            { id: "vk", name: "VK Music", check: (links: any) => !!links?.vk, domain: "vk.com", region: "ru" },
                            { id: "zvuk", name: "Zvuk", check: (links: any) => !!links?.zvuk || !!links?.sber, domain: "zvuk.com", region: "ru" },
                            { id: "okru", name: "OK.ru Music", check: (links: any) => !!links?.okru, domain: "ok.ru", region: "ru" },
                            { id: "mts", name: "MTS Music", check: (links: any) => !!links?.mts || !!links?.mtsMusic, domain: "music.mts.ru", region: "ru" },
                            // Western platforms
                            { id: "spotify", name: "Spotify", check: (links: any) => !!links?.spotify, domain: "open.spotify.com", region: "west" },
                            { id: "apple", name: "Apple Music", check: (links: any) => !!links?.appleMusic || !!links?.itunes, domain: "music.apple.com" },
                            { id: "youtube", name: "YouTube", check: (links: any) => !!links?.youtube, domain: "youtube.com", region: "west" },
                            { id: "youtubemusic", name: "YouTube Music", check: (links: any) => !!links?.youtubeMusic, domain: "music.youtube.com", region: "west" },
                            { id: "tiktok", name: "TikTok", check: (links: any) => !!links?.tiktok, domain: "tiktok.com", region: "west" },
                            { id: "soundcloud", name: "SoundCloud", check: (links: any) => !!links?.soundcloud, domain: "soundcloud.com", region: "west" },
                            { id: "deezer", name: "Deezer", check: (links: any) => !!links?.deezer, domain: "deezer.com", region: "west" },
                            { id: "tidal", name: "Tidal", check: (links: any) => !!links?.tidal, domain: "tidal.com", region: "west" },
                            { id: "amazon", name: "Amazon Music", check: (links: any) => !!links?.amazonMusic || !!links?.amazonStore, domain: "music.amazon.com", region: "west" },
                            { id: "shazam", name: "Shazam", check: (links: any) => !!links?.shazam, domain: "shazam.com", region: "west" },
                            { id: "pandora", name: "Pandora", check: (links: any) => !!links?.pandora, domain: "pandora.com", region: "west" },
                            { id: "qobuz", name: "Qobuz", check: (links: any) => !!links?.qobuz, domain: "qobuz.com", region: "west" },
                            { id: "napster", name: "Napster", check: (links: any) => !!links?.napster, domain: "napster.com", region: "west" },
                            { id: "boomplay", name: "Boomplay", check: (links: any) => !!links?.boomplay, domain: "boomplay.com", region: "west" },
                            { id: "audiomack", name: "Audiomack", check: (links: any) => !!links?.audiomack, domain: "audiomack.com", region: "west" },
                            { id: "anghami", name: "Anghami", check: (links: any) => !!links?.anghami, domain: "anghami.com", region: "west" }
                          ].filter(p => {
                              if (platformFilter === "all") return true;
                              if (platformFilter === "ru" || platformFilter === "west") return p.region === platformFilter;
                              return enabledPlatforms.includes(p.id);
                          }).map(platform => {
                             const isFound = platform.check(metadataResult.links);
                             let linkUrl = "";
                                                          if (isFound) {
                               const platformData = metadataResult.links[platform.id] || 
                                     metadataResult.links[
                                       platform.id === 'apple' ? 'appleMusic' : 
                                       platform.id === 'amazon' ? 'amazonMusic' : 
                                       platform.id === 'youtubemusic' ? 'youtubeMusic' : 
                                       platform.id === 'mts' ? 'mtsMusic' : platform.id
                                     ] ||
                                     metadataResult.links[
                                       platform.id === 'apple' ? 'itunes' : 
                                       platform.id === 'amazon' ? 'amazonStore' : platform.id
                                     ] ||
                                     (platform.id === 'zvuk' ? metadataResult.links['sber'] : null);
                               
                               if (platformData && platformData.url) {
                                   linkUrl = platformData.url;
}
                             }
                             
                             let searchUrl = "";
                             if (!isFound) {
                                const query = encodeURIComponent((metadataResult.artist || '') + ' ' + (metadataResult.title || ''));
                                if (platform.id === 'vk') searchUrl = `https://vk.com/audio?q=${query}`;
                                else if (platform.id === 'zvuk') searchUrl = `https://zvuk.com/search?query=${query}`;
                                else if (platform.id === 'mts') searchUrl = `https://music.mts.ru/search?text=${query}`;
                                else if (platform.id === 'yandex') searchUrl = `https://music.yandex.ru/search?text=${query}`;
                                else if (platform.id === 'spotify') searchUrl = `https://open.spotify.com/search/${query}`;
                                else if (platform.id === 'appleMusic') searchUrl = `https://music.apple.com/search?term=${query}`;
                             }
                             
                             return (
                               <div key={platform.id} className="flex items-center justify-between p-3 bg-zinc-50 dark:bg-black/20 rounded-xl border border-zinc-100 dark:border-white/5">
                                 <div className="flex items-center gap-3">
                                    <PlatformBrandIcon platformId={platform.id} domain={platform.domain} name={platform.name} size="md" isFound={isFound} />
                                   <div className="flex flex-col">
                                     <span className={`font-medium text-sm leading-tight ${isFound ? 'text-zinc-700 dark:text-zinc-300' : 'text-zinc-500'}`}>{platform.name}</span>
                                     {platformLatencies[platform.id] && (
                                       <div className="flex items-center gap-1.5 mt-0.5">
                                          <div className={`w-2 h-2 rounded-full ${platformLatencies[platform.id].status === 'up' ? (platformLatencies[platform.id].latency < 500 ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.5)]') : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'}`}></div>
                                          <span className="text-[10px] text-zinc-400 font-medium">{platformLatencies[platform.id].status === 'up' ? `${platformLatencies[platform.id].latency}ms` : 'Error'}</span>
                                       </div>
                                     )}
                                   </div>
                                 </div>
                                 {isFound ? (
                                   linkUrl ? (
                                     <a href={linkUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-lg text-xs font-medium hover:bg-emerald-500/20 transition-colors">
                                       <Check className="w-3.5 h-3.5" />
                                       {t("Found", "Найдено")}
                                     </a>
                                   ) : (
                                     <span className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-lg text-xs font-medium">
                                       <Check className="w-3.5 h-3.5" />
                                       {t("Found", "Найдено")}
                                     </span>
                                   )
                                 ) : (
                                   searchUrl ? (
                                     <a href={searchUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-medium hover:bg-blue-500/20 transition-colors">
                                       <Search className="w-3.5 h-3.5" />
                                       {t("Search", "Поиск")}
                                     </a>
                                   ) : (
                                     <span className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 rounded-lg text-xs font-medium">
                                       <X className="w-3.5 h-3.5" />
                                       {t("Not Found", "Не найдено")}
                                     </span>
                                   )
                                 )}
                               </div>
                             );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  )}
                  {/* Actions / Audio Section */}
                  <div className="mt-6 pt-6 border-t border-zinc-200/50 dark:border-white/10 flex flex-col gap-4">

                  
                  <div className="flex flex-col sm:flex-row gap-4 mb-4 items-center">
                    <button
                      onClick={handleDownloadZip}
                      disabled={isZipping}
                      className="flex-1 bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black shadow-sm font-semibold py-3 px-6 rounded-2xl transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isZipping ? (
                        <>
                          <RefreshCw className="w-5 h-5 animate-spin" />
                          {zipProgress}
                        </>
                      ) : (
                        <>
                          <Download className="w-5 h-5" />
                          {t("Download ZIP", "Скачать ZIP")}
                        </>
                      )}
                    </button>
                    <select
                      value={zipFormat}
                      onChange={(e) => setZipFormat(e.target.value as any)}
                      className="bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] text-zinc-900 dark:text-zinc-50 rounded-2xl px-4 py-3 font-medium outline-none focus:ring-2 focus:ring-black dark:focus:ring-white h-[48px]"
                      disabled={isZipping}
                    >
                      <option value="txt">TXT</option>
                      <option value="pdf">PDF</option>
                      <option value="xlsx">Excel</option>
                    </select>
                  </div>


                    {(metadataResult.type === "album" || metadataResult.type === "artist") && metadataResult.tracks && metadataResult.tracks.length > 0 ? (
                      metadataResult.tracks.map((track: any, idx: number) => (
                        <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between bg-white dark:bg-[#1c1c1e] p-3 rounded-2xl shadow-sm border border-zinc-200/50 dark:border-white/10 w-full flex-1 gap-4">
                          <div className="flex items-center gap-4 min-w-0">
                            <div className="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center shrink-0">
                              <Music className="w-5 h-5 text-zinc-600 dark:text-zinc-400" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-50 truncate" title={track.title}>
                                {track.title}
                              </p>
                              <p
                                className="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate"
                                title={t("Full track download requires Yandex Plus", "Для скачивания полного трека нужен Яндекс Плюс")}
                              >
                                WAV 44.1kHz{" "}
                                <span className="text-orange-500 lowercase normal-case">{t("(If 30 sec - Plus needed)", "(Если 30 сек — нужен Плюс)")}</span>
                                {track.durationMs ? ` • ${Math.floor(track.durationMs / 60000)}:${String(Math.floor((track.durationMs % 60000) / 1000)).padStart(2, '0')}` : (track.duration ? ` • ${Math.floor(track.duration / 60)}:${String(Math.floor(track.duration % 60)).padStart(2, '0')}` : '')}
                              </p>
                              {(track.copyright || track.copyrightOwnerName) && (
                                <p className="text-[10px] text-orange-600 dark:text-orange-400 font-semibold tracking-wide truncate mt-0.5" title={`Правообладатель OK.ru: ${track.copyrightOwnerName || track.copyright}`}>
                                  © {track.copyrightOwnerName || track.copyright}{track.copyrightOwnerId ? ` (ID: ${track.copyrightOwnerId})` : ''}
                                </p>
                              )}
                              {track.upc && (
                                <p className="text-[10px] text-zinc-400 dark:text-zinc-500 uppercase tracking-wider font-semibold truncate mt-0.5">
                                  UPC: {track.upc} {track.isrc ? ` | ISRC: ${track.isrc}` : ''}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto overflow-x-auto pb-1">
                            <button
                              onClick={(e) => {
                                handlePlayTrackGlobally({
                                  id: track.id,
                                  title: track.title,
                                  artists: [{ name: metadataResult.artists || "Unknown" }],
                                  coverUri: metadataResult.coverUri,
                                  durationMs: track.durationMs,
                                  duration: track.duration,
                                  durationFormatted: track.durationFormatted
                                }, metadataResult.tracks || []);
                              }}
                              className="p-2.5 bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-zinc-900 dark:text-zinc-50 shadow-sm rounded-lg transition-colors flex items-center gap-2 shrink-0"
                            >
                              <Play className="w-4 h-4" />
                            </button>
                            <button
                              onClick={(e) => {
                                if (!status?.connected) {
                                  e.preventDefault();
                                  alert(t("To download and listen to audio, you need to connect your Yandex account (authorize).", "Для скачивания и прослушивания аудио необходимо подключить аккаунт Yandex (авторизоваться)."));
                                  return;
                                }
                                downloadAudio(e, track.id, track.title, track.artists || metadataResult.artists, track.upc, track.isrc, track.coverUri);
                              }}
                              disabled={downloadingTrackId === track.id}
                              className="p-2.5 bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black shadow-sm rounded-lg transition-colors flex items-center gap-2 shrink-0 group disabled:opacity-50"
                            >
                              {downloadingTrackId === track.id ? (
                                <Loader2 className="w-4 h-4 animate-spin text-purple-400 dark:text-purple-600" />
                              ) : (
                                <Download className="w-4 h-4" />
                              )}
                              <span className="text-sm font-semibold pr-1 hidden lg:inline">
                                {downloadingTrackId === track.id ? t("Saving...", "Скачивание...") : "WAV"}
                              </span>
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-white dark:bg-[#1c1c1e] p-3 rounded-2xl shadow-sm border border-zinc-200/50 dark:border-white/10 w-full flex-1 gap-4">
                        <div className="flex items-center gap-4 min-w-0">
                          <div className="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center shrink-0">
                            <Music className="w-5 h-5 text-zinc-600 dark:text-zinc-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-50 truncate">{metadataResult.title || t("Audio Track", "Аудио трек")}</p>
                            <p
                              className="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate"
                              title={t("Full track download requires Yandex Plus", "Для скачивания полного трека нужен Яндекс Плюс")}
                            >
                              WAV 44.1kHz{" "}
                              <span className="text-orange-500 lowercase normal-case">{t("(If 30 sec - Plus needed)", "(Если 30 сек — нужен Плюс)")}</span>
                              {metadataResult.durationMs ? ` • ${Math.floor(metadataResult.durationMs / 60000)}:${String(Math.floor((metadataResult.durationMs % 60000) / 1000)).padStart(2, '0')}` : (metadataResult.duration ? ` • ${Math.floor(metadataResult.duration / 60)}:${String(Math.floor(metadataResult.duration % 60)).padStart(2, '0')}` : '')}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto pb-1 overflow-x-auto">
                          {!metadataResult.isSpotify && !metadataResult.isOkRu && (
                            <>
                          <button
                              onClick={(e) => {
                                handlePlayTrackGlobally({
                                  id: metadataResult.id,
                                  title: metadataResult.title,
                                  artists: [{ name: metadataResult.artists || "Unknown" }],
                                  coverUri: metadataResult.coverUri,
                                  durationMs: metadataResult.durationMs,
                                  duration: metadataResult.duration,
                                  durationFormatted: metadataResult.durationFormatted
                                });
                              }}
                              className="p-2.5 bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-zinc-900 dark:text-zinc-50 shadow-sm rounded-lg transition-colors flex items-center gap-2 shrink-0"
                            >
                              <Play className="w-4 h-4" />
                            </button>
                          
                          <button
                            onClick={(e) => {
                              if (!status?.connected) {
                                e.preventDefault();
                                alert(t("To download and listen to audio, you need to connect your Yandex account (authorize).", "Для скачивания и прослушивания аудио необходимо подключить аккаунт Yandex (авторизоваться)."));
                                return;
                              }
                              downloadAudio(e, metadataResult.id, metadataResult.title, metadataResult.artists, metadataResult.upc, metadataResult.isrc, metadataResult.coverUri);
                            }}
                            disabled={downloadingTrackId === metadataResult.id}
                            className="p-2.5 bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black shadow-sm rounded-lg transition-colors flex items-center gap-2 shrink-0 group disabled:opacity-50"
                          >
                            {downloadingTrackId === metadataResult.id ? (
                              <Loader2 className="w-4 h-4 animate-spin text-purple-400 dark:text-purple-600" />
                            ) : (
                              <Download className="w-4 h-4" />
                            )}
                            <span className="text-sm font-semibold pr-1 hidden lg:inline">
                              {downloadingTrackId === metadataResult.id ? t("Saving...", "Скачивание...") : "WAV"}
                            </span>
                          </button>
                            </>
                          )}
                          {metadataResult.okruTrackUrl && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const a = document.createElement("a");
                                a.href = `/api/okru/download?url=${encodeURIComponent(metadataResult.okruTrackUrl)}&title=${encodeURIComponent(metadataResult.title || "")}&artists=${encodeURIComponent(metadataResult.artists || "")}`;
                                a.download = "";
                                document.body.appendChild(a);
                                a.click();
                                document.body.removeChild(a);
                              }}
                              className="p-2.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 text-zinc-900 dark:text-white rounded-lg transition-colors flex items-center gap-2 shrink-0 group"
                              title={t("Download full track from OK.ru (bypass 30 sec)", "Скачать полный трек с OK.ru (обход 30 сек)")}
                            >
                              <Download className="w-4 h-4" />
                              <span className="text-sm font-semibold pr-1 hidden lg:inline">{t("Audio (Bypass limitations)", "Аудио (обход ограничений)")}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : null}

            {!hasOkRuSession && (
              <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden mt-6">
                {/* Custom API Request Block */}
                <div className="p-6 border-b border-zinc-100 dark:border-white/5">
                  <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-zinc-50 mb-1">
                    Raw API Explorer
                  </h3>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4">
                    Make custom requests to the Yandex Music API to extract the
                    full raw JSON data.
                  </p>

                  <form onSubmit={handleFetchCustom} className="flex gap-3">
                    <span className="bg-zinc-100 dark:bg-zinc-800 border border-zinc-200/50 dark:border-white/10 rounded-2xl px-4 py-3 font-mono text-sm flex items-center text-zinc-500 dark:text-zinc-400 whitespace-nowrap">
                      api.music.yandex.net/
                    </span>
                    <input
                      type="text"
                      value={customEndpoint}
                      onChange={(e) => setCustomEndpoint(e.target.value)}
                      placeholder="e.g. tracks/114948834 or albums/26366744/with-tracks"
                      className="flex-1 text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white focus:border-transparent transition-all"
                      required
                    />
                    <button
                      type="submit"
                      disabled={!customEndpoint.trim() || isFetchingCustom}
                      className="bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black shadow-sm font-semibold py-3 px-6 rounded-2xl transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isFetchingCustom ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4 hidden" />
                      )}
                      Fetch API
                    </button>
                  </form>
                </div>
                {customResult && (
                  <div className="p-6 bg-zinc-50/50 dark:bg-black/20 border-t border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider">
                        API Response
                      </span>
                    </div>
                    <pre className="bg-zinc-900 dark:bg-zinc-100 text-zinc-300 p-4 rounded-2xl font-mono text-xs overflow-x-auto max-h-96">
                      {JSON.stringify(customResult, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </>)}
      </div>
    </div>
    
      {activeTrack && (
        <CustomAudioPlayer 
          hasOkRuSession={hasOkRuSession}
          src={`/api/music/download/${activeTrack.id}?title=${encodeURIComponent(activeTrack.title || '')}&artists=${encodeURIComponent(activeTrack.artists ? (typeof activeTrack.artists === 'string' ? activeTrack.artists : activeTrack.artists.map((a: any) => a.name).join(', ')) : '')}&upc=${encodeURIComponent(activeTrack.upc || '')}&isrc=${encodeURIComponent(activeTrack.isrc || '')}${activeTrack.durationMs ? `&duration=${Math.round(activeTrack.durationMs / 1000)}` : (activeTrack.duration ? `&duration=${Math.round(activeTrack.duration)}` : '')}`}
          track={activeTrack} 
          albumCover={activeTrack.coverUri}
          albumArtists={activeTrack.artists ? (typeof activeTrack.artists === 'string' ? activeTrack.artists : activeTrack.artists.map((a: any) => a.name).join(', ')) : ''}
          artistAvatarUri={activeTrack.artistAvatarUri || activeTrack.coverUri}
          onNext={handleNextTrack}
          onPlayTrack={handlePlayTrackGlobally}
          onArtistClick={(artistName: string) => {
            if (artistName) {
              setCurrentArtistId(artistName);
            }
          }}
        />
      )}

      <DownloadProgressToast t={t} />
      <BackgroundExportWidget t={t} />

      {/* Global Album / Release Screen Modal */}
      {globalAlbumModal.isOpen && globalAlbumModal.album && (
        <AlbumModal
          isOpen={globalAlbumModal.isOpen}
          onClose={() => setGlobalAlbumModal({ isOpen: false, album: null })}
          album={globalAlbumModal.album}
          activeTrackId={activeTrack?.id}
          isPlaying={Boolean(activeTrack)}
          onPlayTrack={handlePlayTrackGlobally}
          onArtistClick={(artistName: string) => {
            if (artistName) {
              setGlobalAlbumModal({ isOpen: false, album: null });
              setCurrentArtistId(artistName);
            }
          }}
          onSearchClick={() => {
            setGlobalAlbumModal({ isOpen: false, album: null });
            setActiveAppTab("search");
          }}
          t={t}
        />
      )}

      {/* Global Full-Screen Artist Profile Modal - Adapted for Mobile & Desktop */}
      {currentArtistId && (
        <ArtistProfile
          artistId={currentArtistId}
          provider={currentArtistProvider}
          onPlayTrack={handlePlayTrackGlobally}
          onDownloadTrack={downloadAudio}
          onSelectAlbum={(albumOrId: any) => {
            handleOpenAlbumModal(albumOrId);
          }}
          onBack={() => {
            setCurrentArtistId(null);
            setCurrentArtistProvider("");
          }}
          t={t}
        />
      )}

      {/* Secure 2FA Chief Owner Auth Modal */}
      {showOwnerLoginModal && (
        <OwnerAuthModal
          isOpen={showOwnerLoginModal}
          onClose={() => setShowOwnerLoginModal(false)}
          onAuthenticated={() => {
            setChiefOwnerAuthenticated(CHIEF_OWNER_TG_ID);
            setIsChiefOwner(true);
            setShowOwnerLoginModal(false);
            setActiveAppTab('cloud');
          }}
          t={t}
        />
      )}

</div>
  );
}
