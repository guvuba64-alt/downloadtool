import React from "react";
import { ProxyImage } from "./ProxyImage";
import { Clock, Trash2, Music } from "lucide-react";

function formatTrackDuration(track: any): string {
  if (!track) return "";
  
  if (track.durationFormatted && typeof track.durationFormatted === 'string') {
    const clean = track.durationFormatted.split(' ')[0].trim();
    if (clean && clean.includes(':')) return clean;
  }

  let totalSeconds = 0;
  if (typeof track.durationMs === 'number' && track.durationMs > 0) {
    totalSeconds = Math.round(track.durationMs / 1000);
  } else if (typeof track.duration === 'number' && track.duration > 0) {
    totalSeconds = track.duration > 10000 ? Math.round(track.duration / 1000) : Math.round(track.duration);
  } else if (typeof track.durationSec === 'number' && track.durationSec > 0) {
    totalSeconds = Math.round(track.durationSec);
  }

  if (totalSeconds > 0) {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  return "";
}

function formatPlayedTime(playedAt: any): string {
  if (!playedAt) return "";
  try {
    const d = new Date(playedAt);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return "";
  }
}

export function HistoryTab({ history, onClear, onPlayTrack, t }: any) {
  return (
    <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-6 border-b border-zinc-100 dark:border-white/5 flex items-center justify-between">
        <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
           <Clock className="w-5 h-5" /> {t("History", "История")}
        </h3>
        {history.length > 0 && (
           <button onClick={onClear} className="text-zinc-500 hover:text-red-500 transition-colors flex items-center gap-1 text-sm font-medium">
             <Trash2 className="w-4 h-4" /> {t("Clear", "Очистить")}
           </button>
        )}
      </div>

      <div className="p-6">
         {history.length === 0 ? (
            <div className="text-center text-zinc-500 py-12">
               {t("No history yet.", "История пуста.")}
            </div>
         ) : (
            <div className="flex flex-col gap-2">
               {history.map((track: any, idx: number) => {
                 const durationStr = formatTrackDuration(track);
                 const playedTimeStr = formatPlayedTime(track.playedAt);
                 return (
                   <div key={idx} className="flex items-center gap-4 p-3 hover:bg-zinc-50 dark:hover:bg-white/5 rounded-2xl transition-colors group cursor-pointer" onClick={() => onPlayTrack(track)}>
                      <div className="w-12 h-12 bg-zinc-100 dark:bg-zinc-800 rounded-xl flex items-center justify-center shrink-0 overflow-hidden">
                          {track.coverUri ? (
                              <ProxyImage src={track.coverUri ? track.coverUri.replace("%%", "100x100") : undefined} className="w-full h-full object-cover" />
                          ) : (
                              <Music className="w-5 h-5 text-zinc-400" />
                          )}
                      </div>
                      <div className="flex-1 min-w-0">
                         <div className="font-semibold text-zinc-900 dark:text-zinc-50 truncate">{track.title}</div>
                         <div className="text-sm text-zinc-500 truncate">{typeof track.artists === 'string' ? track.artists : (track.artists?.map((a:any)=>a.name).join(", ") || track.rawArtists?.map((a:any)=>a.name).join(", ") || "Unknown")}</div>
                      </div>
                      <div className="text-right shrink-0 flex flex-col items-end justify-center">
                         <div className="text-sm font-semibold font-mono text-zinc-800 dark:text-zinc-200">
                            {durationStr || "--:--"}
                         </div>
                         {playedTimeStr && (
                            <div className="text-[10px] text-zinc-400 mt-0.5" title={track.playedAt ? new Date(track.playedAt).toLocaleString() : undefined}>
                               {playedTimeStr}
                            </div>
                         )}
                      </div>
                   </div>
                 );
               })}
            </div>
         )}
      </div>
    </div>
  );
}
