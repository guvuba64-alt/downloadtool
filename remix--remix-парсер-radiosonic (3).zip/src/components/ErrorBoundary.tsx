import React, { ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw, RotateCcw } from "lucide-react";

export interface ErrorBoundaryProps {
  children: ReactNode;
}

export interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  props: ErrorBoundaryProps;
  state: ErrorBoundaryState = {
    hasError: false,
    error: null,
  };

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.props = props;
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught application error:", error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleResetCache = () => {
    try {
      localStorage.removeItem("adminSession");
      localStorage.removeItem("tgContacts");
      localStorage.removeItem("app-color-theme");
      localStorage.removeItem("liked_vibe_tracks");
      localStorage.removeItem("player_cover_variant");
      sessionStorage.clear();
    } catch (e) {}
    window.location.href = window.location.pathname;
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-zinc-50 dark:bg-[#121214] text-zinc-900 dark:text-zinc-100 flex items-center justify-center p-4">
          <div className="max-w-lg w-full bg-white dark:bg-[#1c1c1e] rounded-3xl p-8 border border-zinc-200/80 dark:border-white/10 shadow-2xl space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto shadow-inner">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="text-center space-y-2">
              <h2 className="text-xl font-bold tracking-tight">
                Произошла ошибка при отображении
              </h2>
              <p className="text-sm text-zinc-500 dark:text-zinc-400">
                Приложение защищено от сбоев. Вы можете перезагрузить страницу или сбросить временные данные.
              </p>
            </div>

            {this.state.error && (
              <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-500/20 rounded-2xl text-xs font-mono text-red-700 dark:text-red-300 break-words max-h-36 overflow-y-auto">
                {this.state.error.toString()}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-semibold text-sm hover:opacity-90 transition-opacity shadow-sm"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Перезагрузить</span>
              </button>

              <button
                type="button"
                onClick={this.handleResetCache}
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-zinc-100 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 font-semibold text-sm hover:bg-zinc-200 dark:hover:bg-white/20 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Сбросить кэш</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
