import React from 'react';

// High-resolution SVG Brand Icons for Music Services

export const YandexMusicIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#FFCC00" />
    <circle cx="24" cy="24" r="13" fill="#000000" />
    <path d="M24 14V28.5C24 30.985 21.985 33 19.5 33C17.015 33 15 30.985 15 28.5C15 26.015 17.015 24 19.5 24C20.5 24 21.4 24.33 22.1 24.9V14H28.5V18.5H24" fill="#FFCC00" />
    <path d="M24 14H33V18.5H24V14Z" fill="#FF3333" />
  </svg>
);

export const VkMusicIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#0077FF" />
    <path d="M26.2 33C15.8 33 9.9 25.8 9.7 14H14.9C15.1 22.7 18.9 26.4 21.9 27.2V14H26.8V21.5C29.8 21.2 32.9 17.8 34 14H38.9C38 18.7 34.6 22.1 32.1 23.6C34.6 24.8 38.5 27.8 40 33H34.6C33.4 29.3 30.5 26.4 26.8 26V33H26.2Z" fill="#FFFFFF" />
  </svg>
);

export const ZvukIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="zvukGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1CE589" />
        <stop offset="50%" stopColor="#0EC9C4" />
        <stop offset="100%" stopColor="#7F30FF" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#zvukGrad)" />
    {/* Sound waves stylized */}
    <rect x="11" y="20" width="4.5" height="8" rx="2.25" fill="#FFFFFF" />
    <rect x="18" y="14" width="4.5" height="20" rx="2.25" fill="#FFFFFF" />
    <rect x="25" y="10" width="4.5" height="28" rx="2.25" fill="#FFFFFF" />
    <rect x="32" y="17" width="4.5" height="14" rx="2.25" fill="#FFFFFF" />
  </svg>
);

export const OkRuMusicIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#EE8208" />
    <path d="M24 8C19.58 8 16 11.58 16 16C16 20.42 19.58 24 24 24C28.42 24 32 20.42 32 16C32 11.58 28.42 8 24 8ZM24 19.5C22.07 19.5 20.5 17.93 20.5 16C20.5 14.07 22.07 12.5 24 12.5C25.93 12.5 27.5 14.07 27.5 16C27.5 17.93 25.93 19.5 24 19.5Z" fill="#FFFFFF" />
    <path d="M31.9 28.5C30.6 29.5 27.9 30.5 24 30.5C20.1 30.5 17.4 29.5 16.1 28.5C14.7 27.4 12.8 28.9 13.9 30.3C15.8 32.7 19.4 34.3 23.5 34.7L18.4 39.8C17.5 40.7 17.5 42.1 18.4 43C19.3 43.9 20.7 43.9 21.6 43L26.7 37.9L31.8 43C32.7 43.9 34.1 43.9 35 43C35.9 42.1 35.9 40.7 35 39.8L29.9 34.7C34 34.3 37.6 32.7 39.5 30.3C40.6 28.9 33.3 27.4 31.9 28.5Z" fill="#FFFFFF" />
  </svg>
);

export const MtsMusicIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#E30611" />
    {/* MTS Red tile with white M */}
    <path d="M12 34V14H18.5L24 23.5L29.5 14H36V34H30.5V21.5L25.8 29.5H22.2L17.5 21.5V34H12Z" fill="#FFFFFF" />
  </svg>
);

export const SpotifyBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#1ED760" />
    <path d="M34.7 21.4C27.7 17.2 16.2 16.8 9.5 18.9C8.4 19.2 7.3 18.6 7 17.5C6.7 16.4 7.3 15.3 8.4 15C16.1 12.6 28.8 13.1 36.9 17.9C37.9 18.5 38.2 19.8 37.6 20.8C37 21.7 35.7 22 34.7 21.4ZM34.4 27.2C33.9 28 32.9 28.3 32.1 27.8C26.3 24.2 17.4 23.1 10.4 25.2C9.5 25.5 8.5 25 8.2 24.1C7.9 23.2 8.4 22.2 9.3 21.9C17.3 19.5 27.1 20.7 33.8 24.8C34.6 25.3 34.9 26.4 34.4 27.2ZM31.7 32.8C31.3 33.4 30.5 33.6 29.9 33.2C25 30.2 18.5 29.5 10.9 31.2C10.2 31.4 9.5 30.9 9.3 30.2C9.1 29.5 9.6 28.8 10.3 28.6C18.6 26.7 25.8 27.5 31.3 30.9C31.9 31.2 32.1 32.1 31.7 32.8Z" fill="#000000" />
  </svg>
);

export const AppleMusicBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="appleMusicGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FC3C44" />
        <stop offset="100%" stopColor="#F92472" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#appleMusicGrad)" />
    <path d="M33 13V26.5C33 29 30.8 31 28 31C25.2 31 23 29 23 26.5C23 24 25.2 22 28 22C29 22 29.9 22.3 30.7 22.8V17.2L19 19.7V30.5C19 33 16.8 35 14 35C11.2 35 9 33 9 30.5C9 28 11.2 26 14 26C15 26 15.9 26.3 16.7 26.8V16.8C16.7 15.5 17.7 14.4 19 14.2L31.3 11.7C32.2 11.5 33 12.2 33 13Z" fill="#FFFFFF" />
  </svg>
);

export const YoutubeBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#FF0000" />
    <path d="M37 17.5C36.6 15.9 35.3 14.6 33.7 14.2C30.8 13.5 24 13.5 24 13.5C24 13.5 17.2 13.5 14.3 14.2C12.7 14.6 11.4 15.9 11 17.5C10.2 20.4 10.2 24 10.2 24C10.2 24 10.2 27.6 11 30.5C11.4 32.1 12.7 33.4 14.3 33.8C17.2 34.5 24 34.5 24 34.5C24 34.5 30.8 34.5 33.7 33.8C35.3 33.4 36.6 32.1 37 30.5C37.8 27.6 37.8 24 37.8 24C37.8 24 37.8 20.4 37 17.5ZM21.2 28.5V19.5L29 24L21.2 28.5Z" fill="#FFFFFF" />
  </svg>
);

export const YoutubeMusicBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#FF0000" />
    <circle cx="24" cy="24" r="14" stroke="#FFFFFF" strokeWidth="2.5" />
    <circle cx="24" cy="24" r="7" stroke="#FFFFFF" strokeWidth="1.8" />
    <polygon points="22,20.5 28,24 22,27.5" fill="#FFFFFF" />
  </svg>
);

export const TikTokBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#010101" />
    <g transform="translate(11, 10)">
      {/* TikTok note with cyan/pink shadow */}
      <path d="M19.5 0.5C18.2 2.2 16.3 3.4 14.1 3.7V17C14.1 20.8 11 23.9 7.2 23.9C3.4 23.9 0.3 20.8 0.3 17C0.3 13.2 3.4 10.1 7.2 10.1C7.8 10.1 8.4 10.2 9 10.4V14.6C8.4 14.4 7.8 14.3 7.2 14.3C5.7 14.3 4.5 15.5 4.5 17C4.5 18.5 5.7 19.7 7.2 19.7C8.7 19.7 9.9 18.5 9.9 17V0.5H14.1C14.1 2.8 16 4.7 18.3 4.7H19.5V0.5Z" fill="#25F4EE" />
      <path d="M21.5 2.5C20.2 4.2 18.3 5.4 16.1 5.7V19C16.1 22.8 13 25.9 9.2 25.9C5.4 25.9 2.3 22.8 2.3 19C2.3 15.2 5.4 12.1 9.2 12.1C9.8 12.1 10.4 12.2 11 12.4V16.6C10.4 16.4 9.8 16.3 9.2 16.3C7.7 16.3 6.5 17.5 6.5 19C6.5 20.5 7.7 21.7 9.2 21.7C10.7 21.7 11.9 20.5 11.9 19V2.5H16.1C16.1 4.8 18 6.7 20.3 6.7H21.5V2.5Z" fill="#FE2C55" />
      <path d="M20.5 1.5C19.2 3.2 17.3 4.4 15.1 4.7V18C15.1 21.8 12 24.9 8.2 24.9C4.4 24.9 1.3 21.8 1.3 18C1.3 14.2 4.4 11.1 8.2 11.1C8.8 11.1 9.4 11.2 10 11.4V15.6C9.4 15.4 8.8 15.3 8.2 15.3C6.7 15.3 5.5 16.5 5.5 18C5.5 19.5 6.7 20.7 8.2 20.7C9.7 20.7 10.9 19.5 10.9 18V1.5H15.1C15.1 3.8 17 5.7 19.3 5.7H20.5V1.5Z" fill="#FFFFFF" />
    </g>
  </svg>
);

export const SoundCloudBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="scGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FF7700" />
        <stop offset="100%" stopColor="#FF3300" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#scGrad)" />
    <path d="M11 26.5C11 28.4 12.6 30 14.5 30H34.5C37.5 30 40 27.5 40 24.5C40 21.6 37.8 19.2 34.9 19C34.4 14.5 30.6 11 26 11C23 11 20.3 12.5 18.7 14.8C18.1 14.6 17.5 14.5 16.8 14.5C13.6 14.5 11 17.1 11 20.3C11 20.7 11.05 21.1 11.15 21.5C11.05 21.8 11 22.1 11 22.5V26.5Z" fill="#FFFFFF" />
  </svg>
);

export const DeezerBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="deezerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#A238FF" />
        <stop offset="100%" stopColor="#5A00EC" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#deezerGrad)" />
    {/* Deezer iconic equalizer bars */}
    <rect x="10" y="27" width="5" height="7" rx="1.5" fill="#FFFFFF" />
    <rect x="17" y="22" width="5" height="12" rx="1.5" fill="#FFFFFF" />
    <rect x="24" y="15" width="5" height="19" rx="1.5" fill="#FFFFFF" />
    <rect x="31" y="20" width="5" height="14" rx="1.5" fill="#FFFFFF" />
  </svg>
);

export const TidalBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#000000" />
    <g transform="translate(10, 14)">
      {/* 4 Diamonds */}
      <polygon points="7,0 12,5 7,10 2,5" fill="#00FFFF" />
      <polygon points="17,0 22,5 17,10 12,5" fill="#00FFFF" />
      <polygon points="27,0 32,5 27,10 22,5" fill="#00FFFF" />
      <polygon points="17,10 22,15 17,20 12,15" fill="#00FFFF" />
    </g>
  </svg>
);

export const AmazonMusicBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#14213d" />
    {/* Music Note in Cyan */}
    <path d="M32 12V24C32 26.2 30.2 28 28 28C25.8 28 24 26.2 24 24C24 21.8 25.8 20 28 20C28.7 20 29.4 20.2 30 20.5V15.5L20 17.5V27C20 29.2 18.2 31 16 31C13.8 31 12 29.2 12 27C12 24.8 13.8 23 16 23C16.7 23 17.4 23.2 18 23.5V15C18 14 18.8 13.2 19.8 13L30.8 11C31.5 10.9 32 11.4 32 12Z" fill="#00A8E1" />
    {/* Amazon Smile Curve */}
    <path d="M12 36C18 39.5 28 39.5 35 34.5" stroke="#FF9900" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M34 32L36 34.5L33 36.5" fill="#FF9900" />
  </svg>
);

export const ShazamBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#0088FF" />
    <path d="M21.5 29.5C20.5 29.5 19.6 29.1 19 28.4L15.3 24.2C14.5 23.3 14 22 14 20.7C14 17.8 16.3 15.5 19.2 15.5C20.5 15.5 21.8 16 22.7 16.8L26.4 21C27.2 21.9 27.7 23.2 27.7 24.5C27.7 27.3 25.4 29.5 22.5 29.5H21.5ZM26.5 18.5C27.5 18.5 28.4 18.9 29 19.6L32.7 23.8C33.5 24.7 34 26 34 27.3C34 30.2 31.7 32.5 28.8 32.5C27.5 32.5 26.2 32 25.3 31.2L21.6 27C20.8 26.1 20.3 24.8 20.3 23.5C20.3 20.7 22.6 18.5 25.5 18.5H26.5Z" fill="#FFFFFF" />
  </svg>
);

export const PandoraBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="pandoraGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#005483" />
        <stop offset="100%" stopColor="#00A0EE" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#pandoraGrad)" />
    <path d="M15 12H27C32 12 35 15 35 19.5C35 24 32 27 27 27H22V36H15V12ZM22 21.5H26.5C27.8 21.5 28.8 20.6 28.8 19.5C28.8 18.4 27.8 17.5 26.5 17.5H22V21.5Z" fill="#FFFFFF" />
  </svg>
);

export const QobuzBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#1B1D1F" />
    <circle cx="23" cy="23" r="11" stroke="#FFFFFF" strokeWidth="3" />
    <circle cx="23" cy="23" r="4.5" fill="#FFFFFF" />
    <line x1="29" y1="29" x2="36" y2="36" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
  </svg>
);

export const NapsterBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#007AFF" />
    <g transform="translate(10, 10)">
      {/* Cat silhouette with headphones */}
      <circle cx="14" cy="14" r="11" fill="#FFFFFF" />
      <polygon points="7,5 11,10 4,11" fill="#007AFF" />
      <polygon points="21,5 17,10 24,11" fill="#007AFF" />
      {/* Sunglasses / Headphones eyes */}
      <circle cx="10" cy="14" r="3.5" fill="#007AFF" />
      <circle cx="18" cy="14" r="3.5" fill="#007AFF" />
      <path d="M12 19C13 20 15 20 16 19" stroke="#007AFF" strokeWidth="1.5" strokeLinecap="round" />
    </g>
  </svg>
);

export const BoomplayBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="12" fill="#E51A24" />
    {/* Stylized Boomplay 'b' record */}
    <circle cx="24" cy="26" r="9" stroke="#FFFFFF" strokeWidth="3" />
    <line x1="15" y1="11" x2="15" y2="26" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
    <circle cx="24" cy="26" r="3.5" fill="#FFFFFF" />
  </svg>
);

export const AudiomackBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="audiomackGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFA200" />
        <stop offset="100%" stopColor="#FF5500" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#audiomackGrad)" />
    {/* Fast forward dual play arrows */}
    <polygon points="13,16 23,24 13,32" fill="#FFFFFF" />
    <polygon points="23,16 33,24 23,32" fill="#FFFFFF" />
    <line x1="34" y1="16" x2="34" y2="32" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

export const AnghamiBrandIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="anghamiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#6710F5" />
        <stop offset="100%" stopColor="#A805FF" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#anghamiGrad)" />
    {/* Anghami sound icon */}
    <circle cx="24" cy="24" r="11" stroke="#FFFFFF" strokeWidth="2.5" />
    <path d="M19 28V20L29 24L19 28Z" fill="#FFFFFF" />
  </svg>
);

// Map of canonical platforms to high-resolution icons
export const PLATFORM_ICONS_MAP: Record<string, React.FC<{ className?: string }>> = {
  yandex: YandexMusicIcon,
  yandexmusic: YandexMusicIcon,
  'music.yandex.ru': YandexMusicIcon,
  vk: VkMusicIcon,
  vkmusic: VkMusicIcon,
  'vk.com': VkMusicIcon,
  zvuk: ZvukIcon,
  sber: ZvukIcon,
  'zvuk.com': ZvukIcon,
  okru: OkRuMusicIcon,
  'ok.ru': OkRuMusicIcon,
  mts: MtsMusicIcon,
  mtsmusic: MtsMusicIcon,
  'music.mts.ru': MtsMusicIcon,
  spotify: SpotifyBrandIcon,
  'open.spotify.com': SpotifyBrandIcon,
  apple: AppleMusicBrandIcon,
  applemusic: AppleMusicBrandIcon,
  itunes: AppleMusicBrandIcon,
  'music.apple.com': AppleMusicBrandIcon,
  youtube: YoutubeBrandIcon,
  'youtube.com': YoutubeBrandIcon,
  youtubemusic: YoutubeMusicBrandIcon,
  'music.youtube.com': YoutubeMusicBrandIcon,
  tiktok: TikTokBrandIcon,
  'tiktok.com': TikTokBrandIcon,
  soundcloud: SoundCloudBrandIcon,
  'soundcloud.com': SoundCloudBrandIcon,
  deezer: DeezerBrandIcon,
  'deezer.com': DeezerBrandIcon,
  tidal: TidalBrandIcon,
  'tidal.com': TidalBrandIcon,
  amazon: AmazonMusicBrandIcon,
  amazonmusic: AmazonMusicBrandIcon,
  amazonstore: AmazonMusicBrandIcon,
  'music.amazon.com': AmazonMusicBrandIcon,
  shazam: ShazamBrandIcon,
  'shazam.com': ShazamBrandIcon,
  pandora: PandoraBrandIcon,
  'pandora.com': PandoraBrandIcon,
  qobuz: QobuzBrandIcon,
  'qobuz.com': QobuzBrandIcon,
  napster: NapsterBrandIcon,
  'napster.com': NapsterBrandIcon,
  boomplay: BoomplayBrandIcon,
  'boomplay.com': BoomplayBrandIcon,
  audiomack: AudiomackBrandIcon,
  'audiomack.com': AudiomackBrandIcon,
  anghami: AnghamiBrandIcon,
  'anghami.com': AnghamiBrandIcon,
};

export interface PlatformBrandIconProps {
  platformId?: string;
  domain?: string;
  name?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isFound?: boolean;
}

export function PlatformBrandIcon({
  platformId = '',
  domain = '',
  name = '',
  className = '',
  size = 'md',
  isFound = true
}: PlatformBrandIconProps) {
  const normId = (platformId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const normDomain = (domain || '').toLowerCase().trim();

  // Lookup in canonical map
  const IconComponent = 
    PLATFORM_ICONS_MAP[normId] || 
    (normDomain ? PLATFORM_ICONS_MAP[normDomain] : null) ||
    PLATFORM_ICONS_MAP[name.toLowerCase().replace(/[^a-z0-9]/g, '')];

  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
    xl: 'w-12 h-12',
  }[size];

  if (IconComponent) {
    return (
      <div className={`shrink-0 flex items-center justify-center transition-transform hover:scale-105 ${!isFound ? 'opacity-50 grayscale' : ''} ${className}`}>
        <IconComponent className={sizeClasses} />
      </div>
    );
  }

  // Graceful fallback: Google Favicon with rounded container, fallback music icon
  const faviconDomain = normDomain || `${normId}.com`;
  return (
    <div className={`relative ${sizeClasses} rounded-xl bg-zinc-800 flex items-center justify-center shrink-0 overflow-hidden shadow-sm ${!isFound ? 'opacity-50 grayscale' : ''} ${className}`}>
      <img
        src={`https://www.google.com/s2/favicons?domain=${faviconDomain}&sz=128`}
        alt={name || platformId}
        className="w-5/6 h-5/6 object-contain"
        onError={(e) => {
          (e.currentTarget as HTMLElement).style.display = 'none';
        }}
      />
    </div>
  );
}
