import { TelegramIcon } from './Icons';
import React, { useState } from 'react';
import { Send, ShieldCheck, KeyRound, Loader2, AlertCircle } from 'lucide-react';

interface Props {
  children: React.ReactNode;
  t: (en: string, ru: string) => string;
}

export function TgAuthGuard({ children, t }: Props) {
  const [adminSession, setAdminSession] = useState(() => localStorage.getItem('adminSession') || '');
  const [authStep, setAuthStep] = useState(1);
  const [authId, setAuthId] = useState(localStorage.getItem('adminTgId') || '8981404137');
  const [authCode, setAuthCode] = useState('');
  const [authError, setAuthError] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [isValidating, setIsValidating] = useState(true);

  React.useEffect(() => {
    const validateSession = async () => {
      const session = localStorage.getItem('adminSession');
      const tgId = localStorage.getItem('adminTgId');
      
      if (!session || !tgId) {
        setIsValidating(false);
        return;
      }
      
      try {
        const res = await fetch('/api/auth/validate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tgId, token: session })
        });
        const data = await res.json();
        if (!data.allowed) {
          localStorage.removeItem('adminSession');
          localStorage.removeItem('adminTgId');
          setAdminSession('');
          setAuthError('Ваша сессия истекла или доступ был отозван.');
        }
      } catch(e) {
        // on network error, we might still allow them if they had a session, or fail safe. 
        // We'll allow them for now to support offline-ish.
      }
      setIsValidating(false);
    };
    validateSession();
    
    // Also re-validate periodically (every 10 seconds)
    const interval = setInterval(validateSession, 10000);
    return () => clearInterval(interval);
  }, []);

  if (isValidating) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (adminSession) {
    return <>{children}</>;
  }

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthLoading(true);
    setAuthError('');
    try {
      const res = await fetch('/api/auth/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tgId: authId })
      });
      const data = await res.json();
      if (data.success) {
        setAuthStep(2);
      } else {
        setAuthError(data.error || 'Failed to send code');
      }
    } catch (e) {
      setAuthError('Network error');
    }
    setIsAuthLoading(false);
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthLoading(true);
    setAuthError('');
    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tgId: authId, code: authCode })
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem('adminSession', data.token);
        localStorage.setItem('adminTgId', authId);
        setAdminSession(data.token);
      } else {
        setAuthError(data.error || 'Invalid code');
      }
    } catch (e) {
      setAuthError('Network error');
    }
    setIsAuthLoading(false);
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-white dark:bg-[#1c1c1e] rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="w-16 h-16 mb-6 rounded-2xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-500 shadow-inner mx-auto">
        <ShieldCheck className="w-8 h-8" />
      </div>
      <h2 className="text-2xl font-bold text-center text-zinc-900 dark:text-white mb-2">
        {t("Secure Access", "Защищенный доступ")}
      </h2>
      <p className="text-center text-zinc-500 dark:text-zinc-400 mb-8">
        {t("Verify your Telegram ID to access Reports and Logs.", "Подтвердите свой Telegram ID для доступа к Отчётам и Логам.")}
      </p>

      {authError && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-xl flex items-start gap-3 text-sm">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{authError}</span>
        </div>
      )}

      {authStep === 1 ? (
        <form onSubmit={handleRequestCode} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5 text-zinc-700 dark:text-zinc-300">
              {t("Telegram ID", "ID Telegram")}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <TelegramIcon className="h-5 w-5 text-zinc-400" />
              </div>
              <input
                type="tel"
                inputMode="numeric"
                pattern="[0-9]*"
                required
                value={authId}
                onChange={(e) => setAuthId(e.target.value.replace(/\D/g, ""))}
                className="block w-full pl-10 pr-3 py-3 bg-zinc-50 dark:bg-black/50 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-zinc-900 dark:text-white"
                placeholder="123456789"
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={isAuthLoading || !authId}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
          >
            {isAuthLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : t("Send Code via Bot", "Отправить код через бота")}
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerifyCode} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5 text-zinc-700 dark:text-zinc-300">
              {t("Verification Code", "Код подтверждения")}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <KeyRound className="h-5 w-5 text-zinc-400" />
              </div>
              <input
                required
                value={authCode}
                onChange={(e) => setAuthCode(e.target.value.replace(/\D/g, ""))} inputMode="numeric" pattern="[0-9]*" type="tel"
                className="block w-full pl-10 pr-3 py-3 bg-zinc-50 dark:bg-black/50 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-zinc-900 dark:text-white text-center tracking-widest font-mono text-lg"
                placeholder="123456"
                autoFocus
              />
            </div>
            <p className="mt-2 text-xs text-center text-zinc-500">
              {t("Check your Telegram messages from the bot.", "Проверьте сообщения в Telegram от бота.")}
            </p>
          </div>
          <button
            type="submit"
            disabled={isAuthLoading || !authCode}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
          >
            {isAuthLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : t("Verify Code", "Подтвердить код")}
          </button>
          
          <button
            type="button"
            onClick={() => { setAuthStep(1); setAuthCode(''); setAuthError(''); }}
            className="w-full py-2 text-sm text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 transition-colors"
          >
            {t("Go Back", "Вернуться")}
          </button>
        </form>
      )}
    </div>
  );
}
