import React, { useState, useRef, useEffect } from 'react';
import { 
  Film, Download, Play, Pause, AlertCircle, CheckCircle2, 
  UploadCloud, FileVideo, Loader2, Sparkles, Eye, EyeOff
} from 'lucide-react';

export interface VideoShotTabProps {
  t: (en: string, ru: string) => string;
  initialTrack?: {
    title?: string;
    artist?: string;
    coverUrl?: string;
    audioUrl?: string;
  } | null;
  onPlayTrack?: (track: any) => void;
}

export function VideoShotTab({ t }: VideoShotTabProps) {
  // Video file & URL
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);
  const [naturalWidth, setNaturalWidth] = useState<number>(0);
  const [naturalHeight, setNaturalHeight] = useState<number>(0);

  // Target specs for Yandex Music (404x720 9:16 MP4 H.264)
  const targetW = 404;
  const targetH = 720;

  // Trimmer settings (5 to 20 seconds, default 15s)
  const [startTime, setStartTime] = useState<number>(0);
  const [clipDuration, setClipDuration] = useState<number>(15);

  // Overlay guides
  const [showSafeZone, setShowSafeZone] = useState<boolean>(true);

  // Live video preview
  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState<boolean>(true);

  // Conversion process
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [conversionStatusText, setConversionStatusText] = useState<string>('');
  const [conversionError, setConversionError] = useState<string | null>(null);

  // Converted result
  const [convertedResult, setConvertedResult] = useState<{
    fileName: string;
    duration: number;
    resolution: string;
    fileSizeFormatted: string;
    streamUrl: string;
    downloadUrl: string;
  } | null>(null);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  // Handle Video Upload
  const handleFileSelect = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('video/')) {
      alert(t('Please select a valid video file (MP4, MOV, WebM, etc.)', 'Пожалуйста, выберите видеофайл (MP4, MOV, WebM и т.д.)'));
      return;
    }

    if (videoUrl) {
      URL.revokeObjectURL(videoUrl);
    }

    const objectUrl = URL.createObjectURL(file);
    setVideoFile(file);
    setVideoUrl(objectUrl);
    setConvertedResult(null);
    setConversionError(null);
    setStartTime(0);
    setClipDuration(15);
  };

  // Video metadata loaded
  const handleLoadedMetadata = () => {
    if (videoPreviewRef.current) {
      const dur = videoPreviewRef.current.duration || 0;
      setVideoDuration(dur);
      setNaturalWidth(videoPreviewRef.current.videoWidth || 0);
      setNaturalHeight(videoPreviewRef.current.videoHeight || 0);

      if (dur > 0 && dur < 15) {
        setClipDuration(Math.max(5, Math.min(20, Math.floor(dur))));
      } else {
        setClipDuration(15);
      }
    }
  };

  // Video looping within [startTime, startTime + clipDuration]
  const handleTimeUpdate = () => {
    if (!videoPreviewRef.current) return;
    const current = videoPreviewRef.current.currentTime;
    const maxEnd = startTime + clipDuration;
    if (current >= maxEnd || current < startTime) {
      videoPreviewRef.current.currentTime = startTime;
    }
  };

  // Toggle Play / Pause
  const togglePlay = () => {
    if (!videoPreviewRef.current) return;
    if (videoPreviewRef.current.paused) {
      videoPreviewRef.current.play();
      setIsPlayingPreview(true);
    } else {
      videoPreviewRef.current.pause();
      setIsPlayingPreview(false);
    }
  };

  // Execute Video Conversion
  const handleStartConversion = async () => {
    if (!videoFile) return;

    setIsConverting(true);
    setConversionStatusText(t('Centering & converting to 404×720 MP4...', 'Кадрирование и конвертация в 404×720 MP4...'));
    setConversionError(null);

    try {
      const formData = new FormData();
      formData.append('video', videoFile);
      formData.append('startTime', String(startTime));
      formData.append('duration', String(clipDuration));
      formData.append('cropMode', 'crop_center');
      formData.append('muteAudio', 'true');
      formData.append('preset', 'yandex');
      formData.append('targetWidth', String(targetW));
      formData.append('targetHeight', String(targetH));

      const res = await fetch('/api/videoshot/convert', {
        method: 'POST',
        body: formData
      });

      if (!res.ok) {
        throw new Error(`Ошибка сервера: ${res.statusText}`);
      }

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Ошибка конвертации');
      }

      setConvertedResult(data);
    } catch (err: any) {
      console.warn('Server conversion failed, falling back to browser Canvas conversion:', err);
      setConversionStatusText(t('Rendering via browser Canvas engine...', 'Рендеринг через встроенный движок Canvas...'));

      try {
        await convertInBrowser(targetW, targetH);
      } catch (browserErr: any) {
        setConversionError(err.message || 'Не удалось сконвертировать видео.');
      }
    } finally {
      setIsConverting(false);
    }
  };

  // In-Browser fallback using Canvas and MediaRecorder
  const convertInBrowser = async (outW: number, outH: number) => {
    if (!videoUrl) throw new Error('Видео недоступно');

    const tempVideo = document.createElement('video');
    tempVideo.src = videoUrl;
    tempVideo.muted = true;
    tempVideo.crossOrigin = 'anonymous';
    await new Promise((res) => { tempVideo.onloadedmetadata = () => res(true); });

    const canvas = document.createElement('canvas');
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas context недоступен');

    const stream = canvas.captureStream(30);
    let mimeType = 'video/mp4';
    if (!MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=h264') 
        ? 'video/webm;codecs=h264' 
        : 'video/webm';
    }

    const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 3_000_000 });
    const recordedChunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };

    const completionPromise = new Promise<{ blob: Blob; url: string }>((resolve, reject) => {
      recorder.onstop = () => {
        const finalBlob = new Blob(recordedChunks, { type: mimeType });
        const finalUrl = URL.createObjectURL(finalBlob);
        resolve({ blob: finalBlob, url: finalUrl });
      };
      recorder.onerror = reject;
    });

    tempVideo.currentTime = startTime;
    await new Promise((res) => { tempVideo.onseeked = () => res(true); });

    recorder.start();
    tempVideo.play();

    const drawFrame = () => {
      if (!tempVideo.paused && !tempVideo.ended && tempVideo.currentTime < startTime + clipDuration) {
        const vw = tempVideo.videoWidth;
        const vh = tempVideo.videoHeight;
        const scale = Math.max(outW / vw, outH / vh);
        const nw = vw * scale;
        const nh = vh * scale;
        const ox = (outW - nw) / 2;
        const oy = (outH - nh) / 2;

        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, outW, outH);
        ctx.drawImage(tempVideo, ox, oy, nw, nh);

        requestAnimationFrame(drawFrame);
      } else {
        recorder.stop();
        tempVideo.pause();
      }
    };

    drawFrame();

    const { blob, url } = await completionPromise;
    setConvertedResult({
      fileName: `videoshot_404x720.mp4`,
      duration: clipDuration,
      resolution: `404x720`,
      fileSizeFormatted: (blob.size / (1024 * 1024)).toFixed(2) + ' МБ',
      streamUrl: url,
      downloadUrl: url
    });
  };

  const currentDisplayVideo = convertedResult?.streamUrl || videoUrl;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 animate-in fade-in duration-300 space-y-6">
      
      {/* Streamlined Header */}
      <div className="flex items-center justify-between pb-4 border-b border-zinc-200 dark:border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white flex items-center gap-2">
              <Film className="w-6 h-6 text-yellow-500" />
              {t('Create VideoShot', 'Создать видеошот')}
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/20 text-yellow-700 dark:text-yellow-400 font-mono text-xs font-bold">
              404×720 px (9:16)
            </span>
          </div>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            {t(
              'Upload a video — the algorithm converts it to vertical format 9:16 (MP4, H.264) for Yandex Music.',
              'Загрузите видео — алгоритм автоматически кадрирует в вертикальный формат 9:16 (MP4, H.264) для Яндекс Музыки.'
            )}
          </p>
        </div>
      </div>

      {/* Main 2-Column Work Area */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Clean Upload, Duration, and Convert Actions (7 cols) */}
        <div className="md:col-span-7 space-y-5">
          
          {/* 1. Video Upload Box */}
          {!videoFile ? (
            <label className="border-2 border-dashed border-zinc-300 dark:border-white/15 hover:border-yellow-400 dark:hover:border-yellow-400 rounded-3xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all bg-zinc-50 dark:bg-zinc-900/40 hover:bg-yellow-400/5 group">
              <input
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                }}
              />
              <div className="w-14 h-14 rounded-2xl bg-yellow-400/15 text-yellow-500 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <UploadCloud className="w-7 h-7" />
              </div>
              <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mb-1">
                {t('Choose or drag a video file', 'Выберите или перетащите видео')}
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                MP4, MOV, WebM
              </p>
            </label>
          ) : (
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 shadow-sm flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-yellow-400/10 text-yellow-500 flex items-center justify-center shrink-0">
                  <FileVideo className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-zinc-900 dark:text-white truncate">
                    {videoFile.name}
                  </p>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    {(videoFile.size / (1024 * 1024)).toFixed(1)} МБ • {naturalWidth}×{naturalHeight} px • {videoDuration.toFixed(1)} сек
                  </p>
                </div>
              </div>

              <label className="px-3 py-1.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 text-xs font-bold cursor-pointer transition-colors shrink-0">
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                  }}
                />
                {t('Change', 'Заменить')}
              </label>
            </div>
          )}

          {/* 2. Duration Trimmer (Clean & Minimal) */}
          <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 shadow-sm space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-zinc-800 dark:text-zinc-200">
                {t('Loop duration (seconds):', 'Длительность зацикливания:')}
              </span>
              <span className="font-mono font-bold text-yellow-600 dark:text-yellow-400 bg-yellow-400/10 px-2 py-0.5 rounded-md">
                {clipDuration} сек
              </span>
            </div>

            {/* Quick Segmented Duration Buttons */}
            <div className="flex items-center gap-2">
              {[5, 10, 15, 20].map((d) => (
                <button
                  key={d}
                  onClick={() => {
                    setClipDuration(d);
                    if (videoDuration > 0 && startTime + d > videoDuration) {
                      setStartTime(Math.max(0, videoDuration - d));
                    }
                  }}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    clipDuration === d
                      ? 'bg-yellow-400 text-black shadow-sm font-black'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                  }`}
                >
                  {d}s {d === 15 ? '★' : ''}
                </button>
              ))}
            </div>

            {/* Start offset slider if video duration exceeds selected clip duration */}
            {videoDuration > clipDuration && (
              <div className="space-y-1 pt-1 border-t border-zinc-100 dark:border-white/5">
                <div className="flex justify-between text-[11px] text-zinc-500">
                  <span>Отрезок: <strong>{startTime.toFixed(1)}s – {(startTime + clipDuration).toFixed(1)}s</strong></span>
                  <span>Всего: {videoDuration.toFixed(1)}s</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={Math.max(0, videoDuration - clipDuration)}
                  step="0.1"
                  value={startTime}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setStartTime(val);
                    if (videoPreviewRef.current) {
                      videoPreviewRef.current.currentTime = val;
                    }
                  }}
                  className="w-full accent-yellow-400 cursor-pointer h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg"
                />
              </div>
            )}
          </div>

          {/* 3. Convert Button */}
          <button
            onClick={handleStartConversion}
            disabled={!videoFile || isConverting}
            className={`w-full py-3.5 px-6 rounded-2xl font-black text-sm transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2 cursor-pointer ${
              !videoFile
                ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed shadow-none'
                : isConverting
                  ? 'bg-yellow-400/80 text-black cursor-wait'
                  : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-400/20'
            }`}
          >
            {isConverting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-black" />
                <span>{conversionStatusText || 'Идёт конвертация...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 fill-black" />
                <span>{t('Convert to VideoShot (404×720 MP4)', 'Конвертировать в видеошот (404×720 MP4)')}</span>
              </>
            )}
          </button>

          {conversionError && (
            <div className="p-3.5 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{conversionError}</span>
            </div>
          )}

          {/* 4. Converted Result Card & Direct Download */}
          {convertedResult && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/30 space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  {t('VideoShot ready for Yandex Music!', 'Видеошот готов к загрузке в Яндекс Музыку!')}
                </span>
                <span className="font-mono text-zinc-500 dark:text-zinc-400">
                  {convertedResult.resolution} • {convertedResult.fileSizeFormatted}
                </span>
              </div>

              <a
                href={convertedResult.downloadUrl}
                download={convertedResult.fileName}
                className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-sm flex items-center justify-center gap-2 transition-transform active:scale-98 shadow-md shadow-emerald-500/20 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{t('Download VideoShot (MP4)', 'Скачать видеошот (MP4)')}</span>
              </a>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Streamlined 9:16 Vertical Phone Preview (5 cols) */}
        <div className="md:col-span-5 space-y-3 flex flex-col items-center">
          
          {/* Vertical 9:16 Phone Frame */}
          <div className="relative w-full max-w-[260px] aspect-[9/16] bg-black rounded-[28px] overflow-hidden shadow-2xl border-4 border-zinc-800 select-none flex flex-col justify-between">
            {currentDisplayVideo ? (
              <>
                {/* Looping video */}
                <video
                  ref={videoPreviewRef}
                  src={currentDisplayVideo}
                  autoPlay
                  loop
                  muted
                  playsInline
                  onLoadedMetadata={handleLoadedMetadata}
                  onTimeUpdate={handleTimeUpdate}
                  onClick={togglePlay}
                  className="absolute inset-0 w-full h-full object-cover cursor-pointer"
                />

                {/* Safe zone overlay */}
                {showSafeZone && (
                  <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between">
                    {/* Top status bar zone */}
                    <div className="h-9 bg-black/30 border-b border-dashed border-white/20 p-1 flex items-center justify-center">
                      <span className="text-[9px] font-bold text-white/70">
                        {t('Status bar', 'Статус-бар')}
                      </span>
                    </div>

                    {/* Center focus guide */}
                    <div className="flex-1 flex items-center justify-center p-4">
                      <div className="w-28 h-28 border border-dashed border-yellow-400/60 rounded-xl flex items-center justify-center relative bg-yellow-400/5">
                        <div className="w-3 h-0.5 bg-yellow-400" />
                        <div className="h-3 w-0.5 bg-yellow-400 absolute" />
                        <span className="absolute bottom-1 text-[8px] font-bold text-yellow-300 uppercase tracking-wider bg-black/60 px-1 rounded">
                          {t('Center', 'Центр кадра')}
                        </span>
                      </div>
                    </div>

                    {/* Bottom 1/3 player UI warning */}
                    <div className="h-24 bg-gradient-to-t from-red-950/70 to-transparent border-t border-dashed border-red-500/50 p-2 flex flex-col justify-end text-center">
                      <span className="text-[8px] font-black text-red-300 uppercase">
                        {t('Player UI Area', 'Зона интерфейса')}
                      </span>
                      <span className="text-[7.5px] text-white/70 leading-tight">
                        {t('Do not place text here', 'Не размещайте текст внизу')}
                      </span>
                    </div>
                  </div>
                )}

                {/* Pause icon overlay */}
                {!isPlayingPreview && (
                  <div 
                    className="absolute inset-0 flex items-center justify-center z-20 cursor-pointer"
                    onClick={togglePlay}
                  >
                    <div className="w-12 h-12 rounded-full bg-black/70 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white shadow-xl">
                      <Play className="w-5 h-5 fill-white ml-0.5" />
                    </div>
                  </div>
                )}

                {/* Top Badge */}
                <div className="relative z-20 flex items-center justify-between p-2.5">
                  <span className="px-2 py-0.5 rounded-full bg-black/70 text-[9px] font-mono font-bold text-yellow-400 border border-yellow-400/30 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
                    404×720
                  </span>
                  <button
                    onClick={togglePlay}
                    className="w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center cursor-pointer"
                  >
                    {isPlayingPreview ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 fill-white ml-0.5" />}
                  </button>
                </div>
              </>
            ) : (
              /* Empty state placeholder */
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-zinc-500">
                <Film className="w-10 h-10 text-zinc-700 mb-2" />
                <p className="text-xs font-bold text-zinc-400">
                  {t('Preview 9:16', 'Предпросмотр 9:16')}
                </p>
                <p className="text-[10px] text-zinc-600 mt-1 max-w-[150px]">
                  {t('Upload a video to see live looping preview', 'Загрузите видео для отображения вертикального предпросмотра')}
                </p>
              </div>
            )}
          </div>

          {/* Toggle safe zone guide */}
          <button
            onClick={() => setShowSafeZone(!showSafeZone)}
            className="text-xs text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 flex items-center gap-1.5 transition-colors cursor-pointer py-1"
          >
            {showSafeZone ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{showSafeZone ? t('Hide layout guide', 'Скрыть разметку безопасных зон') : t('Show layout guide', 'Показать разметку безопасных зон')}</span>
          </button>

        </div>

      </div>

    </div>
  );
}
