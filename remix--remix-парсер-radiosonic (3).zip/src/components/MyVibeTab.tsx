import React, { useState, useEffect, useMemo, useRef } from "react";
import { Play, Loader2, Pause, Heart, SkipForward, Sparkles, Volume2, Radio, Compass, Flame, Smile, Music, Check, Copy, X } from "lucide-react";
import { ProxyImage } from "./ProxyImage";
import { usePlayerStore } from "./ModernPlayer/store";

interface MyVibeTabProps {
  onPlayTrack: (track: any, queue: any[], source: "manual" | "vibe") => void;
  onSelectArtist?: (artist: string) => void;
  onSelectAlbum?: (album: any) => void;
  t: (en: string, ru: string) => string;
  activeTrack: any;
}

interface StationItem {
  id: { type: string; tag: string };
  name: string;
  icon?: { backgroundColor?: string; imageUrl?: string };
}

export function MyVibeTab({ onPlayTrack, onSelectArtist, onSelectAlbum, t, activeTrack }: MyVibeTabProps) {
  const [tracks, setTracks] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [selectedStation, setSelectedStation] = useState<string>("user:onyourwave");
  const [stations, setStations] = useState<StationItem[]>([
    { id: { type: "user", tag: "onyourwave" }, name: "Моя волна", icon: { backgroundColor: "#FFE500" } },
    { id: { type: "mood", tag: "energetic" }, name: "Энергичное", icon: { backgroundColor: "#FF4500" } },
    { id: { type: "mood", tag: "calm" }, name: "Спокойное", icon: { backgroundColor: "#00C896" } },
    { id: { type: "mood", tag: "happy" }, name: "Радостное", icon: { backgroundColor: "#FFB800" } },
    { id: { type: "diversity", tag: "favorite" }, name: "Любимое", icon: { backgroundColor: "#FF0055" } },
    { id: { type: "diversity", tag: "discover" }, name: "Незнакомое", icon: { backgroundColor: "#7B2CBF" } },
    { id: { type: "language", tag: "russian" }, name: "Русский трек", icon: { backgroundColor: "#0077B6" } },
  ]);

  const [likedTracks, setLikedTracks] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(localStorage.getItem("liked_vibe_tracks") || "{}");
    } catch {
      return {};
    }
  });

  const { isPlaying, state: playerState } = usePlayerStore();
  const [artistAvatar, setArtistAvatar] = useState<string | null>(null);
  const [isFetchingArtist, setIsFetchingArtist] = useState(false);

  // Copyright verification state per track ID
  const [copyrightState, setCopyrightState] = useState<Record<string, {
    status: 'idle' | 'checking' | 'found' | 'not_found';
    copyright?: string | null;
    label?: string | null;
    copyrightOwnerName?: string | null;
    copyrightOwnerId?: number | string | null;
    foundOnOkRu?: boolean;
    source?: string | null;
    message?: string | null;
  }>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const isPlaceholderCopyright = (str?: string | null) => {
    if (!str) return true;
    const s = str.trim().toLowerCase();
    return (
      s === 'не указан' ||
      s === 'не указано' ||
      s === '—' ||
      s === '-' ||
      s === 'unknown' ||
      s === 'null' ||
      s === 'undefined' ||
      s === 'правообладатель' ||
      s === 'copyright'
    );
  };

  const handleVerifyCopyright = async (trackToVerify?: any) => {
    const t = trackToVerify || currentTrack;
    if (!t) return;
    const trackIdKey = String(t.id);
    const trackTitle = (t.title || '').trim();
    const trackArtist = (Array.isArray(t.artists) ? t.artists.map((a: any) => typeof a === 'string' ? a : a.name).join(', ') : (typeof t.artists === 'string' ? t.artists : (t.artistName || artistName || ''))).trim();

    setCopyrightState(prev => ({
      ...prev,
      [trackIdKey]: { status: 'checking', message: 'Проверка лейбла и релизов на OK.ru...' }
    }));

    try {
      const okCookies = localStorage.getItem("okru_cookies") || undefined;
      const res = await fetch("/api/music/verify-track-copyright", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: t.id,
          title: trackTitle,
          artist: trackArtist,
          isrc: t.isrc,
          upc: t.upc,
          okCookies
        })
      });

      const data = await res.json().catch(() => null);

      if (data && data.success && data.verified && (data.copyright || data.copyrightOwnerName || data.label)) {
        const finalCopyright = data.copyright || (data.copyrightOwnerName ? `℗ ${new Date().getFullYear()} ${data.copyrightOwnerName}` : null) || data.label;
        const finalLabel = data.label || data.copyrightOwnerName || null;

        setCopyrightState(prev => ({
          ...prev,
          [trackIdKey]: {
            status: 'found',
            foundOnOkRu: true,
            source: 'OK.RU',
            copyright: finalCopyright,
            label: finalLabel,
            copyrightOwnerName: data.copyrightOwnerName || null,
            copyrightOwnerId: data.copyrightOwnerId || null,
            message: data.message || 'найден на ok.ru'
          }
        }));

        setTracks(prev => prev.map(trk => {
          if (String(trk.id) === trackIdKey) {
            return {
              ...trk,
              copyright: finalCopyright || trk.copyright,
              pLine: finalCopyright || trk.pLine,
              label: finalLabel || trk.label,
              isrc: data.isrc || trk.isrc,
              upc: data.upc || trk.upc,
              copyrightOwnerName: data.copyrightOwnerName || trk.copyrightOwnerName
            };
          }
          return trk;
        }));
      } else {
        setCopyrightState(prev => ({
          ...prev,
          [trackIdKey]: {
            status: 'not_found',
            foundOnOkRu: false,
            source: null,
            message: data?.message || 'не найден на ok.ru'
          }
        }));
      }
    } catch (e) {
      setCopyrightState(prev => ({
        ...prev,
        [trackIdKey]: {
          status: 'not_found',
          foundOnOkRu: false,
          source: null,
          message: 'ошибка проверки'
        }
      }));
    }
  };

  // Load Rotor stations dashboard from Yandex Music API
  useEffect(() => {
    fetch("/api/music/rotor/dashboard")
      .then((res) => res.json())
      .then((data) => {
        const rawStations = data.data?.result?.stations;
        if (Array.isArray(rawStations) && rawStations.length > 0) {
          const parsed = rawStations
            .map((s: any) => s.station || s)
            .filter((s: any) => s && s.id && s.name);
          if (parsed.length > 0) {
            setStations(parsed);
          }
        }
      })
      .catch(() => {});
  }, []);

  // Fetch vibe track feed on mount and on station change
  useEffect(() => {
    fetchVibe(false, selectedStation);

    const handleNext = () => {
      setTracks((prev) => {
        if (prev.length > 1) {
          const nextTracks = prev.slice(1);
          setTimeout(() => onPlayTrack(nextTracks[0], nextTracks, "vibe"), 0);

          if (nextTracks.length <= 4) {
            fetchVibe(true, selectedStation);
          }
          return nextTracks;
        } else {
          fetchVibe(false, selectedStation).then((newBatch) => {
            if (newBatch && newBatch.length > 0) {
              setTimeout(() => onPlayTrack(newBatch[0], newBatch, "vibe"), 0);
            }
          });
          return prev;
        }
      });
    };

    window.addEventListener("playNextVibe", handleNext);
    return () => window.removeEventListener("playNextVibe", handleNext);
  }, [selectedStation]);

  const fetchVibe = async (append = false, stationKey = selectedStation) => {
    if (!append) setLoading(true);
    try {
      const res = await fetch(`/api/music/feed?station=${encodeURIComponent(stationKey)}`);
      const data = await res.json();
      const incoming = data.data || [];
      if (data.batchId) setBatchId(data.batchId);

      if (append) {
        setTracks((prev) => {
          const newTracks = [...prev];
          incoming.forEach((track: any) => {
            if (!newTracks.some((t) => t.id === track.id)) {
              newTracks.push(track);
            }
          });
          return newTracks;
        });
      } else {
        setTracks(incoming);
      }
      return incoming;
    } catch (e: any) {
      console.error("Vibe fetch error:", e?.message || String(e));
    } finally {
      if (!append) setLoading(false);
    }
  };

  const handleStationChange = (station: StationItem) => {
    const key = `${station.id.type}:${station.id.tag}`;
    if (key === selectedStation) return;
    setSelectedStation(key);
    fetchVibe(false, key).then((incoming) => {
      if (incoming && incoming.length > 0 && isMusicActive) {
        onPlayTrack(incoming[0], incoming, "vibe");
      }
    });
  };

  const currentTrack = activeTrack || tracks[0];

  // Fetch artist high-res avatar/cutout if not directly present in track metadata
  useEffect(() => {
    if (!currentTrack) {
      setArtistAvatar(null);
      return;
    }

    if (currentTrack.artistAvatarUri) {
      setArtistAvatar(currentTrack.artistAvatarUri);
      return;
    }

    const artistId = currentTrack.artistId || currentTrack.artistList?.[0]?.id;
    if (artistId) {
      setIsFetchingArtist(true);
      fetch(`/api/music/artist/${artistId}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success && data.data?.artist?.cover?.uri) {
            const raw = data.data.artist.cover.uri;
            setArtistAvatar(`https://${raw.replace("%%", "1000x1000")}`);
          } else if (data.data?.artist?.ogImage) {
            setArtistAvatar(`https://${data.data.artist.ogImage.replace("%%", "1000x1000")}`);
          }
        })
        .catch(() => {})
        .finally(() => setIsFetchingArtist(false));
    } else {
      setArtistAvatar(null);
    }
  }, [currentTrack?.id, currentTrack?.artistAvatarUri]);

  const toggleLike = (trackId: string | number) => {
    const key = String(trackId);
    setLikedTracks((prev) => {
      const updated = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem("liked_vibe_tracks", JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // Send like feedback to rotor endpoint
    fetch("/api/music/rotor/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        station: selectedStation,
        type: !likedTracks[key] ? "like" : "unlike",
        trackId: String(trackId),
        batchId: batchId || undefined
      })
    }).catch(() => {});
  };

  const handleTogglePlayback = () => {
    if (!activeTrack && tracks.length > 0) {
      onPlayTrack(tracks[0], tracks, "vibe");
      return;
    }
    window.dispatchEvent(new CustomEvent("togglePlayAudio"));
  };

  const handleNextTrack = () => {
    if (currentTrack?.id) {
      fetch("/api/music/rotor/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          station: selectedStation,
          type: "skip",
          trackId: String(currentTrack.id),
          batchId: batchId || undefined,
          totalPlayedSeconds: 15
        })
      }).catch(() => {});
    }
    window.dispatchEvent(new CustomEvent("playNextVibe"));
  };

  const artistName = useMemo(() => {
    if (!currentTrack?.artists) return t("Artist", "Артист");
    if (typeof currentTrack.artists === "string") return currentTrack.artists;
    if (Array.isArray(currentTrack.artists)) return currentTrack.artists.map((a: any) => a.name).join(", ");
    return t("Artist", "Артист");
  }, [currentTrack?.artists, t]);

  const isCurrentLiked = currentTrack ? !!likedTracks[String(currentTrack.id)] : false;
  const isMusicActive = isPlaying || playerState === "playing";

  // Dynamic visual color themes based on track title / id for variety
  const themeColors = useMemo(() => {
    if (!isMusicActive) {
      // Warm amber & rose aura for idle/paused state
      return {
        blob1: "rgba(255, 170, 0, 0.45)",
        blob2: "rgba(255, 80, 0, 0.35)",
        blob3: "rgba(230, 0, 90, 0.25)",
        glow: "rgba(255, 190, 40, 0.3)",
      };
    }

    const hash = (currentTrack?.title || "").split("").reduce((acc: number, char: string) => acc + char.charCodeAt(0), 0);
    const mod = hash % 4;

    if (mod === 0) {
      // Vibrant Cyan & Deep Electric Blue
      return {
        blob1: "rgba(0, 225, 255, 0.55)",
        blob2: "rgba(0, 120, 255, 0.45)",
        blob3: "rgba(60, 0, 255, 0.35)",
        glow: "rgba(0, 240, 255, 0.4)",
      };
    } else if (mod === 1) {
      // Fiery Crimson & Orange Ember
      return {
        blob1: "rgba(255, 70, 0, 0.6)",
        blob2: "rgba(255, 0, 80, 0.45)",
        blob3: "rgba(255, 180, 0, 0.35)",
        glow: "rgba(255, 80, 0, 0.45)",
      };
    } else if (mod === 2) {
      // Neon Magenta & Violet
      return {
        blob1: "rgba(220, 0, 255, 0.55)",
        blob2: "rgba(120, 0, 255, 0.45)",
        blob3: "rgba(255, 0, 130, 0.35)",
        glow: "rgba(220, 50, 255, 0.4)",
      };
    } else {
      // Radiant Emerald & Lime
      return {
        blob1: "rgba(0, 240, 140, 0.5)",
        blob2: "rgba(0, 180, 220, 0.4)",
        blob3: "rgba(100, 255, 0, 0.3)",
        glow: "rgba(0, 255, 160, 0.35)",
      };
    }
  }, [currentTrack?.title, isMusicActive]);

  const selectedStationObj = stations.find((s) => `${s.id.type}:${s.id.tag}` === selectedStation) || stations[0];

  return (
    <div 
      id="my-vibe-container"
      className="w-full h-full min-h-[640px] sm:min-h-[720px] relative rounded-[36px] sm:rounded-[44px] overflow-hidden bg-black flex flex-col justify-between items-center isolate select-none shadow-2xl border border-white/5"
    >
      {/* Dynamic, Shimmering Liquid Aurora Mesh Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(20,20,25,0)_0%,_rgba(0,0,0,0.85)_80%,_rgba(0,0,0,0.98)_100%)] z-10" />

        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[70vmin] h-[70vmin] rounded-full mix-blend-screen filter blur-[70px] sm:blur-[90px] transition-all duration-1000 ${
            isMusicActive ? "vibe-blob-active-1" : "vibe-blob-idle-1"
          }`}
          style={{
            background: `radial-gradient(circle, ${themeColors.blob1} 0%, ${themeColors.blob2} 55%, transparent 75%)`,
          }}
        />

        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[85vmin] h-[85vmin] rounded-full mix-blend-screen filter blur-[90px] sm:blur-[120px] transition-all duration-1000 ${
            isMusicActive ? "vibe-blob-active-2" : "vibe-blob-idle-2"
          }`}
          style={{
            background: `radial-gradient(circle, ${themeColors.blob2} 0%, ${themeColors.blob3} 50%, transparent 70%)`,
          }}
        />

        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[50vmin] h-[50vmin] rounded-full mix-blend-screen filter blur-[50px] sm:blur-[70px] transition-all duration-700 ${
            isMusicActive ? "vibe-blob-active-3" : "vibe-blob-idle-3"
          }`}
          style={{
            background: `radial-gradient(circle, ${themeColors.glow} 0%, transparent 65%)`,
          }}
        />

        <div 
          className={`absolute inset-0 opacity-20 mix-blend-overlay ${isMusicActive ? "vibe-shimmer-fast" : "vibe-shimmer-slow"}`} 
          style={{
            backgroundImage: "radial-gradient(circle at 50% 50%, rgba(255,255,255,0.4) 0%, transparent 60%)"
          }}
        />
      </div>

      {/* Top Section: Station Selector Pills / Dashboard */}
      <div className="relative z-30 w-full pt-4 px-4 flex flex-col items-center gap-2">
        <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-2 scrollbar-none px-2">
          {stations.map((st) => {
            const key = `${st.id.type}:${st.id.tag}`;
            const isSelected = key === selectedStation;
            return (
              <button
                key={key}
                id={`station-pill-${st.id.tag}`}
                onClick={() => handleStationChange(st)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide whitespace-nowrap transition-all duration-300 flex items-center gap-1.5 cursor-pointer backdrop-blur-md border ${
                  isSelected
                    ? "bg-yellow-400 text-black border-yellow-300 shadow-[0_0_20px_rgba(255,229,0,0.4)] scale-105"
                    : "bg-white/10 text-white/70 hover:text-white hover:bg-white/15 border-white/10"
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: st.icon?.backgroundColor || "#FFE500" }}
                />
                {st.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Viewport */}
      {!activeTrack ? (
        /* IDLE / STOPPED STATE */
        <div className="relative z-20 flex flex-col items-center justify-between h-full w-full p-6 sm:p-10 flex-1">
          {/* Center Stage: Title + Big Yellow Play Button */}
          <div className="flex flex-col items-center justify-center my-auto text-center px-4">
            <h1 className="text-5xl sm:text-7xl font-black text-white tracking-tight drop-shadow-[0_10px_30px_rgba(0,0,0,0.8)] mb-8">
              {selectedStationObj.name}
            </h1>

            {/* Giant Yellow Round Play Button */}
            <button
              id="vibe-play-btn-idle"
              onClick={handleTogglePlayback}
              disabled={loading || tracks.length === 0}
              aria-label={t("Play My Vibe", "Включить Мою волну")}
              className="w-36 h-36 sm:w-44 sm:h-44 bg-[#FFE500] hover:bg-[#FFF033] active:scale-95 transition-all duration-300 rounded-full flex items-center justify-center shadow-[0_0_90px_rgba(255,229,0,0.45)] hover:shadow-[0_0_120px_rgba(255,229,0,0.65)] group cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="w-14 h-14 text-black animate-spin" />
              ) : (
                <Play className="w-16 h-16 fill-black text-black ml-2.5 group-hover:scale-110 transition-transform duration-300" />
              )}
            </button>

            <p className="text-white/60 mt-8 text-sm sm:text-base font-medium tracking-wide">
              {t("Endless stream of music tailored for you", "Бесконечный поток музыки по вашим предпочтениям")}
            </p>
          </div>

          {/* Bottom Pill: Track Preview info and like button */}
          {currentTrack && (
            <div className="w-full max-w-md bg-zinc-900/80 hover:bg-zinc-900/95 backdrop-blur-2xl border border-white/10 px-5 py-3.5 rounded-full flex items-center justify-between gap-4 shadow-2xl transition-all mb-2">
              <div 
                className="flex items-center gap-3 overflow-hidden cursor-pointer flex-1"
                onClick={() => {
                  if (onSelectAlbum && currentTrack) {
                    onSelectAlbum(currentTrack.albumId || {
                      id: currentTrack.albumId || currentTrack.id,
                      title: currentTrack.albumTitle || currentTrack.title,
                      artist: artistName,
                      coverUri: currentTrack.coverUri,
                      label: currentTrack.label,
                      copyright: currentTrack.copyright,
                      upc: currentTrack.upc,
                      isrc: currentTrack.isrc,
                      year: currentTrack.year,
                      releaseDate: currentTrack.releaseDate,
                    });
                  } else {
                    handleTogglePlayback();
                  }
                }}
                title={t("Open album / release", "Открыть альбом / релиз")}
              >
                {currentTrack.coverUri && (
                  <ProxyImage
                    src={currentTrack.coverUri.replace("%%", "200x200")}
                    className="w-10 h-10 rounded-full object-cover shrink-0 border border-white/10"
                  />
                )}
                <div className="flex flex-col min-w-0 text-left">
                  <span className="text-white text-sm font-semibold truncate leading-tight hover:text-yellow-300 transition-colors">
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        const art = currentTrack.artistId || (currentTrack.artistList?.[0]?.id ? String(currentTrack.artistList[0].id) : null) || artistName;
                        if (onSelectArtist && art) onSelectArtist(art);
                      }}
                      className="hover:underline"
                    >
                      {artistName}
                    </span>
                    {" — "}
                    <span>{currentTrack.title}</span>
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-white/60 text-xs truncate font-mono">
                      {copyrightState[String(currentTrack.id)]?.copyright || currentTrack.copyright || currentTrack.label || t("Next on your wave", "Далее в вашей волне")}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleVerifyCopyright(currentTrack);
                      }}
                      className="text-[11px] text-purple-400 hover:text-purple-300 hover:underline cursor-pointer shrink-0"
                    >
                      {copyrightState[String(currentTrack.id)]?.status === 'checking' ? '(поиск...)' : '(проверить)'}
                    </button>
                  </div>
                </div>
              </div>

              <button
                id="vibe-like-btn-idle"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleLike(currentTrack.id);
                }}
                className={`p-2.5 rounded-full transition-all active:scale-90 ${
                  isCurrentLiked
                    ? "text-red-500 bg-red-500/10"
                    : "text-white/50 hover:text-white bg-white/5 hover:bg-white/10"
                }`}
              >
                <Heart className={`w-5 h-5 ${isCurrentLiked ? "fill-current" : ""}`} />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* ACTIVE / PLAYING STATE */
        <div className="relative z-20 flex flex-col items-center justify-between h-full w-full p-6 sm:p-8 flex-1">
          {/* Top Section: Artist Alias / Name in Big Bold Typography */}
          <div className="w-full flex flex-col items-center justify-center pt-2 sm:pt-4 px-4 text-center">
            <button
              id="vibe-artist-name-btn"
              onClick={() => {
                const art = currentTrack.artistId || (currentTrack.artistList?.[0]?.id ? String(currentTrack.artistList[0].id) : null) || artistName;
                if (onSelectArtist && art) onSelectArtist(art);
              }}
              className="group cursor-pointer max-w-xl transition-transform active:scale-95 text-center"
              title={t("Open artist profile", "Открыть профиль артиста")}
            >
              <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white group-hover:text-yellow-400 transition-colors tracking-tight leading-tight drop-shadow-[0_8px_24px_rgba(0,0,0,0.8)] line-clamp-2 uppercase">
                {artistName}
              </h2>
            </button>
          </div>

          {/* Center Stage: Artist Photo Cutout (without background) & Album Cover Art */}
          <div className="relative flex flex-col items-center justify-center my-auto w-full max-w-lg py-4">
            {artistAvatar ? (
              <div className="relative flex flex-col items-center justify-center w-full">
                <div 
                  onClick={() => {
                    const art = currentTrack.artistId || (currentTrack.artistList?.[0]?.id ? String(currentTrack.artistList[0].id) : null) || artistName;
                    if (onSelectArtist && art) onSelectArtist(art);
                  }}
                  className="relative w-full max-w-[300px] sm:max-w-[380px] h-[300px] sm:h-[380px] flex items-center justify-center cursor-pointer group"
                  title={t("Open artist profile", "Открыть профиль артиста")}
                >
                  <ProxyImage
                    src={artistAvatar}
                    className="w-full h-full object-contain filter drop-shadow-[0_25px_50px_rgba(0,0,0,0.85)] transform group-hover:scale-105 transition-transform duration-700 pointer-events-none"
                  />
                </div>

                {currentTrack?.coverUri && (
                  <button
                    id="vibe-cover-badge-btn"
                    onClick={() => {
                      if (onSelectAlbum && currentTrack) {
                        onSelectAlbum(currentTrack.albumId || {
                          id: currentTrack.albumId || currentTrack.id,
                          title: currentTrack.albumTitle || currentTrack.title,
                          artist: artistName,
                          coverUri: currentTrack.coverUri,
                          label: currentTrack.label,
                          copyright: currentTrack.copyright,
                          upc: currentTrack.upc,
                          isrc: currentTrack.isrc,
                          year: currentTrack.year,
                          releaseDate: currentTrack.releaseDate,
                        });
                      }
                    }}
                    className="absolute -bottom-5 sm:-bottom-7 z-20 w-28 h-28 sm:w-36 sm:h-36 rounded-2xl sm:rounded-3xl overflow-hidden shadow-[0_20px_45px_rgba(0,0,0,0.7)] border border-white/20 bg-zinc-900/80 backdrop-blur-md transition-transform duration-500 hover:scale-105 cursor-pointer group"
                    title={t("Open album / release", "Открыть альбом / релиз")}
                  >
                    <ProxyImage
                      src={currentTrack.coverUri.replace("%%", "400x400")}
                      className="w-full h-full object-cover group-hover:opacity-90 transition-opacity"
                    />
                  </button>
                )}
              </div>
            ) : (
              <div 
                className="relative w-56 h-56 sm:w-72 sm:h-72 group cursor-pointer"
                onClick={() => {
                  if (onSelectAlbum && currentTrack) {
                    onSelectAlbum(currentTrack.albumId || {
                      id: currentTrack.albumId || currentTrack.id,
                      title: currentTrack.albumTitle || currentTrack.title,
                      artist: artistName,
                      coverUri: currentTrack.coverUri,
                      label: currentTrack.label,
                      copyright: currentTrack.copyright,
                      upc: currentTrack.upc,
                      isrc: currentTrack.isrc,
                      year: currentTrack.year,
                      releaseDate: currentTrack.releaseDate,
                    });
                  } else {
                    handleTogglePlayback();
                  }
                }}
                title={t("Open album / release", "Открыть альбом / релиз")}
              >
                <div className="absolute inset-0 bg-white/20 rounded-[32px] sm:rounded-[40px] blur-2xl opacity-60 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10 w-full h-full rounded-[28px] sm:rounded-[38px] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/20 bg-zinc-900 transition-transform duration-500 hover:scale-[1.03]">
                  {currentTrack?.coverUri ? (
                    <ProxyImage
                      src={currentTrack.coverUri.replace("%%", "600x600")}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-zinc-800 flex items-center justify-center">
                      <Play className="w-16 h-16 text-white/20" />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Functional Copyright & Rights Information Bar */}
          {currentTrack && (() => {
            const trackKey = String(currentTrack.id);
            const verified = copyrightState[trackKey];
            const hasVerified = verified?.status === 'found';
            const isChecking = verified?.status === 'checking';
            const isNotFound = verified?.status === 'not_found';
            
            const rawCopyright = currentTrack.pLine || currentTrack.copyright || currentTrack.label || currentTrack.distributor;
            const copyrightText = hasVerified
              ? verified.copyright
              : (rawCopyright && !isPlaceholderCopyright(rawCopyright) ? rawCopyright : null);

            return (
              <div className="w-full max-w-md mx-auto mb-3 px-3.5 py-2.5 rounded-2xl bg-black/50 backdrop-blur-2xl border border-white/15 flex flex-col gap-1.5 shadow-2xl text-[12px] transition-all">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-yellow-400 font-bold text-xs">℗</span>
                    <span className="text-white/70 text-[11px] font-semibold uppercase tracking-wider">Копирайт</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleVerifyCopyright(currentTrack)}
                      disabled={isChecking}
                      className="text-xs text-purple-400 hover:text-purple-300 font-sans flex items-center gap-1 cursor-pointer disabled:opacity-50 transition-colors"
                      title="Проверить лейбл и релизы на OK.ru"
                    >
                      {isChecking ? (
                        <>
                          <Loader2 className="w-3 h-3 animate-spin text-purple-400" />
                          <span className="text-[11px]">(проверка...)</span>
                        </>
                      ) : (
                        <span className="text-[11px] hover:underline font-medium">(проверить)</span>
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-white font-mono text-xs select-all truncate">
                      {copyrightText || 'Не указан (нажмите проверить)'}
                    </p>

                    <div className="flex flex-wrap items-center gap-1.5 mt-1">
                      {isChecking && (
                        <span className="text-purple-300 text-[11px] font-sans animate-pulse flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin text-purple-400" />
                          (проверка лейбла и релизов на ok.ru...)
                        </span>
                      )}

                      {hasVerified && (
                        <span className="text-emerald-400 text-[11px] font-sans flex items-center gap-1 font-medium bg-emerald-500/15 px-2 py-0.5 rounded-md border border-emerald-500/30">
                          <Check className="w-3 h-3" />
                          (найден на ok.ru{verified.label ? `: ${verified.label}` : (verified.copyrightOwnerName ? `: ${verified.copyrightOwnerName}` : '')})
                        </span>
                      )}

                      {isNotFound && (
                        <span className="text-amber-400/90 text-[11px] font-sans bg-amber-500/15 px-2 py-0.5 rounded-md border border-amber-500/30">
                          (не найден на ok.ru)
                        </span>
                      )}

                      {!verified && !isChecking && currentTrack?.isrc && (
                        <span className="text-white/40 text-[10px] font-sans">
                          ISRC: {currentTrack.isrc}
                        </span>
                      )}
                    </div>
                  </div>

                  {copyrightText && (
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(copyrightText);
                        setCopiedKey(trackKey);
                        setTimeout(() => setCopiedKey(null), 2000);
                      }}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                        copiedKey === trackKey
                          ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                          : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                      }`}
                      title="Скопировать строку копирайта"
                    >
                      {copiedKey === trackKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Bottom Floating Control Dock */}
          <div className="w-full max-w-md flex items-center justify-center gap-3 sm:gap-4 px-2 pb-2">
            <button
              id="vibe-control-play-pause"
              onClick={handleTogglePlayback}
              aria-label={isMusicActive ? t("Pause", "Пауза") : t("Play", "Играть")}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white/10 hover:bg-white/20 active:scale-90 backdrop-blur-2xl border border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.4)] flex items-center justify-center text-white cursor-pointer transition-all duration-200 shrink-0 group"
            >
              {isMusicActive ? (
                <Pause className="w-6 h-6 sm:w-7 sm:h-7 fill-white text-white group-hover:scale-110 transition-transform" />
              ) : (
                <Play className="w-6 h-6 sm:w-7 sm:h-7 fill-white text-white ml-1 group-hover:scale-110 transition-transform" />
              )}
            </button>

            <button
              id="vibe-control-track-title"
              onClick={() => {
                if (onSelectAlbum && currentTrack) {
                  onSelectAlbum(currentTrack.albumId || {
                    id: currentTrack.albumId || currentTrack.id,
                    title: currentTrack.albumTitle || currentTrack.title,
                    artist: artistName,
                    coverUri: currentTrack.coverUri,
                    label: currentTrack.label,
                    copyright: currentTrack.copyright,
                    upc: currentTrack.upc,
                    isrc: currentTrack.isrc,
                    year: currentTrack.year,
                    releaseDate: currentTrack.releaseDate,
                  });
                }
              }}
              className="h-14 sm:h-16 flex-1 bg-white/10 hover:bg-white/20 active:scale-[0.98] backdrop-blur-2xl border border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.4)] rounded-full px-5 sm:px-6 flex items-center justify-center text-center cursor-pointer transition-all duration-200 overflow-hidden group"
              title={t("Open album / release", "Открыть альбом / релиз")}
            >
              <span className="text-base sm:text-lg font-bold text-white group-hover:text-yellow-300 transition-colors tracking-wide truncate drop-shadow-sm">
                {currentTrack?.albumTitle || currentTrack?.title}
              </span>
            </button>

            <button
              id="vibe-control-next"
              onClick={handleNextTrack}
              aria-label={t("Next track", "Следующий трек")}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white/5 hover:bg-white/15 active:scale-90 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white/70 hover:text-white cursor-pointer transition-all shrink-0"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              id="vibe-control-like"
              onClick={() => toggleLike(currentTrack.id)}
              aria-label={t("Like track", "Нравится")}
              className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full backdrop-blur-2xl border border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.4)] flex items-center justify-center transition-all duration-200 shrink-0 cursor-pointer active:scale-90 ${
                isCurrentLiked
                  ? "bg-red-500/20 text-red-500 border-red-500/30"
                  : "bg-white/10 hover:bg-white/20 text-white"
              }`}
            >
              <Heart
                className={`w-6 h-6 sm:w-7 sm:h-7 transition-transform ${
                  isCurrentLiked ? "fill-red-500 scale-110" : "group-hover:scale-110"
                }`}
              />
            </button>
          </div>
        </div>
      )}

      {/* Embedded High-Performance Fluid Mesh Animation CSS */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
        @keyframes vibe-morph-1 {
          0%, 100% { transform: translate(-50%, -50%) scale(1) rotate(0deg); }
          33% { transform: translate(-45%, -55%) scale(1.18) rotate(60deg); }
          66% { transform: translate(-55%, -48%) scale(0.92) rotate(120deg); }
        }
        @keyframes vibe-morph-2 {
          0%, 100% { transform: translate(-50%, -50%) scale(1.05) rotate(0deg); }
          50% { transform: translate(-52%, -46%) scale(1.25) rotate(-90deg); }
        }
        @keyframes vibe-morph-3 {
          0%, 100% { transform: translate(-50%, -50%) scale(0.95); opacity: 0.5; }
          50% { transform: translate(-50%, -50%) scale(1.35); opacity: 0.9; }
        }
        @keyframes vibe-idle-breath {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.6; }
          50% { transform: translate(-50%, -50%) scale(1.12); opacity: 0.85; }
        }
        @keyframes vibe-shimmer {
          0% { transform: scale(1) rotate(0deg); }
          50% { transform: scale(1.2) rotate(180deg); }
          100% { transform: scale(1) rotate(360deg); }
        }

        .vibe-blob-active-1 {
          animation: vibe-morph-1 5s infinite ease-in-out;
        }
        .vibe-blob-active-2 {
          animation: vibe-morph-2 7s infinite ease-in-out;
        }
        .vibe-blob-active-3 {
          animation: vibe-morph-3 3.5s infinite ease-in-out;
        }

        .vibe-blob-idle-1 {
          animation: vibe-idle-breath 8s infinite ease-in-out;
        }
        .vibe-blob-idle-2 {
          animation: vibe-idle-breath 10s infinite ease-in-out;
          animation-delay: 2s;
        }
        .vibe-blob-idle-3 {
          animation: vibe-idle-breath 6s infinite ease-in-out;
          animation-delay: 1s;
        }

        .vibe-shimmer-fast {
          animation: vibe-shimmer 8s infinite linear;
        }
        .vibe-shimmer-slow {
          animation: vibe-shimmer 20s infinite linear;
        }
       `,
        }}
      />
    </div>
  );
}
