import React from "react";
import { ProxyImage } from "./ProxyImage";
import { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Maximize2,
  Minimize2,
  Download,
  ChevronDown,
  Mic2,
  X,
  Loader2,
  Sliders,
  Bluetooth,
  Headphones,
  Volume2,
  Sparkles,
  Check
} from "lucide-react";
import { createPortal } from "react-dom";
import { downloadWavTrack, subscribeDownloadState } from "../utils/audioDownloader";
import { audioEqualizer } from "../utils/audioEqualizer";
import { audioOutputManager, AudioOutputDevice } from "../utils/audioOutputManager";
import { EqualizerModal } from "./EqualizerModal";
import { BluetoothOutputModal } from "./BluetoothOutputModal";
import { extractTrackDetails } from "../utils/trackMetadata";

export function AudioPlayer({ src, track, albumCover, albumArtists, artistAvatarUri, hasOkRuSession, onNext, onPrevious }: any) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isLyricsFullScreen, setIsLyricsFullScreen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isBluetoothOpen, setIsBluetoothOpen] = useState(false);
  const [activeDevice, setActiveDevice] = useState<AudioOutputDevice | undefined>(undefined);
  const [trackDetails, setTrackDetails] = useState<any>(() => extractTrackDetails(track, albumArtists, albumCover));
  const [okRuCheckStatus, setOkRuCheckStatus] = useState<{
    status: 'idle' | 'checking' | 'found' | 'not_found';
    foundOnOkRu?: boolean;
    source?: string | null;
    copyright?: string | null;
    label?: string | null;
    copyrightOwnerName?: string | null;
    copyrightOwnerId?: number | string | null;
    trackName?: string | null;
    trackArtist?: string | null;
    message?: string | null;
  }>({ status: 'idle' });
  const [lyrics, setLyrics] = useState<string | null>(null);
  const [syncLyrics, setSyncLyrics] = useState<any[]>([]);
  const [isDownloadingWav, setIsDownloadingWav] = useState(false);

  // Subscribe to audio output manager for Bluetooth status
  useEffect(() => {
    return audioOutputManager.subscribe(() => {
      setActiveDevice(audioOutputManager.getActiveDevice());
    });
  }, []);

  // Attach Web Audio API Equalizer and Output Manager to audio element
  useEffect(() => {
    if (audioRef.current) {
      audioEqualizer.attach(audioRef.current);
      audioOutputManager.attach(audioRef.current);
    }
  }, [src]);

  useEffect(() => {
    return subscribeDownloadState((state) => {
      if (state.isDownloading && state.trackId === String(track?.id)) {
        setIsDownloadingWav(true);
      } else {
        setIsDownloadingWav(false);
      }
    });
  }, [track?.id]);

  const isPlaceholderCopyright = (val?: string | null): boolean => {
    if (!val) return true;
    const s = val.trim().toLowerCase();
    return (
      s === '' ||
      s === 'no copyright' ||
      s === 'copyright не найден' ||
      s === 'не найден' ||
      s === 'не указан' ||
      s === 'copyright не указан' ||
      s === 'unknown' ||
      s === '—' ||
      s === '-' ||
      s === 'нет данных' ||
      s === 'not found' ||
      s === 'ok.ru og metadata' ||
      s === 'правообладатель' ||
      s === 'copyright'
    );
  };

  const verifyOkRuCopyright = async (customArtist?: string, customTitle?: string) => {
    const artistName = customArtist || trackDetails?.performer || albumArtists || (typeof track?.artists === 'string' ? track.artists : track?.artists?.map((a: any) => a.name).join(', ')) || '';
    const trackName = customTitle || trackDetails?.title || track?.title || '';
    const trackId = track?.id || trackDetails?.id;

    if (!trackName && !trackId) return;

    setOkRuCheckStatus(prev => ({ ...prev, status: 'checking', message: 'Проверка лейбла и релизов на ok.ru...' }));

    try {
      const storedCookies = localStorage.getItem("okru_cookies") || undefined;
      const res = await fetch("/api/music/verify-track-copyright", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId,
          title: trackName,
          artist: artistName,
          isrc: trackDetails?.isrc || track?.isrc,
          upc: trackDetails?.upc || track?.upc,
          okCookies: storedCookies
        }),
      });

      const data = await res.json().catch(() => null);

      if (data && data.success && data.verified && (data.copyright || data.copyrightOwnerName || data.label)) {
        const finalCopyright = data.copyright || (data.copyrightOwnerName ? `℗ ${new Date().getFullYear()} ${data.copyrightOwnerName}` : null) || data.label;
        const finalLabel = data.label || data.copyrightOwnerName || null;
        const finalDistributor = data.distributor || data.copyrightOwnerName || null;

        setOkRuCheckStatus({
          status: 'found',
          foundOnOkRu: true,
          source: 'OK.RU',
          copyright: finalCopyright,
          label: finalLabel,
          copyrightOwnerName: data.copyrightOwnerName || null,
          copyrightOwnerId: data.copyrightOwnerId || null,
          trackName,
          trackArtist: artistName,
          message: 'найден на ok.ru'
        });

        setTrackDetails((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            copyright: finalCopyright || prev.copyright,
            label: finalLabel || prev.label,
            distributor: finalDistributor || prev.distributor,
            isrc: data.isrc || prev.isrc,
            upc: data.upc || prev.upc,
            authorsMusic: data.authorsMusic || prev.authorsMusic,
            authorsText: data.authorsText || prev.authorsText
          };
        });
      } else {
        setOkRuCheckStatus({
          status: 'not_found',
          foundOnOkRu: false,
          source: null,
          message: data?.message || 'Копирайт не найден на OK.ru и в реестрах'
        });
      }
    } catch (e) {
      setOkRuCheckStatus({
        status: 'not_found',
        foundOnOkRu: false,
        source: null,
        message: 'Ошибка при проверке копирайта'
      });
    }
  };
  
  useEffect(() => {
    if (track?.id) {
      // 1. INSTANT: Immediately extract and set full metadata from track & album objects (0 ms delay)
      const instantDetails = extractTrackDetails(track, albumArtists, albumCover);
      if (instantDetails) {
        setTrackDetails(instantDetails);
      }
      setOkRuCheckStatus({ status: 'idle' });

      // 2. FAST: Fetch deep credits & supplement from dedicated fast endpoint to seamlessly enrich fields
      fetch(`/api/music/tracks/${track.id}/fast-details`)
        .then(r => r.json())
        .then((d) => {
          if (d?.success && d.data) {
            setTrackDetails((prev: any) => ({
              ...(prev || {}),
              ...d.data,
              title: d.data.title || prev?.title || track.title,
              artists: d.data.artists || prev?.artists,
              performer: d.data.performer || prev?.performer,
              label: (d.data.label && d.data.label !== 'Не указан') ? d.data.label : (prev?.label || 'Не указан'),
              phonogramSource: (d.data.phonogramSource && d.data.phonogramSource !== 'Не указан') ? d.data.phonogramSource : (prev?.phonogramSource || 'Не указан'),
              copyright: (d.data.copyright && d.data.copyright !== 'Не указан') ? d.data.copyright : (prev?.copyright || 'Не указан'),
              isrc: d.data.isrc || prev?.isrc,
              upc: d.data.upc || prev?.upc,
              authorsMusic: d.data.authorsMusic || prev?.authorsMusic,
              authorsText: d.data.authorsText || prev?.authorsText,
            }));
          }
        })
        .catch(() => {});
    }
  }, [track?.id, albumArtists, albumCover]);

  const playPromiseRef = useRef<Promise<void> | null>(null);

  // Sync Media Session API (Bluetooth headset buttons, Apple Watch, lock screen)
  useEffect(() => {
    const dTitle = track?.title || "Unknown Track";
    const dArtists = albumArtists || (typeof track?.artists === "string" ? track.artists : track?.artists?.map((a:any)=>a.name).join(", ")) || "Unknown Artist";
    let cUrl = (albumCover || track?.coverUri || "").replace('%%', '400x400');
    if (cUrl && !cUrl.startsWith('http')) cUrl = 'https://' + cUrl;

    audioOutputManager.updateMediaSession(
      {
        title: dTitle,
        artist: dArtists,
        album: trackDetails?.label || "Yandex Music",
        artworkUrl: cUrl,
      },
      {
        onPlay: () => setIsPlaying(true),
        onPause: () => setIsPlaying(false),
        onNext: onNext ? () => onNext() : undefined,
        onPrevious: onPrevious ? () => onPrevious() : undefined,
        onSeekTo: (time) => {
          if (audioRef.current && duration) {
            audioRef.current.currentTime = time;
            setCurrentTime(time);
          }
        },
        onSeekForward: () => {
          if (audioRef.current) {
            audioRef.current.currentTime = Math.min(duration, audioRef.current.currentTime + 10);
          }
        },
        onSeekBackward: () => {
          if (audioRef.current) {
            audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
          }
        },
      }
    );
  }, [track?.id, track?.title, albumArtists, albumCover, onNext, onPrevious, duration, trackDetails]);

  useEffect(() => {
    audioOutputManager.setPlaybackState(isPlaying ? "playing" : "paused");
  }, [isPlaying]);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioEqualizer.resumeAudioContext();
        const promise = audioRef.current.play();
        playPromiseRef.current = promise;
        if (promise !== undefined) {
          promise.catch((e) => {
             if (e.name !== 'AbortError' && e.name !== 'NotAllowedError' && e.name !== 'NotSupportedError') {
                 console.error("Play error:", e?.message || String(e));
             }
             setIsPlaying(false);
          });
        }
      } else {
        if (playPromiseRef.current !== undefined && playPromiseRef.current !== null) {
          playPromiseRef.current.then(() => {
            audioRef.current?.pause();
          }).catch(() => {
            audioRef.current?.pause();
          });
        } else {
          audioRef.current.pause();
        }
      }
    }
  }, [isPlaying, src]);

  useEffect(() => {
    let animationFrameId: number;
    const updateTime = () => {
      if (audioRef.current && isPlaying) {
        const a = audioRef.current;
        const now = performance.now();
        
        // High-precision lyric sync (sub-100ms)
        if (syncLyrics && syncLyrics.length > 0) {
          let newIdx = -1;
          for (let i = 0; i < syncLyrics.length; i++) {
            if (a.currentTime >= syncLyrics[i].time) {
              newIdx = i;
            } else {
              break;
            }
          }
          if (newIdx !== activeLyricIdxRef.current) {
            activeLyricIdxRef.current = newIdx;
            setActiveLyricIdx(newIdx);
          }
        }

        // Throttle React state updates for time and progress to ~20fps (50ms) to reduce render lag
        if (now - lastUpdateRef.current > 50) {
          setCurrentTime(a.currentTime);
          setProgress((a.currentTime / (a.duration || 1)) * 100 || 0);
          audioOutputManager.setPositionState({
            duration: a.duration || 0,
            position: a.currentTime,
            playbackRate: a.playbackRate || 1.0,
          });
          lastUpdateRef.current = now;
        }
        
        animationFrameId = requestAnimationFrame(updateTime);
      }
    };
    if (isPlaying) {
        animationFrameId = requestAnimationFrame(updateTime);
    }
    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [isPlaying, syncLyrics]);

  // Fetch lyrics
  const activeLyricRef = useRef<HTMLParagraphElement>(null);
  const [activeLyricIdx, setActiveLyricIdx] = useState(-1);
  const activeLyricIdxRef = useRef(-1);
  const lastUpdateRef = useRef(0);



  useEffect(() => {
    if (activeLyricRef.current) {
      activeLyricRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [activeLyricIdx, isModalOpen]);

  useEffect(() => {
    if (track?.id) {
      setLyrics(null);
      setSyncLyrics([]);
      setActiveLyricIdx(-1);
      activeLyricIdxRef.current = -1;
      fetch("/api/music/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: `tracks/${track.id}/supplement` })
      })
      .then(async res => {
         const text = await res.text();
         try { return JSON.parse(text); } catch(e) { throw new Error(text); }
      })
      .then(data => {
         const l = data?.result?.lyrics;
         if (l?.hasRights) {
            setLyrics(l.fullLyrics);
         } else if (l?.syncLyrics) {
             const lines = parseLrc(l.syncLyrics);
             setSyncLyrics(lines);
         } else if (l?.fullLyrics) {
             setLyrics(l.fullLyrics);
         } else if (l?.textLanguage) {
             setLyrics("Текст недоступен / Lyrics not available");
         } else {
             // Fallback to lrclib
             fetch(`https://lrclib.net/api/search?track_name=${encodeURIComponent(track.title)}&artist_name=${encodeURIComponent(albumArtists || "")}`)
               .then(async res => {
                 const text = await res.text();
                 if (!res.ok) throw new Error(text || "Error");
                 try {
                   return JSON.parse(text);
                 } catch(e) {
                   throw new Error("Invalid JSON: " + text);
                 }
               })
               .then(lrclibData => {
                 if (lrclibData && lrclibData.length > 0) {
                   const bestMatch = lrclibData[0];
                   if (bestMatch.syncedLyrics) {
                     setSyncLyrics(parseLrc(bestMatch.syncedLyrics));
                     setLyrics(null);
                   } else if (bestMatch.plainLyrics) {
                     setLyrics(bestMatch.plainLyrics);
                     setSyncLyrics([]);
                   } else {
                     setLyrics("Текст не найден / Lyrics not found");
                     setSyncLyrics([]);
                   }
                 } else {
                   setLyrics("Текст не найден / Lyrics not found");
                 }
               })
               .catch(() => {
                 setLyrics("Текст не найден / Lyrics not found");
               });
         }
      })
      .catch(e => console.error("Caught error:", e.message || "Unknown error"));
    }
  }, [track?.id]);

  const parseLrc = (lrc: string) => {
    const lines = lrc.split('\n');
    const parsed = [];
    for (const line of lines) {
      const match = line.match(/\[(\d+):(\d+(?:\.\d+)?)\](.*)/);
      if (match) {
        const min = parseInt(match[1]);
        const sec = parseFloat(match[2]);
        const time = (min * 60) + sec - 0.8;
        if (!isNaN(time)) {
          parsed.push({ time: Math.max(0, time), text: match[3].trim() });
        }
      }
    }
    return parsed;
  };

  const togglePlay = (e?: any) => {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (e: any) => {
    if (audioRef.current && duration) {
       const newTime = (parseFloat(e.target.value) / 100) * duration;
       audioRef.current.currentTime = newTime;
       setCurrentTime(newTime);
       setProgress(e.target.value);
    }
  };

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const displayTitle = track?.title || "Unknown Track";
  const displayArtists = albumArtists || (typeof track?.artists === "string" ? track.artists : track?.artists?.map((a:any)=>a.name).join(", ")) || "Unknown Artist";
  let coverUrl = (albumCover || track?.coverUri || "").replace('%%', '400x400');
  if (coverUrl && !coverUrl.startsWith('http')) coverUrl = 'https://' + coverUrl;

  let finalArtistAvatar = artistAvatarUri;
  if (finalArtistAvatar && !finalArtistAvatar.startsWith('http')) finalArtistAvatar = 'https://' + finalArtistAvatar;


  const collapsedPlayer = (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl border-t border-zinc-200 dark:border-white/10 p-4 animate-in slide-in-from-bottom-10" onClick={() => setIsModalOpen(true)}>
      <audio 
         ref={audioRef} 
         src={src || undefined}  
         autoPlay={true}
         onPlay={() => setIsPlaying(true)}
         onPause={() => setIsPlaying(false)}
 
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
        onEnded={() => {
          setIsPlaying(false);
          if (onNext) onNext();
        }}
        onError={() => {
          setIsPlaying(false);
          if (onNext) {
            setTimeout(onNext, 2500);
          }
        }}
      />
      <div className="flex items-center justify-between max-w-7xl mx-auto gap-4 cursor-pointer">
        <div className="flex items-center gap-3 w-1/3">
          <ProxyImage src={coverUrl || "https://music.yandex.ru/blocks/playlist-cover/playlist-cover_like.png"} alt="Cover" className="w-12 h-12 rounded-lg object-cover shadow-sm" />
          <div className="truncate">
            <div className="font-semibold text-zinc-900 dark:text-zinc-50 truncate">{displayTitle}</div>
            <div className="text-xs text-zinc-500 truncate">{displayArtists}</div>
          </div>
        </div>
        <div className="flex flex-col items-center flex-1 w-1/3 max-w-md" onClick={e => e.stopPropagation()}>
          <div className="flex items-center gap-4">
            <button onClick={togglePlay} className="w-10 h-10 rounded-full bg-zinc-900 dark:bg-white text-white dark:text-black flex items-center justify-center hover:scale-105 transition-transform">
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-1" />}
            </button>
            {onNext && (
              <button onClick={onNext} className="text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors">
                <SkipForward className="w-5 h-5" />
              </button>
            )}
          </div>
          <div className="w-full flex items-center gap-2 mt-2 text-xs text-zinc-400">
            <span>{formatTime(currentTime)}</span>
            <div className="h-1.5 flex-1 bg-zinc-200 dark:bg-white/10 rounded-full overflow-hidden cursor-pointer" onClick={(e) => {               if (audioRef.current && duration) {                 const rect = e.currentTarget.getBoundingClientRect();                 const x = e.clientX - rect.left;                 audioRef.current.currentTime = (x / rect.width) * duration;               }            }}>
              <div className="h-full bg-blue-500 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        <div className="w-1/3 flex items-center justify-end gap-1 sm:gap-2" onClick={e => e.stopPropagation()}>
           {/* Equalizer Quick Button */}
           <button
             title="Эквалайзер и тонкая настройка"
             onClick={() => setIsEqualizerOpen(true)}
             className="p-2 text-zinc-500 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-purple-500/10 rounded-full transition-colors"
           >
             <Sliders className="w-5 h-5" />
           </button>

           {/* Bluetooth / Output Device Quick Button */}
           <button
             title="Bluetooth и Устройства вывода"
             onClick={() => setIsBluetoothOpen(true)}
             className={`p-2 rounded-full transition-colors relative ${
               activeDevice?.isBluetooth
                 ? 'text-blue-500 hover:bg-blue-500/10'
                 : 'text-zinc-500 hover:text-blue-500 hover:bg-blue-500/10'
             }`}
           >
             {activeDevice?.isBluetooth ? (
               <Bluetooth className="w-5 h-5" />
             ) : (
               <Headphones className="w-5 h-5" />
             )}
             {activeDevice?.isBluetooth && (
               <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 rounded-full ring-2 ring-zinc-900 animate-pulse" />
             )}
           </button>

           <button onClick={(e) => { e.stopPropagation(); setIsModalOpen(true); }} className="p-2 text-zinc-400 hover:text-zinc-900 dark:hover:text-white">
             <Maximize2 className="w-5 h-5" />
           </button>
        </div>
      </div>
    </div>
  );

  
  const expandedModal = isModalOpen && typeof document !== 'undefined' ? createPortal(
      <div className="fixed inset-0 z-[9999] bg-[#111111] animate-in slide-in-from-bottom-full duration-300 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-12 pb-4">
          <button onClick={() => setIsModalOpen(false)} className="text-zinc-400 hover:text-white transition-colors p-2 -ml-2">
            <ChevronDown className="w-8 h-8" />
          </button>
          <div className="flex flex-col items-center">
            <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Моя волна</span>
          </div>
          <div className="flex items-center gap-1 -mr-2">
            <button
              onClick={() => setIsEqualizerOpen(true)}
              title="Эквалайзер"
              className="p-2 text-zinc-400 hover:text-purple-400 hover:bg-purple-500/10 rounded-full transition-colors"
            >
              <Sliders className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsBluetoothOpen(true)}
              title="Bluetooth и Вывод"
              className={`p-2 rounded-full transition-colors relative ${
                activeDevice?.isBluetooth ? 'text-blue-400' : 'text-zinc-400 hover:text-blue-400'
              }`}
            >
              {activeDevice?.isBluetooth ? (
                <Bluetooth className="w-5 h-5" />
              ) : (
                <Headphones className="w-5 h-5" />
              )}
              {activeDevice?.isBluetooth && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-blue-400 rounded-full ring-2 ring-[#111] animate-pulse" />
              )}
            </button>
            <button onClick={() => setIsMenuOpen(true)} className="text-zinc-400 hover:text-white transition-colors p-2">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
            </button>
          </div>
        </div>

        
      {isMenuOpen && (
        <div className="absolute inset-0 z-[10000] bg-[#111] animate-in fade-in flex flex-col">
          <div className="flex items-center justify-between p-6">
            <h2 className="text-xl font-bold text-white">Инфо и Действия</h2>
            <button onClick={() => setIsMenuOpen(false)} className="text-zinc-400 hover:text-white">
              <ChevronDown className="w-8 h-8" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-6 pb-8 space-y-6">
             {/* Sound Tools */}
             <div className="grid grid-cols-2 gap-3">
               <button
                 onClick={() => {
                   setIsMenuOpen(false);
                   setIsEqualizerOpen(true);
                 }}
                 className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex flex-col items-start gap-2 hover:bg-zinc-800 transition-colors text-left"
               >
                 <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400">
                   <Sliders className="w-5 h-5" />
                 </div>
                 <div>
                   <div className="font-bold text-white text-sm">Эквалайзер</div>
                   <div className="text-[11px] text-zinc-400">10 полос & 3D бас</div>
                 </div>
               </button>

               <button
                 onClick={() => {
                   setIsMenuOpen(false);
                   setIsBluetoothOpen(true);
                 }}
                 className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex flex-col items-start gap-2 hover:bg-zinc-800 transition-colors text-left"
               >
                 <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400">
                   <Bluetooth className="w-5 h-5" />
                 </div>
                 <div>
                   <div className="font-bold text-white text-sm">Bluetooth & Вывод</div>
                   <div className="text-[11px] text-zinc-400">{activeDevice?.label || 'Динамик'}</div>
                 </div>
               </button>
             </div>

             {/* Download actions */}
             <div className="space-y-3">
                <button 
                  onClick={() => {
                    if (track?.id) {
                      downloadWavTrack({
                        trackId: String(track.id),
                        title: track.title,
                        artists: albumArtists || (typeof track.artists === 'string' ? track.artists : track.artists?.map((a: any) => a.name).join(', ')),
                        coverUri: albumCover || track.coverUri,
                      });
                    }
                  }}
                  disabled={isDownloadingWav}
                  id="btn-download-wav"
                  className="w-full py-4 bg-white text-black font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-200 disabled:opacity-50"
                >
                  {isDownloadingWav ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                      <span>Конвертация и скачивание...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5" />
                      <span>Скачать WAV</span>
                    </>
                  )}
                </button>
                {coverUrl && (
                  <button 
                    onClick={(e) => {
                      const btn = e.currentTarget;
                      const originalText = btn.innerHTML;
                      btn.innerHTML = '<svg class="animate-spin w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Обработка...';
                      btn.style.pointerEvents = 'none';

                      const dlUrl = `/api/music/proxy-image?url=${encodeURIComponent(coverUrl.replace('400x400', '1000x1000').replace('%%', '1000x1000'))}`;
                      const img = new Image();
                      img.crossOrigin = "anonymous";
                      img.onload = () => {
                         const canvas = document.createElement('canvas');
                         canvas.width = 3000;
                         canvas.height = 3000;
                         const ctx = canvas.getContext('2d');
                         if (ctx) {
                           ctx.imageSmoothingEnabled = true;
                           ctx.imageSmoothingQuality = 'high';
                           ctx.drawImage(img, 0, 0, 3000, 3000);
                           canvas.toBlob((blob) => {
                               if (blob) {
                                   const url = URL.createObjectURL(blob);
                                   const a = document.createElement('a');
                                   a.href = url;
                                   a.download = `${(track?.title || 'cover').replace(/[^a-zA-Z0-9а-яА-Я]/g, '_')}_3000x3000.jpg`;
                                   document.body.appendChild(a);
                                   a.click();
                                   document.body.removeChild(a);
                                   URL.revokeObjectURL(url);
                               }
                               btn.innerHTML = originalText;
                               btn.style.pointerEvents = 'auto';
                           }, 'image/jpeg', 1.0);
                         } else {
                           btn.innerHTML = originalText;
                           btn.style.pointerEvents = 'auto';
                         }
                      };
                      img.onerror = () => {
                          alert('Не удалось загрузить обложку в высоком качестве');
                          btn.innerHTML = originalText;
                          btn.style.pointerEvents = 'auto';
                      };
                      img.src = dlUrl;
                    }}
                    className="w-full py-4 bg-zinc-800 text-white font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-700"
                  >
                    <Download className="w-5 h-5" /> Скачать Обложку (3000x3000)
                  </button>
                )}
             </div>
             
             {/* Track details */}
             <div className="space-y-4 pt-4 border-t border-zinc-800">
               <h3 className="text-sm font-semibold text-zinc-500 uppercase">Данные трека</h3>
               {!trackDetails ? (
                  <div className="text-zinc-400 animate-pulse">Загрузка данных...</div>
               ) : (
                   <div className="space-y-3 text-sm">
                      <div className="flex flex-col">
                         <span className="text-zinc-500">Исполнитель (Псевдоним)</span>
                         <span className="text-zinc-300">{trackDetails.performer || displayArtists || 'Не указан'}</span>
                      </div>
                      <div className="flex flex-col bg-white/[0.02] border border-amber-500/20 rounded-lg p-2.5">
                         <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-zinc-500 text-xs">Лейбл / Дистрибьютор</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-medium border border-amber-500/30">в переработке</span>
                         </div>
                         <span className="text-zinc-300 text-xs">
                            {(trackDetails as any)?.distributor ? (
                               <span><span className="text-zinc-500">Дистрибьютор:</span> {(trackDetails as any).distributor}</span>
                            ) : trackDetails.label && trackDetails.label !== "No label" && trackDetails.label !== "Не указан" ? (
                               <span><span className="text-zinc-500">Дистрибьютор/Лейбл:</span> {trackDetails.label}</span>
                            ) : (
                               <span className="text-amber-400/80 italic">В переработке (поиск дистрибьютора)</span>
                            )}
                         </span>
                      </div>
                      <div className="flex flex-col">
                         <span className="text-zinc-500">Источник фонограммы</span>
                         <span className="text-zinc-300">{trackDetails.phonogramSource && trackDetails.phonogramSource !== "No phonogram source" ? trackDetails.phonogramSource : (trackDetails.label && trackDetails.label !== "No label" ? trackDetails.label : 'Не указан')}</span>
                      </div>
                      <div className="flex flex-col">
                         <span className="text-zinc-500">Автор музыки трека</span>
                         <span className="text-zinc-300">{trackDetails.authorsMusic || 'Не указан'}</span>
                      </div>
                      <div className="flex flex-col">
                         <span className="text-zinc-500">Автор текста</span>
                         <span className="text-zinc-300">{trackDetails.authorsText || 'Не указан'}</span>
                      </div>
                      <div className="flex flex-col">
                         <span className="text-zinc-500">UPC</span>
                         <span className="text-zinc-300 font-mono">{trackDetails.upc || 'Не указан'}</span>
                      </div>
                      <div className="flex flex-col">
                         <span className="text-zinc-500">ISRC</span>
                         <span className="text-zinc-300 font-mono">{trackDetails.isrc || 'Не указан'}</span>
                      </div>
                      <div className="flex flex-col bg-white/[0.02] border border-amber-500/20 rounded-lg p-2.5">
                         <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-zinc-500 text-xs">Копирайт / Правообладатель</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-medium border border-amber-500/30">в переработке</span>
                         </div>
                         <div className="flex flex-col gap-1 mt-0.5">
                            {(() => {
                               const hasRealCopyright = trackDetails?.copyright && !isPlaceholderCopyright(trackDetails.copyright);
                               const hasOkCopyright = okRuCheckStatus.copyright && !isPlaceholderCopyright(okRuCheckStatus.copyright);
                               const copyrightVal = hasOkCopyright
                                 ? okRuCheckStatus.copyright
                                 : (hasRealCopyright ? trackDetails.copyright : '');
                               return (
                                 <span className="text-zinc-300 text-xs font-mono select-all break-all">
                                   {copyrightVal && copyrightVal !== 'Не указан' ? (
                                     <span><span className="text-zinc-500 font-sans">Правообладатель:</span> {copyrightVal}</span>
                                   ) : (
                                     <span className="text-amber-400/80 italic font-sans">В переработке (поиск правообладателя)</span>
                                   )}
                                 </span>
                               );
                            })()}
                         </div>
                      </div>
                   </div>
               )}
             </div>
          </div>
        </div>
      )}

        {/* Cover Art / Lyrics */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 min-h-0 relative py-4">
          {!isLyricsOpen ? (
            <div className="w-full max-w-[340px] aspect-square rounded-[2rem] overflow-hidden shadow-2xl relative group bg-zinc-800">
              <ProxyImage src={coverUrl || "https://music.yandex.ru/blocks/playlist-cover/playlist-cover_like.png"} alt={displayTitle} className="w-full h-full object-cover" />
              <button 
                onClick={() => setIsLyricsOpen(true)}
                className="absolute top-4 right-4 p-2 bg-black/40 backdrop-blur-md rounded-full text-white/70 hover:text-white transition-colors opacity-0 group-hover:opacity-100 sm:opacity-100"
              >
                <Maximize2 className="w-5 h-5" />
              </button>
            </div>
          ) : (
             <div className={`w-full h-full flex flex-col relative mx-auto bg-zinc-900/50 overflow-hidden transition-all duration-300 ${isLyricsFullScreen ? 'max-w-full rounded-none p-8' : 'max-w-[340px] rounded-[2rem] p-6'}`} onClick={() => !isLyricsFullScreen && setIsLyricsFullScreen(true)}>
                <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setIsLyricsFullScreen(!isLyricsFullScreen); }}
                    className="p-2 text-zinc-400 hover:text-white transition-colors bg-black/40 rounded-full"
                  >
                    {isLyricsFullScreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setIsLyricsOpen(false); setIsLyricsFullScreen(false); }}
                    className="p-2 text-zinc-400 hover:text-white transition-colors bg-black/40 rounded-full"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto text-center pt-8 pb-4 relative mask-image-y">
                   {syncLyrics && syncLyrics.length > 0 ? (
                      <div className="flex flex-col gap-6 py-[50%]">
                         {syncLyrics.map((line, idx) => (
                            <p key={idx} 
                               className={`text-2xl sm:text-3xl font-bold transition-all duration-300 ${idx === activeLyricIdx ? 'text-white scale-105' : 'text-zinc-500 scale-100'}`}
                               ref={idx === activeLyricIdx ? activeLyricRef : null}
                            >
                               {line.text || '...'}
                            </p>
                         ))}
                      </div>
                   ) : lyrics ? (
                     <div className="text-xl sm:text-2xl font-bold text-white/90 whitespace-pre-wrap leading-relaxed">{lyrics}</div>
                   ) : (
                     <div className="text-lg text-zinc-500 flex items-center justify-center h-full">Текст отсутствует</div>
                   )}
                </div>
             </div>
          )}
        </div>

        {/* Track Info */}
        {!isLyricsFullScreen && (<>
        <div className="px-6 pb-6 pt-2 flex items-center justify-between max-w-lg w-full mx-auto">
           <div className="flex items-center gap-3 min-w-0">
             {artistAvatarUri && (
               <ProxyImage src={finalArtistAvatar} alt={displayArtists || undefined} className="w-[42px] h-[42px] rounded-full object-cover shadow-sm shrink-0" />
             )}
             <div className="flex flex-col min-w-0">
               <h2 className="text-[22px] font-extrabold text-white truncate tracking-tight">{displayTitle}</h2>
               <p className="text-zinc-400 text-[15px] font-medium truncate">{displayArtists}</p>
             </div>
           </div>
        </div>

        {/* Progress */}
        <div className="px-6 max-w-lg w-full mx-auto mb-8">
           <div className="relative w-full h-1 bg-zinc-800 rounded-full flex items-center group cursor-pointer"
           >
             <input 
                type="range" 
                min="0" 
                max="100" 
                value={progress || 0} 
                onChange={handleSeek}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
             />
             <div className="absolute left-0 top-0 h-full bg-white rounded-full pointer-events-none" style={{ width: `${progress}%` }}></div>
             <div className="absolute h-3 w-3 bg-white rounded-full pointer-events-none shadow-md" style={{ left: `calc(${progress}% - 6px)` }}></div>
           </div>
           <div className="flex justify-between mt-3 text-[11px] font-medium text-zinc-500">
             <span>{formatTime(currentTime)}</span>
             <span>-{formatTime(duration - currentTime)}</span>
           </div>
        </div>

        {/* Controls */}
        <div className="px-6 pb-12 max-w-lg w-full mx-auto flex items-center justify-between">
           <button
             onClick={() => setIsEqualizerOpen(true)}
             title="Эквалайзер"
             className="text-zinc-500 hover:text-purple-400 transition-colors p-2"
           >
             <Sliders className="w-5 h-5" />
           </button>
           <button
             onClick={() => onPrevious && onPrevious()}
             className={`transition-colors p-2 ${onPrevious ? 'text-white hover:text-zinc-300' : 'text-zinc-600 cursor-not-allowed'}`}
           >
             <SkipBack className="w-8 h-8" fill="currentColor" />
           </button>
           <button 
             onClick={(e) => { e.preventDefault(); e.stopPropagation(); togglePlay(); }}
             className="w-16 h-16 rounded-full bg-zinc-800 text-white flex items-center justify-center hover:scale-105 transition-transform shadow-lg shadow-black/40"
           >
             {isPlaying ? (
               <Pause className="w-8 h-8" fill="currentColor" />
             ) : (
               <Play className="w-8 h-8 ml-1" fill="currentColor" />
             )}
           </button>
           <button onClick={() => onNext && onNext()} className={`transition-colors p-2 ${onNext ? 'text-white hover:text-zinc-300' : 'text-zinc-600 cursor-not-allowed'}`}>
             <SkipForward className="w-8 h-8" fill="currentColor" />
           </button>
           <button
             onClick={() => setIsBluetoothOpen(true)}
             title="Bluetooth & Вывод"
             className={`p-2 transition-colors relative ${activeDevice?.isBluetooth ? 'text-blue-400' : 'text-zinc-500 hover:text-white'}`}
           >
             {activeDevice?.isBluetooth ? (
               <Bluetooth className="w-5 h-5" />
             ) : (
               <Headphones className="w-5 h-5" />
             )}
             {activeDevice?.isBluetooth && (
               <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-400 rounded-full animate-pulse ring-2 ring-[#111]" />
             )}
           </button>
        </div>
        </>
        )}
    </div>
  , document.body) : null;


  return (
    <>
      {collapsedPlayer}
      {expandedModal}

      {/* Equalizer & Fine Tuning Modal */}
      <EqualizerModal
        isOpen={isEqualizerOpen}
        onClose={() => setIsEqualizerOpen(false)}
      />

      {/* Bluetooth & Output Devices Modal */}
      <BluetoothOutputModal
        isOpen={isBluetoothOpen}
        onClose={() => setIsBluetoothOpen(false)}
      />
    </>
  );
}
