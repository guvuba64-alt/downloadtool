import React, { useEffect, useState } from 'react';
import {
  audioOutputManager,
  AudioOutputDevice,
} from '../utils/audioOutputManager';
import {
  Headphones,
  Speaker,
  Bluetooth,
  Laptop,
  Check,
  X,
  Volume2,
  RefreshCw,
  Info,
  Radio,
  Sparkles,
} from 'lucide-react';

interface BluetoothOutputModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BluetoothOutputModal({ isOpen, onClose }: BluetoothOutputModalProps) {
  const [devices, setDevices] = useState<AudioOutputDevice[]>([]);
  const [activeDeviceId, setActiveDeviceId] = useState<string>('default');
  const [isScanning, setIsScanning] = useState(false);
  const [hasPermission, setHasPermission] = useState(true);

  useEffect(() => {
    return audioOutputManager.subscribe((devs, activeId) => {
      setDevices(devs);
      setActiveDeviceId(activeId);
    });
  }, []);

  const handleScan = async () => {
    setIsScanning(true);
    const granted = await audioOutputManager.requestPermissions();
    setHasPermission(granted);
    await audioOutputManager.refreshDevices();
    setIsScanning(false);
  };

  const handleSelectDevice = async (deviceId: string) => {
    await audioOutputManager.setDevice(deviceId);
    audioOutputManager.playTestChime();
  };

  if (!isOpen) return null;

  const getDeviceIcon = (device: AudioOutputDevice) => {
    if (device.type === 'bluetooth' || device.isBluetooth) {
      return <Bluetooth className="w-5 h-5 text-blue-400" />;
    }
    if (device.type === 'headphones') {
      return <Headphones className="w-5 h-5 text-purple-400" />;
    }
    if (device.type === 'speaker' || device.type === 'usb') {
      return <Speaker className="w-5 h-5 text-emerald-400" />;
    }
    return <Laptop className="w-5 h-5 text-zinc-400" />;
  };

  return (
    <div className="fixed inset-0 z-[10005] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-3xl w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Bluetooth className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Bluetooth и Устройства вывода
              </h2>
              <p className="text-xs text-zinc-400">
                Наушники, беспроводные колонки, гарнитуры и динамики
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Device List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-blue-400" />
              Доступные аудиоустройства ({devices.length})
            </span>
            <button
              onClick={handleScan}
              disabled={isScanning}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              {isScanning ? 'Поиск...' : 'Обновить список'}
            </button>
          </div>

          <div className="space-y-2.5">
            {devices.map((device) => {
              const isSelected = activeDeviceId === device.deviceId;
              return (
                <div
                  key={device.deviceId}
                  onClick={() => handleSelectDevice(device.deviceId)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-600/10 border-blue-500/50 shadow-lg shadow-blue-500/10'
                      : 'bg-zinc-900/60 border-zinc-800/80 hover:bg-zinc-900 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                          : 'bg-zinc-800/80 text-zinc-400'
                      }`}
                    >
                      {getDeviceIcon(device)}
                    </div>
                    <div className="truncate">
                      <div className="font-semibold text-white text-sm truncate flex items-center gap-2">
                        {device.label || 'Аудиоустройство'}
                        {device.isBluetooth && (
                          <span className="px-1.5 py-0.2 text-[9px] font-bold rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                            BT
                          </span>
                        )}
                        {device.isDefault && (
                          <span className="px-1.5 py-0.2 text-[9px] font-bold rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                            По умолч.
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-zinc-500 truncate">
                        {device.isBluetooth
                          ? 'Беспроводное соединение Bluetooth'
                          : device.type === 'headphones'
                          ? 'Проводные или системные наушники'
                          : 'Системный вывод аудиопотока'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center shadow-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Test Chime and Pairing Info Box */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                Проверка звука на выбранном устройстве
              </span>
              <button
                onClick={() => audioOutputManager.playTestChime()}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Тестовый сигнал
              </button>
            </div>

            <div className="p-3 bg-zinc-950/70 border border-zinc-800/50 rounded-xl flex items-start gap-2.5 text-xs text-zinc-400">
              <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                Подключите ваши Bluetooth наушники или колонку в настройках операционной системы (Windows, macOS, Android, iOS), затем нажмите <span className="text-blue-300 font-semibold">«Обновить список»</span>. Кнопки воспроизведения и переключения треков на Bluetooth гарнитуре поддерживаются нативно через MediaSession API.
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-zinc-800/80 flex items-center justify-end bg-zinc-900/30">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-white text-black font-bold rounded-xl text-sm hover:bg-zinc-200 transition-colors shadow-lg"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
}
