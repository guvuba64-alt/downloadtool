import React, { useState, useMemo } from "react";
import { ArtistEntity, ReleaseEntity, ReleaseType, TrackEntity } from "./types";
import { useAudioPreview } from "./useAudioPreview";
import {
  Search,
  Filter,
  CheckSquare,
  Square,
  ChevronDown,
  ChevronUp,
  Disc,
  Music,
  ArrowRight,
  ArrowLeft,
  Check,
  Layers,
  Sparkles,
  Calendar,
  Clock,
  Play,
  Pause,
  Volume2,
  PlusCircle,
  SlidersHorizontal,
  X,
  Plus,
  Edit3,
  RotateCcw,
  Tag
} from "lucide-react";

interface Step2CatalogSelectProps {
  artist: ArtistEntity;
  artists?: ArtistEntity[];
  releases: ReleaseEntity[];
  selectedReleaseIds: Set<string>;
  selectedTrackIdsMap: Record<string, Set<string>>;
  onSelectionChange: (
    newSelectedReleaseIds: Set<string>,
    newSelectedTrackIdsMap: Record<string, Set<string>>
  ) => void;
  onAddCustomRelease?: (release: ReleaseEntity) => void;
  onBatchUpdateReleases?: (updates: { label?: string; year?: string }) => void;
  onOpenReleaseDatesModal?: () => void;
  onNext: () => void;
  onBack: () => void;
  t: (en: string, ru: string) => string;
}

export function Step2CatalogSelect({
  artist,
  artists,
  releases,
  selectedReleaseIds,
  selectedTrackIdsMap,
  onSelectionChange,
  onAddCustomRelease,
  onBatchUpdateReleases,
  onOpenReleaseDatesModal,
  onNext,
  onBack,
  t
}: Step2CatalogSelectProps) {
  const [filterType, setFilterType] = useState<"all" | ReleaseType>("all");
  const [scopeFilter, setScopeFilter] = useState<"all" | "direct" | "collab">("all");
  const [selectedArtistFilter, setSelectedArtistFilter] = useState<string>("all");
  const [yearFilter, setYearFilter] = useState<string>("all");
  const [sortMode, setSortMode] = useState<"newest" | "oldest" | "tracks" | "title">("newest");
  const [searchQuery, setSearchQuery] = useState("");
  // Track open release accordions for granular track selection
  const [expandedReleaseIds, setExpandedReleaseIds] = useState<Set<string>>(new Set());

  // Audio preview hook
  const { playbackState, togglePlayTrack, stopAudio } = useAudioPreview();

  // Modals state
  const [isBulkEditOpen, setIsBulkEditOpen] = useState(false);
  const [bulkLabel, setBulkLabel] = useState("");
  const [bulkYear, setBulkYear] = useState("");

  const [isAddReleaseOpen, setIsAddReleaseOpen] = useState(false);
  const [newReleaseTitle, setNewReleaseTitle] = useState("");
  const [newReleaseType, setNewReleaseType] = useState<ReleaseType>("single");
  const [newReleaseYear, setNewReleaseYear] = useState(new Date().getFullYear().toString());
  const [newReleaseLabel, setNewReleaseLabel] = useState("");
  const [newReleaseTracks, setNewReleaseTracks] = useState("");

  // Pagination / slice size for smooth performance with large catalogs (100+ items)
  const [visibleCount, setVisibleCount] = useState(24);

  // Toggle single release selection
  const toggleRelease = (releaseId: string) => {
    const nextReleases = new Set(selectedReleaseIds);
    const nextTrackMap = { ...selectedTrackIdsMap };
    const rel = releases.find((r) => r.release_id === releaseId);

    if (!rel) return;

    if (nextReleases.has(releaseId)) {
      // Deselect release
      nextReleases.delete(releaseId);
      delete nextTrackMap[releaseId];
    } else {
      // Select release and all its tracks
      nextReleases.add(releaseId);
      nextTrackMap[releaseId] = new Set(rel.tracks.map((t) => t.track_id));
    }

    onSelectionChange(nextReleases, nextTrackMap);
  };

  // Toggle individual track selection inside an accordion
  const toggleTrack = (releaseId: string, trackId: string) => {
    const nextReleases = new Set(selectedReleaseIds);
    const nextTrackMap = { ...selectedTrackIdsMap };
    const rel = releases.find((r) => r.release_id === releaseId);
    if (!rel) return;

    const currentTracks = new Set(nextTrackMap[releaseId] || []);
    if (currentTracks.has(trackId)) {
      currentTracks.delete(trackId);
    } else {
      currentTracks.add(trackId);
    }

    if (currentTracks.size === 0) {
      nextReleases.delete(releaseId);
      delete nextTrackMap[releaseId];
    } else {
      nextReleases.add(releaseId);
      nextTrackMap[releaseId] = currentTracks;
    }

    onSelectionChange(nextReleases, nextTrackMap);
  };

  // Select all tracks in a release
  const selectAllTracksInRelease = (releaseId: string) => {
    const rel = releases.find((r) => r.release_id === releaseId);
    if (!rel) return;
    const nextReleases = new Set(selectedReleaseIds);
    const nextTrackMap = { ...selectedTrackIdsMap };

    nextReleases.add(releaseId);
    nextTrackMap[releaseId] = new Set(rel.tracks.map((t) => t.track_id));
    onSelectionChange(nextReleases, nextTrackMap);
  };

  // Toggle accordion expand
  const toggleExpand = (releaseId: string) => {
    setExpandedReleaseIds((prev) => {
      const next = new Set(prev);
      if (next.has(releaseId)) next.delete(releaseId);
      else next.add(releaseId);
      return next;
    });
  };

  // Batch actions
  const selectAll = () => {
    const nextReleases = new Set<string>();
    const nextTrackMap: Record<string, Set<string>> = {};

    releases.forEach((rel) => {
      nextReleases.add(rel.release_id);
      nextTrackMap[rel.release_id] = new Set(rel.tracks.map((t) => t.track_id));
    });

    onSelectionChange(nextReleases, nextTrackMap);
  };

  const deselectAll = () => {
    onSelectionChange(new Set(), {});
  };

  const selectByType = (type: ReleaseType) => {
    const nextReleases = new Set(selectedReleaseIds);
    const nextTrackMap = { ...selectedTrackIdsMap };

    releases
      .filter((r) => {
        const matchesType = r.type === type;
        const matchesScope =
          scopeFilter === "all" ||
          (scopeFilter === "direct" ? r.is_direct !== false : r.is_direct === false);
        return matchesType && matchesScope;
      })
      .forEach((rel) => {
        nextReleases.add(rel.release_id);
        nextTrackMap[rel.release_id] = new Set(rel.tracks.map((t) => t.track_id));
      });

    onSelectionChange(nextReleases, nextTrackMap);
  };

  // Pre-calculated counts in current scope
  const scopeReleases = useMemo(() => {
    return releases.filter((r) => {
      if (scopeFilter === "direct") return r.is_direct !== false;
      if (scopeFilter === "collab") return r.is_direct === false;
      return true;
    });
  }, [releases, scopeFilter]);

  const counts = useMemo(() => {
    return {
      all: scopeReleases.length,
      album: scopeReleases.filter((r) => r.type === "album").length,
      ep: scopeReleases.filter((r) => r.type === "ep").length,
      single: scopeReleases.filter((r) => r.type === "single").length,
      compilation: scopeReleases.filter((r) => r.type === "compilation").length
    };
  }, [scopeReleases]);

  // Filtered, searched and sorted releases
  const filteredReleases = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const result = scopeReleases.filter((rel) => {
      const matchesFilter = filterType === "all" || rel.type === filterType;
      const matchesSearch =
        !q ||
        rel.title.toLowerCase().includes(q) ||
        (rel.artist_name && rel.artist_name.toLowerCase().includes(q));
      const matchesArtist =
        selectedArtistFilter === "all" ||
        (rel.artist_id && rel.artist_id === selectedArtistFilter) ||
        (rel.artist_name && rel.artist_name === selectedArtistFilter);
      const releaseYear = rel.release_date ? rel.release_date.substring(0, 4) : "";
      const matchesYear =
        yearFilter === "all" ||
        (yearFilter === "archive"
          ? parseInt(releaseYear || "2020", 10) <= 2021
          : releaseYear === yearFilter);

      return matchesFilter && matchesSearch && matchesArtist && matchesYear;
    });

    return result.sort((a, b) => {
      if (sortMode === "newest") {
        return (b.release_date || "").localeCompare(a.release_date || "");
      }
      if (sortMode === "oldest") {
        return (a.release_date || "").localeCompare(b.release_date || "");
      }
      if (sortMode === "tracks") {
        return (b.tracks?.length || 0) - (a.tracks?.length || 0);
      }
      if (sortMode === "title") {
        return a.title.localeCompare(b.title);
      }
      return 0;
    });
  }, [scopeReleases, filterType, searchQuery, sortMode, selectedArtistFilter, yearFilter]);

  // Total tracks selected count
  const totalSelectedTracksCount = useMemo(() => {
    let sum = 0;
    selectedReleaseIds.forEach((relId) => {
      const set = selectedTrackIdsMap[relId];
      if (set) sum += set.size;
    });
    return sum;
  }, [selectedReleaseIds, selectedTrackIdsMap]);

  // Bulk metadata handler
  const handleApplyBulkMetadata = () => {
    if (onBatchUpdateReleases) {
      onBatchUpdateReleases({
        label: bulkLabel.trim() || undefined,
        year: bulkYear.trim() || undefined
      });
    }
    setIsBulkEditOpen(false);
  };

  // Add custom release handler
  const handleCreateCustomRelease = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReleaseTitle.trim()) return;

    const trackNames = newReleaseTracks
      .split("\n")
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const relId = `rel_custom_${Date.now()}`;
    const generatedTracks: TrackEntity[] =
      trackNames.length > 0
        ? trackNames.map((name, i) => ({
            track_id: `trk_${relId}_${i + 1}`,
            title: name,
            duration: 180,
            position: i + 1,
            isrc: ""
          }))
        : [
            {
              track_id: `trk_${relId}_1`,
              title: newReleaseTitle.trim(),
              duration: 180,
              position: 1,
              isrc: ""
            }
          ];

    const customRel: ReleaseEntity = {
      release_id: relId,
      artist_id: artist.artist_id,
      artist_name: artist.name,
      title: newReleaseTitle.trim(),
      type: newReleaseType,
      release_date: newReleaseYear ? `${newReleaseYear}-01-01` : "2024-01-01",
      label: newReleaseLabel.trim() || artist.name,
      upc: "",
      tracks: generatedTracks
    };

    if (onAddCustomRelease) {
      onAddCustomRelease(customRel);
    }
    setIsAddReleaseOpen(false);
    setNewReleaseTitle("");
    setNewReleaseTracks("");
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 pb-24">
      {/* Header card with Artist Summary & Progress */}
      <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
              2
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-zinc-900 dark:text-zinc-50 tracking-tight">
                {t("Select releases to transfer", "Выберите релизы для переноса")}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
                {t(
                  "Choose entire albums or expand to pick specific tracks.",
                  "Выбирайте релизы целиком или разворачивайте их для выбора отдельных треков."
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto bg-zinc-100 dark:bg-zinc-800/80 px-3 py-1.5 rounded-xl text-xs font-semibold text-zinc-700 dark:text-zinc-300">
            {artist.avatar && (
              <img src={artist.avatar} alt="" className="w-5 h-5 rounded-full object-cover" />
            )}
            <span>
              {artists && artists.length > 1
                ? `${artists.length} ${t("artists in transfer", "артистов в переносе")}`
                : artist.name}
            </span>
            <span className="text-zinc-400">•</span>
            <span>{releases.length} {t("releases in catalog", "релизов в каталоге")}</span>
          </div>
        </div>

        {/* Multi-Artist Filter Bar (if 2+ artists) */}
        {artists && artists.length > 1 && (
          <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                {t("Filter by Artist:", "Фильтр по артистам:")} ({artists.length} {t("artists", "артистов")})
              </span>
              <span className="text-[11px] text-orange-500 font-semibold">
                {selectedArtistFilter === "all" ? t("Showing all", "Показаны все артисты") : selectedArtistFilter}
              </span>
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
              <button
                type="button"
                onClick={() => setSelectedArtistFilter("all")}
                className={`px-3 py-1 rounded-xl text-xs font-bold shrink-0 transition-all ${
                  selectedArtistFilter === "all"
                    ? "bg-orange-500 text-white shadow-xs"
                    : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200"
                }`}
              >
                {t("All Artists", "Все артисты")} ({releases.length})
              </button>
              {artists.map((ar) => {
                const arReleasesCount = releases.filter(
                  (r) => (r.artist_id && r.artist_id === ar.artist_id) || (r.artist_name && r.artist_name === ar.name)
                ).length;
                const isSelected = selectedArtistFilter === ar.artist_id || selectedArtistFilter === ar.name;

                return (
                  <button
                    key={ar.artist_id}
                    type="button"
                    onClick={() => setSelectedArtistFilter(isSelected ? "all" : ar.artist_id)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? "bg-orange-500 text-white shadow-xs"
                        : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200"
                    }`}
                  >
                    {ar.avatar && <img src={ar.avatar} alt="" className="w-4 h-4 rounded-full object-cover" />}
                    <span>{ar.name}</span>
                    <span className="opacity-60 text-[10px]">({arReleasesCount})</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Scope selector, Filter Tabs & Search Bar */}
        <div className="mt-5 flex flex-col gap-3 pt-4 border-t border-zinc-100 dark:border-zinc-800">
          {/* Top row: Scope Selector & Sort dropdown */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Scope segmented switch */}
            <div className="flex items-center p-1 bg-zinc-100 dark:bg-zinc-800/90 rounded-xl">
              {[
                { id: "all", label: t("All Releases", "Все релизы") },
                { id: "direct", label: t("Discography Only", "Дискография артиста") },
                { id: "collab", label: t("Features & Compilations", "Участие и сборники") }
              ].map((scope) => (
                <button
                  key={scope.id}
                  type="button"
                  onClick={() => setScopeFilter(scope.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    scopeFilter === scope.id
                      ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs"
                      : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
                  }`}
                >
                  {scope.label}
                </button>
              ))}
            </div>

            {/* Sort options */}
            <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
              <span className="text-zinc-400 font-medium">{t("Sort:", "Сортировка:")}</span>
              <select
                value={sortMode}
                onChange={(e) => setSortMode(e.target.value as any)}
                className="h-8 px-2.5 rounded-lg bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/40 cursor-pointer"
              >
                <option value="newest">{t("Newest first", "Сначала новые")}</option>
                <option value="oldest">{t("Oldest first", "Сначала старые")}</option>
                <option value="tracks">{t("Most tracks (Albums first)", "Сначала альбомы (по числу треков)")}</option>
                <option value="title">{t("Alphabetical", "По названию (А-Я)")}</option>
              </select>
            </div>
          </div>

          {/* Bottom row: Type Filter Tabs & Search Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              {[
                { id: "all", label: t("All", "Все"), count: counts.all },
                { id: "album", label: t("Albums", "Альбомы"), count: counts.album },
                { id: "ep", label: t("EP", "EP"), count: counts.ep },
                { id: "single", label: t("Singles", "Синглы"), count: counts.single },
                { id: "compilation", label: t("Compilations", "Сборники"), count: counts.compilation }
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterType(tab.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 flex items-center gap-1.5 ${
                    filterType === tab.id
                      ? "bg-orange-500 text-white shadow-sm"
                      : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700"
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      filterType === tab.id
                        ? "bg-white/20 text-white"
                        : "bg-zinc-200/80 dark:bg-zinc-700 text-zinc-600 dark:text-zinc-300"
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>

            {/* Search input */}
            <div className="relative flex-1 sm:max-w-xs">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("Search by release title...", "Поиск по названию релиза...")}
                className="w-full h-9 pl-8 pr-3 text-xs sm:text-sm rounded-lg bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
              />
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-zinc-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Year Filter Quick Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-zinc-400 font-medium mr-1 shrink-0">
            <Calendar className="w-3.5 h-3.5 inline mr-1" />
            {t("Year:", "Год:")}
          </span>
          {[
            { id: "all", label: t("All years", "Все годы") },
            { id: "2026", label: "2026" },
            { id: "2025", label: "2025" },
            { id: "2024", label: "2024" },
            { id: "2023", label: "2023" },
            { id: "2022", label: "2022" },
            { id: "archive", label: t("Archive (≤2021)", "Архив (≤2021)") }
          ].map((yf) => (
            <button
              key={yf.id}
              type="button"
              onClick={() => setYearFilter(yf.id)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold shrink-0 transition-colors ${
                yearFilter === yf.id
                  ? "bg-zinc-900 dark:bg-white text-white dark:text-zinc-900"
                  : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700"
              }`}
            >
              {yf.label}
            </button>
          ))}
        </div>

        {/* Batch selection quick buttons & Custom Release / Bulk Edit */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 text-xs border-t border-zinc-100 dark:border-zinc-800">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-zinc-400 font-medium mr-1">
              {t("Batch select:", "Выбор:")}
            </span>
            <button
              type="button"
              onClick={selectAll}
              className="px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-medium transition-colors"
            >
              {t("Select all", "Выбрать все")} ({counts.all})
            </button>
            <button
              type="button"
              onClick={deselectAll}
              className="px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-medium transition-colors"
            >
              {t("Deselect all", "Снять выбор")}
            </button>
            {counts.album > 0 && (
              <button
                type="button"
                onClick={() => selectByType("album")}
                className="px-2.5 py-1 rounded-md bg-purple-500/10 hover:bg-purple-500/20 text-purple-700 dark:text-purple-300 border border-purple-500/20 font-medium transition-colors"
              >
                {t("All albums", "Все альбомы")} ({counts.album})
              </button>
            )}
            {counts.ep > 0 && (
              <button
                type="button"
                onClick={() => selectByType("ep")}
                className="px-2.5 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 font-medium transition-colors"
              >
                {t("All EPs", "Все EP")} ({counts.ep})
              </button>
            )}
            {counts.single > 0 && (
              <button
                type="button"
                onClick={() => selectByType("single")}
                className="px-2.5 py-1 rounded-md bg-sky-500/10 hover:bg-sky-500/20 text-sky-700 dark:text-sky-300 border border-sky-500/20 font-medium transition-colors"
              >
                {t("All singles", "Все синглы")} ({counts.single})
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {onOpenReleaseDatesModal && (
              <button
                type="button"
                onClick={onOpenReleaseDatesModal}
                className="px-3 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-700 dark:text-purple-300 font-bold border border-purple-500/30 transition-all flex items-center gap-1.5 shadow-xs"
                title={t(
                  "Configure release dates: lines Artist - Title - Date, import from TXT or enter in table",
                  "Настройка дат релизов: строчки Артисты - Название - Дата, импорт из TXT или ввод в таблице"
                )}
              >
                <Calendar className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                <span>{t("Release Dates", "Дата релиза")}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsBulkEditOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 font-bold border border-orange-500/30 transition-all flex items-center gap-1.5"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{t("Bulk Edit Label/Year", "Массовое редактирование")}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAddReleaseOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-100 font-bold transition-all flex items-center gap-1.5 shadow-xs"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{t("+ Custom Release", "+ Свой релиз")}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Releases List */}
      <div className="flex flex-col gap-3">
        {filteredReleases.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-12 text-center border border-zinc-200 dark:border-zinc-800">
            <Disc className="w-10 h-10 text-zinc-400 mx-auto mb-2" />
            <p className="text-zinc-600 dark:text-zinc-300 font-medium">
              {t("No releases match your filter", "Релизов с такими параметрами не найдено")}
            </p>
          </div>
        ) : (
          filteredReleases.slice(0, visibleCount).map((rel, relIdx) => {
            const isSelected = selectedReleaseIds.has(rel.release_id);
            const selectedTracksSet = selectedTrackIdsMap[rel.release_id] || new Set();
            const isPartiallySelected =
              isSelected &&
              selectedTracksSet.size > 0 &&
              selectedTracksSet.size < rel.tracks.length;
            const isFullySelected =
              isSelected && selectedTracksSet.size === rel.tracks.length;
            const isExpanded = expandedReleaseIds.has(rel.release_id);

            return (
              <div
                key={`catalog-rel-${rel.release_id}-${rel.artist_id || ""}-${relIdx}`}
                className={`bg-white dark:bg-zinc-900 rounded-2xl border transition-all duration-200 shadow-sm overflow-hidden ${
                  isSelected
                    ? "border-orange-500/80 ring-1 ring-orange-500/20"
                    : "border-zinc-200/80 dark:border-white/10 hover:border-zinc-300 dark:hover:border-zinc-700"
                }`}
              >
                {/* Release Card Header */}
                <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    {/* Checkbox button */}
                    <button
                      type="button"
                      onClick={() => toggleRelease(rel.release_id)}
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-all hover:scale-105 active:scale-95"
                      title={isSelected ? t("Deselect", "Снять выбор") : t("Select", "Выбрать")}
                    >
                      {isFullySelected ? (
                        <div className="w-6 h-6 rounded-lg bg-orange-500 text-white flex items-center justify-center shadow-sm">
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                      ) : isPartiallySelected ? (
                        <div className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-500 border-2 border-orange-500 flex items-center justify-center">
                          <div className="w-2.5 h-2.5 bg-orange-500 rounded" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-lg border-2 border-zinc-300 dark:border-zinc-600 bg-white dark:bg-zinc-800" />
                      )}
                    </button>

                    {/* Cover art */}
                    <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700 shadow-xs">
                      {rel.cover ? (
                        <img
                          src={rel.cover}
                          alt={rel.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Disc className="w-8 h-8 text-zinc-400 absolute inset-0 m-auto" />
                      )}
                    </div>

                    {/* Title & Type info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="font-bold text-base sm:text-lg text-zinc-900 dark:text-zinc-50 truncate">
                          {rel.title}
                        </h4>

                        {/* Release Type Badge */}
                        {rel.type === "album" && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30 uppercase tracking-wide shrink-0">
                            {t("Album", "Альбом")} • {rel.tracks.length} {t("tracks", "тр.")}
                          </span>
                        )}
                        {rel.type === "ep" && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 uppercase tracking-wide shrink-0">
                            EP • {rel.tracks.length} {t("tracks", "тр.")}
                          </span>
                        )}
                        {rel.type === "single" && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30 uppercase tracking-wide shrink-0">
                            {t("Single", "Сингл")}
                          </span>
                        )}
                        {rel.type === "compilation" && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 uppercase tracking-wide shrink-0">
                            {t("Compilation", "Сборник")}
                          </span>
                        )}

                        {/* Participation tag */}
                        {rel.is_direct === false && (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-700 shrink-0">
                            {t("Feature / Collab", "Участие / Фит")}
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-zinc-500 dark:text-zinc-400 font-medium">
                        <span>{rel.release_date ? rel.release_date.substring(0, 4) : "2024"}</span>
                        <span>•</span>
                        <span>
                          {rel.tracks.length}{" "}
                          {rel.tracks.length === 1
                            ? t("track", "трек")
                            : rel.tracks.length <= 4
                            ? t("tracks", "трека")
                            : t("tracks", "треков")}
                        </span>
                        {rel.upc && (
                          <>
                            <span>•</span>
                            <span className="font-mono text-[11px] text-zinc-400">
                              UPC: {rel.upc}
                            </span>
                          </>
                        )}
                        {rel.label && (
                          <>
                            <span>•</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20">
                              {t("Label:", "Лейбл:")} {rel.label}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions right */}
                  <div className="flex items-center gap-2 justify-end shrink-0 pl-14 sm:pl-0">
                    <button
                      type="button"
                      onClick={() => toggleExpand(rel.release_id)}
                      className="px-3 py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors flex items-center gap-1.5"
                    >
                      <span>
                        {isExpanded
                          ? t("Close tracks", "Скрыть треки")
                          : t("Open release", "Открыть релиз")}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleRelease(rel.release_id)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-xs ${
                        isSelected
                          ? "bg-orange-500/10 text-orange-600 dark:text-orange-400 hover:bg-orange-500/20"
                          : "bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-100"
                      }`}
                    >
                      {isSelected
                        ? t("Deselect release", "Снять релиз")
                        : t("Select release", "Выбрать весь релиз")}
                    </button>
                  </div>
                </div>

                {/* Expanded Tracklist View (Accordion) */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-2 border-t border-zinc-100 dark:border-zinc-800 bg-zinc-50/50 dark:bg-black/20 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between mb-3 pt-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                        {t("Tracklist of release", "Список треков релиза")} (
                        {selectedTracksSet.size} / {rel.tracks.length} {t("selected", "выбрано")})
                      </span>
                      <button
                        type="button"
                        onClick={() => selectAllTracksInRelease(rel.release_id)}
                        className="text-xs font-semibold text-orange-500 hover:underline"
                      >
                        {t("Select all tracks", "Выбрать все треки в этом релизе")}
                      </button>
                    </div>

                    <div className="divide-y divide-zinc-200/50 dark:divide-zinc-800/60 rounded-xl bg-white dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700/80 overflow-hidden">
                      {rel.tracks.map((trk, tIdx) => {
                        const isTrkSelected = selectedTracksSet.has(trk.track_id);
                        return (
                          <div
                            key={`catalog-trk-${rel.release_id}-${trk.track_id}-${tIdx}`}
                            onClick={() => toggleTrack(rel.release_id, trk.track_id)}
                            className={`p-3 sm:px-4 flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                              isTrkSelected
                                ? "bg-orange-500/5 dark:bg-orange-500/10"
                                : "hover:bg-zinc-50 dark:hover:bg-zinc-700/30"
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div
                                className={`w-5 h-5 rounded-md flex items-center justify-center text-xs shrink-0 transition-colors ${
                                  isTrkSelected
                                    ? "bg-orange-500 text-white"
                                    : "border border-zinc-300 dark:border-zinc-600"
                                }`}
                              >
                                {isTrkSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              </div>

                              {/* Audio Play preview button */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  togglePlayTrack(
                                    trk.track_id,
                                    trk.title,
                                    rel.artist_name || artist.name,
                                    trk.preview_url
                                  );
                                }}
                                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-all ${
                                  playbackState.playingTrackId === trk.track_id && playbackState.isPlaying
                                    ? "bg-orange-500 text-white shadow-sm ring-2 ring-orange-500/30 scale-105"
                                    : "bg-zinc-100 dark:bg-zinc-700 hover:bg-orange-500 hover:text-white text-zinc-600 dark:text-zinc-300"
                                }`}
                                title={t("Preview track", "Прослушать фрагмент")}
                              >
                                {playbackState.playingTrackId === trk.track_id && playbackState.isPlaying ? (
                                  <Pause className="w-3.5 h-3.5" />
                                ) : (
                                  <Play className="w-3.5 h-3.5 ml-0.5" />
                                )}
                              </button>

                              <span className="font-mono text-xs text-zinc-400 w-6 shrink-0">
                                {String(tIdx + 1).padStart(2, "0")}
                              </span>

                              <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                                {trk.title}
                              </span>

                              {playbackState.playingTrackId === trk.track_id && playbackState.isPlaying && (
                                <div className="flex items-center gap-0.5 text-orange-500 shrink-0 ml-2">
                                  <span className="w-1 h-3 bg-orange-500 rounded-full animate-pulse" />
                                  <span className="w-1 h-4 bg-orange-500 rounded-full animate-bounce" />
                                  <span className="w-1 h-2 bg-orange-500 rounded-full animate-pulse" />
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-3 shrink-0">
                              {trk.isrc && (
                                <span className="text-[11px] font-mono text-zinc-400">
                                  {trk.isrc}
                                </span>
                              )}
                              {trk.duration && (
                                <span className="text-xs font-mono text-zinc-500 dark:text-zinc-400">
                                  {Math.floor(trk.duration / 60)}:
                                  {String(trk.duration % 60).padStart(2, "0")}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Load more button if catalog is large */}
        {filteredReleases.length > visibleCount && (
          <div className="flex flex-wrap items-center justify-center gap-3 py-4">
            <button
              type="button"
              onClick={() => setVisibleCount((prev) => prev + 30)}
              className="py-3 px-6 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-300 transition-all"
            >
              {t("Show more releases", "Показать ещё")} (+30) (
              {filteredReleases.length - visibleCount} {t("remaining", "осталось")})
            </button>
            <button
              type="button"
              onClick={() => setVisibleCount(filteredReleases.length)}
              className="py-3 px-6 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-xs font-bold text-orange-600 dark:text-orange-400 border border-orange-500/30 transition-all"
            >
              {t("Show all releases", "Показать весь каталог")} ({filteredReleases.length})
            </button>
          </div>
        )}
      </div>

      {/* Floating Audio Preview Mini-Player */}
      {playbackState.isPlaying && (
        <div className="fixed bottom-24 left-0 right-0 z-40 max-w-lg mx-auto px-4 animate-in slide-in-from-bottom-3 duration-200">
          <div className="bg-zinc-950/95 backdrop-blur-xl border border-orange-500/40 rounded-2xl p-3 shadow-2xl flex items-center justify-between gap-3 text-white">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-orange-500 text-white flex items-center justify-center shrink-0">
                <Volume2 className="w-4 h-4 animate-pulse" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-zinc-100 truncate">
                  {playbackState.playingTrackTitle}
                </p>
                <p className="text-[10px] text-zinc-400 truncate">
                  {playbackState.playingArtistName} • {t("Studio WAV 16-bit 44.1kHz preview", "Студийный предпросмотр")}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <div className="text-[11px] font-mono text-orange-400">
                {Math.floor(playbackState.currentTime / 60)}:
                {String(Math.floor(playbackState.currentTime % 60)).padStart(2, "0")} / 0:30
              </div>
              <button
                type="button"
                onClick={stopAudio}
                className="w-8 h-8 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 flex items-center justify-center transition-colors"
                title={t("Stop preview", "Остановить")}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sticky Bottom Counter & Navigation Bar */}
      <div className="fixed bottom-4 left-0 right-0 z-40 max-w-5xl mx-auto px-4 pointer-events-none">
        <div className="bg-zinc-900/95 dark:bg-zinc-800/95 backdrop-blur-xl rounded-2xl border border-zinc-700/60 p-3 sm:p-4 shadow-2xl flex items-center justify-between gap-4 pointer-events-auto text-white">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
              title={t("Back", "Назад")}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider text-orange-400 font-bold">
                  {t("Selected:", "Выбрано:")}
                </span>
                <span className="text-sm sm:text-base font-bold text-white">
                  {selectedReleaseIds.size} {t("releases", "релизов")} • {totalSelectedTracksCount}{" "}
                  {t("tracks", "треков")}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 hidden sm:block">
                {t(
                  "Only chosen tracks will be packaged into the final ZIP",
                  "В итоговый ZIP войдут только отмеченные треки"
                )}
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={selectedReleaseIds.size === 0}
            onClick={onNext}
            className="px-5 sm:px-6 py-3 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white text-xs sm:text-sm font-bold transition-all duration-200 flex items-center gap-2 shadow-lg shadow-orange-500/20"
          >
            <span>
              {t("Proceed to UPC & ISRC", "Перейти к кодам")} ({selectedReleaseIds.size})
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Bulk Metadata Editor Modal */}
      {isBulkEditOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
                  <SlidersHorizontal className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                  {t("Bulk Edit Metadata", "Массовое редактирование")}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsBulkEditOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-4">
              {t(
                `Apply label name or release year to all ${selectedReleaseIds.size} selected releases at once.`,
                `Применить лейбл или год сразу ко всем (${selectedReleaseIds.size}) выбранным релизам.`
              )}
            </p>

            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                  {t("Record Label Name", "Название лейбла")}
                </label>
                <input
                  type="text"
                  value={bulkLabel}
                  onChange={(e) => setBulkLabel(e.target.value)}
                  placeholder={t("e.g. Sony Music, Believe, Self-released", "например, Believe, Sony Music или свой лейбл")}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                  {t("Release Year", "Год выпуска")}
                </label>
                <input
                  type="text"
                  value={bulkYear}
                  onChange={(e) => setBulkYear(e.target.value)}
                  placeholder="2024"
                  maxLength={4}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 mt-6 pt-4 border-t border-zinc-100 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setIsBulkEditOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                {t("Cancel", "Отмена")}
              </button>
              <button
                type="button"
                onClick={handleApplyBulkMetadata}
                className="px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold shadow-md shadow-orange-500/20"
              >
                {t("Apply to Selected Releases", "Применить к выбранным")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Release Creation Modal */}
      {isAddReleaseOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <form
            onSubmit={handleCreateCustomRelease}
            className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6 max-w-lg w-full shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
                  <PlusCircle className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                  {t("Add Custom Release", "Добавить свой релиз")}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddReleaseOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                  {t("Release Title *", "Название релиза *")}
                </label>
                <input
                  type="text"
                  required
                  value={newReleaseTitle}
                  onChange={(e) => setNewReleaseTitle(e.target.value)}
                  placeholder={t("e.g. Midnight Memories, Live at Berlin", "например, Ночные огни (Live)")}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    {t("Release Type", "Тип релиза")}
                  </label>
                  <select
                    value={newReleaseType}
                    onChange={(e) => setNewReleaseType(e.target.value as ReleaseType)}
                    className="w-full h-9 px-3 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                  >
                    <option value="single">{t("Single (1 track)", "Сингл (1 трек)")}</option>
                    <option value="ep">{t("EP (2-6 tracks)", "EP (2-6 треков)")}</option>
                    <option value="album">{t("Album (LP)", "Альбом (LP)")}</option>
                    <option value="compilation">{t("Compilation", "Сборник")}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    {t("Release Year", "Год")}
                  </label>
                  <input
                    type="text"
                    value={newReleaseYear}
                    onChange={(e) => setNewReleaseYear(e.target.value)}
                    maxLength={4}
                    placeholder="2024"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                  {t("Label", "Лейбл")}
                </label>
                <input
                  type="text"
                  value={newReleaseLabel}
                  onChange={(e) => setNewReleaseLabel(e.target.value)}
                  placeholder={artist.name}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                  {t("Track Titles (one title per line)", "Названия треков (каждый с новой строки)")}
                </label>
                <textarea
                  rows={4}
                  value={newReleaseTracks}
                  onChange={(e) => setNewReleaseTracks(e.target.value)}
                  placeholder={t(
                    "Track 1 - Intro\nTrack 2 - Main Song\nTrack 3 - Outro",
                    "01. Интро\n02. Главная песня\n03. Акустика"
                  )}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50 font-mono"
                />
                <p className="text-[10px] text-zinc-400 mt-1">
                  {t(
                    "If left empty, a track with the release title will be created automatically.",
                    "Если оставить пустым, будет создан один трек с названием релиза."
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 mt-6 pt-4 border-t border-zinc-100 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setIsAddReleaseOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                {t("Cancel", "Отмена")}
              </button>
              <button
                type="submit"
                disabled={!newReleaseTitle.trim()}
                className="px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white text-xs font-bold shadow-md shadow-orange-500/20"
              >
                {t("Add to Catalog", "Добавить в каталог")}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
