import React, { useState, useMemo } from "react";
import { ArtistEntity, ReleaseEntity, TrackEntity, BackCatalogExportFormat } from "./types";
import { saveAs } from "file-saver";
import {
  generateCodesExcelBuffer,
  generateCodesCsv,
  generateCatalogCodesTxt,
  generateCatalogDatesTxt,
  generateBackCatalogFullTxt,
  generateBackCatalogLiteTxt
} from "./metadataGenerator";
import {
  CheckCircle2,
  AlertTriangle,
  Download,
  ArrowLeft,
  Disc,
  Music,
  Barcode,
  Hash,
  Image as ImageIcon,
  Edit3,
  ShieldCheck,
  FileCheck,
  ChevronDown,
  ChevronUp,
  FileArchive,
  FolderArchive,
  FileSpreadsheet,
  FileText,
  Calendar,
  Layers,
  Sparkles,
  Check
} from "lucide-react";
import { isValidIsrc, isValidUpc } from "./Step3Codes";

interface Step4VerificationProps {
  artist: ArtistEntity;
  artists?: ArtistEntity[];
  releases: ReleaseEntity[];
  selectedReleaseIds: Set<string>;
  selectedTrackIdsMap: Record<string, Set<string>>;
  exportFormat?: BackCatalogExportFormat;
  onExportFormatChange?: (format: BackCatalogExportFormat) => void;
  onBatchUpdateCodes?: (
    upcMap: Record<string, string>,
    isrcMap: Record<string, string>
  ) => void;
  onBatchUpdateReleases?: (updates: {
    releaseIds: string[];
    label?: string;
    year?: string;
  }) => void;
  onOpenReleaseDatesModal?: () => void;
  onEditStep: (step: 1 | 2 | 3 | 4) => void;
  onStartDownload: () => void;
  t: (en: string, ru: string) => string;
}

export function Step4Verification({
  artist,
  artists,
  releases,
  selectedReleaseIds,
  selectedTrackIdsMap,
  exportFormat = "all_data",
  onExportFormatChange,
  onOpenReleaseDatesModal,
  onEditStep,
  onStartDownload,
  t
}: Step4VerificationProps) {
  const [expandedReleaseId, setExpandedReleaseId] = useState<string | null>(null);

  // Selected releases with only selected tracks
  const selectedReleases = useMemo(() => {
    return releases
      .filter((r) => selectedReleaseIds.has(r.release_id))
      .map((r) => {
        const allowedTrackIds = selectedTrackIdsMap[r.release_id] || new Set();
        return {
          ...r,
          tracks: r.tracks.filter((t) => allowedTrackIds.has(t.track_id))
        };
      });
  }, [releases, selectedReleaseIds, selectedTrackIdsMap]);

  // Aggregate metrics
  const totalReleasesCount = selectedReleases.length;
  const totalTracksCount = useMemo(
    () => selectedReleases.reduce((acc, r) => acc + r.tracks.length, 0),
    [selectedReleases]
  );

  const filledUpcCount = useMemo(
    () => selectedReleases.filter((r) => r.upc && isValidUpc(r.upc)).length,
    [selectedReleases]
  );

  const totalIsrcsFilled = useMemo(() => {
    let count = 0;
    selectedReleases.forEach((r) => {
      r.tracks.forEach((t) => {
        if (t.isrc && isValidIsrc(t.isrc)) count++;
      });
    });
    return count;
  }, [selectedReleases]);

  const toggleExpand = (id: string) => {
    setExpandedReleaseId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 pb-24">
      {/* Header Info */}
      <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
            4
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-zinc-900 dark:text-zinc-50 tracking-tight">
              {t("Verify Catalog Before Export", "Проверьте каталог перед скачиванием")}
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
              {t(
                "Final checklist and summary metrics before structuring the delivery archive.",
                "Итоговая проверка и сводка перед формированием структурированного архива для лейбла."
              )}
            </p>
          </div>
        </div>

        {/* 6 Metric Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-5">
          {/* Artist */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {artists && artists.length > 1 ? t("Artists", "Артисты") : t("Artist", "Артист")}
            </span>
            <div className="flex items-center gap-2 mt-2">
              {artists && artists.length > 1 ? (
                <div className="w-6 h-6 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  {artists.length}
                </div>
              ) : artist.avatar ? (
                <img
                  src={artist.avatar}
                  alt=""
                  className="w-6 h-6 rounded-full object-cover shrink-0"
                />
              ) : (
                <Music className="w-4 h-4 text-orange-500" />
              )}
              <span className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">
                {artists && artists.length > 1
                  ? `${artists.length} ${t("artists", "артистов")}`
                  : artist.name}
              </span>
            </div>
          </div>

          {/* Releases */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {t("Releases", "Релизы")}
            </span>
            <div className="flex items-center gap-2 mt-2">
              <Disc className="w-4 h-4 text-blue-500" />
              <span className="font-bold text-base text-zinc-900 dark:text-zinc-100">
                {totalReleasesCount}
              </span>
            </div>
          </div>

          {/* Tracks */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {t("Tracks", "Треки")}
            </span>
            <div className="flex items-center gap-2 mt-2">
              <Music className="w-4 h-4 text-purple-500" />
              <span className="font-bold text-base text-zinc-900 dark:text-zinc-100">
                {totalTracksCount}
              </span>
            </div>
          </div>

          {/* Covers */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {t("Covers", "Обложки")}
            </span>
            <div className="flex items-center gap-2 mt-2">
              <ImageIcon className="w-4 h-4 text-emerald-500" />
              <span className="font-bold text-xs text-zinc-900 dark:text-zinc-100">
                3000×3000 px
              </span>
            </div>
          </div>

          {/* UPC */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {t("UPC Codes", "Коды UPC")}
            </span>
            <div className="flex items-center gap-1.5 mt-2">
              <Barcode className="w-4 h-4 text-orange-500" />
              <span
                className={`font-bold text-sm ${
                  filledUpcCount === totalReleasesCount && totalReleasesCount > 0
                    ? "text-emerald-600 dark:text-emerald-400"
                    : filledUpcCount > 0
                    ? "text-blue-600 dark:text-blue-400"
                    : "text-zinc-600 dark:text-zinc-300"
                }`}
              >
                {filledUpcCount} / {totalReleasesCount}
              </span>
            </div>
          </div>

          {/* ISRC */}
          <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/60 flex flex-col justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              {t("ISRC Codes", "Коды ISRC")}
            </span>
            <div className="flex items-center gap-1.5 mt-2">
              <Hash className="w-4 h-4 text-indigo-500" />
              <span
                className={`font-bold text-sm ${
                  totalIsrcsFilled === totalTracksCount && totalTracksCount > 0
                    ? "text-emerald-600 dark:text-emerald-400"
                    : totalIsrcsFilled > 0
                    ? "text-blue-600 dark:text-blue-400"
                    : "text-zinc-600 dark:text-zinc-300"
                }`}
              >
                {totalIsrcsFilled} / {totalTracksCount}
              </span>
            </div>
          </div>
        </div>

        {/* Pre-flight Automated Checklist */}
        <div className="mt-5 pt-4 border-t border-zinc-100 dark:border-zinc-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>{t("Automated Pre-flight Inspection", "Автоматический чек-лист готовности")}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Artist Verified:", "Артист выбран:")}</strong> {artist.name}
              </span>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Releases & Titles:", "Названия и типы:")}</strong> {totalReleasesCount}{" "}
                {t("standardized", "стандартизированы")}
              </span>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Studio Covers:", "Обложки 3000×3000px:")}</strong>{" "}
                {t("Automated upscale & square crop ready", "Масштабирование и квадрат готовы")}
              </span>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Studio WAV Audio:", "WAV 16-bit 44.1kHz:")}</strong>{" "}
                {exportFormat === "release_date_link_cover"
                  ? t("Audio excluded by selected format", "Аудио исключено (выбран компактный вариант)")
                  : `${totalTracksCount} ${t("track files ready to archive", "файлов готовы к упаковке")}`}
              </span>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Codes (UPC & ISRC):", "Коды UPC & ISRC:")}</strong>{" "}
                {filledUpcCount === totalReleasesCount && totalIsrcsFilled === totalTracksCount
                  ? t("100% complete", "Полностью заполнены")
                  : filledUpcCount > 0 || totalIsrcsFilled > 0
                  ? t("Partially specified (empty will mark NOT SPECIFIED)", "Частично заполнены (пустые будут отмечены «НЕ УКАЗАН»)")
                  : t("Left empty by choice (marked NOT SPECIFIED)", "Оставлены пустыми (в метаданных будет «НЕ УКАЗАН»)")}
              </span>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 text-zinc-800 dark:text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                <strong>{t("Path & File Security:", "Проверка на конфликты:")}</strong>{" "}
                {t("Sanitized names without traversal risks", "Имена очищены от недопустимых символов")}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Export Format Selector Cards: Option 1 vs Option 2 */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm flex flex-col gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-orange-500" />
            <h3 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-zinc-50">
              {t("Choose Export Format & ZIP Content", "Выберите формат экспорта и состав ZIP-архива")}
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
            {t(
              "Select what data and files should be generated and packaged into the final archive.",
              "Укажите режим комплектации архива: полный каталог со студийным WAV или компактный с датами и ссылками."
            )}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {/* Option 1: Все данные */}
          <div
            onClick={() => onExportFormatChange?.("all_data")}
            className={`p-4 sm:p-5 rounded-2xl border-2 cursor-pointer transition-all duration-200 flex flex-col justify-between relative group ${
              exportFormat === "all_data"
                ? "border-orange-500 bg-orange-500/5 dark:bg-orange-500/10 shadow-md shadow-orange-500/10 ring-2 ring-orange-500/20"
                : "border-zinc-200 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-800/40 hover:border-zinc-300 dark:hover:border-zinc-700"
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2.5">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                      exportFormat === "all_data"
                        ? "bg-orange-500 text-white shadow-md shadow-orange-500/30"
                        : "bg-zinc-200 dark:bg-zinc-700 text-zinc-600 dark:text-zinc-300"
                    }`}
                  >
                    <FolderArchive className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-orange-500 block">
                      {t("Option 1", "Вариант 1")}
                    </span>
                    <h4 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
                      {t("All Data (Full Catalog)", "«Все данные»")}
                    </h4>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                    exportFormat === "all_data"
                      ? "border-orange-500 bg-orange-500 text-white"
                      : "border-zinc-300 dark:border-zinc-600"
                  }`}
                >
                  {exportFormat === "all_data" && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-orange-500/15 text-orange-600 dark:text-orange-400 font-bold text-[11px] mb-2.5">
                <span>{t("WAV + Covers 3000×3000 + Full TXT", "WAV + Обложки 3000×3000 + Полный TXT")}</span>
              </div>

              <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed mb-3">
                {t(
                  "Collects all metadata (Label, Artist, Release, Date, UPC, ISRC, Lyrics Author, Music Author, Link) + studio WAVs + 3000×3000 covers.",
                  "Для каждого релиза: Лейбл, Артист, Название, Дата, UPC, ISRC, Автор текста, Автор музыки, Ссылка на релиз + аудио WAV + обложка 3000×3000."
                )}
              </p>
            </div>

            <div className="pt-3 border-t border-zinc-200/60 dark:border-zinc-700/60 text-[11px] font-mono text-zinc-500 dark:text-zinc-400 space-y-0.5 bg-white/50 dark:bg-black/20 p-2.5 rounded-xl">
              <div className="font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                {t("Inside ZIP:", "Содержимое ZIP:")}
              </div>
              <div className="text-orange-600 dark:text-orange-400">/catalog.txt <span className="text-zinc-400 font-sans text-[10px]">(полные метаданные)</span></div>
              <div className="text-purple-600 dark:text-purple-400">/audio/01_artist_release.wav <span className="text-zinc-400 font-sans text-[10px]">(мастер WAV)</span></div>
              <div className="text-emerald-600 dark:text-emerald-400">/covers/01_artist_release.jpg <span className="text-zinc-400 font-sans text-[10px]">(3000×3000 px)</span></div>
            </div>
          </div>

          {/* Option 2: Дата релиза + ссылка + обложка */}
          <div
            onClick={() => onExportFormatChange?.("release_date_link_cover")}
            className={`p-4 sm:p-5 rounded-2xl border-2 cursor-pointer transition-all duration-200 flex flex-col justify-between relative group ${
              exportFormat === "release_date_link_cover"
                ? "border-purple-500 bg-purple-500/5 dark:bg-purple-500/10 shadow-md shadow-purple-500/10 ring-2 ring-purple-500/20"
                : "border-zinc-200 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-800/40 hover:border-zinc-300 dark:hover:border-zinc-700"
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2.5">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                      exportFormat === "release_date_link_cover"
                        ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                        : "bg-zinc-200 dark:bg-zinc-700 text-zinc-600 dark:text-zinc-300"
                    }`}
                  >
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400 block">
                      {t("Option 2 (Fast)", "Вариант 2 (Компактный)")}
                    </span>
                    <h4 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
                      {t("Release Date + Link + Cover", "«Дата релиза + ссылка + обложка»")}
                    </h4>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                    exportFormat === "release_date_link_cover"
                      ? "border-purple-600 bg-purple-600 text-white"
                      : "border-zinc-300 dark:border-zinc-600"
                  }`}
                >
                  {exportFormat === "release_date_link_cover" && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/15 text-purple-700 dark:text-purple-300 font-bold text-[11px] mb-2.5">
                <span>{t("Covers 3000×3000 + Lite TXT (No WAV)", "Обложки 3000×3000 + Компактный TXT (Без WAV)")}</span>
              </div>

              <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed mb-3">
                {t(
                  "Shortest variant: only Release Date, Artist, Release Name, Link to Release + 3000×3000 covers. Audio WAV is NOT downloaded.",
                  "Максимально короткий и лёгкий вариант: Дата релиза, Артист, Название релиза, Ссылка на релиз + обложки 3000×3000. WAV не скачивается."
                )}
              </p>
            </div>

            <div className="pt-3 border-t border-zinc-200/60 dark:border-zinc-700/60 text-[11px] font-mono text-zinc-500 dark:text-zinc-400 space-y-0.5 bg-white/50 dark:bg-black/20 p-2.5 rounded-xl">
              <div className="font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                {t("Inside ZIP:", "Содержимое ZIP:")}
              </div>
              <div className="text-purple-600 dark:text-purple-400">/catalog.txt <span className="text-zinc-400 font-sans text-[10px]">(даты, ссылки и названия)</span></div>
              <div className="text-emerald-600 dark:text-emerald-400">/covers/01_artist_release.jpg <span className="text-zinc-400 font-sans text-[10px]">(3000×3000 px)</span></div>
              <div className="text-zinc-400 line-through">/audio/ <span className="text-zinc-400 font-sans text-[10px]">(WAV исключен)</span></div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Codes & TXT Export Banner */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-white/10 p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
              {t("Direct Metadata Files (TXT / Excel / CSV)", "Прямое скачивание файлов метаданных (TXT / Excel / CSV)")}
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {t(
                "Instantly download catalog.txt or registries without packaging ZIP.",
                "Скачайте catalog.txt или таблицы реестров в один клик без сборки ZIP."
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto flex-wrap">
          <button
            type="button"
            onClick={() => {
              const txt = generateBackCatalogFullTxt(artist.name, selectedReleases, selectedTrackIdsMap);
              saveAs(new Blob([txt], { type: "text/plain;charset=utf-8;" }), `${artist.name}_catalog_full.txt`);
            }}
            className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-orange-50 hover:bg-orange-100 dark:bg-orange-950/40 dark:hover:bg-orange-900/40 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-sm"
            title={t("Download full catalog.txt with all metadata", "Скачать catalog.txt (Все данные: лейбл, UPC, ISRC, авторы, ссылка)")}
          >
            <FileText className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
            <span>TXT {t("«All Data»", "«Все данные»")}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const txt = generateBackCatalogLiteTxt(artist.name, selectedReleases, selectedTrackIdsMap);
              saveAs(new Blob([txt], { type: "text/plain;charset=utf-8;" }), `${artist.name}_catalog_dates_links.txt`);
            }}
            className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-sm"
            title={t("Download lite catalog.txt with dates and links", "Скачать catalog.txt (Даты + Ссылки + Названия)")}
          >
            <Calendar className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span>TXT {t("«Dates + Links»", "«Даты + Ссылки»")}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const buf = generateCodesExcelBuffer(artist.name, selectedReleases, selectedTrackIdsMap);
              saveAs(
                new Blob([buf], {
                  type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                }),
                `${artist.name}_codes_registry.xlsx`
              );
            }}
            className="flex-1 sm:flex-initial px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Excel</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const csv = generateCodesCsv(artist.name, selectedReleases, selectedTrackIdsMap);
              saveAs(new Blob([csv], { type: "text/csv;charset=utf-8;" }), `${artist.name}_codes_registry.csv`);
            }}
            className="flex-1 sm:flex-initial px-3 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* Selected Releases Interactive Review */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-400">
            {t("Included Releases Structure", "Структура релизов в архиве")} ({selectedReleases.length})
          </h3>
          <div className="flex items-center gap-3">
            {onOpenReleaseDatesModal && (
              <button
                type="button"
                onClick={onOpenReleaseDatesModal}
                className="text-xs text-purple-600 dark:text-purple-400 hover:underline font-semibold flex items-center gap-1"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{t("Release Dates", "Дата релиза")}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onEditStep(2)}
              className="text-xs text-orange-500 hover:underline font-semibold flex items-center gap-1"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{t("Change selection", "Изменить состав релизов")}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {selectedReleases.map((rel, rIdx) => {
            const isExpanded = expandedReleaseId === rel.release_id;
            const pad = String(rIdx + 1).padStart(2, "0");

            return (
              <div
                key={`verif-rel-${rel.release_id}-${rIdx}`}
                className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm transition-all"
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono text-xs text-zinc-400 w-6 shrink-0">{pad}</span>

                    <div className="w-12 h-12 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700">
                      {rel.cover ? (
                        <img src={rel.cover} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <Disc className="w-6 h-6 text-zinc-400 m-auto" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-base text-zinc-900 dark:text-zinc-50 truncate">
                          {rel.title}
                        </h4>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 uppercase shrink-0">
                          {rel.type}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400 mt-0.5 flex-wrap">
                        <span>
                          {rel.tracks.length} {t("tracks", "треков")}
                        </span>
                        <span>•</span>
                        <span className="font-mono">
                          UPC: {rel.upc || t("NOT_PROVIDED", "НЕ УКАЗАН")}
                        </span>
                        <span>•</span>
                        <span className="font-mono text-purple-700 dark:text-purple-300 flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-purple-500 inline" />
                          {t("Date:", "Дата:")} {rel.release_date || t("NOT_PROVIDED", "НЕ УКАЗАНА")}
                        </span>
                        {rel.label && (
                          <>
                            <span>•</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20">
                              {t("Label:", "Лейбл:")} {rel.label}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onEditStep(3)}
                      className="p-2 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
                      title={t("Edit codes", "Редактировать коды")}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleExpand(rel.release_id)}
                      className="p-2 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Expanded Track Inspection */}
                {isExpanded && (
                  <div className="mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800 text-xs">
                    <div className="divide-y divide-zinc-100 dark:divide-zinc-800">
                      {rel.tracks.map((trk, tIdx) => (
                        <div
                          key={`verif-trk-${rel.release_id}-${trk.track_id}-${tIdx}`}
                          className="py-2 flex items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="font-mono text-zinc-400 w-6">
                              {String(tIdx + 1).padStart(2, "0")}
                            </span>
                            <span className="font-medium text-zinc-800 dark:text-zinc-200 truncate">
                              {trk.title}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 font-mono text-zinc-400 shrink-0">
                            <span>ISRC:</span>
                            <span className="text-zinc-700 dark:text-zinc-300">
                              {trk.isrc || t("NOT_PROVIDED", "НЕ УКАЗАН")}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Sticky Bottom Primary Download Action Bar */}
      <div className="fixed bottom-4 left-0 right-0 z-40 max-w-5xl mx-auto px-4 pointer-events-none">
        <div className="bg-zinc-900/95 dark:bg-zinc-800/95 backdrop-blur-xl rounded-2xl border border-zinc-700/60 p-3 sm:p-4 shadow-2xl flex items-center justify-between gap-4 pointer-events-auto text-white">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onEditStep(3)}
              className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
              title={t("Back", "Назад")}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className={`text-xs uppercase tracking-wider font-bold ${
                  exportFormat === "release_date_link_cover" ? "text-purple-400" : "text-orange-400"
                }`}>
                  {exportFormat === "release_date_link_cover"
                    ? t("Format: «Dates + Links + Covers»", "Формат: «Даты + Ссылки + Обложки»")
                    : t("Format: «All Data (Full)»", "Формат: «Все данные (Полный)»")}
                </span>
                <span className="text-sm sm:text-base font-bold text-white">
                  {totalReleasesCount} {t("releases", "релизов")}
                  {exportFormat === "all_data" && ` • ${totalTracksCount} ${t("tracks", "треков (WAV)")}`}
                  {` • ${totalReleasesCount} ${t("covers (3000x3000)", "обложек (3000x3000)")}`}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 hidden sm:block">
                {exportFormat === "release_date_link_cover"
                  ? t(
                      "ZIP structure: /catalog.txt + /covers/*.jpg (3000×3000px). WAV audio excluded.",
                      "Структура ZIP: /catalog.txt (даты и ссылки) + /covers/*.jpg (3000×3000px). Без WAV."
                    )
                  : t(
                      "ZIP structure: /catalog.txt + /covers/*.jpg (3000×3000px) + /audio/*.wav (16-bit 44.1kHz).",
                      "Структура ZIP: /catalog.txt (все метаданные) + /covers/*.jpg (3000×3000px) + /audio/*.wav."
                    )}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onStartDownload}
            className={`px-6 sm:px-8 py-3.5 rounded-xl text-white text-sm font-bold transition-all duration-200 flex items-center gap-2.5 shadow-lg active:scale-95 shrink-0 ${
              exportFormat === "release_date_link_cover"
                ? "bg-purple-600 hover:bg-purple-700 shadow-purple-600/30"
                : "bg-orange-500 hover:bg-orange-600 shadow-orange-500/25"
            }`}
          >
            <Download className="w-5 h-5 stroke-[2.5]" />
            <span>
              {exportFormat === "release_date_link_cover"
                ? t("Download ZIP (Dates + Links + Covers)", "Скачать ZIP (Даты + Ссылки + Обложки)")
                : t("Download ZIP (All Data + WAV)", "Скачать ZIP (Все данные: WAV + Обложки + TXT)")}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
