import React, { useState, useEffect } from "react";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { ArtistEntity, ReleaseEntity, BackCatalogExportFormat } from "./types";
import {
  sanitizeFsName,
  formatReleaseFolderName,
  formatTrackFileName
} from "./sanitizer";
import { generateStudioCoverBlob } from "./coverHelper";
import { fetchOrGenerateTrackWav } from "./wavHelper";
import {
  generateReleaseMetadataTxt,
  generateReleaseCodesTxt,
  generateCatalogSummaryTxt,
  generateCodesExcelBuffer,
  generateCodesCsv,
  generateCatalogCodesTxt,
  generateCatalogDatesTxt,
  generateBackCatalogFullTxt,
  generateBackCatalogLiteTxt
} from "./metadataGenerator";
import { downloadCatalogArchive, downloadExportFile } from "./downloadHelper";
import {
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Download,
  Check,
  X,
  RefreshCw,
  FolderArchive,
  Users,
  Sparkles,
  FileSpreadsheet,
  FileText,
  Minimize2,
  ShieldCheck,
  Calendar,
  Layers
} from "lucide-react";

interface DownloadProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  artist: ArtistEntity;
  artists?: ArtistEntity[];
  releases: ReleaseEntity[];
  selectedReleaseIds: Set<string>;
  selectedTrackIdsMap: Record<string, Set<string>>;
  exportFormat?: BackCatalogExportFormat;
  onExportFormatChange?: (format: BackCatalogExportFormat) => void;
  onSaveToHistory: (stats: {
    totalReleases: number;
    totalTracks: number;
    artistCount?: number;
    taskId?: string;
    zipFileName?: string;
    fileSize?: number;
    exportFormat?: BackCatalogExportFormat;
  }) => void;
  t: (en: string, ru: string) => string;
}

type StepStage = 1 | 2 | 3 | 4 | 5 | 6 | 7;

export function DownloadProgressModal({
  isOpen,
  onClose,
  artist,
  artists = [],
  releases,
  selectedReleaseIds,
  selectedTrackIdsMap,
  exportFormat = "all_data",
  onExportFormatChange,
  onSaveToHistory,
  t
}: DownloadProgressModalProps) {
  const [currentFormat, setCurrentFormat] = useState<BackCatalogExportFormat>(exportFormat);
  const [stage, setStage] = useState<StepStage>(1);
  const [percent, setPercent] = useState(0);
  const [processingStatusText, setProcessingStatusText] = useState("");
  const [currentReleaseIndex, setCurrentReleaseIndex] = useState(0);
  const [currentReleaseTitle, setCurrentReleaseTitle] = useState("");
  const [errorCount, setErrorCount] = useState(0);
  const [failedFiles, setFailedFiles] = useState<string[]>([]);
  const [completedZipBlob, setCompletedZipBlob] = useState<Blob | null>(null);
  const [zipFileName, setZipFileName] = useState("");
  const [isBuilding, setIsBuilding] = useState(false);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [serverFileSize, setServerFileSize] = useState<number | null>(null);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadingFileType, setDownloadingFileType] = useState<string | null>(null);

  useEffect(() => {
    if (exportFormat) {
      setCurrentFormat(exportFormat);
    }
  }, [exportFormat]);

  const activeArtistsList = artists.length > 0 ? artists : [artist];
  const isMultiArtist = activeArtistsList.length > 1;

  const stagesList = [
    { id: 1, label: t("File Discovery", "Поиск файлов") },
    { id: 2, label: t("Covers (3000×3000px)", "Подготовка обложек (3000x3000px)") },
    {
      id: 3,
      label:
        currentFormat === "release_date_link_cover"
          ? t("Skip Audio (No WAV needed)", "Пропуск аудио (без WAV)")
          : t("WAV Preparation (16-bit 44.1kHz)", "Подготовка WAV (16-bit 44.1kHz)")
    },
    { id: 4, label: t("Forming catalog.txt", "Формирование catalog.txt") },
    { id: 5, label: t("Building ZIP", "Создание ZIP") },
    { id: 6, label: t("Archive Verification", "Проверка архива") },
    { id: 7, label: t("Completed", "Готово") }
  ];

  // Filter selected releases with only selected tracks
  const selectedReleasesList = React.useMemo(() => {
    return releases
      .filter((r) => selectedReleaseIds.has(r.release_id))
      .map((r) => {
        const allowed = selectedTrackIdsMap[r.release_id] || new Set();
        return {
          ...r,
          tracks: r.tracks.filter((t) => allowed.has(t.track_id))
        };
      });
  }, [releases, selectedReleaseIds, selectedTrackIdsMap]);

  const totalReleases = selectedReleasesList.length;
  const totalTracks = React.useMemo(
    () => selectedReleasesList.reduce((acc, r) => acc + r.tracks.length, 0),
    [selectedReleasesList]
  );

  // Poll server task
  const pollServerTask = async (taskId: string) => {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(`/api/catalog/export-task/${taskId}`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!res.ok) {
        if (res.status === 404) {
          startServerPackaging();
        }
        return;
      }
      const data = await res.json();
      if (!data.success || !data.task) return;

      const tState = data.task;
      setPercent(tState.percent || 0);
      setStage((tState.stage || 1) as StepStage);
      setProcessingStatusText(tState.statusText || "");
      if (tState.currentReleaseTitle) setCurrentReleaseTitle(tState.currentReleaseTitle);
      if (tState.fileName) setZipFileName(tState.fileName);
      if (tState.fileSize) setServerFileSize(tState.fileSize);

      if (tState.status === "completed") {
        setStage(7);
        setPercent(100);
        setIsBuilding(false);
        setProcessingStatusText(
          t(
            "Processing complete! The archive was packaged on the server and is ready for download.",
            "Сборка завершена! Архив успешно собран на сервере в фоне и готов к скачиванию."
          )
        );
        onSaveToHistory({
          totalReleases,
          totalTracks,
          artistCount: activeArtistsList.length,
          taskId: tState.taskId || taskId,
          zipFileName: tState.fileName,
          fileSize: tState.fileSize,
          exportFormat: currentFormat
        });
        window.dispatchEvent(new Event("catalog_export_task_updated"));
        return;
      }

      if (tState.status === "error") {
        setIsBuilding(false);
        setErrorCount(1);
        setFailedFiles([tState.error || "Error during background build"]);
        return;
      }

      if (tState.status === "processing") {
        setTimeout(() => pollServerTask(taskId), 1000);
      }
    } catch (e) {
      setTimeout(() => pollServerTask(taskId), 2000);
    }
  };

  // Primary: Server-side background packaging (survives tab close & phone battery die)
  const startServerPackaging = async () => {
    setIsBuilding(true);
    setErrorCount(0);
    setFailedFiles([]);
    setStage(1);
    setPercent(5);
    setActiveTaskId(null);
    setCompletedZipBlob(null);
    setServerFileSize(null);
    localStorage.removeItem("active_catalog_export_task_id");
    setProcessingStatusText(
      t(
        "Initializing background export on server...",
        "Запуск фоновой сборки каталога на сервере..."
      )
    );

    try {
      const payload = {
        artist: {
          artist_id: artist.artist_id,
          name: artist.name,
          disambiguation: artist.disambiguation
        },
        artists: activeArtistsList.map((a) => ({
          artist_id: a.artist_id,
          name: a.name,
          disambiguation: a.disambiguation
        })),
        releases: selectedReleasesList,
        selectedReleaseIds: Array.from(selectedReleaseIds),
        selectedTrackIdsMap: Object.fromEntries(
          Object.entries(selectedTrackIdsMap).map(([k, v]) => [k, Array.from(v)])
        ),
        exportFormat: currentFormat
      };

      const res = await fetch("/api/catalog/export-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!data.success || !data.task) {
        throw new Error(data.error || "Failed to start server export");
      }

      const task = data.task;
      setActiveTaskId(task.taskId);
      localStorage.setItem("active_catalog_export_task_id", task.taskId);
      window.dispatchEvent(new Event("catalog_export_task_updated"));
      setZipFileName(task.fileName);
      pollServerTask(task.taskId);
    } catch (err: any) {
      console.warn("Failed to start server export, starting client packaging:", err);
      startClientPackaging();
    }
  };

  // Fallback client-side packaging
  const startClientPackaging = async (ignoreErrors = false) => {
    setIsBuilding(true);
    setErrorCount(0);
    setFailedFiles([]);
    setPercent(5);
    setStage(1);
    setProcessingStatusText(
      t("Initializing transfer structure and checking catalog...", "Инициализация структуры каталога и проверка файлов...")
    );

    try {
      const zip = new JSZip();
      const safeArtistName = sanitizeFsName(artist.name, "Artist");
      const dateStr = new Date().toISOString().slice(0, 10);
      const generatedName =
        currentFormat === "release_date_link_cover"
          ? `${safeArtistName}_BackCatalog_Dates_${dateStr}.zip`
          : `${safeArtistName}_BackCatalog_${dateStr}.zip`;

      await new Promise((r) => setTimeout(r, 200));
      setPercent(15);
      setStage(2);
      setProcessingStatusText(
        t("Starting HD studio cover preparation (3000×3000px)...", "Запуск подготовки HD-обложек 3000×3000px...")
      );

      const localFailed: string[] = [];
      const coversFolder = zip.folder("covers") || zip;

      for (let rIdx = 0; rIdx < selectedReleasesList.length; rIdx++) {
        const rel = selectedReleasesList[rIdx];
        const relArtistName = rel.artist_name || artist.name;
        setCurrentReleaseIndex(rIdx + 1);
        setCurrentReleaseTitle(rel.title);

        setProcessingStatusText(
          t(
            `Generating studio cover 3000×3000px: ${rel.title} (${rIdx + 1}/${totalReleases})`,
            `Генерация студийной обложки 3000×3000px: ${rel.title} (${rIdx + 1} из ${totalReleases})`
          )
        );

        const padRel = String(rIdx + 1).padStart(2, "0");
        const safeRelArtist = sanitizeFsName(relArtistName, "Artist");
        const safeRelTitle = sanitizeFsName(rel.title, "Release");
        const coverFileName = `${padRel}_${safeRelArtist}_${safeRelTitle}.jpg`;

        try {
          const coverBlob = await generateStudioCoverBlob(rel.cover, rel.title, relArtistName);
          coversFolder.file(coverFileName, coverBlob);
        } catch (e: any) {
          localFailed.push(`${rel.title} - cover.jpg`);
        }

        const stageProgress = 15 + Math.floor(((rIdx + 1) / Math.max(1, totalReleases)) * 25);
        setPercent(stageProgress);
        await new Promise((r) => setTimeout(r, 0));
      }

      setStage(3);
      if (currentFormat === "release_date_link_cover") {
        setPercent(70);
        setProcessingStatusText(
          t("Audio WAV excluded for selected format.", "Пропуск аудио: выбран компактный формат без WAV...")
        );
        await new Promise((r) => setTimeout(r, 50));
      } else {
        setProcessingStatusText(
          t("Preparing uncompressed master WAV files...", "Подготовка мастер-аудиофайлов WAV...")
        );
        let processedTracks = 0;
        const audioFolder = zip.folder("audio") || zip;

        for (let rIdx = 0; rIdx < selectedReleasesList.length; rIdx++) {
          const rel = selectedReleasesList[rIdx];
          const relArtistName = rel.artist_name || artist.name;
          const padRel = String(rIdx + 1).padStart(2, "0");
          const safeRelArtist = sanitizeFsName(relArtistName, "Artist");
          const safeRelTitle = sanitizeFsName(rel.title, "Release");

          for (let tIdx = 0; tIdx < rel.tracks.length; tIdx++) {
            const trk = rel.tracks[tIdx];
            let wavFileName = "";
            if (rel.tracks.length === 1) {
              wavFileName = `${padRel}_${safeRelArtist}_${safeRelTitle}.wav`;
            } else {
              const padTrk = String(tIdx + 1).padStart(2, "0");
              const safeTrkTitle = sanitizeFsName(trk.title, "Track");
              wavFileName = `${padRel}_${padTrk}_${safeRelArtist}_${safeTrkTitle}.wav`;
            }

            setProcessingStatusText(
              t(
                `Packaging audio WAV: ${trk.title} (${processedTracks + 1}/${totalTracks})`,
                `Обработка мастер-WAV: ${trk.title} (${processedTracks + 1} из ${totalTracks})`
              )
            );

            try {
              const wavBlob = await fetchOrGenerateTrackWav(trk.track_id, trk.title, relArtistName);
              audioFolder.file(wavFileName, wavBlob);
            } catch (e) {
              localFailed.push(`${rel.title} / ${wavFileName}`);
            }

            processedTracks++;
            const trackProgress = 40 + Math.floor((processedTracks / Math.max(1, totalTracks)) * 32);
            setPercent(trackProgress);
            await new Promise((r) => setTimeout(r, 5));
          }
        }
      }

      if (localFailed.length > 0) {
        setErrorCount(localFailed.length);
        setFailedFiles(localFailed);
        // Resilient export: continue so all available data and files are safely packaged in ZIP
      }

      setStage(4);
      setPercent(75);
      setProcessingStatusText(
        t("Forming catalog.txt...", "Формирование файла catalog.txt...")
      );

      const catalogTxt =
        currentFormat === "release_date_link_cover"
          ? generateBackCatalogLiteTxt(artist.name, selectedReleasesList, selectedTrackIdsMap)
          : generateBackCatalogFullTxt(artist.name, selectedReleasesList, selectedTrackIdsMap);

      zip.file("catalog.txt", catalogTxt);

      setStage(5);
      setPercent(82);
      setProcessingStatusText(
        t("Packaging ZIP archive without CPU lag (STORE stream mode)...", "Упаковка единого ZIP-архива...")
      );

      await new Promise((r) => setTimeout(r, 50));

      const zipBlob = await zip.generateAsync(
        {
          type: "blob",
          compression: "STORE",
          streamFiles: true
        },
        (metadata) => {
          const zipP = 82 + Math.floor(metadata.percent * 0.12);
          setPercent(zipP);
        }
      );

      setStage(6);
      setPercent(96);
      setProcessingStatusText(
        t("Verifying archive file integrity...", "Проверка целостности и структуры готового архива...")
      );
      await new Promise((r) => setTimeout(r, 300));

      setZipFileName(generatedName);
      setCompletedZipBlob(zipBlob);

      setStage(7);
      setPercent(100);
      setIsBuilding(false);
      setProcessingStatusText(
        t(
          "Processing complete! All files have been successfully verified, packed into ZIP, and ready.",
          "Обработка завершена! Все файлы успешно проверены и упакованы в ZIP-архив."
        )
      );

      onSaveToHistory({
        totalReleases,
        totalTracks,
        artistCount: activeArtistsList.length,
        taskId: activeTaskId || undefined,
        zipFileName: generatedName,
        fileSize: zipBlob.size,
        exportFormat: currentFormat
      });

      saveAs(zipBlob, generatedName);
    } catch (err: any) {
      setIsBuilding(false);
      setErrorCount(1);
      setFailedFiles([err?.message || "Failed to generate ZIP"]);
      setProcessingStatusText(
        t("An error occurred during packaging. Please retry.", "Произошла ошибка при сборке архива. Пожалуйста, повторите.")
      );
    }
  };

  const handleDownloadZipAction = async () => {
    setDownloadError(null);

    // If we already have the blob in memory, save it instantly
    if (completedZipBlob) {
      saveAs(completedZipBlob, zipFileName || "BackCatalog.zip");
      return;
    }

    if (activeTaskId) {
      setIsDownloadingZip(true);
      try {
        const safeName = zipFileName || "BackCatalog.zip";
        const blob = await downloadCatalogArchive(activeTaskId, safeName, (status) => {
          setProcessingStatusText(status);
        });
        setCompletedZipBlob(blob);
        setProcessingStatusText(
          t(
            "Archive downloaded successfully!",
            "Архив успешно сохранён на ваше устройство!"
          )
        );
      } catch (err: any) {
        console.warn("Download archive warning:", err);
        setDownloadError(err?.message || "Не удалось скачать архив с сервера.");
      } finally {
        setIsDownloadingZip(false);
      }
    } else {
      startClientPackaging();
    }
  };

  const handleDownloadQuickFile = async (type: "excel" | "csv" | "txt" | "dates") => {
    setDownloadingFileType(type);
    setDownloadError(null);
    try {
      const baseName = (zipFileName || "catalog").replace(/\.zip$/i, "");
      if (type === "excel") {
        if (activeTaskId) {
          try {
            await downloadExportFile(activeTaskId, "excel", `${baseName}_codes.xlsx`, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            return;
          } catch {}
        }
        const buf = generateCodesExcelBuffer(artist.name, selectedReleasesList, selectedTrackIdsMap);
        saveAs(
          new Blob([buf], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          }),
          `${baseName}_codes.xlsx`
        );
      } else if (type === "csv") {
        if (activeTaskId) {
          try {
            await downloadExportFile(activeTaskId, "csv", `${baseName}_codes.csv`, "text/csv;charset=utf-8;");
            return;
          } catch {}
        }
        const csv = generateCodesCsv(artist.name, selectedReleasesList, selectedTrackIdsMap);
        saveAs(new Blob([csv], { type: "text/csv;charset=utf-8;" }), `${baseName}_codes.csv`);
      } else if (type === "txt") {
        if (activeTaskId) {
          try {
            await downloadExportFile(activeTaskId, "txt", `${baseName}_codes.txt`, "text/plain;charset=utf-8;");
            return;
          } catch {}
        }
        const txt = generateCatalogCodesTxt(artist.name, selectedReleasesList, selectedTrackIdsMap);
        saveAs(new Blob([txt], { type: "text/plain;charset=utf-8;" }), `${baseName}_codes.txt`);
      } else if (type === "dates") {
        if (activeTaskId) {
          try {
            await downloadExportFile(activeTaskId, "dates", `${baseName}_dates.txt`, "text/plain;charset=utf-8;");
            return;
          } catch {}
        }
        const datesTxt = generateCatalogDatesTxt(artist.name, selectedReleasesList, selectedTrackIdsMap);
        saveAs(new Blob([datesTxt], { type: "text/plain;charset=utf-8;" }), `${baseName}_dates.txt`);
      }
    } catch (err: any) {
      console.warn(`Download ${type} warning:`, err);
      setDownloadError(err?.message || `Не удалось скачать файл`);
    } finally {
      setDownloadingFileType(null);
    }
  };

  useEffect(() => {
    if (isOpen) {
      // Check if there is an existing active task in localStorage
      const storedTaskId = localStorage.getItem("active_catalog_export_task_id");
      if (storedTaskId) {
        fetch(`/api/catalog/export-task/${storedTaskId}`)
          .then((res) => res.json())
          .then((data) => {
            if (
              data.success &&
              data.task &&
              data.task.artistName.toLowerCase() === artist.name.toLowerCase() &&
              data.task.totalReleases === selectedReleaseIds.size &&
              data.task.status === "processing"
            ) {
              setActiveTaskId(storedTaskId);
              setZipFileName(data.task.fileName);
              setIsBuilding(true);
              pollServerTask(storedTaskId);
            } else {
              startServerPackaging();
            }
          })
          .catch(() => startServerPackaging());
      } else {
        startServerPackaging();
      }
    } else {
      setStage(1);
      setPercent(0);
      setProcessingStatusText("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-zinc-200 dark:border-zinc-800 shadow-2xl flex flex-col gap-5 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
              {isMultiArtist ? <Users className="w-5 h-5" /> : <FolderArchive className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
                <span>
                  {stage === 7
                    ? t("Catalog is ready!", "Каталог готов!")
                    : isMultiArtist
                    ? t("Generating Multi-Artist Catalog", "Сборка каталога артистов")
                    : t("Generating Back-Catalog", "Формирование каталога")}
                </span>
              </h3>
              <p className="text-xs text-zinc-400">
                {isMultiArtist ? `${activeArtistsList.length} ${t("artists", "артистов")}` : artist.name} • {totalReleases} {t("releases", "релизов")} • {totalTracks}{" "}
                {t("tracks", "треков")}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {stage !== 7 && (
              <button
                type="button"
                onClick={onClose}
                className="px-2.5 py-1.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                title={t("Minimize to background", "Свернуть в фон")}
              >
                <Minimize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t("Minimize", "Свернуть")}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Server Background Mode Notice Banner */}
        <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl bg-orange-50/90 dark:bg-orange-950/40 border border-orange-200/80 dark:border-orange-800/60 text-orange-900 dark:text-orange-200 text-xs leading-relaxed">
          <ShieldCheck className="w-4 h-4 text-orange-500 shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="font-bold text-orange-600 dark:text-orange-400">
              {t("Automatic background processing: ", "Автоматическая фоновая сборка: ")}
            </span>
            <span className="text-zinc-600 dark:text-zinc-300 text-[11px]">
              {t(
                "You don't need to keep the tab open! If your phone battery dies or tab closes, the server finishes the packaging automatically.",
                "Вкладку держать открытой не нужно! Если телефон сядет или браузер закроется, сервер закончит сборку в фоне."
              )}
            </span>
          </div>
        </div>

        {/* 7 Visual Stages Flow */}
        <div className="flex flex-col gap-2 bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-200/60 dark:border-zinc-700/60">
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className={stage === 7 ? "text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5" : "text-zinc-700 dark:text-zinc-300"}>
              {stage === 7 && <CheckCircle2 className="w-4 h-4" />}
              {stage === 7 ? t("Processing Finished (100%)", "Обработка завершена (100%)") : stagesList[stage - 1]?.label}
            </span>
            <span className={`font-mono ${stage === 7 ? "text-emerald-600 dark:text-emerald-400 font-extrabold" : "text-orange-500 font-bold"}`}>
              {percent}%
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2.5 rounded-full bg-zinc-200 dark:bg-zinc-700 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                stage === 7 ? "bg-emerald-500" : "bg-orange-500"
              }`}
              style={{ width: `${percent}%` }}
            />
          </div>

          {/* Persistent Dynamic Processing Status Text */}
          <div className="mt-2 min-h-[36px] flex items-start gap-2 text-xs rounded-xl p-2.5 bg-white/70 dark:bg-zinc-900/70 border border-zinc-200/50 dark:border-zinc-700/50">
            {stage === 7 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            ) : isBuilding ? (
              <Loader2 className="w-4 h-4 animate-spin text-orange-500 shrink-0 mt-0.5" />
            ) : (
              <Sparkles className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
            )}
            <span
              className={`leading-relaxed ${
                stage === 7
                  ? "text-emerald-700 dark:text-emerald-300 font-semibold"
                  : "text-zinc-700 dark:text-zinc-200 font-medium"
              }`}
            >
              {processingStatusText || (stage === 7
                ? t("Catalog successfully packaged and ready.", "Каталог успешно упакован в архив.")
                : t("Processing on server...", "Сборка на сервере..."))}
            </span>
          </div>

          {/* Stages List check-marks */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 mt-2 pt-2.5 border-t border-zinc-200/50 dark:border-zinc-700/50 text-[11px]">
            {stagesList.slice(0, 6).map((stg) => {
              const isPast = stage > stg.id || stage === 7;
              const isCurr = stage === stg.id && stage !== 7;

              return (
                <div
                  key={stg.id}
                  className={`flex items-center gap-1.5 ${
                    isPast
                      ? "text-emerald-600 dark:text-emerald-400 font-medium"
                      : isCurr
                      ? "text-orange-500 font-bold"
                      : "text-zinc-400 opacity-60"
                  }`}
                >
                  {isPast ? (
                    <Check className="w-3 h-3 stroke-[3]" />
                  ) : isCurr ? (
                    <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                  ) : (
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
                  )}
                  <span className="truncate">{stg.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error Handling State */}
        {errorCount > 0 && (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs flex flex-col gap-3">
            <div className="flex items-center gap-2 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>
                {t(
                  `Could not prepare ${errorCount} files`,
                  `Не удалось подготовить ${errorCount} файлов`
                )}
              </span>
            </div>

            <p className="text-[11px] opacity-90 leading-relaxed">
              {t(
                "Some external platform audio tracks were rate-limited or unavailable. You can retry with synthesis or proceed to build the archive with available files.",
                "Некоторые внешние файлы треков были временно недоступны. Вы можете повторить попытку или продолжить сборку архива."
              )}
            </p>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => startServerPackaging()}
                className="px-3 py-1.5 rounded-lg bg-amber-100 dark:bg-amber-900/60 hover:bg-amber-200 text-amber-900 dark:text-amber-100 font-bold text-xs transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3 h-3" />
                <span>{t("Retry", "Повторить")}</span>
              </button>

              <button
                type="button"
                onClick={() => startClientPackaging(true)}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs transition-colors"
              >
                {t("Continue without file", "Продолжить без файла")}
              </button>
            </div>
          </div>
        )}

        {/* Completion Success Screen: WITH DEDICATED ZIP DOWNLOAD BUTTON */}
        {stage === 7 && (
          <div className="flex flex-col items-center text-center gap-4 py-1 animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-3xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h4 className="text-xl font-bold text-zinc-900 dark:text-zinc-50">
                {t("Archive successfully generated!", "Каталог готов к передаче лейблу!")}
              </h4>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 max-w-xs mx-auto">
                {isMultiArtist && `${activeArtistsList.length} ${t("artists", "артистов")} • `}
                {totalReleases} {t("releases", "релизов")} • {totalTracks} {t("tracks", "треков")} •{" "}
                {totalReleases} {t("covers (3000x3000px)", "обложек (3000x3000px)")}
              </p>
            </div>

            <div className="w-full p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800 font-mono text-xs text-zinc-600 dark:text-zinc-300 truncate border border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
              <span className="truncate">📦 {zipFileName || "BackCatalog.zip"}</span>
              {serverFileSize && (
                <span className="text-[11px] text-zinc-400 shrink-0 ml-2 font-sans font-medium">
                  {(serverFileSize / (1024 * 1024)).toFixed(1)} MB
                </span>
              )}
            </div>

            {/* Download Error Banner with Client Fallback Option */}
            {downloadError && (
              <div className="w-full p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs flex flex-col gap-2.5 animate-in fade-in">
                <div className="flex items-start gap-2 font-bold text-left">
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                  <span className="leading-snug">{downloadError}</span>
                </div>
                <div className="flex items-center justify-end gap-2 pt-1 border-t border-rose-200/60 dark:border-rose-800/60 flex-wrap">
                  {activeTaskId && (
                    <a
                      href={`/api/catalog/export-download/${encodeURIComponent(activeTaskId)}`}
                      download={zipFileName || "BackCatalog.zip"}
                      className="px-3 py-1.5 rounded-lg bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t("Direct download", "Прямое скачивание")}</span>
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => startClientPackaging(true)}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{t("Build archive in browser", "Собрать архив прямо в браузере")}</span>
                  </button>
                </div>
              </div>
            )}

            {/* DEDICATED EXTRA ZIP DOWNLOAD BUTTON REQUESTED BY USER */}
            <button
              type="button"
              disabled={isDownloadingZip}
              onClick={handleDownloadZipAction}
              className="w-full py-3.5 px-5 rounded-2xl bg-orange-500 hover:bg-orange-600 active:scale-95 disabled:opacity-75 disabled:pointer-events-none text-white font-bold text-base shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2.5 ring-4 ring-orange-500/20 cursor-pointer"
            >
              {isDownloadingZip ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{t("Downloading archive...", "Сохранение архива на устройство...")}</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5 stroke-[2.5]" />
                  <span>
                    {t("Download Full ZIP", "Скачать полный ZIP")}
                    {serverFileSize
                      ? serverFileSize >= 1024 * 1024 * 1024
                        ? ` (${(serverFileSize / (1024 * 1024 * 1024)).toFixed(2)} ГБ)`
                        : ` (${(serverFileSize / (1024 * 1024)).toFixed(1)} МБ)`
                      : ""}
                  </span>
                </>
              )}
            </button>

            {/* Quick Export Direct Tables & Texts */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full">
              <button
                type="button"
                disabled={Boolean(downloadingFileType)}
                onClick={() => handleDownloadQuickFile("excel")}
                className="w-full py-2.5 px-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                title="Скачать реестр кодов (UPC и ISRC) в формате Excel"
              >
                {downloadingFileType === "excel" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                ) : (
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                )}
                <span>Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                disabled={Boolean(downloadingFileType)}
                onClick={() => handleDownloadQuickFile("csv")}
                className="w-full py-2.5 px-2 rounded-xl bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/40 dark:hover:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                title="Скачать реестр кодов в формате CSV"
              >
                {downloadingFileType === "csv" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-sky-600" />
                ) : (
                  <Download className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                )}
                <span>CSV</span>
              </button>

              <button
                type="button"
                disabled={Boolean(downloadingFileType)}
                onClick={() => handleDownloadQuickFile("txt")}
                className="w-full py-2.5 px-2 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                title="Скачать реестр кодов в формате TXT"
              >
                {downloadingFileType === "txt" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                ) : (
                  <FileText className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                )}
                <span>TXT {t("Codes", "Коды")}</span>
              </button>

              <button
                type="button"
                disabled={Boolean(downloadingFileType)}
                onClick={() => handleDownloadQuickFile("dates")}
                className="w-full py-2.5 px-2 rounded-xl bg-purple-100 hover:bg-purple-200 dark:bg-purple-900/50 dark:hover:bg-purple-800/50 text-purple-800 dark:text-purple-200 border border-purple-300 dark:border-purple-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                title={t(
                  "Download release dates: Artist - Album/Track - Release Date",
                  "Скачать даты релизов: Артист - Альбом/Трек - Дата релиза"
                )}
              >
                {downloadingFileType === "dates" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                ) : (
                  <Calendar className="w-4 h-4 text-purple-600 dark:text-purple-300" />
                )}
                <span>TXT {t("Dates", "Даты")}</span>
              </button>
            </div>

            <div className="flex items-center gap-3 w-full pt-1">
              <button
                type="button"
                onClick={() => startServerPackaging()}
                className="w-1/2 py-3 px-4 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 font-bold text-sm transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>{t("Re-package", "Собрать заново")}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-1/2 py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 font-bold text-sm transition-all"
              >
                {t("Close", "Закрыть")}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
