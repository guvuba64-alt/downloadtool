import React, { useState } from "react";
import { ArtistEntity } from "./types";
import { ReleaseDateLookup } from "./ReleaseDateLookup";
import {
  Search,
  Link2,
  Music,
  Check,
  ArrowRight,
  ExternalLink,
  Loader2,
  Sparkles,
  UserCheck,
  Users,
  Plus,
  Trash2,
  ListPlus,
  Layers,
  X,
  CheckCircle2,
  Upload,
  Calendar
} from "lucide-react";

interface Step1SearchArtistProps {
  onArtistSelected: (artist: ArtistEntity) => void;
  onArtistsBatchSelected?: (artists: ArtistEntity[]) => void;
  t: (en: string, ru: string) => string;
}

export function Step1SearchArtist({
  onArtistSelected,
  onArtistsBatchSelected,
  t
}: Step1SearchArtistProps) {
  const [searchMode, setSearchMode] = useState<"name" | "link" | "batch" | "release_date">("name");
  const [nameQuery, setNameQuery] = useState("");
  const [linkQuery, setLinkQuery] = useState("");
  const [batchText, setBatchText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [results, setResults] = useState<ArtistEntity[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  // Multi-artist selection queue ("100 артистов и до бесконечности")
  const [queuedArtists, setQueuedArtists] = useState<ArtistEntity[]>([]);

  // Selected artist confirmation state (protection against accidental selection)
  const [confirmingArtist, setConfirmingArtist] = useState<ArtistEntity | null>(null);
  const [confirmingBatch, setConfirmingBatch] = useState(false);

  const sampleArtists = ["FEDUK", "MACAN", "MARKUL", "SALUKI", "OG Buda", "MAYOT", "Big Baby Tape", "Boulevard Depo", "Kizaru", "Miyagi & Эндшпиль"];

  // 100 popular artists preset for 1-click test of "100 артистов и до бесконечности"
  const TOP_100_ARTISTS_LIST = [
    "FEDUK", "MACAN", "MARKUL", "SALUKI", "OG Buda", "MAYOT", "Big Baby Tape", "Boulevard Depo", "Kizaru", "Miyagi & Эндшпиль",
    "Скриптонит", "Баста", "PHARAOH", "Lizer", "Obladaet", "Guf", "Oxxxymiron", "ЛСП", "Thomas Mraz", "Платина",
    "SQWOZ BAB", "GONE.Fludd", "T-Fest", "104", "Jeembo", "Truwer", "Mnogoznaal", "Rocket", "Soda Luv", "Bushido Zho",
    "Scally Milano", "Yanix", "Jah Khalib", "HammAli & Navai", "Rauf & Faik", "Jony", "Andro", "Elman", "Gafur", "Zivert",
    "ANNA ASTI", "Клава Кока", "Mary Gu", "Моя Мишель", "DEAD BLONDE", "GSPD", "Cream Soda", "Хлеб", "Shortparis", "RSAC",
    "Пошлая Молли", "Три дня дождя", "Wildways", "Lumen", "Animal ДжаZ", "Noize MC", "Anacondaz", "ATL", "Horus", "Zarif",
    "FRIENDLY THUG 52 NGG", "ALBLAK 52", "Hugo Loud", "Toxi$", "Icegergert", "Heronwater", "Voskr", "Baby Melo", "Kai Angel", "9mice",
    "Glocki52", "Saint Laurent", "LIL KRYSTALL", "Flesh", "Thrill Pill", "Cakeboy", "Irbis", "White Punk", "Karna.val", "Instasamka",
    "MIA BOYKA", "Егор Крид", "Dava", "Hensy", "Ramil'", "NЮ", "Хабиб", "Люся Чеботина", "Dabro", "MiyaGi",
    "Andy Panda", "Natan", "Мот", "Джиган", "Тимати", "Doni", "L'One", "ST", "Loc-Dog", "Каспийский Груз"
  ];

  const handleSearch = async (overrideQuery?: string) => {
    const query = overrideQuery !== undefined ? overrideQuery : (searchMode === "name" ? nameQuery : linkQuery);
    const cleanQ = query.trim();

    if (!cleanQ) {
      setError(t("Please enter artist name or URL", "Введите название артиста или ссылку на профиль"));
      return;
    }

    setLoading(true);
    setError("");
    setHasSearched(true);
    setResults([]);

    try {
      // Pass limit=100 so all matching artists are returned
      const res = await fetch(`/api/music/back-catalog/search-artist?query=${encodeURIComponent(cleanQ)}&limit=100`);
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || t("Failed to search artist", "Не удалось найти артиста"));
      }

      setResults(data.artists || []);
      if ((data.artists || []).length === 0) {
        setError(t("No artists found with this query", "По вашему запросу артистов не найдено"));
      }
    } catch (err: any) {
      setError(err.message || t("Search error", "Ошибка при выполнении поиска"));
    } finally {
      setLoading(false);
    }
  };

  // Batch search & import (up to 100+ artists and beyond)
  const handleBatchProcess = async () => {
    const rawLines = batchText
      .split(/[\n,;]+/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (rawLines.length === 0) {
      setError(t("Please paste at least one artist name or URL", "Вставьте хотя бы одно имя артиста или ссылку"));
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/music/back-catalog/batch-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ queries: rawLines })
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || t("Failed to process batch", "Не удалось обработать список артистов"));
      }

      const foundList: ArtistEntity[] = data.artists || [];
      // Merge into queued artists
      setQueuedArtists((prev) => {
        const existingIds = new Set(prev.map((a) => a.artist_id));
        const newOnes = foundList.filter((a) => !existingIds.has(a.artist_id));
        return [...prev, ...newOnes];
      });

      setResults(foundList);
      setHasSearched(true);
    } catch (err: any) {
      setError(err.message || t("Batch processing error", "Ошибка при обработке списка артистов"));
    } finally {
      setLoading(false);
    }
  };

  const addArtistToQueue = (artist: ArtistEntity) => {
    setQueuedArtists((prev) => {
      if (prev.some((a) => a.artist_id === artist.artist_id)) return prev;
      return [...prev, artist];
    });
  };

  const removeArtistFromQueue = (artistId: string) => {
    setQueuedArtists((prev) => prev.filter((a) => a.artist_id !== artistId));
  };

  const addAllResultsToQueue = () => {
    setQueuedArtists((prev) => {
      const map = new Map<string, ArtistEntity>();
      prev.forEach((a) => map.set(a.artist_id, a));
      results.forEach((a) => map.set(a.artist_id, a));
      return Array.from(map.values());
    });
  };

  const handleConfirmBatchTransfer = () => {
    if (queuedArtists.length === 0) return;
    if (queuedArtists.length === 1) {
      onArtistSelected(queuedArtists[0]);
    } else if (onArtistsBatchSelected) {
      onArtistsBatchSelected(queuedArtists);
    } else {
      onArtistSelected(queuedArtists[0]);
    }
    setConfirmingBatch(false);
  };

  const handleBatchFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setBatchText((prev) => (prev ? `${prev}\n${text}` : text));
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-6">
      {/* Header Info */}
      <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
            1
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">
              {t("Find your artist or import 100+ artists", "Поиск артиста или пакетный перенос (100+ артистов)")}
            </h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">
              {t(
                "Transfer a single artist discography or an entire roster of 100+ artists to infinity.",
                "Переносите дискографию одного артиста или формируйте единый бэк-каталог на 100 артистов и до бесконечности."
              )}
            </p>
          </div>
        </div>

        {/* 4 Search Modes (Name vs Link vs Batch vs Manual) */}
        <div className="flex gap-2 mt-6 p-1 bg-zinc-100 dark:bg-zinc-800 rounded-xl max-w-2xl overflow-x-auto">
          <button
            type="button"
            onClick={() => setSearchMode("name")}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              searchMode === "name"
                ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-sm"
                : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <Search className="w-4 h-4 shrink-0" />
            <span>{t("By Name", "По имени")}</span>
          </button>
          <button
            type="button"
            onClick={() => setSearchMode("link")}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              searchMode === "link"
                ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-sm"
                : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <Link2 className="w-4 h-4 shrink-0" />
            <span>{t("By Link", "По ссылке")}</span>
          </button>
          <button
            type="button"
            onClick={() => setSearchMode("batch")}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              searchMode === "batch"
                ? "bg-orange-500 text-white shadow-sm"
                : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <ListPlus className="w-4 h-4 shrink-0" />
            <span>{t("Batch (100+)", "Пакетный (100+)")}</span>
          </button>
          <button
            type="button"
            onClick={() => setSearchMode("release_date")}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              searchMode === "release_date"
                ? "bg-purple-600 text-white shadow-sm"
                : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <Calendar className="w-4 h-4 shrink-0" />
            <span>{t("Release Date", "Дата релиза")}</span>
          </button>
        </div>

        {/* Release Date Lookup Mode (Outputs strictly Release Title and Release Date) */}
        {searchMode === "release_date" && (
          <ReleaseDateLookup
            onSelectArtist={onArtistSelected}
            t={t}
          />
        )}

        {/* Name or Link Search Form */}
        {searchMode === "name" || searchMode === "link" ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className="mt-4 flex flex-col sm:flex-row gap-3"
          >
            {searchMode === "name" ? (
              <div className="relative flex-1">
                <input
                  type="text"
                  value={nameQuery}
                  onChange={(e) => setNameQuery(e.target.value)}
                  placeholder={t("For example: FEDUK", "Например: FEDUK")}
                  className="w-full h-12 pl-4 pr-10 text-sm sm:text-base rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
                />
                <Search className="absolute right-3.5 top-3.5 w-5 h-5 text-zinc-400 pointer-events-none" />
              </div>
            ) : (
              <div className="relative flex-1">
                <input
                  type="text"
                  value={linkQuery}
                  onChange={(e) => setLinkQuery(e.target.value)}
                  placeholder={t(
                    "https://music.yandex.ru/artist/4291880 or Spotify",
                    "https://music.yandex.ru/artist/4291880 или Spotify"
                  )}
                  className="w-full h-12 pl-4 pr-10 text-sm sm:text-base rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
                />
                <Link2 className="absolute right-3.5 top-3.5 w-5 h-5 text-zinc-400 pointer-events-none" />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="h-12 px-6 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 shrink-0"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
              <span>
                {searchMode === "name"
                  ? t("Find artist", "Найти артиста")
                  : t("Find by link", "Найти по ссылке")}
              </span>
            </button>
          </form>
        ) : searchMode === "batch" ? (
          /* Batch Multi-Artist Form (100+ Artists and Beyond) */
          <div className="mt-4 flex flex-col gap-3 animate-in fade-in duration-200">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                {t(
                  "Paste a list of artists or profile links (100+ artists up to infinity):",
                  "Вставьте список имен артистов или ссылок (до 100+ артистов и бесконечности):"
                )}
              </label>
              <div className="flex items-center gap-2">
                <label className="text-xs px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-bold transition-all flex items-center gap-1 cursor-pointer">
                  <Upload className="w-3.5 h-3.5 text-orange-500" />
                  <span>{t("Import File (.txt / .csv)", "Файл (.txt / .csv)")}</span>
                  <input
                    type="file"
                    accept=".txt,.csv"
                    className="hidden"
                    onChange={handleBatchFileUpload}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => setBatchText(TOP_100_ARTISTS_LIST.join("\n"))}
                  className="text-xs px-2.5 py-1 rounded-lg bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 font-bold transition-all flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t("Fill 100 Artists", "Заполнить Топ-100 артистов")}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBatchText("")}
                  className="text-xs px-2 py-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 transition-colors"
                >
                  {t("Clear", "Очистить")}
                </button>
              </div>
            </div>

            <textarea
              rows={6}
              value={batchText}
              onChange={(e) => setBatchText(e.target.value)}
              placeholder={`FEDUK\nMACAN\nMARKUL\nOG Buda\nhttps://music.yandex.ru/artist/4291880\n...`}
              className="w-full p-3.5 text-xs sm:text-sm font-mono rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all resize-y"
            />

            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-zinc-400 font-medium">
                {batchText.split(/[\n,;]+/).filter((s) => s.trim().length > 0).length}{" "}
                {t("artists in input", "артистов указано в списке")}
              </span>

              <button
                type="button"
                disabled={loading || !batchText.trim()}
                onClick={handleBatchProcess}
                className="px-6 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs sm:text-sm transition-all shadow-sm flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4" />
                )}
                <span>{t("Load and verify all artists", "Загрузить и проверить всех артистов")}</span>
              </button>
            </div>
          </div>
        ) : null}

        {/* Quick Sample Chips */}
        {searchMode === "name" && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-xs text-zinc-400 font-medium">
              {t("Quick search:", "Быстрый пример:")}
            </span>
            {sampleArtists.map((artist) => (
              <button
                key={artist}
                type="button"
                onClick={() => {
                  setNameQuery(artist);
                  handleSearch(artist);
                }}
                className="text-xs px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-orange-500/10 hover:text-orange-500 text-zinc-600 dark:text-zinc-300 font-medium transition-all"
              >
                {artist}
              </button>
            ))}
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm">
            {error}
          </div>
        )}
      </div>

      {/* Roster Queue Card ("Очередь переноса: до бесконечности") */}
      {queuedArtists.length > 0 && (
        <div className="bg-gradient-to-br from-orange-500/10 via-amber-500/5 to-transparent rounded-2xl border-2 border-orange-500/30 p-5 shadow-sm flex flex-col gap-4 animate-in zoom-in-95 duration-200">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-500 text-white flex items-center justify-center font-bold shadow-sm">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
                    {t("Batch Transfer Roster", "Очередь пакетного переноса")}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-xs font-black bg-orange-500 text-white">
                    {queuedArtists.length} {t("artists", "артистов")}
                  </span>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {t(
                    "All queued artists will be processed and bundled into your distribution package.",
                    "Все выбранные артисты будут включены в единый архив передачи прав."
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setQueuedArtists([])}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t("Clear all", "Очистить всех")}</span>
              </button>

              <button
                type="button"
                onClick={() => setConfirmingBatch(true)}
                className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <span>
                  {t(`Transfer all ${queuedArtists.length} artists →`, `Перенести всех ${queuedArtists.length} артистов →`)}
                </span>
              </button>
            </div>
          </div>

          {/* Badges of queued artists */}
          <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto pr-1">
            {queuedArtists.map((ar) => (
              <div
                key={ar.artist_id}
                className="inline-flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 shadow-xs text-xs font-semibold text-zinc-800 dark:text-zinc-200"
              >
                {ar.avatar ? (
                  <img src={ar.avatar} alt={ar.name} className="w-5 h-5 rounded-md object-cover" />
                ) : (
                  <div className="w-5 h-5 rounded-md bg-orange-500/10 text-orange-500 flex items-center justify-center text-[10px]">
                    <Music className="w-3 h-3" />
                  </div>
                )}
                <span>{ar.name}</span>
                <button
                  type="button"
                  onClick={() => removeArtistFromQueue(ar.artist_id)}
                  className="text-zinc-400 hover:text-red-500 ml-0.5"
                  title={t("Remove", "Удалить")}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results List */}
      {results.length > 0 && (
        <div className="flex flex-col gap-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-400">
                {t("Search Results", "Найденные артисты")} ({results.length})
              </h3>
              <p className="text-xs text-zinc-400">
                {t("Select an artist or add to roster for batch transfer", "Выберите артиста или добавьте в ростер для переноса")}
              </p>
            </div>

            {results.length > 1 && (
              <button
                type="button"
                onClick={addAllResultsToQueue}
                className="px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-orange-500/10 hover:text-orange-500 text-zinc-700 dark:text-zinc-300 text-xs font-bold transition-all flex items-center gap-1.5 border border-zinc-200 dark:border-zinc-700"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t(`Add all ${results.length} artists to roster`, `Добавить всех (${results.length} артистов) в очередь`)}</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {results.map((artist) => {
              const isQueued = queuedArtists.some((q) => q.artist_id === artist.artist_id);

              return (
                <div
                  key={artist.artist_id}
                  className={`bg-white dark:bg-zinc-900 rounded-2xl border p-5 shadow-sm transition-all flex flex-col justify-between group ${
                    isQueued
                      ? "border-orange-500 ring-1 ring-orange-500/20"
                      : "border-zinc-200 dark:border-white/10 hover:border-orange-500/50"
                  }`}
                >
                  <div className="flex items-start gap-4">
                    {artist.avatar ? (
                      <img
                        src={artist.avatar}
                        alt={artist.name}
                        className="w-16 h-16 rounded-2xl object-cover bg-zinc-100 dark:bg-zinc-800 shadow-sm shrink-0 border border-zinc-200 dark:border-zinc-800"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center shrink-0">
                        <Music className="w-8 h-8" />
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 truncate">
                          {artist.name}
                        </h4>
                        <span className="shrink-0 px-1.5 py-0.5 rounded text-[10px] font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400 uppercase">
                          {artist.provider || "verified"}
                        </span>
                      </div>

                      <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 line-clamp-2">
                        {artist.disambiguation || t("Catalog Artist", "Артист музыкального каталога")}
                      </p>

                      <div className="flex items-center gap-3 mt-2 text-xs font-semibold text-zinc-600 dark:text-zinc-300">
                        <span>
                          {artist.releaseCount || 12} {t("releases", "релизов")}
                        </span>
                        <span>•</span>
                        <span>
                          {artist.trackCount || 47} {t("tracks", "треков")}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 pt-4 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {artist.platform_links?.yandex && (
                        <a
                          href={artist.platform_links.yandex}
                          target="_blank"
                          rel="noreferrer"
                          className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 text-xs flex items-center gap-1"
                          title="Yandex Music"
                        >
                          Яндекс <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Add to batch queue button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (isQueued) {
                            removeArtistFromQueue(artist.artist_id);
                          } else {
                            addArtistToQueue(artist);
                          }
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 ${
                          isQueued
                            ? "bg-orange-500 text-white"
                            : "bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-orange-500/10 hover:text-orange-500"
                        }`}
                      >
                        {isQueued ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                        <span>{isQueued ? t("In Roster", "В очереди") : t("+ Roster", "+ В очередь")}</span>
                      </button>

                      {/* Direct single selection */}
                      <button
                        type="button"
                        onClick={() => setConfirmingArtist(artist)}
                        className="px-3.5 py-1.5 rounded-xl bg-zinc-900 dark:bg-white hover:bg-orange-500 dark:hover:bg-orange-500 text-white dark:text-zinc-900 hover:text-white dark:hover:text-white text-xs font-bold transition-all flex items-center gap-1 shadow-xs"
                      >
                        <span>{t("Select", "Выбрать")}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Confirmation Modal - Single Selection */}
      {confirmingArtist && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl max-w-md w-full p-6 border border-zinc-200 dark:border-zinc-800 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                  {t("Confirm artist selection", "Подтвердите выбор артиста")}
                </h3>
                <p className="text-xs text-zinc-400">
                  {t("Protection against accidental misselection", "Защита от случайного выбора другого артиста")}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700/60 flex items-center gap-4 mb-6">
              {confirmingArtist.avatar ? (
                <img
                  src={confirmingArtist.avatar}
                  alt={confirmingArtist.name}
                  className="w-14 h-14 rounded-xl object-cover"
                />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                  <Music className="w-6 h-6" />
                </div>
              )}
              <div>
                <h4 className="font-bold text-base text-zinc-900 dark:text-zinc-100">
                  {confirmingArtist.name}
                </h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {confirmingArtist.releaseCount || 12} {t("releases", "релизов")} •{" "}
                  {confirmingArtist.trackCount || 47} {t("tracks", "треков")}
                </p>
                <p className="text-[11px] text-orange-600 dark:text-orange-400 font-medium mt-0.5">
                  {confirmingArtist.disambiguation}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmingArtist(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
              >
                {t("Cancel", "Отмена")}
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = confirmingArtist;
                  setConfirmingArtist(null);
                  onArtistSelected(target);
                }}
                className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <span>{t("Confirm & Load Catalog", "Подтвердить и загрузить каталог")}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal - Batch Multi-Artist Transfer ("все 100 артистов и до бесконечности") */}
      {confirmingBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl max-w-lg w-full p-6 border border-zinc-200 dark:border-zinc-800 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                  {t(
                    `Confirm transfer of ${queuedArtists.length} artists`,
                    `Подтвердите перенос ${queuedArtists.length} артистов`
                  )}
                </h3>
                <p className="text-xs text-zinc-400">
                  {t("Batch catalog generation for distribution", "Формирование единого бэк-каталога для лейбла")}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700/60 mb-5 max-h-56 overflow-y-auto">
              <div className="grid grid-cols-2 gap-2 text-xs">
                {queuedArtists.map((a, i) => (
                  <div key={a.artist_id} className="flex items-center gap-2 truncate">
                    <span className="text-orange-500 font-bold">{i + 1}.</span>
                    <span className="font-semibold text-zinc-800 dark:text-zinc-200 truncate">
                      {a.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-6 leading-relaxed">
              {t(
                `On the next step, discographies for all ${queuedArtists.length} artists will be loaded. You will be able to select releases and export a unified master archive.`,
                `На следующем шаге будет загружена дискография всех ${queuedArtists.length} артистов. Вы сможете выбрать нужные релизы и выгрузить общий архив со всеми папками и паспортами.`
              )}
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmingBatch(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
              >
                {t("Cancel", "Отмена")}
              </button>
              <button
                type="button"
                onClick={handleConfirmBatchTransfer}
                className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <span>{t(`Start Transfer (${queuedArtists.length})`, `Начать перенос (${queuedArtists.length})`)}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
