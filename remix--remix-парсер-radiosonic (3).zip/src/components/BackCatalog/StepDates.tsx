import React, { useState, useMemo } from "react";
import { ReleaseEntity, ArtistEntity } from "./types";
import {
  formatReleaseDateLine,
  parseReleaseDatesFromText,
  generateReleaseDatesText,
  normalizeDateString
} from "./releaseDateHelper";
import { saveAs } from "file-saver";
import {
  Calendar,
  FileText,
  Upload,
  Copy,
  Check,
  Download,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Filter,
  Layers,
  FileCheck2,
  Disc,
  Music,
  Trash2
} from "lucide-react";

interface StepDatesProps {
  artist: ArtistEntity;
  artists?: ArtistEntity[];
  releases: ReleaseEntity[];
  selectedReleaseIds: Set<string>;
  selectedTrackIdsMap: Record<string, Set<string>>;
  onUpdateReleaseDate: (releaseId: string, releaseDate: string) => void;
  onBatchUpdateDates: (dateMap: Record<string, string>) => void;
  onNext: () => void;
  onBack: () => void;
  t: (en: string, ru: string) => string;
}

export function StepDates({
  artist,
  artists,
  releases,
  selectedReleaseIds,
  selectedTrackIdsMap,
  onUpdateReleaseDate,
  onBatchUpdateDates,
  onNext,
  onBack,
  t
}: StepDatesProps) {
  // Sub-tabs inside the Release Dates view
  const [activeSubTab, setActiveSubTab] = useState<"lines" | "import" | "table">("lines");
  const [lineMode, setLineMode] = useState<"releases" | "tracks" | "both">("releases");
  const [searchQuery, setSearchQuery] = useState("");
  const [isCopiedAll, setIsCopiedAll] = useState(false);
  const [copiedLineId, setCopiedLineId] = useState<string | null>(null);

  // Import TXT/Text state
  const [importText, setImportText] = useState("");
  const [parseResult, setParseResult] = useState<ReturnType<typeof parseReleaseDatesFromText> | null>(null);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);

  // Filtered selected releases
  const selectedReleases = useMemo(() => {
    return releases.filter((r) => selectedReleaseIds.has(r.release_id));
  }, [releases, selectedReleaseIds]);

  const defaultArtistName = artist?.name || "Артист";

  // Generated list of formatted strings: "Артисты - Название альбома/трека - Дата релиза"
  const formattedRows = useMemo(() => {
    const list: Array<{
      id: string;
      line: string;
      type: "release" | "track";
      artistName: string;
      title: string;
      date: string;
      hasDate: boolean;
      releaseId: string;
      trackId?: string;
      cover?: string;
      releaseType?: string;
      label?: string;
      upc?: string;
      trackCount?: number;
    }> = [];

    selectedReleases.forEach((rel) => {
      const relArtist = (rel.artist_name || defaultArtistName).trim();
      const rawDate = rel.release_date ? rel.release_date.trim() : "";
      const hasDate = Boolean(rawDate);
      const normalizedDate = hasDate ? normalizeDateString(rawDate) : "Не указана";

      if (lineMode === "releases" || lineMode === "both") {
        list.push({
          id: `rel_${rel.release_id}`,
          line: formatReleaseDateLine(relArtist, rel.title, normalizedDate),
          type: "release",
          artistName: relArtist,
          title: rel.title,
          date: normalizedDate,
          hasDate,
          releaseId: rel.release_id,
          cover: rel.cover,
          releaseType: rel.type,
          label: rel.label,
          upc: rel.upc,
          trackCount: rel.tracks?.length || 1
        });
      }

      if (lineMode === "tracks" || lineMode === "both") {
        const allowedTracks = selectedTrackIdsMap[rel.release_id] || new Set();
        const tracksToProcess = rel.tracks.filter((trk) =>
          allowedTracks.size > 0 ? allowedTracks.has(trk.track_id) : true
        );

        tracksToProcess.forEach((trk) => {
          list.push({
            id: `trk_${trk.track_id}`,
            line: formatReleaseDateLine(relArtist, trk.title, normalizedDate),
            type: "track",
            artistName: relArtist,
            title: trk.title,
            date: normalizedDate,
            hasDate,
            releaseId: rel.release_id,
            trackId: trk.track_id,
            cover: rel.cover,
            releaseType: rel.type,
            label: rel.label,
            upc: trk.isrc ? `ISRC: ${trk.isrc}` : rel.upc,
            trackCount: 1
          });
        });
      }
    });

    return list;
  }, [selectedReleases, lineMode, selectedTrackIdsMap, defaultArtistName]);

  // Filtered rows by search query
  const filteredRows = useMemo(() => {
    if (!searchQuery.trim()) return formattedRows;
    const q = searchQuery.toLowerCase().trim();
    return formattedRows.filter(
      (r) =>
        r.line.toLowerCase().includes(q) ||
        r.title.toLowerCase().includes(q) ||
        r.artistName.toLowerCase().includes(q) ||
        r.date.toLowerCase().includes(q)
    );
  }, [formattedRows, searchQuery]);

  // Stats
  const releasesWithDateCount = useMemo(() => {
    return selectedReleases.filter((r) => Boolean(r.release_date && r.release_date.trim())).length;
  }, [selectedReleases]);

  // Handle parsing text (from TXT file or paste)
  const handleParse = (textToParse: string) => {
    if (!textToParse.trim()) {
      setParseResult(null);
      return;
    }
    const parsed = parseReleaseDatesFromText(textToParse, selectedReleases, defaultArtistName);
    setParseResult(parsed);
  };

  // Handle file upload (.txt, .csv)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = String(event.target?.result || "");
      setImportText(content);
      handleParse(content);
    };
    reader.readAsText(file);
  };

  // Apply parsed dates to releases
  const handleApplyDates = () => {
    if (!parseResult || parseResult.matchedCount === 0) return;
    onBatchUpdateDates(parseResult.matchedMap);
    setImportSuccessMsg(
      t(
        `Successfully updated release dates for ${parseResult.matchedCount} releases!`,
        `Успешно обновлена дата релиза для ${parseResult.matchedCount} релизов!`
      )
    );
    setTimeout(() => {
      setImportSuccessMsg(null);
      setActiveSubTab("lines");
    }, 1600);
  };

  // Copy all lines to clipboard
  const handleCopyAllLines = async () => {
    const text = filteredRows.map((r) => r.line).join("\n");
    await navigator.clipboard.writeText(text);
    setIsCopiedAll(true);
    setTimeout(() => setIsCopiedAll(false), 2000);
  };

  // Copy individual line
  const handleCopySingleLine = async (lineText: string, id: string) => {
    await navigator.clipboard.writeText(lineText);
    setCopiedLineId(id);
    setTimeout(() => setCopiedLineId(null), 1500);
  };

  // Download all lines as a .txt file
  const handleDownloadTxt = () => {
    const mode =
      lineMode === "releases"
        ? "releases_only"
        : lineMode === "tracks"
        ? "tracks_only"
        : "all";
    const content = generateReleaseDatesText(
      defaultArtistName,
      selectedReleases,
      selectedTrackIdsMap,
      mode
    );
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    saveAs(blob, `${defaultArtistName}_release_dates.txt`);
  };

  return (
    <div className="w-full max-w-5xl flex flex-col gap-6 animate-in fade-in duration-200">
      {/* Step Header Banner */}
      <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-white/10 p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0">
              <Calendar className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-zinc-900 dark:text-zinc-50">
                  {t("Release Dates", "Дата релиза")}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-purple-500/15 text-purple-700 dark:text-purple-300">
                  {releasesWithDateCount} / {selectedReleases.length} {t("specified", "заполнено")}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                {t(
                  "Lines format: Artist - Album/Track title - Release Date. Import from TXT file or configure in catalog.",
                  "Формат строчек: Артисты - Название альбома/трека - Дата релиза. Загрузка через TXT файл или ввод в каталоге."
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleDownloadTxt}
              className="px-3.5 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
              title={t("Download TXT file with formatted lines", "Скачать TXT файл со строчками дат")}
            >
              <Download className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>TXT {t("File", "Файл")}</span>
            </button>

            <button
              type="button"
              onClick={handleCopyAllLines}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-purple-600/20 transition-all active:scale-95"
            >
              {isCopiedAll ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>{t("Copied all!", "Все строчки скопированы!")}</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>{t("Copy all lines", "Копировать все строчки")}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pt-5 mt-4">
          <button
            type="button"
            onClick={() => setActiveSubTab("lines")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeSubTab === "lines"
                ? "border-purple-500 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/30 rounded-t-xl"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{t("Lines (Artist - Title - Date)", "Строчки (Артисты - Название - Дата)")}</span>
            <span className="px-1.5 py-0.5 rounded-md text-[10px] bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
              {formattedRows.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab("import")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeSubTab === "import"
                ? "border-purple-500 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/30 rounded-t-xl"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>{t("Via TXT File / Text", "Через TXT файл / Текст")}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab("table")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeSubTab === "table"
                ? "border-purple-500 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/30 rounded-t-xl"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>{t("Dates Table", "Таблица дат")}</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: FORMATTED LINES (Артисты - Название альбома/трека - Дата релиза) */}
      {activeSubTab === "lines" && (
        <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm flex flex-col gap-4">
          {/* Controls Bar: Mode Switch & Search */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/60">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                {t("Format:", "Режим:")}
              </span>
              <div className="flex items-center bg-white dark:bg-zinc-800 rounded-xl p-0.5 border border-zinc-200 dark:border-zinc-700 text-xs">
                <button
                  type="button"
                  onClick={() => setLineMode("releases")}
                  className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                    lineMode === "releases"
                      ? "bg-purple-600 text-white shadow-xs"
                      : "text-zinc-600 dark:text-zinc-300 hover:text-zinc-900"
                  }`}
                >
                  {t("Albums / Singles", "Альбомы / Синглы")}
                </button>
                <button
                  type="button"
                  onClick={() => setLineMode("tracks")}
                  className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                    lineMode === "tracks"
                      ? "bg-purple-600 text-white shadow-xs"
                      : "text-zinc-600 dark:text-zinc-300 hover:text-zinc-900"
                  }`}
                >
                  {t("Tracks", "Потреково")}
                </button>
                <button
                  type="button"
                  onClick={() => setLineMode("both")}
                  className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                    lineMode === "both"
                      ? "bg-purple-600 text-white shadow-xs"
                      : "text-zinc-600 dark:text-zinc-300 hover:text-zinc-900"
                  }`}
                >
                  {t("All", "Все")}
                </button>
              </div>
            </div>

            <div className="relative flex-1 sm:max-w-xs">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("Filter lines by title/artist...", "Поиск строчек...")}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
            </div>
          </div>

          {/* List of Formatted Strings */}
          <div className="flex flex-col gap-2 max-h-[560px] overflow-y-auto pr-1">
            {filteredRows.length === 0 ? (
              <div className="py-12 text-center text-zinc-400 text-xs">
                {t("No lines match the criteria", "Нет строчек по заданным критериям")}
              </div>
            ) : (
              filteredRows.map((item, idx) => {
                const isCopied = copiedLineId === item.id;
                const pad = String(idx + 1).padStart(2, "0");

                return (
                  <div
                    key={`date-item-${item.id}-${idx}`}
                    className={`group flex items-center justify-between gap-3 p-3 rounded-2xl border transition-all ${
                      item.hasDate
                        ? "bg-zinc-50/80 dark:bg-zinc-800/40 border-zinc-200/70 dark:border-zinc-700/60 hover:border-purple-300 dark:hover:border-purple-700"
                        : "bg-amber-50/40 dark:bg-amber-950/20 border-amber-200/60 dark:border-amber-800/40"
                    }`}
                  >
                    <div className="flex items-center gap-3.5 min-w-0 flex-1">
                      <span className="font-mono text-xs font-bold text-zinc-400 dark:text-zinc-500 w-6 shrink-0 text-right">
                        {pad}
                      </span>

                      {/* Cover Art (14x14 = 56px) */}
                      <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700 shadow-xs">
                        {item.cover ? (
                          <img src={item.cover} alt="" className="w-full h-full object-cover" />
                        ) : item.type === "track" ? (
                          <Music className="w-6 h-6 text-zinc-400 m-auto" />
                        ) : (
                          <Disc className="w-6 h-6 text-zinc-400 m-auto" />
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        {/* Title & Type */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 truncate">
                            {item.title}
                          </span>
                          <span className="px-2 py-0.5 text-[9px] font-extrabold uppercase rounded-full bg-purple-500/15 text-purple-700 dark:text-purple-300 border border-purple-500/30">
                            {item.type === "track" ? "трек" : item.releaseType || "релиз"}
                          </span>
                        </div>

                        {/* Artist & Metadata chips */}
                        <div className="flex items-center gap-2 flex-wrap text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                          <span className="font-semibold text-zinc-700 dark:text-zinc-300">{item.artistName}</span>
                          {item.label && (
                            <>
                              <span>•</span>
                              <span className="px-1.5 py-0.2 rounded bg-zinc-100 dark:bg-zinc-800 text-[10px] text-zinc-600 dark:text-zinc-400">
                                {item.label}
                              </span>
                            </>
                          )}
                          {item.upc && (
                            <>
                              <span>•</span>
                              <span className="font-mono text-[10px] text-zinc-400">
                                {item.upc}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Date Badge & Copy Button */}
                    <div className="flex items-center gap-2.5 shrink-0">
                      <div
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-mono font-bold ${
                          item.hasDate
                            ? "bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300"
                            : "bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 italic"
                        }`}
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{item.date}</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleCopySingleLine(item.line, item.id)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                          isCopied
                            ? "bg-emerald-600 text-white shadow-emerald-600/20"
                            : "bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 shadow-2xs"
                        }`}
                        title={t("Copy distributor line: Artist - Title - Date", "Скопировать строчку: Артист - Название - Дата")}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                            <span>{t("Copied", "Скопировано")}</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-zinc-500" />
                            <span>{t("Line", "Строчка")}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: VIA TXT FILE / PASTE TEXT */}
      {activeSubTab === "import" && (
        <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm flex flex-col gap-5">
          <div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
              {t("Import Release Dates via TXT File", "Импорт дат релизов через TXT файл")}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
              {t(
                "Upload a .txt or .csv file, or paste text containing lines like 'Artist - Album Title - YYYY-MM-DD'. The system automatically matches releases and assigns the dates.",
                "Загрузите .txt или .csv файл, либо вставьте текст со строками вида «Артист - Название альбома - ГГГГ-ММ-ДД». Система автоматически распознает названия и привяжет даты к релизам."
              )}
            </p>
          </div>

          {/* Drag & Drop / File Input Box */}
          <div className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-2xl p-6 text-center hover:border-purple-500 transition-colors bg-zinc-50/50 dark:bg-zinc-800/30">
            <input
              type="file"
              id="txt-date-file-upload"
              accept=".txt,.csv,.tsv"
              onChange={handleFileUpload}
              className="hidden"
            />
            <label
              htmlFor="txt-date-file-upload"
              className="cursor-pointer flex flex-col items-center justify-center gap-2"
            >
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                <Upload className="w-6 h-6" />
              </div>
              <div className="text-sm font-bold text-zinc-800 dark:text-zinc-200">
                {t("Click to select .txt file with dates", "Нажмите для выбора .txt файла с датами")}
              </div>
              <div className="text-xs text-zinc-400">
                {t("Supported formats: .txt, .csv, .tsv", "Поддерживаются файлы .txt, .csv, .tsv")}
              </div>
            </label>
          </div>

          {/* Textarea for Direct Paste */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-500">
                {t("Or paste lines from clipboard:", "Или вставьте строчки из буфера:")}
              </label>
              {importText && (
                <button
                  type="button"
                  onClick={() => {
                    setImportText("");
                    setParseResult(null);
                  }}
                  className="text-xs text-red-500 hover:underline flex items-center gap-1 font-medium"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{t("Clear", "Очистить")}</span>
                </button>
              )}
            </div>

            <textarea
              rows={6}
              value={importText}
              onChange={(e) => {
                setImportText(e.target.value);
                handleParse(e.target.value);
              }}
              placeholder={`Oxxxymiron - Горгород - 2015-11-13\nOxxxymiron - Вечный жид - 2011-09-15\nOxxxymiron - Красота и уродство - 2021-12-01`}
              className="w-full p-3 font-mono text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
            />
          </div>

          {/* Parse Result Preview */}
          {parseResult && (
            <div className="flex flex-col gap-3 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/80 dark:border-zinc-700/80">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                    {t("Recognized lines:", "Распознано строчек:")} {parseResult.matchedCount} / {parseResult.totalLines}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                    {t("Matches found", "Совпадений:")} {parseResult.matchedCount}
                  </span>
                </div>

                <button
                  type="button"
                  disabled={parseResult.matchedCount === 0}
                  onClick={handleApplyDates}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 shadow-sm transition-all"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>{t("Apply recognized dates to releases", "Применить даты к релизам")}</span>
                </button>
              </div>

              {importSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{importSuccessMsg}</span>
                </div>
              )}

              {/* Preview table of matched items */}
              <div className="max-h-60 overflow-y-auto divide-y divide-zinc-200/60 dark:divide-zinc-700/60 border border-zinc-200 dark:border-zinc-700 rounded-xl bg-white dark:bg-zinc-900">
                {parseResult.items.map((it, idx) => (
                  <div key={idx} className="p-2.5 flex items-center justify-between text-xs gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="font-mono text-zinc-800 dark:text-zinc-200 truncate">
                        {it.rawLine}
                      </div>
                      {it.matchedReleaseTitle && (
                        <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                          ✓ {t("Matched release:", "Привязано к релизу:")} «{it.matchedReleaseTitle}»
                        </div>
                      )}
                    </div>
                    <div className="font-mono font-bold text-purple-600 dark:text-purple-400 shrink-0">
                      {it.extractedDate || "—"}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: DATES TABLE (Direct catalog dates inputs) */}
      {activeSubTab === "table" && (
        <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
                {t("Catalog Releases Dates Table", "Таблица дат релизов")}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                {t(
                  "Enter or edit the release dates directly in the list below. Changes automatically update the formatted strings.",
                  "Редактируйте даты прямо в таблице. Все изменения сразу отображаются в строчках для дистрибьютора."
                )}
              </p>
            </div>
            <span className="text-xs font-bold text-zinc-400">
              {selectedReleases.length} {t("releases", "релизов")}
            </span>
          </div>

          <div className="divide-y divide-zinc-200/70 dark:divide-zinc-800 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden">
            {selectedReleases.map((rel, idx) => {
              const pad = String(idx + 1).padStart(2, "0");
              const dateVal = rel.release_date || "";

              return (
                <div
                  key={`step-dates-rel-${rel.release_id}-${idx}`}
                  className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-zinc-900 hover:bg-zinc-50/50 dark:hover:bg-zinc-800/30 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <span className="font-mono text-xs text-zinc-400 w-6 shrink-0">{pad}</span>

                    <div className="w-10 h-10 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700">
                      {rel.cover ? (
                        <img src={rel.cover} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <Disc className="w-5 h-5 text-zinc-400 m-auto" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-zinc-900 dark:text-zinc-50 truncate">
                          {rel.title}
                        </span>
                        <span className="px-1.5 py-0.2 text-[9px] font-extrabold uppercase rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-500">
                          {rel.type}
                        </span>
                      </div>
                      <div className="text-xs text-zinc-400 truncate">
                        {rel.artist_name || defaultArtistName} • {rel.tracks.length} {t("tracks", "треков")}
                      </div>
                    </div>
                  </div>

                  {/* Date Input Field */}
                  <div className="flex items-center gap-2 shrink-0 sm:w-72">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={dateVal}
                        onChange={(e) => onUpdateReleaseDate(rel.release_id, e.target.value)}
                        placeholder="YYYY-MM-DD (2021-05-14)"
                        className="w-full h-9 px-3 text-xs font-mono rounded-lg bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                      />
                      {dateVal && (
                        <CheckCircle2 className="absolute right-2.5 top-2.5 w-4 h-4 text-emerald-500" />
                      )}
                    </div>

                    {/* Quick Today Shortcut */}
                    <button
                      type="button"
                      onClick={() => {
                        const today = new Date().toISOString().slice(0, 10);
                        onUpdateReleaseDate(rel.release_id, today);
                      }}
                      className="px-2 py-1.5 text-[11px] font-bold rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 transition-colors"
                      title={t("Set today's date", "Установить сегодняшнюю дату")}
                    >
                      {t("Today", "Сегодня")}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Navigation Buttons */}
      <div className="flex items-center justify-between gap-4 p-5 bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-white/10 shadow-sm">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-2xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 font-bold text-sm flex items-center gap-2 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t("Back to Codes (UPC/ISRC)", "Назад к Кодам (UPC/ISRC)")}</span>
        </button>

        <button
          type="button"
          onClick={onNext}
          className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-orange-500/25 transition-all active:scale-95"
        >
          <span>{t("Next: Verification & Export", "Далее: Проверка и экспорт")}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
