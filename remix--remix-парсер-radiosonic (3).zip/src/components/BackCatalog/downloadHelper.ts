import { saveAs } from "file-saver";

/**
 * Direct browser native download using an anchor tag (fallback for huge files or proxy constraints)
 */
export function triggerBrowserDirectDownload(taskId: string, fileName: string = "BackCatalog.zip"): void {
  const safeTaskId = encodeURIComponent(taskId.trim());
  const url = `/api/catalog/export-download/${safeTaskId}`;
  const cleanFileName = fileName.endsWith(".zip") ? fileName : `${fileName}.zip`;

  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", cleanFileName);
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    if (document.body.contains(link)) document.body.removeChild(link);
  }, 2000);
}

/**
 * Downloads a completed catalog ZIP archive safely without opening new tabs or triggering browser popup / redirect blocks.
 * Uses in-session fetch to guarantee authentication, detects server errors and prevents saving HTML error pages.
 */
export async function downloadCatalogArchive(
  taskId: string,
  fileName: string = "BackCatalog.zip",
  onProgress?: (status: string) => void
): Promise<Blob> {
  const safeTaskId = encodeURIComponent(taskId.trim());
  const url = `/api/catalog/export-download/${safeTaskId}`;

  onProgress?.("Подключение к серверу...");

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/zip, application/octet-stream, */*"
    }
  });

  if (!response.ok) {
    // Read the response body as text once to avoid "body stream already read"
    const rawText = await response.text().catch(() => "");
    let errorDetail = "";

    if (rawText) {
      try {
        const json = JSON.parse(rawText);
        if (json?.error) {
          errorDetail = json.error;
        }
      } catch {
        if (!rawText.includes("<html") && !rawText.includes("<!DOCTYPE")) {
          errorDetail = rawText.slice(0, 150).trim();
        }
      }
    }

    if (response.status === 404) {
      const msg = errorDetail || "Архив не найден на сервере.";
      throw new Error(`${msg} Пожалуйста, запустите повторную сборку каталога.`);
    }

    if (response.status === 409) {
      throw new Error(errorDetail || "Архив еще формируется на сервере. Пожалуйста, подождите завершения сборки.");
    }

    // On 500 error or gateway issue, trigger native direct browser download before throwing
    try {
      triggerBrowserDirectDownload(taskId, fileName);
    } catch {}

    throw new Error(errorDetail || `Ошибка сервера (${response.status}) при скачивании архива.`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("text/html")) {
    throw new Error("Сервер вернул веб-страницу ошибки вместо архива ZIP. Пожалуйста, соберите каталог заново.");
  }

  onProgress?.("Загрузка данных архива на устройство...");
  const rawBlob = await response.blob();

  if (rawBlob.size < 50) {
    throw new Error("Скачанный архив пуст. Пожалуйста, повторите сборку каталога.");
  }

  const cleanFileName = fileName.endsWith(".zip") ? fileName : `${fileName}.zip`;
  const zipBlob =
    rawBlob.type === "application/zip"
      ? rawBlob
      : new Blob([rawBlob], { type: "application/zip" });

  saveAs(zipBlob, cleanFileName);
  return zipBlob;
}

/**
 * Downloads an export auxiliary file (Excel, CSV, TXT codes, TXT dates)
 */
export async function downloadExportFile(
  taskId: string,
  type: "excel" | "csv" | "txt" | "dates",
  fileName: string,
  expectedMime: string
): Promise<void> {
  const safeTaskId = encodeURIComponent(taskId.trim());
  const url = `/api/catalog/export-file/${safeTaskId}/${type}`;

  const response = await fetch(url);
  if (!response.ok) {
    const rawText = await response.text().catch(() => "");
    let errorDetail = "";
    if (rawText) {
      try {
        const json = JSON.parse(rawText);
        if (json?.error) errorDetail = json.error;
      } catch {
        if (!rawText.includes("<html") && !rawText.includes("<!DOCTYPE")) {
          errorDetail = rawText.slice(0, 150).trim();
        }
      }
    }
    throw new Error(errorDetail || `Не удалось скачать файл с сервера (HTTP ${response.status})`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("text/html")) {
    throw new Error("Сервер вернул HTML-страницу вместо запрашиваемого файла.");
  }

  const rawBlob = await response.blob();
  const fileBlob = rawBlob.type ? rawBlob : new Blob([rawBlob], { type: expectedMime });
  saveAs(fileBlob, fileName);
}
