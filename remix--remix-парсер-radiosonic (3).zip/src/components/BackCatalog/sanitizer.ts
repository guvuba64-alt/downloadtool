/**
 * File and folder name sanitizer for Back-Catalog archives.
 * Adheres strictly to security rules:
 * - Eliminates path traversal (e.g. ../, ..\)
 * - Strips characters forbidden on Windows, macOS, and Linux: \ / ? % * : | " < >
 * - Preserves Unicode, Cyrillic, and Latin characters safely
 * - Caps excessively long file/directory names to avoid OS path length exhaustion
 */

export function sanitizeFsName(raw: string, fallback = "Untitled"): string {
  if (!raw || typeof raw !== "string") return fallback;

  let cleaned = raw
    // Remove null bytes and control chars
    .replace(/[\x00-\x1f\x80-\x9f]/g, "")
    // Remove path traversal and dangerous separators
    .replace(/\.\.+/g, ".")
    // Replace forbidden characters with safe hyphen or space
    .replace(/[/\\?%*:|"<>]/g, "-")
    // Collapse multiple consecutive hyphens or spaces
    .replace(/[-_]{2,}/g, "-")
    .replace(/\s+/g, " ")
    .trim();

  // Strip leading or trailing dots / hyphens
  cleaned = cleaned.replace(/^[.-]+|[.-]+$/g, "").trim();

  // Cap length to 100 chars
  if (cleaned.length > 100) {
    cleaned = cleaned.substring(0, 100).trim();
  }

  return cleaned || fallback;
}

export function formatFolderIndex(index: number): string {
  return String(index).padStart(2, "0");
}

export function formatTrackFileName(index: number, title: string, ext = "wav"): string {
  const safeTitle = sanitizeFsName(title, `Track_${index}`);
  const pad = String(index).padStart(2, "0");
  const cleanExt = (ext || "wav").replace(/^\./, "");
  return `${pad} - ${safeTitle}.${cleanExt}`;
}

export function formatReleaseFolderName(index: number, title: string): string {
  const safeTitle = sanitizeFsName(title, `Release_${index}`);
  const pad = String(index).padStart(2, "0");
  return `${pad} - ${safeTitle}`;
}
