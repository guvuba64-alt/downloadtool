import React, { useState, useMemo } from "react";
import { ReleaseEntity, TrackEntity } from "./types";
import { saveAs } from "file-saver";
import {
  generateCodesExcelBuffer,
  generateCodesCsv,
  generateCodesTsv,
  generateCatalogCodesTxt
} from "./metadataGenerator";
import {
  autoFillMissingCodes,
  generateValidUpc,
  generateValidIsrc
} from "./codeGenerator";
import {
  Barcode,
  Hash,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowRight,
  ArrowLeft,
  FileSpreadsheet,
  FileText,
  Upload,
  Info,
  Sparkles,
  HelpCircle,
  Copy,
  Check,
  RotateCcw,
  Download,
  Wand2,
  Calendar
} from "lucide-react";

interface Step3CodesProps {
  releases: ReleaseEntity[];
  selectedReleaseIds: Set<string>;
  selectedTrackIdsMap: Record<string, Set<string>>;
  onUpdateReleaseUpc: (releaseId: string, upc: string) => void;
  onUpdateTrackIsrc: (releaseId: string, trackId: string, isrc: string) => void;
  onBatchUpdateCodes?: (
    upcMap: Record<string, string>,
    isrcMap: Record<string, string>
  ) => void;
  onUpdateReleaseDate?: (releaseId: string, releaseDate: string) => void;
  onOpenReleaseDatesModal?: () => void;
  onNext: () => void;
  onBack: () => void;
  t: (en: string, ru: string) => string;
}

// Validation helpers
export function cleanIsrc(val: string): string {
  return (val || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}

export function isValidIsrc(val: string): boolean {
  const clean = cleanIsrc(val);
  // Standard ISRC: 2 letters Country, 3 letters/digits Registrant, 2 digits Year, 5 digits Designation = 12 chars
  return /^[A-Z]{2}[A-Z0-9]{3}\d{7}$/.test(clean);
}

export function isValidUpc(val: string): boolean {
  const clean = (val || "").replace(/\D/g, "");
  return clean.length >= 12 && clean.length <= 14;
}

export function formatIsrcHyphens(clean: string): string {
  if (clean.length === 12) {
    return `${clean.substring(0, 2)}-${clean.substring(2, 5)}-${clean.substring(5, 7)}-${clean.substring(7)}`;
  }
  return clean;
}

export function Step3Codes({
  releases,
  selectedReleaseIds,
  selectedTrackIdsMap,
  onUpdateReleaseUpc,
  onUpdateTrackIsrc,
  onBatchUpdateCodes,
  onUpdateReleaseDate,
  onOpenReleaseDatesModal,
  onNext,
  onBack,
  t
}: Step3CodesProps) {
  // Mass import modal state
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [csvText, setCsvText] = useState("");
  const [csvMatchStats, setCsvMatchStats] = useState<string | null>(null);

  // Skip codes confirmation modal state
  const [isSkipConfirmOpen, setIsSkipConfirmOpen] = useState(false);
  const [isCopiedTsv, setIsCopiedTsv] = useState(false);
  const [justGeneratedNotification, setJustGeneratedNotification] = useState<string | null>(null);

  // Selected releases list with only selected tracks
  const selectedReleases = useMemo(() => {
    return releases
      .filter((r) => selectedReleaseIds.has(r.release_id))
      .map((r) => {
        const allowedTrackIds = selectedTrackIdsMap[r.release_id] || new Set();
        return {
          ...r,
          tracks: r.tracks.filter((t) => allowedTrackIds.has(t.track_id))
        };
      });
  }, [releases, selectedReleaseIds, selectedTrackIdsMap]);

  // Auto-generate missing codes using GS1 standard for UPC and IFPI for ISRC
  const handleAutoGenerateMissing = (overwrite = false) => {
    const { updatedUpcs, updatedIsrcs } = autoFillMissingCodes(selectedReleases, {
      countryCode: "RU",
      registrant: "M01",
      overwriteExisting: overwrite
    });

    const flatIsrcs: Record<string, string> = {};
    let filledUpcCount = 0;
    let filledIsrcCount = 0;

    Object.entries(updatedUpcs).forEach(([relId, upc]) => {
      onUpdateReleaseUpc(relId, upc);
      filledUpcCount++;
    });

    Object.entries(updatedIsrcs).forEach(([relId, tracksMap]) => {
      Object.entries(tracksMap).forEach(([trkId, isrc]) => {
        onUpdateTrackIsrc(relId, trkId, isrc);
        flatIsrcs[trkId] = isrc;
        filledIsrcCount++;
      });
    });

    if (onBatchUpdateCodes) {
      onBatchUpdateCodes(updatedUpcs, flatIsrcs);
    }

    setJustGeneratedNotification(
      t(
        `Generated ${filledUpcCount} UPC and ${filledIsrcCount} ISRC codes according to GS1 / IFPI standards.`,
        `Сгенерировано ${filledUpcCount} кодов UPC и ${filledIsrcCount} кодов ISRC по стандартам GS1 / IFPI.`
      )
    );
    setTimeout(() => setJustGeneratedNotification(null), 4000);
  };

  // Generate codes for a single release
  const handleGenerateReleaseCodes = (rel: ReleaseEntity) => {
    const { updatedUpcs, updatedIsrcs } = autoFillMissingCodes([rel], {
      countryCode: "RU",
      registrant: "M01",
      overwriteExisting: true
    });

    if (updatedUpcs[rel.release_id]) {
      onUpdateReleaseUpc(rel.release_id, updatedUpcs[rel.release_id]);
    }
    const trks = updatedIsrcs[rel.release_id] || {};
    Object.entries(trks).forEach(([trkId, isrc]) => {
      onUpdateTrackIsrc(rel.release_id, trkId, isrc);
    });
  };

  // Generate individual track ISRC
  const handleGenerateTrackIsrc = (relId: string, trkId: string, trackIndex: number) => {
    const isrc = generateValidIsrc(trackIndex + 1, "RU", "M01");
    onUpdateTrackIsrc(relId, trkId, isrc);
  };

  const handleDownloadExcel = () => {
    const defaultArtist = selectedReleases[0]?.artist_name || "Artist";
    const buf = generateCodesExcelBuffer(defaultArtist, selectedReleases, selectedTrackIdsMap);
    saveAs(
      new Blob([buf], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      }),
      "codes_registry.xlsx"
    );
  };

  const handleDownloadCsv = () => {
    const defaultArtist = selectedReleases[0]?.artist_name || "Artist";
    const csv = generateCodesCsv(defaultArtist, selectedReleases, selectedTrackIdsMap);
    saveAs(new Blob([csv], { type: "text/csv;charset=utf-8;" }), "codes_registry.csv");
  };

  const handleDownloadTxt = () => {
    const defaultArtist = selectedReleases[0]?.artist_name || "Artist";
    const txt = generateCatalogCodesTxt(defaultArtist, selectedReleases, selectedTrackIdsMap);
    saveAs(new Blob([txt], { type: "text/plain;charset=utf-8;" }), "codes_registry.txt");
  };

  const handleCopyTsv = () => {
    const defaultArtist = selectedReleases[0]?.artist_name || "Artist";
    const tsv = generateCodesTsv(defaultArtist, selectedReleases, selectedTrackIdsMap);
    navigator.clipboard.writeText(tsv);
    setIsCopiedTsv(true);
    setTimeout(() => setIsCopiedTsv(false), 2000);
  };

  // Duplicate UPC detection across selected releases
  const upcDuplicates = useMemo(() => {
    const counts: Record<string, number> = {};
    selectedReleases.forEach((r) => {
      const u = (r.upc || "").trim();
      if (u) {
        counts[u] = (counts[u] || 0) + 1;
      }
    });
    const dupes = new Set<string>();
    Object.entries(counts).forEach(([u, count]) => {
      if (count > 1) dupes.add(u);
    });
    return dupes;
  }, [selectedReleases]);

  // Calculate readiness status per release
  const releaseStatuses = useMemo(() => {
    const statuses: Record<string, "ready" | "partial" | "empty"> = {};

    selectedReleases.forEach((r) => {
      const upcClean = (r.upc || "").trim();
      const hasUpc = upcClean.length > 0;
      const isUpcValid = isValidUpc(upcClean);

      const totalTracks = r.tracks.length;
      let validIsrcCount = 0;
      let filledIsrcCount = 0;

      r.tracks.forEach((t) => {
        const i = (t.isrc || "").trim();
        if (i.length > 0) {
          filledIsrcCount++;
          if (isValidIsrc(i)) validIsrcCount++;
        }
      });

      if (hasUpc && isUpcValid && validIsrcCount === totalTracks) {
        statuses[r.release_id] = "ready";
      } else if (hasUpc || filledIsrcCount > 0) {
        statuses[r.release_id] = "partial";
      } else {
        statuses[r.release_id] = "empty";
      }
    });

    return statuses;
  }, [selectedReleases]);

  // Summary counts
  const readyCount = useMemo(
    () => Object.values(releaseStatuses).filter((s) => s === "ready").length,
    [releaseStatuses]
  );
  const needActionCount = selectedReleases.length - readyCount;

  // Jump to first release that requires action
  const jumpToFirstIncomplete = () => {
    const incomplete = selectedReleases.find(
      (r) => releaseStatuses[r.release_id] !== "ready"
    );
    if (incomplete) {
      const el = document.getElementById(`release-code-card-${incomplete.release_id}`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  // Mass CSV / TXT Parser
  const handleApplyCsv = () => {
    if (!csvText.trim()) return;

    const lines = csvText.split(/\r?\n/);
    let matchedTracks = 0;
    let matchedUpcs = 0;

    lines.forEach((rawLine) => {
      const line = rawLine.trim();
      if (!line || line.startsWith("#") || line.startsWith("=") || line.startsWith("-")) return;

      // Extract parts by tab, semicolon, comma, pipe, or double-space dash
      let parts: string[] = [];
      if (line.includes("\t")) {
        parts = line.split("\t").map((p) => p.trim());
      } else if (line.includes(";")) {
        parts = line.split(";").map((p) => p.trim());
      } else if (line.includes("|")) {
        parts = line.split("|").map((p) => p.trim());
      } else if (line.includes(" - ")) {
        parts = line.split(" - ").map((p) => p.trim());
      } else {
        parts = line.split(",").map((p) => p.trim());
      }

      // Check for UPC and ISRC anywhere in the parts
      let foundUpc: string | null = null;
      let foundIsrc: string | null = null;
      let textCandidates: string[] = [];

      parts.forEach((part) => {
        const cleanedDigits = part.replace(/^upc[:\s]*/i, "").replace(/\D/g, "");
        const cleanedAlpha = part.replace(/^isrc[:\s]*/i, "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();

        if (isValidUpc(cleanedDigits) && !foundUpc) {
          foundUpc = cleanedDigits;
        } else if (isValidIsrc(cleanedAlpha) && !foundIsrc) {
          foundIsrc = cleanedAlpha;
        } else if (part.length > 1) {
          textCandidates.push(part.replace(/^[0-9]+[\.\)]\s*/, "").trim());
        }
      });

      // Match releases and tracks
      textCandidates.forEach((cand) => {
        const query = cand.toLowerCase();
        selectedReleases.forEach((r) => {
          // Release title matching
          if (foundUpc && (r.title.toLowerCase().includes(query) || query.includes(r.title.toLowerCase()))) {
            onUpdateReleaseUpc(r.release_id, foundUpc);
            matchedUpcs++;
          }

          // Track title matching
          r.tracks.forEach((t) => {
            const trackLower = t.title.toLowerCase();
            if (trackLower === query || trackLower.includes(query) || query.includes(trackLower)) {
              // Exact logic: ISRC or fallback to UPC if ISRC is missing
              const effectiveIsrc = foundIsrc || (foundUpc ? foundUpc : "");
              if (effectiveIsrc) {
                onUpdateTrackIsrc(r.release_id, t.track_id, effectiveIsrc);
                matchedTracks++;
              }
            }
          });
        });
      });
    });

    setCsvMatchStats(
      t(
        `Matched and filled ${matchedTracks} tracks and ${matchedUpcs} UPC codes from TXT / CSV.`,
        `Успешно сопоставлено и заполнено ${matchedTracks} треков и ${matchedUpcs} кодов UPC из TXT / CSV.`
      )
    );
  };

  // Clear all codes across all selected releases
  const handleClearAllCodes = () => {
    selectedReleases.forEach((r) => {
      onUpdateReleaseUpc(r.release_id, "");
      r.tracks.forEach((t) => {
        onUpdateTrackIsrc(r.release_id, t.track_id, "");
      });
    });
  };

  // Clear codes for a single release
  const handleClearReleaseCodes = (releaseId: string) => {
    onUpdateReleaseUpc(releaseId, "");
    const rel = selectedReleases.find((r) => r.release_id === releaseId);
    if (rel) {
      rel.tracks.forEach((t) => {
        onUpdateTrackIsrc(releaseId, t.track_id, "");
      });
    }
  };

  const hasAnyCodes = useMemo(() => {
    return selectedReleases.some(
      (r) =>
        (r.upc && r.upc.trim().length > 0) ||
        r.tracks.some((t) => t.isrc && t.isrc.trim().length > 0)
    );
  }, [selectedReleases]);

  const handleNextClick = () => {
    onNext();
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 pb-24">
      {/* Header Info with Educational Scope */}
      <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
              3
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-zinc-900 dark:text-zinc-50 tracking-tight">
                {t("Release & Track Codes", "Коды релизов и треков")}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
                {t(
                  "Codes are optional. You can enter your own real codes from your distributor or leave fields empty.",
                  "Коды не обязательны. Вы можете ввести свои реальные коды от дистрибьютора или оставить поля пустыми."
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            {/* Auto-generate missing codes button */}
            <button
              type="button"
              onClick={() => handleAutoGenerateMissing(false)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-orange-500/20 transition-all active:scale-95"
              title={t("Auto-fill all empty UPC and ISRC with standard compliant codes", "Сгенерировать недостающие коды UPC и ISRC по стандартам GS1 / IFPI")}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t("Auto-Fill Missing Codes", "Сгенерировать коды")}</span>
            </button>

            {hasAnyCodes && (
              <button
                type="button"
                onClick={handleClearAllCodes}
                className="px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-red-500/10 hover:text-red-500 text-xs font-semibold text-zinc-600 dark:text-zinc-300 flex items-center gap-1.5 transition-colors"
                title={t("Clear all codes", "Очистить все коды")}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t("Clear all", "Очистить")}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleDownloadExcel}
              className="px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-800/80 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
              title={t("Download Excel with codes (.xlsx)", "Скачать таблицу Excel (.xlsx) с реестром кодов")}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Excel (.xlsx)</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadCsv}
              className="px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-200 flex items-center gap-1.5 transition-colors"
              title={t("Download CSV file", "Скачать CSV файл")}
            >
              <Download className="w-3.5 h-3.5 text-sky-500" />
              <span>CSV</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadTxt}
              className="px-3 py-2 rounded-xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200/80 dark:border-purple-800/80 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
              title={t("Download TXT file (.txt)", "Скачать текстовый файл (.txt) с реестром кодов")}
            >
              <FileText className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
              <span>TXT (.txt)</span>
            </button>

            <button
              type="button"
              onClick={handleCopyTsv}
              className="px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-200 flex items-center gap-1.5 transition-colors"
              title={t("Copy TSV for Excel / Google Sheets", "Скопировать TSV для вставки в Excel")}
            >
              {isCopiedTsv ? (
                <Check className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-indigo-500" />
              )}
              <span>{isCopiedTsv ? t("Copied!", "Скопировано!") : "TSV"}</span>
            </button>

            {onOpenReleaseDatesModal && (
              <button
                type="button"
                onClick={onOpenReleaseDatesModal}
                className="px-3.5 py-2 rounded-xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200/80 dark:border-purple-800/80 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
                title={t(
                  "Configure release dates: lines Artist - Title - Date, import from TXT, copy lines",
                  "Настройка дат релизов: строчки Артисты - Название - Дата, импорт из TXT, копирование строк"
                )}
              >
                <Calendar className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                <span>{t("Release Dates", "Дата релиза")}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsCsvModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-200 flex items-center gap-2 transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-orange-500" />
              <span>{t("Mass Import (CSV / TXT)", "Импорт кодов")}</span>
            </button>
          </div>
        </div>

        {/* Educational Scope Notice */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-xl bg-orange-500/5 dark:bg-orange-500/10 border border-orange-500/20 text-xs">
          <div className="flex items-start gap-2.5">
            <Barcode className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-zinc-900 dark:text-zinc-100">UPC (Release level):</span>{" "}
              <span className="text-zinc-600 dark:text-zinc-300">
                {t(
                  "Release barcode (album or single). One code for the entire release package.",
                  "Код релиза (альбома или сингла). Один код на весь релиз."
                )}
              </span>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <Hash className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-zinc-900 dark:text-zinc-100">ISRC (Track level):</span>{" "}
              <span className="text-zinc-600 dark:text-zinc-300">
                {t(
                  "Specific track code. Every single track has its own distinct ISRC.",
                  "Код конкретного трека. У каждого трека свой уникальный ISRC."
                )}
              </span>
            </div>
          </div>
        </div>

        {/* Live Status Bar */}
        <div className="mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-zinc-700 dark:text-zinc-300">
              {selectedReleases.length} {t("releases:", "релизов:")}
            </span>
            {readyCount > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> {readyCount} {t("with codes", "с кодами")}
              </span>
            )}
            <span className="px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 font-medium">
              {selectedReleases.length - readyCount} {t("without codes (optional)", "без кодов (по выбору)")}
            </span>
          </div>

          <div className="text-xs text-zinc-400">
            {t(
              "Empty codes will be marked as NOT SPECIFIED in metadata files.",
              "Если оставить пустыми — в метаданных запишется «НЕ УКАЗАН»."
            )}
          </div>
        </div>

        {/* Success toast after generating codes */}
        {justGeneratedNotification && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in duration-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{justGeneratedNotification}</span>
          </div>
        )}
      </div>

      {/* Selected Releases Code List */}
      <div className="flex flex-col gap-4">
        {selectedReleases.map((rel, rIdx) => {
          const status = releaseStatuses[rel.release_id];
          const isUpcDup = rel.upc ? upcDuplicates.has(rel.upc.trim()) : false;
          const isUpcOk = isValidUpc(rel.upc || "");
          const hasRelCodes =
            (rel.upc && rel.upc.trim().length > 0) ||
            rel.tracks.some((t) => t.isrc && t.isrc.trim().length > 0);

          return (
            <div
              key={`code-rel-${rel.release_id}-${rIdx}`}
              id={`release-code-card-${rel.release_id}`}
              className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm flex flex-col gap-4"
            >
              {/* Release Header */}
              <div className="flex items-center justify-between gap-4 pb-3 border-b border-zinc-100 dark:border-zinc-800">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700">
                    {rel.cover ? (
                      <img src={rel.cover} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <Barcode className="w-6 h-6 text-zinc-400 m-auto" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-base sm:text-lg text-zinc-900 dark:text-zinc-50 truncate">
                        {rel.title}
                      </h4>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 uppercase shrink-0">
                        {rel.type}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5 flex-wrap">
                      <span>
                        {rel.tracks.length} {t("tracks selected", "выбранных треков")}
                      </span>
                      {rel.label && (
                        <>
                          <span>•</span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20">
                            {t("Label:", "Лейбл:")} {rel.label}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Status Badge & Clear Option */}
                <div className="shrink-0 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleGenerateReleaseCodes(rel)}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 transition-colors flex items-center gap-1.5"
                    title={t("Generate UPC and ISRCs for this release", "Сгенерировать коды для этого релиза")}
                  >
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>{t("Auto-Fill", "Авто-коды")}</span>
                  </button>

                  {status === "ready" ? (
                    <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{t("Codes specified", "Коды указаны")}</span>
                    </span>
                  ) : status === "partial" ? (
                    <span className="px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-semibold flex items-center gap-1.5">
                      <Info className="w-4 h-4" />
                      <span>{t("Partially filled", "Заполнено частично")}</span>
                    </span>
                  ) : (
                    <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 text-xs font-medium flex items-center gap-1.5">
                      <span>{t("Left blank (Optional)", "Оставлено пустым")}</span>
                    </span>
                  )}

                  {hasRelCodes && (
                    <button
                      type="button"
                      onClick={() => handleClearReleaseCodes(rel.release_id)}
                      className="px-2 py-1 rounded text-xs text-zinc-400 hover:text-red-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors flex items-center gap-1"
                      title={t("Clear codes for this release", "Очистить коды этого релиза")}
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span className="hidden sm:inline">{t("Clear", "Очистить")}</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* UPC Section (Release Level) */}
                <div className="bg-zinc-50/70 dark:bg-zinc-800/40 rounded-xl p-4 border border-zinc-200/60 dark:border-zinc-700/60">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                      <Barcode className="w-4 h-4 text-orange-500" />
                      <span>UPC {t("Code of Release", "Код релиза")}</span>
                    </label>

                    <a
                      href="https://musicfetch.io/upc-finder"
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1 self-start sm:self-auto font-medium"
                    >
                      <span>{t("Don't remember UPC?", "Не помню UPC?")}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={rel.upc || ""}
                        onChange={(e) => onUpdateReleaseUpc(rel.release_id, e.target.value.replace(/\D/g, ""))}
                        placeholder={t("e.g. 012345678901 (digits only, or leave empty)", "Только цифры: 012345678901 (или оставьте пустым)")}
                        className={`w-full h-10 px-3 text-xs sm:text-sm font-mono rounded-lg bg-white dark:bg-zinc-900 border text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                          isUpcDup
                            ? "border-red-500 ring-1 ring-red-500"
                            : rel.upc && !isUpcOk
                            ? "border-amber-500"
                            : "border-zinc-200 dark:border-zinc-700"
                        }`}
                      />
                      {isUpcOk && !isUpcDup && (
                        <CheckCircle2 className="absolute right-3 top-2.5 w-4 h-4 text-emerald-500" />
                      )}
                    </div>
                  </div>

                  {isUpcDup && (
                    <p className="text-[11px] text-red-500 font-medium mt-1">
                      {t(
                        "This UPC code is already used in another selected release!",
                        "Этот UPC код уже указан для другого выбранного релиза!"
                      )}
                    </p>
                  )}

                  <p className="text-[10px] text-zinc-400 mt-2">
                    {t(
                      "You can enter your own real barcode or leave it blank.",
                      "Вы можете ввести свой штрихкод или оставить поле пустым."
                    )}
                  </p>
                </div>

                {/* Release Date Section (Release Level) */}
                <div className="bg-zinc-50/70 dark:bg-zinc-800/40 rounded-xl p-4 border border-zinc-200/60 dark:border-zinc-700/60">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-purple-500" />
                      <span>{t("Release Date", "Дата релиза")}</span>
                    </label>

                    {onOpenReleaseDatesModal && (
                      <button
                        type="button"
                        onClick={onOpenReleaseDatesModal}
                        className="text-xs text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1 self-start sm:self-auto font-medium"
                      >
                        <span>{t("Import from TXT", "Импорт из TXT")}</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={rel.release_date || ""}
                        onChange={(e) => onUpdateReleaseDate?.(rel.release_id, e.target.value)}
                        placeholder={t("YYYY-MM-DD or DD.MM.YYYY (e.g. 2021-05-14)", "ГГГГ-ММ-ДД или ДД.ММ.ГГГГ (напр. 2021-05-14)")}
                        className="w-full h-10 px-3 text-xs sm:text-sm font-mono rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                      />
                      {rel.release_date && (
                        <CheckCircle2 className="absolute right-3 top-2.5 w-4 h-4 text-emerald-500" />
                      )}
                    </div>
                  </div>

                  <p className="text-[10px] text-zinc-400 mt-2">
                    {t(
                      "Original distribution release date for label catalog transfer.",
                      "Оригинальная дата выхода релиза для передачи в каталог лейбла."
                    )}
                  </p>
                </div>
              </div>

              {/* Tracks ISRCs Section (Track Level) */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                    {t("Track ISRCs", "ISRC коды треков")} ({rel.tracks.length})
                  </span>
                  <a
                    href="https://musicfetch.io/isrc-finder"
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1 font-medium"
                  >
                    <span>{t("Don't remember ISRC?", "Не помню ISRC?")}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="divide-y divide-zinc-100 dark:divide-zinc-800 rounded-xl border border-zinc-200/80 dark:border-zinc-800 overflow-hidden bg-white dark:bg-zinc-900/50">
                  {rel.tracks.map((trk, tIdx) => {
                    const clean = cleanIsrc(trk.isrc || "");
                    const isOk = isValidIsrc(clean);
                    const isFilled = clean.length > 0;

                    return (
                      <div
                        key={`code-trk-${rel.release_id}-${trk.track_id}-${tIdx}`}
                        className="p-3 sm:px-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                      >
                        <div className="flex items-center gap-2.5 flex-1 min-w-0">
                          <span className="font-mono text-xs text-zinc-400 w-6 shrink-0">
                            {String(tIdx + 1).padStart(2, "0")}
                          </span>
                          <span className="text-xs sm:text-sm font-semibold text-zinc-800 dark:text-zinc-200 truncate">
                            {trk.title}
                          </span>
                        </div>

                        <div className="flex flex-col gap-1 w-full sm:w-72 shrink-0">
                          <div className="flex items-center gap-1.5 w-full">
                            <div className="relative flex-1">
                              <input
                                type="text"
                                value={trk.isrc || ""}
                                onChange={(e) =>
                                  onUpdateTrackIsrc(
                                    rel.release_id,
                                    trk.track_id,
                                    e.target.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()
                                  )
                                }
                                placeholder={t("ISRC (or auto-filled with UPC)", "Буквы и цифры (или авто-UPC)")}
                                className={`w-full h-8 px-2.5 text-xs font-mono rounded-lg bg-zinc-50 dark:bg-zinc-800/90 border text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-orange-500 uppercase ${
                                  isOk
                                    ? "border-emerald-500/50 bg-emerald-50/20 dark:bg-emerald-950/10"
                                    : isFilled
                                    ? "border-amber-500"
                                    : "border-zinc-200 dark:border-zinc-700"
                                }`}
                              />
                              {isOk && (
                                <CheckCircle2 className="absolute right-2 top-2 w-4 h-4 text-emerald-500 pointer-events-none" />
                              )}
                              {isFilled && !isOk && (
                                <AlertTriangle className="absolute right-2 top-2 w-4 h-4 text-amber-500 pointer-events-none" />
                              )}
                            </div>

                            <button
                              type="button"
                              onClick={() => handleGenerateTrackIsrc(rel.release_id, trk.track_id, tIdx)}
                              className="w-8 h-8 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-orange-500 hover:text-white text-zinc-500 dark:text-zinc-400 flex items-center justify-center shrink-0 transition-colors"
                              title={t("Generate standard ISRC for this track", "Сгенерировать ISRC по стандарту IFPI")}
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {!isFilled && rel.upc && (
                            <div className="flex items-center gap-1 text-[10px] text-zinc-500 dark:text-zinc-400 font-mono px-0.5">
                              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Авто-UPC:</span>
                              <span className="truncate">{rel.upc.replace(/\D/g, "")}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sticky Bottom Navigation Bar */}
      <div className="fixed bottom-4 left-0 right-0 z-40 max-w-5xl mx-auto px-4 pointer-events-none">
        <div className="bg-zinc-900/95 dark:bg-zinc-800/95 backdrop-blur-xl rounded-2xl border border-zinc-700/60 p-3 sm:p-4 shadow-2xl flex items-center justify-between gap-4 pointer-events-auto text-white">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
              title={t("Back", "Назад")}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider text-orange-400 font-bold">
                  {t("Catalog status:", "Статус кодов:")}
                </span>
                <span className="text-sm sm:text-base font-bold text-white">
                  {readyCount > 0
                    ? t(`${readyCount} of ${selectedReleases.length} with codes`, `${readyCount} из ${selectedReleases.length} с кодами`)
                    : t("Codes left empty (optional)", "Коды не указаны (по выбору)")}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 hidden sm:block">
                {t(
                  "You can enter codes manually or leave fields empty.",
                  "Вы можете заполнить коды вручную или оставить поля пустыми."
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleNextClick}
              className="px-5 sm:px-6 py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs sm:text-sm font-bold transition-all duration-200 flex items-center gap-2 shadow-lg shadow-orange-500/20"
            >
              <span>{t("Proceed to Verification", "Проверить каталог")}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* CSV Mass Import Modal */}
      {isCsvModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl max-w-xl w-full p-6 border border-zinc-200 dark:border-zinc-800 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                    {t("Mass Code Import", "Массовый импорт кодов")}
                  </h3>
                  <p className="text-xs text-zinc-400">
                    {t("Paste CSV or TXT rows", "Вставьте строки CSV или текст из таблицы")}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsCsvModalOpen(false);
                  setCsvMatchStats(null);
                }}
                className="text-zinc-400 hover:text-zinc-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
              {t(
                "Supported format per line: Track Name, ISRC or UPC, Track Name, ISRC, or «Pseudonym - Track - UPC - ISRC». If ISRC is absent, UPC is automatically applied.",
                "Поддерживаемый формат: Название трека, ISRC / UPC, Название трека, ISRC / «Псевдоним - Трек - UPC - ISRC». Если ISRC отсутствует, автоматически подставляется UPC."
              )}
            </p>

            <div className="flex items-center gap-2">
              <label className="cursor-pointer px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-200 flex items-center gap-1.5 transition-colors border border-zinc-200 dark:border-zinc-700">
                <Upload className="w-3.5 h-3.5 text-orange-500" />
                <span>{t("Load .txt or .csv file", "Загрузить файл .txt или .csv")}</span>
                <input
                  type="file"
                  accept=".txt,.csv,.tsv"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (ev) => {
                        const content = ev.target?.result as string;
                        if (content) setCsvText(content);
                      };
                      reader.readAsText(file);
                    }
                  }}
                />
              </label>
              <span className="text-[11px] text-zinc-400">{t("or paste text below:", "или вставьте текст ниже:")}</span>
            </div>

            <textarea
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="01. Хлопья летят наверх, RUA012400101&#10;02. Моряк, RUA012400102&#10;Псевдоним - Трек 1 - UPC: 4601234567890 - ISRC: RUA012400101&#10;4601234567890, Хлопья летят наверх, RUA012400101"
              className="w-full p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800 font-mono text-xs border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500/50"
            />

            {csvMatchStats && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
                {csvMatchStats}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsCsvModalOpen(false);
                  setCsvMatchStats(null);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                {t("Close", "Закрыть")}
              </button>
              <button
                type="button"
                onClick={handleApplyCsv}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm"
              >
                {t("Match & Apply Codes", "Сопоставить и применить")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Skip Codes Explicit Warning Confirmation Modal */}
      {isSkipConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl max-w-md w-full p-6 border border-zinc-200 dark:border-zinc-800 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50">
                  {t("Missing UPC or ISRC codes", "Не все коды заполнены")}
                </h3>
                <p className="text-xs text-zinc-400">
                  {t("Explicit verification warning", "Предупреждение перед формированием архива")}
                </p>
              </div>
            </div>

            <p className="text-xs text-zinc-600 dark:text-zinc-300 mb-6 leading-relaxed">
              {t(
                "Digital music labels and distributors require UPC codes for releases and ISRC codes for every audio track to match streaming royalties. Proceeding without these codes may result in the label rejecting the transfer.",
                "Лейблы и дистрибьюторы используют UPC и ISRC для привязки каталога и стриминговых выплат. Если вы оставите коды пустыми, новому лейблу может потребоваться запрашивать их повторно."
              )}
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsSkipConfirmOpen(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
              >
                {t("Return and fill codes", "Вернуться и заполнить")}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsSkipConfirmOpen(false);
                  onNext();
                }}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-sm"
              >
                {t("Proceed anyway", "Продолжить без кодов")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
