import { ReleaseEntity, TrackEntity, ArtistEntity } from "./types";
import * as XLSX from "xlsx";

/**
 * Sanitizes UPC: strictly digits only
 */
export function sanitizeUpcOnlyDigits(val?: string | null): string {
  if (!val) return "";
  return String(val).replace(/\D/g, "");
}

/**
 * Sanitizes ISRC: strictly letters and digits (alphanumeric uppercase)
 */
export function sanitizeIsrcAlphanumeric(val?: string | null): string {
  if (!val) return "";
  return String(val).replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}

/**
 * Resolves codes according to specification:
 * - Псевдоним (artist pseudonym / name)
 * - UPC: только цифры
 * - ISRC: буквы с цифрами
 * - ЕСЛИ ISRC НЕТУ: автоматически вставляется UPC
 */
export function resolveCodePair(
  artistName: string,
  rawUpc?: string | null,
  rawIsrc?: string | null
): {
  pseudonym: string;
  upc: string;
  isrc: string;
  isrcAutoFilledFromUpc: boolean;
} {
  const pseudonym = (artistName || "Unknown Artist").trim();
  const upc = sanitizeUpcOnlyDigits(rawUpc);
  const isrcClean = sanitizeIsrcAlphanumeric(rawIsrc);

  // Логика: если ISRC нету, значит автоматически вставляется UPC
  const isrc = isrcClean || upc;
  const isrcAutoFilledFromUpc = !isrcClean && Boolean(upc);

  return {
    pseudonym,
    upc,
    isrc,
    isrcAutoFilledFromUpc
  };
}

/**
 * Generates metadata.txt for a single release according to label delivery specs
 */
export function generateReleaseMetadataTxt(
  artistName: string,
  release: ReleaseEntity,
  selectedTracks: TrackEntity[]
): string {
  const relTypeUpper = (release.type || "album").toUpperCase();
  const relDate = release.release_date || "Unknown";
  const upc = sanitizeUpcOnlyDigits(release.upc) || "NOT_PROVIDED";
  const label = release.label || "NOT_PROVIDED";

  const trackBlocks = selectedTracks.map((t, idx) => {
    const pad = String(idx + 1).padStart(2, "0");
    const resolved = resolveCodePair(artistName, release.upc, t.isrc);
    const isrcDisplay = resolved.isrc || "NOT_PROVIDED";
    const note = resolved.isrcAutoFilledFromUpc ? " (AUTO-UPC)" : "";
    return `${pad}. ${t.title}\nISRC: ${isrcDisplay}${note}`;
  });

  return [
    `ARTIST: ${artistName}`,
    `RELEASE: ${release.title}`,
    `TYPE: ${relTypeUpper}`,
    `LABEL / DISTRIBUTOR: ${label}`,
    `RELEASE DATE: ${relDate}`,
    "",
    "TRACKS:",
    "",
    trackBlocks.join("\n\n"),
    "",
    `UPC: ${upc}`,
    `LABEL: ${label}`
  ].join("\n");
}

/**
 * Generates codes.txt for a single release with exact logic:
 * - Псевдоним
 * - UPC (только цифры)
 * - ISRC (буквы с цифрами), если ISRC нет -> автоматически вставляется UPC
 */
export function generateReleaseCodesTxt(
  artistName: string,
  release: ReleaseEntity,
  selectedTracks: TrackEntity[]
): string {
  const cleanUpc = sanitizeUpcOnlyDigits(release.upc);
  const label = release.label || "Не указан";

  const trackLines = selectedTracks.map((t, idx) => {
    const pad = String(idx + 1).padStart(2, "0");
    const resolved = resolveCodePair(artistName, release.upc, t.isrc);
    const isrcVal = resolved.isrc || (cleanUpc || "—");
    const tag = resolved.isrcAutoFilledFromUpc ? " [AUTO: UPC]" : "";
    return `${pad}. ${artistName} — ${t.title} | UPC: ${cleanUpc || "—"} | ISRC: ${isrcVal}${tag} | Лейбл: ${label}`;
  });

  const simpleFormatLines = selectedTracks.map((t) => {
    const resolved = resolveCodePair(artistName, release.upc, t.isrc);
    return `${artistName} - ${t.title} - UPC: ${cleanUpc || "—"} - ISRC: ${resolved.isrc || cleanUpc || "—"} - Лейбл: ${label}`;
  });

  return [
    "==================================================",
    "       РЕЕСТР КОДОВ РЕЛИЗА (UPC & ISRC)           ",
    "==================================================",
    `Псевдоним (Артист):        ${artistName}`,
    `Название релиза:           ${release.title}`,
    `Тип релиза:                ${(release.type || "album").toUpperCase()}`,
    `Лейбл (отгрузка через):   ${label}`,
    `UPC (только цифры):        ${cleanUpc || "НЕ УКАЗАН"}`,
    `Дата релиза:               ${release.release_date || "Не указана"}`,
    "",
    "ПРАВИЛО ФОРМАТИРОВАНИЯ:",
    "- Псевдоним: сценическое имя артиста",
    "- Лейбл: издатель / через кого отгружался релиз",
    "- UPC: только цифры (без дефисов и пробелов)",
    "- ISRC: буквы с цифрами (если ISRC отсутствует, автоматически вставлен UPC)",
    "- Дата релиза: оригинальная дата выхода для дистрибьютора",
    "",
    "ПОТРЕКОВЫЙ СПИСОК КОДОВ:",
    "--------------------------------------------------",
    trackLines.join("\n"),
    "",
    "СТРОКИ С ДАТАМИ ВЫХОДА (АРТИСТ - РЕЛИЗ/ТРЕК - ДАТА):",
    "--------------------------------------------------",
    `${artistName} - ${release.title} - ${release.release_date || "Не указана"}`,
    ...selectedTracks.map((t) => `${artistName} - ${t.title} - ${release.release_date || "Не указана"}`),
    "",
    "СТРОКИ ДЛЯ БЫСТРОГО КОПИРОВАНИЯ В ТАБЛИЦУ / ДИСТРИБЬЮТОР:",
    "--------------------------------------------------",
    simpleFormatLines.join("\n"),
    "=================================================="
  ].join("\n");
}

export interface CodeExportRow {
  pseudonym: string;
  label: string;
  releaseTitle: string;
  trackTitle: string;
  trackNumber: number;
  releaseType: string;
  upc: string;
  isrc: string;
  isrcStatus: string;
  year?: string | number;
  releaseDate?: string;
}

/**
 * Builds structured code export rows from releases
 */
export function buildCodesExportRows(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): CodeExportRow[] {
  const rows: CodeExportRow[] = [];

  releases.forEach((rel) => {
    const relArtist = rel.artist_name || defaultArtistName;
    const cleanUpc = sanitizeUpcOnlyDigits(rel.upc);
    const relLabel = rel.label || "Не указан";
    const allowedTrackIds = selectedTrackIdsMap ? selectedTrackIdsMap[rel.release_id] : null;

    const tracksToProcess = allowedTrackIds
      ? rel.tracks.filter((t) => allowedTrackIds.has(t.track_id))
      : rel.tracks;

    tracksToProcess.forEach((trk, idx) => {
      const resolved = resolveCodePair(relArtist, rel.upc, trk.isrc);
      rows.push({
        pseudonym: resolved.pseudonym,
        label: relLabel,
        releaseTitle: rel.title,
        trackTitle: trk.title,
        trackNumber: idx + 1,
        releaseType: (rel.type || "album").toUpperCase(),
        upc: resolved.upc,
        isrc: resolved.isrc,
        isrcStatus: resolved.isrcAutoFilledFromUpc
          ? "Авто-UPC (ISRC отсутствовал)"
          : trk.isrc
          ? "Оригинальный ISRC"
          : "Отсутствует",
        year: rel.release_date ? rel.release_date.substring(0, 4) : "",
        releaseDate: rel.release_date || ""
      });
    });
  });

  return rows;
}

/**
 * Generates an Excel (.xlsx) workbook Buffer / Uint8Array
 */
export function generateCodesExcelBuffer(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): Uint8Array {
  const rows = buildCodesExportRows(defaultArtistName, releases, selectedTrackIdsMap);

  const sheetData = [
    [
      "Псевдоним (Артист)",
      "Лейбл (через кого отгружался релиз)",
      "Код UPC (только цифры)",
      "Код ISRC (буквы и цифры)",
      "Название трека",
      "Название релиза",
      "№ трека",
      "Тип релиза",
      "Статус ISRC",
      "Дата релиза",
      "Год"
    ],
    ...rows.map((r) => [
      r.pseudonym,
      r.label,
      r.upc,
      r.isrc,
      r.trackTitle,
      r.releaseTitle,
      r.trackNumber,
      r.releaseType,
      r.isrcStatus,
      r.releaseDate || "",
      r.year || ""
    ])
  ];

  const ws = XLSX.utils.aoa_to_sheet(sheetData);

  // Set column widths for comfortable reading
  ws["!cols"] = [
    { wch: 24 }, // Псевдоним
    { wch: 28 }, // Лейбл
    { wch: 18 }, // UPC
    { wch: 18 }, // ISRC
    { wch: 32 }, // Название трека
    { wch: 30 }, // Название релиза
    { wch: 10 }, // Номер трека
    { wch: 12 }, // Тип
    { wch: 28 }, // Статус ISRC
    { wch: 16 }, // Дата релиза
    { wch: 10 }  // Год
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Реестр Кодов и Дат");

  const buffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  return new Uint8Array(buffer);
}

/**
 * Generates CSV with UTF-8 BOM for Excel compatibility
 */
export function generateCodesCsv(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const rows = buildCodesExportRows(defaultArtistName, releases, selectedTrackIdsMap);

  const headers = [
    "Псевдоним (Артист)",
    "Лейбл (через кого отгружался релиз)",
    "Код UPC (только цифры)",
    "Код ISRC (буквы и цифры)",
    "Название трека",
    "Название релиза",
    "№ трека",
    "Тип релиза",
    "Статус ISRC",
    "Дата релиза",
    "Год"
  ];

  const escapeCell = (val: string | number) => `"${String(val ?? "").replace(/"/g, '""')}"`;

  const csvLines = [
    headers.map(escapeCell).join(";"),
    ...rows.map((r) =>
      [
        r.pseudonym,
        r.label,
        r.upc,
        r.isrc,
        r.trackTitle,
        r.releaseTitle,
        r.trackNumber,
        r.releaseType,
        r.isrcStatus,
        r.releaseDate || "",
        r.year || ""
      ]
        .map(escapeCell)
        .join(";")
    )
  ];

  return "\uFEFF" + csvLines.join("\r\n");
}

/**
 * Generates TSV string for pasting directly into Excel / Google Sheets
 */
export function generateCodesTsv(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const rows = buildCodesExportRows(defaultArtistName, releases, selectedTrackIdsMap);

  const headers = [
    "Псевдоним",
    "Лейбл",
    "UPC",
    "ISRC",
    "Трек",
    "Релиз",
    "№",
    "Тип",
    "Статус ISRC",
    "Дата релиза"
  ];

  const lines = [
    headers.join("\t"),
    ...rows.map((r) =>
      [
        r.pseudonym,
        r.label,
        r.upc,
        r.isrc,
        r.trackTitle,
        r.releaseTitle,
        r.trackNumber,
        r.releaseType,
        r.isrcStatus,
        r.releaseDate || ""
      ].join("\t")
    )
  ];

  return lines.join("\n");
}

/**
 * Generates plain text (.txt) codes registry file across all selected releases
 * Logic:
 * - Псевдоним (artist pseudonym / name)
 * - UPC: только цифры
 * - ISRC: буквы с цифрами
 * - ЕСЛИ ISRC НЕТУ: автоматически вставляется UPC
 * - Дата релиза: дата выхода каждого альбома/сингла
 */
export function generateCatalogCodesTxt(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const rows = buildCodesExportRows(defaultArtistName, releases, selectedTrackIdsMap);

  const lines = [
    "==================================================",
    "       РЕЕСТР КОДОВ И ДАТ КАТАЛОГА (UPC, ISRC & DATES)",
    "==================================================",
    `Псевдоним (Артист):  ${defaultArtistName}`,
    `Всего треков:        ${rows.length}`,
    "",
    "ПРАВИЛО ФОРМАТИРОВАНИЯ:",
    "- Псевдоним: сценическое имя артиста",
    "- Лейбл: издатель / через кого отгружался релиз",
    "- UPC: только цифры (без дефисов, пробелов и букв)",
    "- ISRC: буквы с цифрами (если ISRC отсутствует, автоматически вставлен UPC)",
    "- Дата релиза: оригинальная дата выхода для дистрибьютора",
    "",
    "РЕЕСТР ТРЕКОВ (ПСЕВДОНИМ | ЛЕЙБЛ | UPC | ISRC | ДАТА | ТРЕК | РЕЛИЗ):",
    "--------------------------------------------------",
    ...rows.map((r, idx) => {
      const pad = String(idx + 1).padStart(2, "0");
      const tag = r.isrcStatus.startsWith("Авто-UPC") ? " [АВТО-UPC]" : "";
      const dateStr = r.releaseDate || "—";
      return `${pad}. ${r.pseudonym} | [${r.label}] | UPC: ${r.upc || "—"} | ISRC: ${r.isrc || "—"}${tag} | Дата: ${dateStr} | «${r.trackTitle}» (Релиз: ${r.releaseTitle}, №${r.trackNumber})`;
    }),
    "",
    "СТРОКИ С ДАТАМИ РЕЛИЗОВ (АРТИСТ - АЛЬБОМ/ТРЕК - ДАТА РЕЛИЗА):",
    "--------------------------------------------------",
    ...releases.map((rel) => `${rel.artist_name || defaultArtistName} - ${rel.title} - ${rel.release_date || "Не указана"}`),
    ...rows.map((r) => `${r.pseudonym} - ${r.trackTitle} - ${r.releaseDate || "Не указана"}`),
    "",
    "СТРОКИ ДЛЯ БЫСТРОГО КОПИРОВАНИЯ (ПСЕВДОНИМ - ТРЕК - UPC - ISRC - ЛЕЙБЛ):",
    "--------------------------------------------------",
    ...rows.map((r) => `${r.pseudonym} - ${r.trackTitle} - UPC: ${r.upc || "—"} - ISRC: ${r.isrc || "—"} - Лейбл: ${r.label}`),
    "",
    "ФОРМАТ ДЛЯ ДИСТРИБЬЮТОРА (ПСЕВДОНИМ / ЛЕЙБЛ / UPC / ISRC / ДАТА):",
    "--------------------------------------------------",
    ...rows.map((r) => `${r.pseudonym}\t${r.label}\t${r.upc}\t${r.isrc}\t${r.releaseDate || "—"}\t${r.trackTitle}\t${r.releaseTitle}`),
    "=================================================="
  ];

  return lines.join("\n");
}

/**
 * Generates dates.txt text registry strictly in the user requested format:
 * "Название артистов - Название альбома/трека - Дата релиза"
 */
export function generateCatalogDatesTxt(
  defaultArtistName: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const lines: string[] = [
    "==================================================",
    "          РЕЕСТР ДАТ РЕЛИЗОВ (RELEASE DATES)      ",
    "==================================================",
    `Артист: ${defaultArtistName}`,
    `Дата:   ${new Date().toISOString().split("T")[0]}`,
    "",
    "СТРОКИ С ДАТАМИ ВЫХОДА РЕЛИЗОВ (АРТИСТ - АЛЬБОМ - ДАТА):",
    "--------------------------------------------------",
    ...releases.map((r) => `${r.artist_name || defaultArtistName} - ${r.title} - ${r.release_date || "Не указана"}`),
    "",
    "СТРОКИ С ДАТАМИ ВЫХОДА ПОТРЕКОВО (АРТИСТ - ТРЕК - ДАТА):",
    "--------------------------------------------------"
  ];

  releases.forEach((rel) => {
    const artist = rel.artist_name || defaultArtistName;
    const date = rel.release_date || "Не указана";
    const allowed = selectedTrackIdsMap ? selectedTrackIdsMap[rel.release_id] : null;
    const tracks = allowed ? rel.tracks.filter((t) => allowed.has(t.track_id)) : rel.tracks;
    tracks.forEach((t) => {
      lines.push(`${artist} - ${t.title} - ${date}`);
    });
  });

  lines.push("==================================================");
  return lines.join("\n");
}

/**
 * Generates root catalog_summary.txt for the entire archive
 */
export function generateCatalogSummaryTxt(
  artist: ArtistEntity,
  releasesWithTracks: Array<{ release: ReleaseEntity; tracks: TrackEntity[] }>
): string {
  const totalReleases = releasesWithTracks.length;
  const totalTracks = releasesWithTracks.reduce((acc, item) => acc + item.tracks.length, 0);

  const releaseBlocks = releasesWithTracks.map((item, idx) => {
    const pad = String(idx + 1).padStart(2, "0");
    const typeUpper = (item.release.type || "album").toUpperCase();
    const upc = sanitizeUpcOnlyDigits(item.release.upc) || "NOT_PROVIDED";
    const label = item.release.label || "NOT_PROVIDED";
    const releaseDate = item.release.release_date || "NOT_PROVIDED";

    return [
      `${pad}. ${item.release.title}`,
      `TYPE: ${typeUpper}`,
      `LABEL: ${label}`,
      `RELEASE DATE: ${releaseDate}`,
      `TRACKS: ${item.tracks.length}`,
      `UPC: ${upc}`
    ].join("\n");
  });

  return [
    "BACK CATALOG EXPORT",
    "",
    `ARTIST: ${artist.name}`,
    "",
    `TOTAL RELEASES: ${totalReleases}`,
    `TOTAL TRACKS: ${totalTracks}`,
    "",
    "RELEASES:",
    "",
    releaseBlocks.join("\n\n"),
    ""
  ].join("\n");
}

/**
 * Cleanly formats a release date into DD.MM.YYYY
 */
export function formatDisplayDate(dateStr?: string | null): string {
  if (!dateStr) return "Не указана";
  const s = String(dateStr).trim();
  const isoMatch = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (isoMatch) {
    const y = isoMatch[1];
    const mo = isoMatch[2].padStart(2, "0");
    const d = isoMatch[3].padStart(2, "0");
    return `${d}.${mo}.${y}`;
  }
  if (/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(s)) {
    const parts = s.split(".");
    return `${parts[0].padStart(2, "0")}.${parts[1].padStart(2, "0")}.${parts[2]}`;
  }
  if (/^\d{4}$/.test(s)) {
    return `01.01.${s}`;
  }
  return s;
}

/**
 * Resolves a real platform link to the release (e.g. Yandex Music album link)
 */
export function resolveReleaseLink(release: ReleaseEntity | any): string {
  if (!release) return "https://music.yandex.ru";
  if (release.link && String(release.link).startsWith("http")) return release.link;
  if (release.url && String(release.url).startsWith("http")) return release.url;
  const id = String(release.release_id || "").trim();
  if (/^\d+$/.test(id)) return `https://music.yandex.ru/album/${id}`;
  if (id.startsWith("ya_")) return `https://music.yandex.ru/album/${id.replace("ya_", "")}`;
  if (id.startsWith("sp_")) return `https://open.spotify.com/album/${id.replace("sp_", "")}`;
  if (id.startsWith("dz_")) return `https://www.deezer.com/album/${id.replace("dz_", "")}`;
  if (id) return `https://music.yandex.ru/album/${id}`;
  return "https://music.yandex.ru";
}

/**
 * Cleanly formats track title with feat., prod., and version info, avoiding any duplication
 */
export function formatTrackDisplayTitle(
  track: {
    title: string;
    artist?: string;
    artists?: string[];
    version?: string;
    producer?: string;
    prod?: string;
  },
  releaseArtist?: string
): string {
  let title = (track.title || "Без названия").trim();
  const version = (track.version || "").trim();
  const producer = ((track.producer || track.prod || "") as string).trim();

  // Extract artists from track
  const rawArtists = Array.isArray(track.artists) ? track.artists : [];
  const trackArtists: string[] = rawArtists
    .map((a: any) => (typeof a === "string" ? a.trim() : a?.name?.trim()))
    .filter(Boolean);

  if (track.artist && typeof track.artist === "string" && !trackArtists.includes(track.artist.trim())) {
    trackArtists.unshift(track.artist.trim());
  }

  // If there are guest artists on this track not matching the main release artist
  if (trackArtists.length > 0) {
    let guestArtists: string[] = [];
    if (releaseArtist) {
      const mainLower = releaseArtist.toLowerCase().trim();
      guestArtists = trackArtists.filter((a) => !mainLower.includes(a.toLowerCase()));
    } else if (trackArtists.length > 1) {
      guestArtists = trackArtists.slice(1);
    }

    if (guestArtists.length > 0) {
      const featRegex = /\b(?:feat\.?|ft\.?|featuring)\b/i;
      const alreadyHasFeat = featRegex.test(title) || (version && featRegex.test(version));
      const alreadyHasGuest = guestArtists.some((g) => title.toLowerCase().includes(g.toLowerCase()));

      if (!alreadyHasFeat && !alreadyHasGuest) {
        title = `${title} (feat. ${guestArtists.join(", ")})`;
      }
    }
  }

  // Handle producer if specified separately
  if (producer) {
    const prodRegex = /\b(?:prod\.?|produced\s+by)\b/i;
    const alreadyHasProd = prodRegex.test(title) || (version && prodRegex.test(version));
    if (!alreadyHasProd && !title.toLowerCase().includes(producer.toLowerCase())) {
      title = `${title} [prod. by ${producer}]`;
    }
  }

  // Version / Prod / Remix handling
  if (version) {
    const vLower = version.toLowerCase();
    const tLower = title.toLowerCase();

    if (!tLower.includes(vLower)) {
      if (/^prod\.?\s*(?:by)?/i.test(version)) {
        title = `${title} [${version}]`;
      } else if (/^(?:feat\.?|ft\.?|featuring)/i.test(version)) {
        if (!/\b(?:feat\.?|ft\.?|featuring)\b/i.test(title)) {
          title = `${title} (${version})`;
        }
      } else {
        title = `${title} (${version})`;
      }
    }
  }

  return title;
}

/**
 * Generates catalog.txt for Option 1: "Все данные"
 *
 * Structure for every release (single or multi-track album):
 * 1. Псевдоним — Название релиза
 *
 * Дата релиза: 15.03.2025
 * Лейбл: RadioSonic Media Group
 * Артист: Псевдоним
 * Название релиза: Название
 * Автор текста: Имя
 * Автор музыки: Имя
 *
 * 1 - Название трека 1 (feat. Гость) [prod. Продюсер] — ISRC: RU-XXX-25-00001
 * 2 - Название трека 2 — ISRC: RU-XXX-25-00002
 *
 * Коды: UPC: 123456789012 / ISRC: RU-XXX-25-00001
 * Ссылка на альбом/сингл: https://...
 */
export function generateBackCatalogFullTxt(
  defaultArtist: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const blocks = releases.map((rel, idx) => {
    const artist = (rel.artist_name || defaultArtist || "Не указан").trim();
    const title = (rel.title || "Без названия").trim();
    const label = (rel.label || "Не указан").trim();
    const date = formatDisplayDate(rel.release_date);
    const link = resolveReleaseLink(rel);
    const cleanUpc = sanitizeUpcOnlyDigits(rel.upc);

    const allowed = selectedTrackIdsMap ? selectedTrackIdsMap[rel.release_id] : null;
    const tracks = allowed ? rel.tracks.filter((t) => allowed.has(t.track_id)) : rel.tracks;

    // Collect ISRCs
    const isrcList: string[] = [];
    tracks.forEach((t) => {
      const c = sanitizeIsrcAlphanumeric(t.isrc);
      if (c && !isrcList.includes(c)) isrcList.push(c);
    });

    // Lyricist / Composer
    const authorText =
      rel.author_text ||
      tracks.find((t) => t.author_text)?.author_text ||
      artist ||
      "Не указан";
    const authorMusic =
      rel.author_music ||
      tracks.find((t) => t.author_music)?.author_music ||
      artist ||
      "Не указан";

    // Tracklist with 1 -, 2 -, feat, prod, ISRC (all tracks from 1 to N, never empty)
    const effectiveTracks = tracks && tracks.length > 0 ? tracks : [{
      track_id: `t_${rel.release_id}_1`,
      release_id: rel.release_id,
      track_number: 1,
      title: title,
      artist: artist,
      artists: (rel as any).artists || [artist],
      version: (rel as any).version || "",
      isrc: isrcList[0] || ""
    }];

    const trackLines = effectiveTracks.map((t, tIdx) => {
      const formattedTitle = formatTrackDisplayTitle(t, artist);
      const isrc = sanitizeIsrcAlphanumeric(t.isrc);
      return `${tIdx + 1} - ${formattedTitle}${isrc ? ` — ISRC: ${isrc}` : ""}`;
    });

    // Summary codes line
    const codesParts: string[] = [];
    if (cleanUpc) {
      codesParts.push(`UPC: ${cleanUpc}`);
    }
    if (isrcList.length === 1) {
      codesParts.push(`ISRC: ${isrcList[0]}`);
    } else if (isrcList.length > 1) {
      if (isrcList.length <= 4) {
        codesParts.push(`ISRC: ${isrcList.join(", ")}`);
      } else {
        codesParts.push(`ISRC: указаны по трекам (${isrcList.length} шт.)`);
      }
    }
    const codesLine = codesParts.length > 0 ? `Коды: ${codesParts.join(" / ")}` : "Коды: не указаны";

    const lines: string[] = [
      `${idx + 1}. ${artist} — ${title}`,
      "",
      `Дата релиза: ${date}`,
      `Лейбл: ${label}`,
      `Артист: ${artist}`,
      `Название релиза: ${title}`,
      `Автор текста: ${authorText}`,
      `Автор музыки: ${authorMusic}`,
      ""
    ];

    if (trackLines.length > 0) {
      lines.push(...trackLines);
      lines.push("");
    }

    lines.push(codesLine);
    lines.push(`Ссылка на альбом/сингл: ${link}`);

    return lines.join("\n");
  });

  return ["БЭК-КАТАЛОГ", "", blocks.join("\n\n\n")].join("\n");
}

/**
 * Generates catalog.txt for Option 2: "Дата релиза + ссылка + обложка"
 *
 * Structure for every release (single or multi-track album):
 * 1. Псевдоним — Название релиза
 *
 * Дата релиза: 15.03.2025
 * Артист: Псевдоним
 * Название релиза: Название
 *
 * 1 - Название трека 1 (feat. Гость) [prod. Продюсер] — ISRC: RU-XXX-25-00001
 * 2 - Название трека 2 — ISRC: RU-XXX-25-00002
 *
 * Коды: UPC: 123456789012 / ISRC: RU-XXX-25-00001
 * Ссылка на альбом/сингл: https://...
 */
export function generateBackCatalogLiteTxt(
  defaultArtist: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>
): string {
  const blocks = releases.map((rel, idx) => {
    const artist = (rel.artist_name || defaultArtist || "Не указан").trim();
    const title = (rel.title || "Без названия").trim();
    const date = formatDisplayDate(rel.release_date);
    const link = resolveReleaseLink(rel);
    const cleanUpc = sanitizeUpcOnlyDigits(rel.upc);

    const allowed = selectedTrackIdsMap ? selectedTrackIdsMap[rel.release_id] : null;
    const tracks = allowed ? rel.tracks.filter((t) => allowed.has(t.track_id)) : rel.tracks;

    // Collect ISRCs
    const isrcList: string[] = [];
    tracks.forEach((t) => {
      const c = sanitizeIsrcAlphanumeric(t.isrc);
      if (c && !isrcList.includes(c)) isrcList.push(c);
    });

    // Tracklist with 1 -, 2 -, feat, prod, ISRC (all tracks from 1 to N, never empty)
    const effectiveTracks = tracks && tracks.length > 0 ? tracks : [{
      track_id: `t_${rel.release_id}_1`,
      release_id: rel.release_id,
      track_number: 1,
      title: title,
      artist: artist,
      artists: (rel as any).artists || [artist],
      version: (rel as any).version || "",
      isrc: isrcList[0] || ""
    }];

    const trackLines = effectiveTracks.map((t, tIdx) => {
      const formattedTitle = formatTrackDisplayTitle(t, artist);
      const isrc = sanitizeIsrcAlphanumeric(t.isrc);
      return `${tIdx + 1} - ${formattedTitle}${isrc ? ` — ISRC: ${isrc}` : ""}`;
    });

    // Summary codes line
    const codesParts: string[] = [];
    if (cleanUpc) {
      codesParts.push(`UPC: ${cleanUpc}`);
    }
    if (isrcList.length === 1) {
      codesParts.push(`ISRC: ${isrcList[0]}`);
    } else if (isrcList.length > 1) {
      if (isrcList.length <= 4) {
        codesParts.push(`ISRC: ${isrcList.join(", ")}`);
      } else {
        codesParts.push(`ISRC: указаны по трекам (${isrcList.length} шт.)`);
      }
    }
    const codesLine = codesParts.length > 0 ? `Коды: ${codesParts.join(" / ")}` : "Коды: не указаны";

    const lines: string[] = [
      `${idx + 1}. ${artist} — ${title}`,
      "",
      `Дата релиза: ${date}`,
      `Артист: ${artist}`,
      `Название релиза: ${title}`,
      ""
    ];

    if (trackLines.length > 0) {
      lines.push(...trackLines);
      lines.push("");
    }

    lines.push(codesLine);
    lines.push(`Ссылка на альбом/сингл: ${link}`);

    return lines.join("\n");
  });

  return ["БЭК-КАТАЛОГ", "", blocks.join("\n\n\n")].join("\n");
}


