import React, { useState, useEffect } from "react";
import {
  ArtistEntity,
  ReleaseEntity,
  TrackEntity,
  TransferDraft,
  TransferHistoryItem,
  WizardStep,
  BackCatalogExportFormat
} from "./types";
import { Step1SearchArtist } from "./Step1SearchArtist";
import { Step2CatalogSelect } from "./Step2CatalogSelect";
import { Step3Codes } from "./Step3Codes";
import { StepDates } from "./StepDates";
import { Step4Verification } from "./Step4Verification";
import { DownloadProgressModal } from "./DownloadProgressModal";
import { HistoryAndDraftsView } from "./HistoryAndDraftsView";
import {
  FolderArchive,
  Search,
  CheckSquare,
  Barcode,
  CheckCircle2,
  Clock,
  Sparkles,
  RotateCcw,
  Loader2,
  AlertCircle,
  Music,
  ImageIcon,
  Calendar
} from "lucide-react";

interface BackCatalogTabProps {
  t: (en: string, ru: string) => string;
}

const STORAGE_DRAFTS_KEY = "back_catalog_drafts_v1";
const STORAGE_HISTORY_KEY = "back_catalog_history_v1";

export function BackCatalogTab({ t }: BackCatalogTabProps) {
  // Wizard state
  const [currentStep, setCurrentStep] = useState<WizardStep>(1);
  const [selectedArtist, setSelectedArtist] = useState<ArtistEntity | null>(null);
  const [selectedArtists, setSelectedArtists] = useState<ArtistEntity[]>([]);
  const [batchLoadingProgress, setBatchLoadingProgress] = useState<{ current: number; total: number; artistName: string } | null>(null);
  const [catalogReleases, setCatalogReleases] = useState<ReleaseEntity[]>([]);
  const [isLoadingCatalog, setIsLoadingCatalog] = useState(false);
  const [catalogError, setCatalogError] = useState("");

  // Selection state
  const [selectedReleaseIds, setSelectedReleaseIds] = useState<Set<string>>(new Set());
  const [selectedTrackIdsMap, setSelectedTrackIdsMap] = useState<Record<string, Set<string>>>({});

  // Export format selection: "all_data" or "release_date_link_cover"
  const [exportFormat, setExportFormat] = useState<BackCatalogExportFormat>("all_data");

  // Download modal state
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Saved Drafts & History state
  const [drafts, setDrafts] = useState<TransferDraft[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_DRAFTS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [history, setHistory] = useState<TransferHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_HISTORY_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Autosave current session draft whenever state changes on steps 2-4
  useEffect(() => {
    if (!selectedArtist || catalogReleases.length === 0 || selectedReleaseIds.size === 0) {
      return;
    }

    const timer = setTimeout(() => {
      try {
        const serializableTracksMap: Record<string, string[]> = {};
        Object.entries(selectedTrackIdsMap).forEach(([relId, trackSet]) => {
          serializableTracksMap[relId] = Array.from(trackSet as Set<string>);
        });

        const activeDraft: TransferDraft = {
          id: `draft_${selectedArtist.artist_id}`,
          updatedAt: Date.now(),
          artist: selectedArtist,
          artists: selectedArtists.length > 1 ? selectedArtists : undefined,
          releases: catalogReleases,
          selectedReleaseIds: Array.from(selectedReleaseIds),
          selectedTrackIdsMap: serializableTracksMap,
          step: currentStep,
          taskId: localStorage.getItem("active_catalog_export_task_id") || undefined,
          exportFormat
        };

        setDrafts((prev) => {
          const filtered = prev.filter((d) => d.id !== activeDraft.id);
          const updated = [activeDraft, ...filtered].slice(0, 10);
          localStorage.setItem(STORAGE_DRAFTS_KEY, JSON.stringify(updated));
          return updated;
        });
      } catch (e) {}
    }, 1000);

    return () => clearTimeout(timer);
  }, [selectedArtist, catalogReleases, selectedReleaseIds, selectedTrackIdsMap, currentStep, exportFormat]);

  // Load catalog for selected artist
  const handleArtistSelected = async (artist: ArtistEntity) => {
    setSelectedArtist(artist);
    setIsLoadingCatalog(true);
    setCatalogError("");

    try {
      const queryParams = new URLSearchParams();
      if (artist.name) queryParams.set("name", artist.name);
      if (artist.platform_links?.yandex) queryParams.set("yandex_link", artist.platform_links.yandex);

      const res = await fetch(`/api/music/back-catalog/artist/${encodeURIComponent(artist.artist_id)}/catalog?${queryParams.toString()}`);
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || t("Failed to load artist catalog", "Не удалось загрузить каталог артиста"));
      }

      if (data.artist) {
        setSelectedArtist((prev) => prev ? { ...prev, ...data.artist } : data.artist);
      }

      const rawReleases: ReleaseEntity[] = data.releases || [];
      const seenRelIds = new Set<string>();
      const releases: ReleaseEntity[] = [];
      for (const r of rawReleases) {
        if (!seenRelIds.has(r.release_id)) {
          seenRelIds.add(r.release_id);
          releases.push(r);
        }
      }
      setCatalogReleases(releases);

      // By default, select all releases and all tracks
      const initialRelIds = new Set<string>();
      const initialTrackMap: Record<string, Set<string>> = {};

      releases.forEach((rel) => {
        initialRelIds.add(rel.release_id);
        initialTrackMap[rel.release_id] = new Set(rel.tracks.map((t) => t.track_id));
      });

      setSelectedReleaseIds(initialRelIds);
      setSelectedTrackIdsMap(initialTrackMap);
      setCurrentStep(2);
    } catch (err: any) {
      setCatalogError(err.message || t("Error loading catalog", "Ошибка при загрузке каталога"));
    } finally {
      setIsLoadingCatalog(false);
    }
  };

  // Load catalog for multiple artists (100+ artists up to infinity)
  const handleArtistsBatchSelected = async (artists: ArtistEntity[]) => {
    if (artists.length === 0) return;
    if (artists.length === 1) {
      handleArtistSelected(artists[0]);
      return;
    }

    setSelectedArtists(artists);
    setSelectedArtist(artists[0]);
    setIsLoadingCatalog(true);
    setCatalogError("");
    setBatchLoadingProgress({ current: 0, total: artists.length, artistName: artists[0].name });

    try {
      const allReleases: ReleaseEntity[] = [];
      const concurrency = 4;

      for (let i = 0; i < artists.length; i += concurrency) {
        const chunk = artists.slice(i, i + concurrency);
        await Promise.all(
          chunk.map(async (art, chunkIndex) => {
            const index = i + chunkIndex + 1;
            setBatchLoadingProgress({ current: index, total: artists.length, artistName: art.name });

            try {
              const qp = new URLSearchParams();
              if (art.name) qp.set("name", art.name);
              if (art.platform_links?.yandex) qp.set("yandex_link", art.platform_links.yandex);

              const res = await fetch(
                `/api/music/back-catalog/artist/${encodeURIComponent(art.artist_id)}/catalog?${qp.toString()}`
              );
              const data = await res.json();
              if (res.ok && data.success && Array.isArray(data.releases)) {
                const tagged = data.releases.map((r: ReleaseEntity) => ({
                  ...r,
                  artist_id: art.artist_id,
                  artist_name: art.name
                }));
                allReleases.push(...tagged);
              }
            } catch (err) {
              console.warn(`Failed loading catalog for ${art.name}:`, err);
            }
          })
        );
      }

      if (allReleases.length === 0) {
        throw new Error(
          t("Failed to load catalog for selected artists", "Не удалось загрузить каталог для выбранных артистов")
        );
      }

      // Deduplicate releases across multiple artists to prevent duplicate keys
      const seenRelIds = new Set<string>();
      const uniqueReleases: ReleaseEntity[] = [];
      for (const r of allReleases) {
        if (!seenRelIds.has(r.release_id)) {
          seenRelIds.add(r.release_id);
          uniqueReleases.push(r);
        }
      }

      setCatalogReleases(uniqueReleases);

      // Select all releases and tracks
      const initialRelIds = new Set<string>();
      const initialTrackMap: Record<string, Set<string>> = {};
      uniqueReleases.forEach((rel) => {
        initialRelIds.add(rel.release_id);
        initialTrackMap[rel.release_id] = new Set(rel.tracks.map((t) => t.track_id));
      });

      setSelectedReleaseIds(initialRelIds);
      setSelectedTrackIdsMap(initialTrackMap);
      setCurrentStep(2);
    } catch (err: any) {
      setCatalogError(err.message || t("Error loading multi-artist catalog", "Ошибка при загрузке каталогов"));
    } finally {
      setIsLoadingCatalog(false);
      setBatchLoadingProgress(null);
    }
  };

  // Resume draft
  const handleResumeDraft = (draft: TransferDraft) => {
    setSelectedArtist(draft.artist);
    if (draft.artists) setSelectedArtists(draft.artists);
    setCatalogReleases(draft.releases);
    setSelectedReleaseIds(new Set(draft.selectedReleaseIds));
    if (draft.exportFormat) setExportFormat(draft.exportFormat);

    const restoredTracksMap: Record<string, Set<string>> = {};
    Object.entries(draft.selectedTrackIdsMap).forEach(([rId, arr]) => {
      restoredTracksMap[rId] = new Set(arr);
    });
    setSelectedTrackIdsMap(restoredTracksMap);

    setCurrentStep(draft.step);
  };

  // Direct download draft ZIP
  const handleDownloadDraftZip = (draft: TransferDraft) => {
    setSelectedArtist(draft.artist);
    if (draft.artists) setSelectedArtists(draft.artists);
    setCatalogReleases(draft.releases);
    setSelectedReleaseIds(new Set(draft.selectedReleaseIds));
    if (draft.exportFormat) setExportFormat(draft.exportFormat);

    const restoredTracksMap: Record<string, Set<string>> = {};
    Object.entries(draft.selectedTrackIdsMap).forEach(([rId, arr]) => {
      restoredTracksMap[rId] = new Set(arr);
    });
    setSelectedTrackIdsMap(restoredTracksMap);

    setIsDownloadModalOpen(true);
  };

  // Delete draft
  const handleDeleteDraft = (draftId: string) => {
    setDrafts((prev) => {
      const updated = prev.filter((d) => d.id !== draftId);
      localStorage.setItem(STORAGE_DRAFTS_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  // Delete history item
  const handleDeleteHistoryItem = (id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((h) => h.id !== id);
      localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  // Save to history after download
  const handleSaveToHistory = (stats: {
    totalReleases: number;
    totalTracks: number;
    artistCount?: number;
    taskId?: string;
    zipFileName?: string;
    fileSize?: number;
    exportFormat?: BackCatalogExportFormat;
  }) => {
    if (!selectedArtist) return;

    const isMulti = selectedArtists.length > 1;
    const resolvedTaskId = stats.taskId || localStorage.getItem("active_catalog_export_task_id") || undefined;
    const distinctLabels: string[] = Array.from(
      new Set<string>(
        catalogReleases
          .filter((r) => selectedReleaseIds.has(r.release_id))
          .map((r) => r.label)
          .filter((l): l is string => Boolean(l && l.trim().length > 0))
      )
    );

    const historyItem: TransferHistoryItem = {
      id: `hist_${Date.now()}`,
      timestamp: Date.now(),
      artistName: isMulti
        ? `${selectedArtists.length} ${t("artists", "артистов")} (${selectedArtist.name} + ${selectedArtists.length - 1})`
        : selectedArtist.name,
      artistAvatar: selectedArtist.avatar,
      artists: isMulti ? selectedArtists : undefined,
      totalReleases: stats.totalReleases,
      totalTracks: stats.totalTracks,
      labels: distinctLabels.length > 0 ? distinctLabels : undefined,
      status: "completed",
      taskId: resolvedTaskId,
      zipFileName: stats.zipFileName,
      fileSize: stats.fileSize,
      exportFormat: stats.exportFormat || exportFormat
    };

    setHistory((prev) => {
      const updated = [historyItem, ...prev].slice(0, 30);
      localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(updated));
      return updated;
    });

    // Clean up corresponding draft
    if (selectedArtist) {
      handleDeleteDraft(`draft_${selectedArtist.artist_id}`);
    }
  };

  // Code updates
  const handleUpdateReleaseUpc = (releaseId: string, upc: string) => {
    setCatalogReleases((prev) =>
      prev.map((r) => (r.release_id === releaseId ? { ...r, upc } : r))
    );
  };

  const handleUpdateTrackIsrc = (releaseId: string, trackId: string, isrc: string) => {
    setCatalogReleases((prev) =>
      prev.map((r) => {
        if (r.release_id !== releaseId) return r;
        return {
          ...r,
          tracks: r.tracks.map((t) => (t.track_id === trackId ? { ...t, isrc } : t))
        };
      })
    );
  };

  // Release date updates
  const handleUpdateReleaseDate = (releaseId: string, releaseDate: string) => {
    setCatalogReleases((prev) =>
      prev.map((r) => (r.release_id === releaseId ? { ...r, release_date: releaseDate } : r))
    );
  };

  const handleBatchUpdateDates = (dateMap: Record<string, string>) => {
    setCatalogReleases((prev) =>
      prev.map((r) => {
        if (dateMap[r.release_id] !== undefined) {
          return { ...r, release_date: dateMap[r.release_id] };
        }
        return r;
      })
    );
  };

  // Bulk codes batch update
  const handleBatchUpdateCodes = (
    upcMap: Record<string, string>,
    isrcMap: Record<string, string>
  ) => {
    setCatalogReleases((prev) =>
      prev.map((r) => {
        const newUpc = upcMap[r.release_id] !== undefined ? upcMap[r.release_id] : r.upc;
        const newTracks = r.tracks.map((trk) => ({
          ...trk,
          isrc: isrcMap[trk.track_id] !== undefined ? isrcMap[trk.track_id] : trk.isrc
        }));
        return {
          ...r,
          upc: newUpc,
          tracks: newTracks
        };
      })
    );
  };

  // Bulk metadata update (label / year)
  const handleBatchUpdateReleases = (updates: { label?: string; year?: string }) => {
    setCatalogReleases((prev) =>
      prev.map((r) => {
        if (!selectedReleaseIds.has(r.release_id)) return r;
        return {
          ...r,
          ...(updates.label !== undefined ? { label: updates.label } : {}),
          ...(updates.year !== undefined
            ? { release_date: updates.year ? `${updates.year}-01-01` : r.release_date }
            : {})
        };
      })
    );
  };

  // Add custom release
  const handleAddCustomRelease = (newRelease: ReleaseEntity) => {
    setCatalogReleases((prev) => [newRelease, ...prev]);
    setSelectedReleaseIds((prev) => new Set([...prev, newRelease.release_id]));
    setSelectedTrackIdsMap((prev) => ({
      ...prev,
      [newRelease.release_id]: new Set(newRelease.tracks.map((t) => t.track_id))
    }));
  };

  // Reset wizard
  const handleResetWizard = () => {
    setCurrentStep(1);
    setSelectedArtist(null);
    setSelectedArtists([]);
    setCatalogReleases([]);
    setSelectedReleaseIds(new Set());
    setSelectedTrackIdsMap({});
  };

  const stepsList = [
    { num: 1, title: t("Artist", "Артист"), icon: Search },
    { num: 2, title: t("Catalog", "Каталог"), icon: CheckSquare },
    { num: 3, title: t("UPC & ISRC", "Коды"), icon: Barcode },
    { num: 4, title: t("Release Dates", "Дата релиза"), icon: Calendar },
    { num: 5, title: t("Verification", "Проверка"), icon: CheckCircle2 }
  ];

  return (
    <div className="w-full flex flex-col items-center">
      {/* Top Banner & Title */}
      <div className="w-full max-w-5xl mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-transparent p-6 rounded-3xl border border-orange-500/20 shadow-xs">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-orange-500 text-white flex items-center justify-center shadow-md shadow-orange-500/20 shrink-0">
              <FolderArchive className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-zinc-900 dark:text-zinc-50">
                  {t("Back-Catalog Transfer", "Бэк-каталог для музыкальной платформы / лейбла")}
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-orange-500 text-white uppercase tracking-wider">
                  PRO
                </span>
              </div>
              <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 mt-1">
                {t(
                  "Fast automated packaging of artist discography: covers 3000×3000px, 16-bit WAV, UPC, ISRC, and metadata for digital distribution.",
                  "Автоматический перенос дискографии артиста: обложки 3000×3000px, 16-bit WAV, коды UPC/ISRC и файлы metadata.txt для цифровой дистрибуции."
                )}
              </p>

              {/* Studio Specification Badges */}
              <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-zinc-900/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 border border-zinc-200/60 dark:border-white/10 flex items-center gap-1">
                  <Music className="w-3 h-3 text-orange-500" />
                  <span>16-Bit / 44.1kHz WAV</span>
                </span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-zinc-900/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 border border-zinc-200/60 dark:border-white/10 flex items-center gap-1">
                  <ImageIcon className="w-3 h-3 text-emerald-500" />
                  <span>3000×3000 px Cover</span>
                </span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-zinc-900/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 border border-zinc-200/60 dark:border-white/10 flex items-center gap-1">
                  <Barcode className="w-3 h-3 text-blue-500" />
                  <span>UPC & ISRC DDEX</span>
                </span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-zinc-900/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 border border-zinc-200/60 dark:border-white/10 flex items-center gap-1">
                  <FolderArchive className="w-3 h-3 text-purple-500" />
                  <span>Multi-GB ZIP64</span>
                </span>
              </div>
            </div>
          </div>

          {currentStep > 1 && (
            <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setCurrentStep(4)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors flex items-center gap-2 shadow-xs ${
                  currentStep === 4
                    ? "bg-purple-600 text-white border-purple-600 shadow-purple-500/20"
                    : "bg-purple-500/10 hover:bg-purple-500/20 text-purple-700 dark:text-purple-300 border-purple-500/30"
                }`}
                title={t("Open Release Dates tab", "Вкладка: Дата релиза")}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{t("Release Dates", "Дата релиза")}</span>
              </button>

              <button
                type="button"
                onClick={handleResetWizard}
                className="px-3.5 py-2 rounded-xl bg-white/80 dark:bg-zinc-800/80 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 text-xs font-bold border border-zinc-200 dark:border-zinc-700 transition-colors flex items-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t("New Transfer", "Начать сначала")}</span>
              </button>
            </div>
          )}
        </div>

        {/* 5-Step Stepper Header */}
        <div className="grid grid-cols-5 gap-1.5 sm:gap-2 mt-4">
          {stepsList.map((st) => {
            const isCompleted = currentStep > st.num;
            const isCurrent = currentStep === st.num;
            const canJump = isCompleted || isCurrent;
            const Icon = st.icon;

            return (
              <button
                key={st.num}
                type="button"
                disabled={!canJump}
                onClick={() => canJump && setCurrentStep(st.num as any)}
                className={`p-3 rounded-2xl border transition-all text-left flex items-center gap-2.5 ${
                  isCurrent
                    ? "bg-white dark:bg-zinc-900 border-orange-500 shadow-sm ring-1 ring-orange-500/20"
                    : isCompleted
                    ? "bg-emerald-500/5 dark:bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-500 text-emerald-700 dark:text-emerald-400 cursor-pointer"
                    : "bg-zinc-50 dark:bg-zinc-900/50 border-zinc-200/60 dark:border-zinc-800 opacity-50 cursor-not-allowed"
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                    isCurrent
                      ? "bg-orange-500 text-white"
                      : isCompleted
                      ? "bg-emerald-500 text-white"
                      : "bg-zinc-200 dark:bg-zinc-700 text-zinc-500"
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : st.num}
                </div>

                <div className="hidden sm:block min-w-0 truncate">
                  <span className="text-[10px] uppercase font-bold text-zinc-400 block leading-tight">
                    {t("Step", "Шаг")} {st.num}
                  </span>
                  <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 truncate block">
                    {st.title}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Loading state when fetching catalog */}
      {isLoadingCatalog && (
        <div className="w-full max-w-5xl bg-white dark:bg-zinc-900 rounded-3xl p-12 border border-zinc-200 dark:border-zinc-800 text-center flex flex-col items-center justify-center gap-3 shadow-sm my-6">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          <h3 className="font-bold text-base text-zinc-900 dark:text-zinc-100">
            {batchLoadingProgress
              ? `${t("Loading discography:", "Загрузка дискографии:")} ${batchLoadingProgress.current} ${t("of", "из")} ${batchLoadingProgress.total} («${batchLoadingProgress.artistName}»)...`
              : t("Loading full discography...", "Загрузка всей дискографии артиста...")}
          </h3>
          <p className="text-xs text-zinc-400 max-w-md">
            {batchLoadingProgress
              ? t(
                  `Batch importing artist discographies in parallel. Processing ${batchLoadingProgress.total} artists without limits.`,
                  `Пакетный импорт дискографий в параллельном режиме. Обработка ${batchLoadingProgress.total} артистов без ограничений.`
                )
              : t(
                  "Retrieving all releases, tracks, and available ISRC/UPC codes across music platforms.",
                  "Получение альбомов, треков и доступных кодов из музыкальных платформ."
                )}
          </p>
        </div>
      )}

      {catalogError && (
        <div className="w-full max-w-5xl mb-6 p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{catalogError}</span>
        </div>
      )}

      {/* Wizard Steps Rendering */}
      {!isLoadingCatalog && (
        <>
          {currentStep === 1 && (
            <Step1SearchArtist
              onArtistSelected={handleArtistSelected}
              onArtistsBatchSelected={handleArtistsBatchSelected}
              t={t}
            />
          )}

          {currentStep === 2 && selectedArtist && (
            <Step2CatalogSelect
              artist={selectedArtist}
              artists={selectedArtists.length > 1 ? selectedArtists : undefined}
              releases={catalogReleases}
              selectedReleaseIds={selectedReleaseIds}
              selectedTrackIdsMap={selectedTrackIdsMap}
              onSelectionChange={(newRels, newTracks) => {
                setSelectedReleaseIds(newRels);
                setSelectedTrackIdsMap(newTracks);
              }}
              onAddCustomRelease={handleAddCustomRelease}
              onBatchUpdateReleases={handleBatchUpdateReleases}
              onOpenReleaseDatesModal={() => setCurrentStep(4)}
              onNext={() => setCurrentStep(3)}
              onBack={() => setCurrentStep(1)}
              t={t}
            />
          )}

          {currentStep === 3 && (
            <Step3Codes
              releases={catalogReleases}
              selectedReleaseIds={selectedReleaseIds}
              selectedTrackIdsMap={selectedTrackIdsMap}
              onUpdateReleaseUpc={handleUpdateReleaseUpc}
              onUpdateTrackIsrc={handleUpdateTrackIsrc}
              onBatchUpdateCodes={handleBatchUpdateCodes}
              onUpdateReleaseDate={handleUpdateReleaseDate}
              onOpenReleaseDatesModal={() => setCurrentStep(4)}
              onNext={() => setCurrentStep(4)}
              onBack={() => setCurrentStep(2)}
              t={t}
            />
          )}

          {currentStep === 4 && selectedArtist && (
            <StepDates
              artist={selectedArtist}
              artists={selectedArtists.length > 1 ? selectedArtists : undefined}
              releases={catalogReleases}
              selectedReleaseIds={selectedReleaseIds}
              selectedTrackIdsMap={selectedTrackIdsMap}
              onUpdateReleaseDate={handleUpdateReleaseDate}
              onBatchUpdateDates={handleBatchUpdateDates}
              onNext={() => setCurrentStep(5)}
              onBack={() => setCurrentStep(3)}
              t={t}
            />
          )}

          {currentStep === 5 && selectedArtist && (
            <Step4Verification
              artist={selectedArtist}
              artists={selectedArtists.length > 1 ? selectedArtists : undefined}
              releases={catalogReleases}
              selectedReleaseIds={selectedReleaseIds}
              selectedTrackIdsMap={selectedTrackIdsMap}
              exportFormat={exportFormat}
              onExportFormatChange={setExportFormat}
              onBatchUpdateCodes={handleBatchUpdateCodes}
              onBatchUpdateReleases={handleBatchUpdateReleases}
              onOpenReleaseDatesModal={() => setCurrentStep(4)}
              onEditStep={(st) => setCurrentStep(st as any)}
              onStartDownload={() => setIsDownloadModalOpen(true)}
              t={t}
            />
          )}
        </>
      )}

      {/* History and Drafts View at the bottom */}
      {currentStep === 1 && !isLoadingCatalog && (
        <HistoryAndDraftsView
          drafts={drafts}
          history={history}
          onResumeDraft={handleResumeDraft}
          onDownloadDraftZip={handleDownloadDraftZip}
          onDeleteDraft={handleDeleteDraft}
          onDeleteHistoryItem={handleDeleteHistoryItem}
          t={t}
        />
      )}

      {/* Download Packaging Modal */}
      {selectedArtist && (
        <DownloadProgressModal
          isOpen={isDownloadModalOpen}
          onClose={() => setIsDownloadModalOpen(false)}
          artist={selectedArtist}
          artists={selectedArtists.length > 1 ? selectedArtists : undefined}
          releases={catalogReleases}
          selectedReleaseIds={selectedReleaseIds}
          selectedTrackIdsMap={selectedTrackIdsMap}
          exportFormat={exportFormat}
          onExportFormatChange={setExportFormat}
          onSaveToHistory={handleSaveToHistory}
          t={t}
        />
      )}
    </div>
  );
}
