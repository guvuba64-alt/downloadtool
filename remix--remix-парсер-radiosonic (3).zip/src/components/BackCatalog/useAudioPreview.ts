import { useState, useRef, useEffect, useCallback } from "react";

export interface AudioPlaybackState {
  playingTrackId: string | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  isLoading: boolean;
}

export function useAudioPreview() {
  const [playbackState, setPlaybackState] = useState<AudioPlaybackState>({
    playingTrackId: null,
    isPlaying: false,
    currentTime: 0,
    duration: 30,
    isLoading: false
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const synthCtxRef = useRef<AudioContext | null>(null);
  const synthOscRef = useRef<OscillatorNode | null>(null);
  const progressIntervalRef = useRef<number | null>(null);

  // Stop everything
  const stopAudio = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
    }
    if (synthOscRef.current) {
      try {
        synthOscRef.current.stop();
        synthOscRef.current.disconnect();
      } catch {}
      synthOscRef.current = null;
    }
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }

    setPlaybackState({
      playingTrackId: null,
      isPlaying: false,
      currentTime: 0,
      duration: 30,
      isLoading: false
    });
  }, []);

  // Play synthetic pleasant preview tone chord
  const playSynthesizedPreview = useCallback((trackId: string, title: string) => {
    stopAudio();
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      synthCtxRef.current = ctx;

      // Generate melody frequencies from track title hash
      let hash = 0;
      for (let i = 0; i < title.length; i++) {
        hash = (hash << 5) - hash + title.charCodeAt(i);
        hash |= 0;
      }
      const baseFreq = 220 + (Math.abs(hash) % 220); // 220 - 440 Hz

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);

      // Subtle vibrato
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.setValueAtTime(4.5, ctx.currentTime);
      lfoGain.gain.setValueAtTime(8, ctx.currentTime);
      lfo.connect(osc.frequency);
      lfo.start();

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 15);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      synthOscRef.current = osc;

      let time = 0;
      setPlaybackState({
        playingTrackId: trackId,
        isPlaying: true,
        currentTime: 0,
        duration: 15,
        isLoading: false
      });

      progressIntervalRef.current = window.setInterval(() => {
        time += 0.25;
        if (time >= 15) {
          stopAudio();
        } else {
          setPlaybackState((prev) => ({ ...prev, currentTime: time }));
        }
      }, 250);
    } catch (e) {
      console.warn("Synth playback failed:", e);
      stopAudio();
    }
  }, [stopAudio]);

  // Main toggle play
  const togglePlayTrack = useCallback(
    (trackId: string, trackTitle: string, artistName: string, previewUrl?: string) => {
      if (playbackState.playingTrackId === trackId && playbackState.isPlaying) {
        stopAudio();
        return;
      }

      stopAudio();

      setPlaybackState({
        playingTrackId: trackId,
        isPlaying: true,
        currentTime: 0,
        duration: 30,
        isLoading: true
      });

      // Target audio URL: either explicit preview, or music download endpoint
      let targetUrl = previewUrl;
      if (!targetUrl && trackId && !trackId.startsWith("syn_") && !trackId.startsWith("trk_")) {
        targetUrl = `/api/music/download/${encodeURIComponent(trackId)}?title=${encodeURIComponent(
          trackTitle
        )}&artists=${encodeURIComponent(artistName)}`;
      }

      if (!targetUrl) {
        playSynthesizedPreview(trackId, trackTitle);
        return;
      }

      try {
        const audio = new Audio();
        audioRef.current = audio;
        audio.src = targetUrl;
        audio.volume = 0.85;

        audio.oncanplay = () => {
          setPlaybackState((prev) => ({
            ...prev,
            isLoading: false,
            duration: audio.duration && !isNaN(audio.duration) ? audio.duration : 30
          }));
          audio.play().catch(() => {
            playSynthesizedPreview(trackId, trackTitle);
          });
        };

        audio.ontimeupdate = () => {
          setPlaybackState((prev) => ({
            ...prev,
            currentTime: audio.currentTime,
            duration: audio.duration && !isNaN(audio.duration) ? audio.duration : prev.duration
          }));
        };

        audio.onended = () => {
          stopAudio();
        };

        audio.onerror = () => {
          console.warn("HTML5 audio playback error, falling back to synth preview");
          playSynthesizedPreview(trackId, trackTitle);
        };

        audio.load();
      } catch {
        playSynthesizedPreview(trackId, trackTitle);
      }
    },
    [playbackState.playingTrackId, playbackState.isPlaying, stopAudio, playSynthesizedPreview]
  );

  useEffect(() => {
    return () => {
      stopAudio();
    };
  }, [stopAudio]);

  return {
    playbackState,
    togglePlayTrack,
    stopAudio
  };
}
