/**
 * Generates verified, studio-grade 3000 x 3000 px JPEG covers for Back-Catalog packages.
 * Includes CORS proxy handling, high-res canvas scaling, and typographic fallback.
 */

export async function generateStudioCoverBlob(
  coverUri: string | undefined,
  title: string,
  artistName: string
): Promise<Blob> {
  const TARGET_SIZE = 3000;
  const canvas = document.createElement("canvas");
  canvas.width = TARGET_SIZE;
  canvas.height = TARGET_SIZE;
  const ctx = canvas.getContext("2d", { willReadFrequently: false });

  if (!ctx) {
    throw new Error("Canvas 2D context unavailable");
  }

  // Attempt to load and render image
  let imageLoaded = false;

  if (coverUri) {
    try {
      // Use proxy or direct URL
      const proxyUrl = coverUri.startsWith("http")
        ? `/api/music/cover-proxy?url=${encodeURIComponent(coverUri)}`
        : coverUri;

      const img = new Image();
      img.crossOrigin = "anonymous";

      await new Promise<void>((resolve, reject) => {
        img.onload = () => {
          imageLoaded = true;
          resolve();
        };
        img.onerror = () => {
          // Retry direct without proxy if needed
          const directImg = new Image();
          directImg.crossOrigin = "anonymous";
          directImg.onload = () => {
            img.src = directImg.src;
            imageLoaded = true;
            resolve();
          };
          directImg.onerror = () => reject(new Error("Cover load failed"));
          directImg.src = coverUri;
        };
        img.src = proxyUrl;
      });

      if (imageLoaded) {
        // High quality image smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";

        // Center crop square
        const minDim = Math.min(img.naturalWidth, img.naturalHeight);
        const sx = (img.naturalWidth - minDim) / 2;
        const sy = (img.naturalHeight - minDim) / 2;

        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, TARGET_SIZE, TARGET_SIZE);
      }
    } catch (e) {
      imageLoaded = false;
    }
  }

  // If image could not be loaded, draw a crisp high-res 3000x3000px typographic vinyl label
  if (!imageLoaded) {
    // Dark luxury vinyl gradient
    const grad = ctx.createLinearGradient(0, 0, TARGET_SIZE, TARGET_SIZE);
    grad.addColorStop(0, "#111116");
    grad.addColorStop(0.5, "#181820");
    grad.addColorStop(1, "#0d0d12");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, TARGET_SIZE, TARGET_SIZE);

    // Subtle concentric vinyl grooves
    ctx.strokeStyle = "rgba(255, 255, 255, 0.04)";
    ctx.lineWidth = 4;
    for (let r = 400; r < 1450; r += 70) {
      ctx.beginPath();
      ctx.arc(TARGET_SIZE / 2, TARGET_SIZE / 2, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Outer border
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 16;
    ctx.strokeRect(120, 120, TARGET_SIZE - 240, TARGET_SIZE - 240);

    // Header badge
    ctx.fillStyle = "#EE8208";
    ctx.font = "bold 72px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("LABEL MASTER ARCHIVE • 3000×3000", TARGET_SIZE / 2, 380);

    // Release Title
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 160px system-ui, sans-serif";
    ctx.fillText(title.length > 25 ? title.substring(0, 24) + "…" : title, TARGET_SIZE / 2, TARGET_SIZE / 2 - 40);

    // Artist Name
    ctx.fillStyle = "#A1A1AA";
    ctx.font = "600 110px system-ui, sans-serif";
    ctx.fillText(artistName, TARGET_SIZE / 2, TARGET_SIZE / 2 + 130);

    // Footer
    ctx.fillStyle = "#71717A";
    ctx.font = "500 64px monospace";
    ctx.fillText("BACK-CATALOG VERIFIED STEREO WAV 44.1kHz / 16-BIT", TARGET_SIZE / 2, TARGET_SIZE - 280);
  }

  // Export as 0.92 quality JPEG Blob and immediately release canvas memory
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        // Explicitly clear canvas backbuffer to avoid browser memory spikes
        canvas.width = 0;
        canvas.height = 0;
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error("Failed to encode cover into JPEG"));
        }
      },
      "image/jpeg",
      0.92
    );
  });
}
