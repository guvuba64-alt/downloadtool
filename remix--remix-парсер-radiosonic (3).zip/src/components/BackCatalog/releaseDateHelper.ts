import { ReleaseEntity, TrackEntity } from "./types";

/**
 * Normalizes any date string (ISO, Russian DD.MM.YYYY, slash, year-only)
 * to standard ISO YYYY-MM-DD or YYYY format.
 */
export function normalizeDateString(raw: string): string {
  if (!raw) return "";
  const s = raw.trim();

  // Pattern 1: YYYY-MM-DD or YYYY.MM.DD or YYYY/MM/DD
  const isoMatch = s.match(/\b(19\d\d|20\d\d)[-/.](0[1-9]|1[0-2])[-/.](0[1-9]|[12]\d|3[01])\b/);
  if (isoMatch) {
    return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
  }

  // Pattern 2: DD.MM.YYYY or DD-MM-YYYY or DD/MM/YYYY
  const ruMatch = s.match(/\b(0[1-9]|[12]\d|3[01])[-/.](0[1-9]|1[0-2])[-/.](19\d\d|20\d\d)\b/);
  if (ruMatch) {
    return `${ruMatch[3]}-${ruMatch[2]}-${ruMatch[1]}`;
  }

  // Pattern 3: YYYY-MM or MM.YYYY
  const ymMatch = s.match(/\b(19\d\d|20\d\d)[-/.](0[1-9]|1[0-2])\b/);
  if (ymMatch) {
    return `${ymMatch[1]}-${ymMatch[2]}-01`;
  }

  // Pattern 4: Just Year 19xx or 20xx
  const yearMatch = s.match(/\b(19\d\d|20\d\d)\b/);
  if (yearMatch) {
    return `${yearMatch[1]}-01-01`;
  }

  return s;
}

/**
 * Formats a clean display date string, e.g. "2021-05-14" or "14.05.2021"
 */
export function formatDisplayDate(raw?: string | null): string {
  if (!raw || !raw.trim()) return "Не указана";
  const normalized = normalizeDateString(raw);
  if (/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
    const [y, m, d] = normalized.split("-");
    if (m === "01" && d === "01" && raw.trim().length === 4) {
      return y; // If user only entered year
    }
    return `${d}.${m}.${y} (${y}-${m}-${d})`;
  }
  return normalized;
}

/**
 * Generates the requested line format:
 * "Название артистов - Название альбома/трека - Дата релиза"
 */
export function formatReleaseDateLine(
  artistName: string,
  title: string,
  date?: string | null
): string {
  const safeArtist = (artistName || "Артист").trim();
  const safeTitle = (title || "Релиз").trim();
  const safeDate = date && date.trim() ? normalizeDateString(date) : "Не указана";
  return `${safeArtist} - ${safeTitle} - ${safeDate}`;
}

export interface ParsedDateItem {
  rawLine: string;
  matchedReleaseId?: string;
  matchedReleaseTitle?: string;
  matchedArtist?: string;
  extractedTitle: string;
  extractedArtist?: string;
  extractedDate: string;
  status: "matched" | "unmatched" | "ambiguous";
}

/**
 * Simplifies string for fuzzy comparison
 */
function simplify(str: string): string {
  return (str || "")
    .toLowerCase()
    .replace(/[«»"'`()[\]{}]/g, "")
    .replace(/[-_–—/\\|:]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Parses dates from text (TXT, CSV, TSV or copy-pasted lines).
 * Handles formats like:
 * 1. "Артист - Название альбома - Дата"
 * 2. "Артист - Название трека - Дата"
 * 3. "Название альбома - Дата"
 * 4. "1. Название - 2021-05-14"
 * 5. Tab / Semicolon / Comma separated lines
 */
export function parseReleaseDatesFromText(
  inputText: string,
  releases: ReleaseEntity[],
  defaultArtistName: string
): {
  items: ParsedDateItem[];
  matchedMap: Record<string, string>; // release_id -> normalizedDate
  totalLines: number;
  matchedCount: number;
} {
  const lines = inputText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !l.startsWith("#") && !l.startsWith("//"));

  const items: ParsedDateItem[] = [];
  const matchedMap: Record<string, string> = {};

  for (const line of lines) {
    // Strip leading index like "1. ", "01 - ", "[1] "
    let cleanLine = line.replace(/^\s*(?:\[?\d+[.)\]\s-]+)+/, "").trim();

    // Try splitting by common delimiters: " - ", "\t", ";", "|"
    let parts: string[] = [];
    if (cleanLine.includes("\t")) {
      parts = cleanLine.split("\t").map((p) => p.trim()).filter(Boolean);
    } else if (cleanLine.includes(";")) {
      parts = cleanLine.split(";").map((p) => p.trim()).filter(Boolean);
    } else if (cleanLine.includes(" | ")) {
      parts = cleanLine.split(" | ").map((p) => p.trim()).filter(Boolean);
    } else if (cleanLine.includes(" - ")) {
      parts = cleanLine.split(" - ").map((p) => p.trim()).filter(Boolean);
    } else if (cleanLine.includes(" — ")) {
      parts = cleanLine.split(" — ").map((p) => p.trim()).filter(Boolean);
    } else if (cleanLine.includes(" – ")) {
      parts = cleanLine.split(" – ").map((p) => p.trim()).filter(Boolean);
    }

    let extractedArtist = "";
    let extractedTitle = "";
    let rawDatePart = "";

    if (parts.length >= 3) {
      // e.g. Artist - Title - Date
      extractedArtist = parts[0];
      extractedTitle = parts[1];
      rawDatePart = parts.slice(2).join(" ");
    } else if (parts.length === 2) {
      // e.g. Title - Date OR Artist - Date
      const possibleDate = normalizeDateString(parts[1]);
      if (possibleDate) {
        extractedTitle = parts[0];
        rawDatePart = parts[1];
      } else {
        extractedArtist = parts[0];
        extractedTitle = parts[1];
      }
    } else {
      // Single string: try to extract date with regex at the end
      const dateMatch = cleanLine.match(
        /((?:19\d\d|20\d\d)[-/.](?:0[1-9]|1[0-2])[-/.](?:0[1-9]|[12]\d|3[01])|(?:0[1-9]|[12]\d|3[01])[-/.](?:0[1-9]|1[0-2])[-/.](?:19\d\d|20\d\d)|\b(?:19|20)\d{2}\b)/
      );
      if (dateMatch) {
        rawDatePart = dateMatch[0];
        extractedTitle = cleanLine.replace(dateMatch[0], "").replace(/[-—–:;,]+$/, "").trim();
      } else {
        extractedTitle = cleanLine;
      }
    }

    const normalizedDate = normalizeDateString(rawDatePart);

    // Try matching with releases
    let matchedRel: ReleaseEntity | undefined;
    const simpTitle = simplify(extractedTitle);
    const simpArtist = simplify(extractedArtist || defaultArtistName);

    if (simpTitle) {
      // 1. Exact title match
      matchedRel = releases.find((r) => simplify(r.title) === simpTitle);

      // 2. Contains match
      if (!matchedRel) {
        matchedRel = releases.find(
          (r) => simplify(r.title).includes(simpTitle) || simpTitle.includes(simplify(r.title))
        );
      }

      // 3. Track title match (e.g. single released with same title as track)
      if (!matchedRel) {
        matchedRel = releases.find((r) =>
          r.tracks.some((t) => simplify(t.title) === simpTitle || simpTitle.includes(simplify(t.title)))
        );
      }

      // 4. If artist is provided, verify artist match
      if (matchedRel && extractedArtist) {
        const relArtist = simplify(matchedRel.artist_name || defaultArtistName);
        if (!relArtist.includes(simpArtist) && !simpArtist.includes(relArtist)) {
          // If mismatch in artist, check if another release matches better
          const better = releases.find(
            (r) =>
              simplify(r.title) === simpTitle &&
              simplify(r.artist_name || defaultArtistName).includes(simpArtist)
          );
          if (better) matchedRel = better;
        }
      }
    }

    if (matchedRel && normalizedDate) {
      matchedMap[matchedRel.release_id] = normalizedDate;
      items.push({
        rawLine: line,
        matchedReleaseId: matchedRel.release_id,
        matchedReleaseTitle: matchedRel.title,
        matchedArtist: matchedRel.artist_name || defaultArtistName,
        extractedTitle: extractedTitle || matchedRel.title,
        extractedArtist,
        extractedDate: normalizedDate,
        status: "matched"
      });
    } else {
      items.push({
        rawLine: line,
        extractedTitle: extractedTitle || cleanLine,
        extractedArtist,
        extractedDate: normalizedDate || "Не распознана",
        status: "unmatched"
      });
    }
  }

  const matchedCount = Object.keys(matchedMap).length;
  return {
    items,
    matchedMap,
    totalLines: lines.length,
    matchedCount
  };
}

/**
 * Builds the complete export text file with the required format:
 * "Название артистов - Название альбома/трека - Дата релиза"
 */
export function generateReleaseDatesText(
  defaultArtist: string,
  releases: ReleaseEntity[],
  selectedTrackIdsMap?: Record<string, Set<string>>,
  mode: "releases_only" | "tracks_only" | "all" = "all"
): string {
  const lines: string[] = [];

  lines.push("==================================================");
  lines.push("          РЕЕСТР ДАТ РЕЛИЗОВ (RELEASE DATES)      ");
  lines.push("==================================================");
  lines.push(`Артист / Псевдоним:      ${defaultArtist}`);
  lines.push(`Дата формирования:       ${new Date().toISOString().split("T")[0]}`);
  lines.push(`Формат строк:            Название артистов - Название альбома/трека - Дата релиза`);
  lines.push("==================================================");
  lines.push("");

  if (mode === "releases_only" || mode === "all") {
    lines.push("1. ДАТЫ ВЫХОДА АЛЬБОМОВ И СИНГЛОВ (РЕЛИЗЫ):");
    lines.push("--------------------------------------------------");
    releases.forEach((rel, idx) => {
      const pad = String(idx + 1).padStart(2, "0");
      const artistName = rel.artist_name || defaultArtist;
      const dateStr = rel.release_date ? normalizeDateString(rel.release_date) : "Не указана";
      const lineStr = `${artistName} - ${rel.title} - ${dateStr}`;
      lines.push(`${pad}. ${lineStr}`);
    });
    lines.push("");
  }

  if (mode === "tracks_only" || mode === "all") {
    lines.push("2. ДАТЫ ВЫХОДА ПОТРЕКОВО (АРТИСТ - ТРЕК - ДАТА):");
    lines.push("--------------------------------------------------");
    let trackCounter = 1;
    releases.forEach((rel) => {
      const artistName = rel.artist_name || defaultArtist;
      const relDate = rel.release_date ? normalizeDateString(rel.release_date) : "Не указана";
      const allowed = selectedTrackIdsMap ? selectedTrackIdsMap[rel.release_id] : null;
      const tracksToProcess = allowed ? rel.tracks.filter((t) => allowed.has(t.track_id)) : rel.tracks;

      tracksToProcess.forEach((trk) => {
        const pad = String(trackCounter++).padStart(2, "0");
        const lineStr = `${artistName} - ${trk.title} - ${relDate}`;
        lines.push(`${pad}. ${lineStr}`);
      });
    });
    lines.push("");
  }

  lines.push("3. СТРОКИ ДЛЯ БЫСТРОЙ ВСТАВКИ / КОПИРОВАНИЯ ДИСТРИБЬЮТОРУ:");
  lines.push("--------------------------------------------------");
  releases.forEach((rel) => {
    const artistName = rel.artist_name || defaultArtist;
    const dateStr = rel.release_date ? normalizeDateString(rel.release_date) : "Не указана";
    lines.push(`${artistName} - ${rel.title} - ${dateStr}`);
  });

  lines.push("");
  lines.push("==================================================");

  return lines.join("\n");
}
