import React, { useState } from "react";
import { ArtistEntity, ReleaseEntity, TrackEntity } from "./types";
import { normalizeDateString, formatDisplayDate } from "./releaseDateHelper";
import {
  Calendar,
  Search,
  Copy,
  Check,
  Download,
  Loader2,
  Music,
  ArrowRight,
  Filter,
  Sparkles,
  FileText,
  RefreshCw,
  ExternalLink,
  Disc,
  Barcode,
  Tag,
  Clock,
  Layers,
  Eye,
  ChevronDown,
  ChevronUp,
  X,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Info
} from "lucide-react";

interface ReleaseDateLookupProps {
  onSelectArtist?: (artist: ArtistEntity) => void;
  t: (en: string, ru: string) => string;
}

export interface DetailedDateItem {
  id: string;
  artistId?: string;
  artistName: string;
  artistAvatar?: string;
  title: string;
  releaseDate: string; // ISO format e.g. "2023-04-21"
  humanDate: string;   // Localized e.g. "21 апр 2023 г."
  year: string;
  cover?: string;
  type: "album" | "single" | "ep" | "compilation" | "track" | string;
  label?: string;
  upc?: string;
  trackCount: number;
  tracks?: TrackEntity[];
  matchedQuery?: boolean;
}

// Helper to format Russian localized date
function formatHumanRussianDate(raw?: string | null): string {
  if (!raw) return "Не указана";
  const normalized = normalizeDateString(raw);
  const parts = normalized.split("-");
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);
    const months = [
      "января", "февраля", "марта", "апреля", "мая", "июня",
      "июля", "августа", "сентября", "октября", "ноября", "декабря"
    ];
    if (month >= 1 && month <= 12 && !isNaN(day)) {
      return `${day} ${months[month - 1]} ${year} г.`;
    }
  }
  if (normalized.length === 4) {
    return `${normalized} год`;
  }
  return raw;
}

// Helper to format track seconds into mm:ss
function formatDuration(sec?: number): string {
  if (!sec || isNaN(sec)) return "";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? "0" : ""}${s}`;
}

export function ReleaseDateLookup({ onSelectArtist, t }: ReleaseDateLookupProps) {
  const [pseudonym, setPseudonym] = useState("");
  const [releasesQuery, setReleasesQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [items, setItems] = useState<DetailedDateItem[]>([]);
  const [selectedArtistObj, setSelectedArtistObj] = useState<ArtistEntity | null>(null);

  // Copy feedback state
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // View presentation mode
  const [viewMode, setViewMode] = useState<"lineup" | "cards" | "text">("lineup");
  const [formatMode, setFormatMode] = useState<"artist-title-date" | "title-date" | "upc-full">("artist-title-date");

  // Filtering
  const [filterText, setFilterText] = useState("");
  const [filterType, setFilterType] = useState<string>("all");

  // Expanded tracklists state (track accordion)
  const [expandedReleases, setExpandedReleases] = useState<Set<string>>(new Set());

  // Lightbox cover preview modal
  const [previewCover, setPreviewCover] = useState<{ url: string; title: string; artist: string } | null>(null);

  const sampleArtists = ["OG Buda", "FEDUK", "MACAN", "Big Baby Tape", "MAYOT", "MARKUL", "SALUKI", "KIZARU"];

  const toggleExpandRelease = (id: string) => {
    setExpandedReleases((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleLookup = async (overridePseudonym?: string) => {
    const artistName = (overridePseudonym !== undefined ? overridePseudonym : pseudonym).trim();
    if (!artistName) {
      setError(t("Please enter artist pseudonym", "Пожалуйста, введите псевдоним артиста"));
      return;
    }

    setLoading(true);
    setError("");
    setItems([]);
    setSelectedArtistObj(null);
    setExpandedReleases(new Set());

    try {
      // 1. Find artist by pseudonym/name
      const searchRes = await fetch(
        `/api/music/back-catalog/search-artist?query=${encodeURIComponent(artistName)}&limit=10`
      );
      const searchData = await searchRes.json();

      if (!searchRes.ok || !searchData.success || !searchData.artists?.length) {
        throw new Error(
          t(
            "Artist not found. Please check pseudonym spelling or try another name.",
            "Артист с таким псевдонимом не найден. Проверьте правильность написания или попробуйте другой вариант."
          )
        );
      }

      // Pick best matching artist
      const targetArtist: ArtistEntity = searchData.artists[0];
      setSelectedArtistObj(targetArtist);

      // 2. Fetch full catalog of this artist (with all releases, covers, UPC, labels, tracks)
      const catalogRes = await fetch(
        `/api/music/back-catalog/artist/${targetArtist.artist_id}/catalog?name=${encodeURIComponent(
          targetArtist.name
        )}`
      );
      const catalogData = await catalogRes.json();

      if (!catalogRes.ok || !catalogData.success) {
        throw new Error(
          catalogData.error || t("Failed to load catalog for this artist", "Не удалось загрузить дискографию артиста")
        );
      }

      const rawReleases: ReleaseEntity[] = catalogData.releases || [];

      // Parse user's requested release queries if any
      const requestedTitles = releasesQuery
        .split(/[\n,;]+/)
        .map((s) => s.trim().toLowerCase())
        .filter((s) => s.length > 0);

      const collectedItems: DetailedDateItem[] = [];
      const seenReleaseIds = new Set<string>();

      // Extract full releases with covers and metadata
      for (const rel of rawReleases) {
        const titleClean = (rel.title || "").trim();
        const rawDate = rel.release_date || (rel.year ? `${rel.year}-01-01` : "");
        const dateClean = rawDate ? normalizeDateString(rawDate) : t("Unknown", "Дата неизвестна");
        const humanDateClean = formatHumanRussianDate(rawDate);
        const relYear = rel.year || (rawDate ? rawDate.substring(0, 4) : "—");

        const relId = rel.release_id || `rel_${titleClean}`;

        if (!seenReleaseIds.has(relId)) {
          seenReleaseIds.add(relId);

          const isMatched =
            requestedTitles.length === 0 ||
            requestedTitles.some(
              (q) =>
                titleClean.toLowerCase().includes(q) ||
                q.includes(titleClean.toLowerCase()) ||
                (rel.tracks && rel.tracks.some((tr) => tr.title.toLowerCase().includes(q)))
            );

          collectedItems.push({
            id: relId,
            artistId: rel.artist_id || targetArtist.artist_id,
            artistName: rel.artist_name || targetArtist.name,
            artistAvatar: targetArtist.avatar,
            title: titleClean,
            releaseDate: dateClean,
            humanDate: humanDateClean,
            year: relYear,
            cover: rel.cover || targetArtist.avatar,
            type: rel.type || "single",
            label: rel.label || undefined,
            upc: rel.upc || undefined,
            trackCount: rel.tracks?.length || 1,
            tracks: rel.tracks || [],
            matchedQuery: isMatched
          });
        }
      }

      // If user specified requested release titles, filter to matches first
      let finalItems = collectedItems;
      if (requestedTitles.length > 0) {
        const matched = collectedItems.filter((i) => i.matchedQuery);
        // Also if user entered some titles that weren't found in catalog, add them with notice
        const notFoundRequested = requestedTitles.filter(
          (req) =>
            !collectedItems.some(
              (i) =>
                i.title.toLowerCase().includes(req) ||
                req.includes(i.title.toLowerCase()) ||
                (i.tracks && i.tracks.some((tr) => tr.title.toLowerCase().includes(req)))
            )
        );

        const customNotFoundItems: DetailedDateItem[] = notFoundRequested.map((title, idx) => ({
          id: `custom_${idx}`,
          artistName: targetArtist.name,
          artistAvatar: targetArtist.avatar,
          title: title,
          releaseDate: t("Not in database", "Не найдена в базе"),
          humanDate: t("Not in database", "Не найдена в базе"),
          year: "—",
          cover: targetArtist.avatar,
          type: "single",
          trackCount: 1,
          matchedQuery: true
        }));

        finalItems = [...matched, ...customNotFoundItems];
      }

      // Sort descending by releaseDate
      finalItems.sort((a, b) => {
        if (!a.releaseDate || a.releaseDate.includes("Не")) return 1;
        if (!b.releaseDate || b.releaseDate.includes("Не")) return -1;
        return b.releaseDate.localeCompare(a.releaseDate);
      });

      setItems(finalItems);
      if (finalItems.length === 0) {
        setError(t("No releases found for specified query", "Релизов по указанным критериям не найдено"));
      }
    } catch (err: any) {
      setError(err.message || t("Lookup error occurred", "Произошла ошибка при поиске дат релиза"));
    } finally {
      setLoading(false);
    }
  };

  // Filtered items based on inner filter text and release type
  const displayedItems = items.filter((item) => {
    if (filterType !== "all" && item.type !== filterType) return false;
    if (!filterText.trim()) return true;
    const q = filterText.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.releaseDate.toLowerCase().includes(q) ||
      item.humanDate.toLowerCase().includes(q) ||
      (item.label && item.label.toLowerCase().includes(q)) ||
      (item.upc && item.upc.toLowerCase().includes(q))
    );
  });

  // Generate plain string formatted lines
  const getFormattedLines = (mode: "artist-title-date" | "title-date" | "upc-full") => {
    return displayedItems.map((item) => {
      if (mode === "title-date") {
        return `${item.title} — ${item.releaseDate}`;
      }
      if (mode === "upc-full") {
        return `${item.upc || "NO-UPC"} | ${item.artistName} - ${item.title} - ${item.releaseDate}${
          item.label ? ` [${item.label}]` : ""
        }`;
      }
      return `${item.artistName} - ${item.title} - ${item.releaseDate}`;
    });
  };

  const copyToClipboard = (mode: "artist-title-date" | "title-date" | "upc-full") => {
    const lines = getFormattedLines(mode);
    navigator.clipboard.writeText(lines.join("\n"));
    setCopiedKey(`bulk_${mode}`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const copySingleItem = (item: DetailedDateItem, mode: "full" | "date" | "upc" = "full") => {
    let text = "";
    if (mode === "date") {
      text = item.releaseDate;
    } else if (mode === "upc") {
      text = item.upc || "";
    } else {
      text = `${item.artistName} - ${item.title} - ${item.releaseDate}`;
    }
    navigator.clipboard.writeText(text);
    setCopiedKey(`${item.id}_${mode}`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const downloadTxt = () => {
    const lines = getFormattedLines(formatMode);
    const content = lines.join("\n");
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${pseudonym.trim() || "artist"}_release_dates.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mt-4 p-5 sm:p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-purple-500/30 shadow-lg flex flex-col gap-6 animate-in fade-in duration-200">
      {/* Lightbox Modal for Cover Art */}
      {previewCover && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setPreviewCover(null)}
        >
          <div
            className="relative max-w-md w-full bg-zinc-900 rounded-3xl p-5 border border-zinc-800 flex flex-col items-center gap-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setPreviewCover(null)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-72 h-72 sm:w-80 sm:h-80 rounded-2xl overflow-hidden shadow-2xl border border-zinc-700 bg-zinc-950">
              <img
                src={previewCover.url}
                alt={previewCover.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="text-center">
              <h4 className="text-lg font-bold text-white">{previewCover.title}</h4>
              <p className="text-sm text-zinc-400">{previewCover.artist}</p>
            </div>

            <a
              href={previewCover.url}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-2 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>{t("Open Original Image", "Открыть оригинал")}</span>
            </a>
          </div>
        </div>
      )}

      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-200 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-purple-500/20 shrink-0">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-extrabold text-zinc-900 dark:text-zinc-50">
                {t("Release Dates & Catalog Lineup", "Даты релиза и линейка каталога")}
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30 uppercase tracking-wide">
                HD Covers & Metadata
              </span>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              {t(
                "Find verified release dates with high-res cover art, label, UPC barcode, and tracks.",
                "Точные даты выхода с обложками высокого разрешения, лейблом, UPC штрихкодом и треклистом."
              )}
            </p>
          </div>
        </div>

        {/* Popular artist suggestions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-medium text-zinc-400">
            {t("Suggestions:", "Быстрый выбор:")}
          </span>
          {sampleArtists.map((artistName) => (
            <button
              key={artistName}
              type="button"
              onClick={() => {
                setPseudonym(artistName);
                handleLookup(artistName);
              }}
              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-zinc-100 hover:bg-purple-100 dark:bg-zinc-800 dark:hover:bg-purple-950/60 text-zinc-700 dark:text-zinc-300 hover:text-purple-700 dark:hover:text-purple-300 border border-zinc-200/80 dark:border-zinc-700/80 transition-all shadow-2xs"
            >
              {artistName}
            </button>
          ))}
        </div>
      </div>

      {/* Search Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleLookup();
        }}
        className="flex flex-col gap-4 bg-zinc-50/80 dark:bg-zinc-800/40 p-4 sm:p-5 rounded-2xl border border-zinc-200/80 dark:border-zinc-700/70"
      >
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* Pseudonym Input (7 cols) */}
          <div className="md:col-span-7 flex flex-col gap-1.5">
            <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center justify-between">
              <span>{t("Artist Pseudonym / Stage Name *", "Псевдоним артиста / Название *")}</span>
              <span className="text-[10px] text-zinc-400 font-normal">
                {t("Required", "Обязательное поле")}
              </span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={pseudonym}
                onChange={(e) => setPseudonym(e.target.value)}
                placeholder={t("e.g. OG Buda, FEDUK, MACAN...", "Например: OG Buda, FEDUK, MACAN...")}
                className="w-full h-11 pl-10 pr-4 text-sm font-medium rounded-xl bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 shadow-2xs"
              />
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3.5" />
            </div>
          </div>

          {/* Release Titles Input (5 cols) */}
          <div className="md:col-span-5 flex flex-col gap-1.5">
            <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center justify-between">
              <span>{t("Release / Track Titles", "Названия релизов или треков")}</span>
              <span className="text-[10px] text-zinc-400 font-normal">
                {t("Optional (empty = all)", "Опционально (пусто = всё)")}
              </span>
            </label>
            <input
              type="text"
              value={releasesQuery}
              onChange={(e) => setReleasesQuery(e.target.value)}
              placeholder={t("e.g. Скучаю Но Работаю, Сайфер...", "Например: Скучаю Но Работаю, Сайфер...")}
              className="w-full h-11 px-3.5 text-sm rounded-xl bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 shadow-2xs"
            />
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2">
            <button
              type="submit"
              disabled={loading || !pseudonym.trim()}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm transition-all shadow-md shadow-purple-600/20 flex items-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Calendar className="w-4 h-4" />
              )}
              <span>{t("Get Release Dates & Covers", "Узнать даты релиза и обложки")}</span>
            </button>

            {items.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setItems([]);
                  setFilterText("");
                  setError("");
                }}
                className="px-3.5 py-2.5 rounded-xl bg-zinc-200/70 hover:bg-zinc-200 dark:bg-zinc-700/60 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 text-xs font-semibold transition-colors"
              >
                {t("Clear", "Очистить")}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
            <Info className="w-4 h-4 text-purple-500 shrink-0" />
            <span>
              {t(
                "Full metadata: covers, albums, singles, label info and exact release dates.",
                "Полные данные: обложки, альбомы, синглы, инфо о лейбле и точные даты."
              )}
            </span>
          </div>
        </div>
      </form>

      {/* Error Message */}
      {error && (
        <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 text-red-700 dark:text-red-300 text-xs font-medium flex items-center justify-between gap-2">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => setError("")}
            className="text-red-500 hover:text-red-700 dark:hover:text-red-200"
          >
            ✕
          </button>
        </div>
      )}

      {/* Loading state indicator */}
      {loading && (
        <div className="py-14 flex flex-col items-center justify-center gap-3 text-zinc-500 dark:text-zinc-400">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600 dark:text-purple-400" />
          <p className="text-sm font-semibold text-zinc-700 dark:text-zinc-200">
            {t("Scanning streaming catalog, covers, labels and release dates...", "Сканирование дискографии, обложек, лейблов и дат релизов...")}
          </p>
          <span className="text-xs text-zinc-400">
            {t("Connecting to verified databases...", "Подключение к базам данных и сбор метаданных...")}
          </span>
        </div>
      )}

      {/* RESULTS DISPLAY: FULL METADATA + COVERS + BEAUTIFUL LINEUP */}
      {!loading && items.length > 0 && (
        <div className="flex flex-col gap-4 pt-2">
          {/* Toolbar: Artist Header + View Switcher + Filter + Export */}
          <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/80 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            {/* Artist Info Badge */}
            <div className="flex items-center gap-3">
              {selectedArtistObj?.avatar && (
                <div className="w-11 h-11 rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700 shadow-sm shrink-0">
                  <img
                    src={selectedArtistObj.avatar}
                    alt={selectedArtistObj.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-extrabold text-zinc-900 dark:text-zinc-100">
                    {selectedArtistObj?.name || pseudonym}
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-700 dark:text-purple-300 font-bold text-xs">
                    {displayedItems.length} {t("releases found", "релизов найдено")}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  {t("Verified catalog entries with release dates and artwork", "Проверенный каталог релизов с датами выхода и обложками")}
                </p>
              </div>
            </div>

            {/* Controls Right Side */}
            <div className="flex flex-wrap items-center gap-2">
              {/* View Switcher: Lineup, Cards, Text */}
              <div className="flex items-center p-1 bg-zinc-200/70 dark:bg-zinc-700/70 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setViewMode("lineup")}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    viewMode === "lineup"
                      ? "bg-white dark:bg-zinc-900 text-purple-600 dark:text-purple-400 shadow-xs font-bold"
                      : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                  title={t("Catalog Lineup View", "Вид линейки каталога")}
                >
                  <List className="w-3.5 h-3.5" />
                  <span>{t("Lineup", "Линейка")}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode("cards")}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    viewMode === "cards"
                      ? "bg-white dark:bg-zinc-900 text-purple-600 dark:text-purple-400 shadow-xs font-bold"
                      : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                  title={t("Cards Grid View", "Вид карточек")}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span>{t("Cards", "Карточки")}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode("text")}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    viewMode === "text"
                      ? "bg-white dark:bg-zinc-900 text-purple-600 dark:text-purple-400 shadow-xs font-bold"
                      : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                  title={t("Clean Text Registry", "Текстовый реестр")}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{t("Lines", "Строчки")}</span>
                </button>
              </div>

              {/* Fast Copy All Lines Button */}
              <button
                type="button"
                onClick={() => copyToClipboard(formatMode)}
                className="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                title={t("Copy all release date lines", "Скопировать все строчки с датами")}
              >
                {copiedKey === `bulk_${formatMode}` ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{t("Copied!", "Скопировано!")}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{t("Copy All Lines", "Скопировать все строчки")}</span>
                  </>
                )}
              </button>

              {/* Download TXT Button */}
              <button
                type="button"
                onClick={downloadTxt}
                className="px-3 py-2 rounded-xl bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-zinc-800 dark:text-zinc-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                title={t("Download TXT file", "Скачать TXT файл")}
              >
                <Download className="w-3.5 h-3.5" />
                <span>TXT</span>
              </button>
            </div>
          </div>

          {/* Filtering Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            {/* Search filter input */}
            <div className="relative flex-1">
              <input
                type="text"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder={t("Filter by title, date, label, or UPC...", "Фильтр по названию, дате, лейблу или UPC...")}
                className="w-full h-10 pl-9 pr-3 text-xs rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 shadow-2xs"
              />
              <Filter className="absolute left-3 top-3 w-4 h-4 text-zinc-400 pointer-events-none" />
            </div>

            {/* Type filter pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {[
                { id: "all", labelRu: "Все типы", labelEn: "All Types" },
                { id: "album", labelRu: "Альбомы", labelEn: "Albums" },
                { id: "single", labelRu: "Синглы", labelEn: "Singles" },
                { id: "ep", labelRu: "EP", labelEn: "EP" }
              ].map((tp) => (
                <button
                  key={tp.id}
                  type="button"
                  onClick={() => setFilterType(tp.id)}
                  className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors ${
                    filterType === tp.id
                      ? "bg-purple-600 text-white shadow-2xs"
                      : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                >
                  {t(tp.labelEn, tp.labelRu)}
                </button>
              ))}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* VIEW MODE 1: ELEGANT "ЛИНЕЙКА КАТАЛОГА" (Sleek List with HD Covers & Dates) */}
          {/* ========================================================================= */}
          {viewMode === "lineup" && (
            <div className="flex flex-col gap-2.5">
              {displayedItems.length === 0 ? (
                <div className="p-8 text-center text-xs text-zinc-400 bg-zinc-50 dark:bg-zinc-800/30 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                  {t("No releases match your filter", "Ничего не найдено по данному фильтру")}
                </div>
              ) : (
                displayedItems.map((item, idx) => {
                  const isExpanded = expandedReleases.has(item.id);
                  const padIndex = String(idx + 1).padStart(2, "0");
                  const isCopied = copiedKey === `${item.id}_full`;
                  const isCopiedDate = copiedKey === `${item.id}_date`;
                  const isCopiedUPC = copiedKey === `${item.id}_upc`;

                  return (
                    <div
                      key={`lookup-line-${item.id}-${idx}`}
                      className="group rounded-2xl border border-zinc-200/90 dark:border-zinc-700/80 bg-white dark:bg-zinc-900/90 hover:border-purple-400 dark:hover:border-purple-600/80 transition-all shadow-xs hover:shadow-md overflow-hidden"
                    >
                      {/* Main Release Lineup Row */}
                      <div className="p-3.5 sm:p-4 flex flex-col md:flex-row md:items-center justify-between gap-3.5">
                        {/* Left: Index + Cover Art + Title & Metadata */}
                        <div className="flex items-center gap-3.5 min-w-0 flex-1">
                          {/* Index */}
                          <span className="font-mono text-xs font-bold text-zinc-400 dark:text-zinc-500 w-6 text-right shrink-0">
                            {padIndex}
                          </span>

                          {/* Cover Artwork (60x60 with hover zoom & lightbox trigger) */}
                          <div
                            onClick={() =>
                              item.cover &&
                              setPreviewCover({
                                url: item.cover,
                                title: item.title,
                                artist: item.artistName
                              })
                            }
                            className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shrink-0 border border-zinc-200 dark:border-zinc-700 shadow-sm cursor-pointer group/cover"
                            title={t("Click to enlarge cover", "Нажмите для увеличения обложки")}
                          >
                            {item.cover ? (
                              <img
                                src={item.cover}
                                alt={item.title}
                                className="w-full h-full object-cover group-hover/cover:scale-105 transition-transform duration-200"
                              />
                            ) : (
                              <Disc className="w-7 h-7 text-zinc-400 absolute inset-0 m-auto" />
                            )}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/cover:opacity-100 transition-opacity flex items-center justify-center">
                              <Eye className="w-4 h-4 text-white" />
                            </div>
                          </div>

                          {/* Title, Artist, Badges */}
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h4 className="font-extrabold text-sm sm:text-base text-zinc-900 dark:text-zinc-50 truncate">
                                {item.title}
                              </h4>

                              {/* Type Badge */}
                              {item.type === "album" && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30 uppercase tracking-wide shrink-0">
                                  {t("Album", "Альбом")} • {item.trackCount} {t("tr.", "тр.")}
                                </span>
                              )}
                              {item.type === "ep" && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 uppercase tracking-wide shrink-0">
                                  EP • {item.trackCount} {t("tr.", "тр.")}
                                </span>
                              )}
                              {item.type === "single" && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30 uppercase tracking-wide shrink-0">
                                  {t("Single", "Сингл")}
                                </span>
                              )}
                              {item.type === "compilation" && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 uppercase tracking-wide shrink-0">
                                  {t("Compilation", "Сборник")}
                                </span>
                              )}
                            </div>

                            {/* Secondary Line: Artist + Label + UPC */}
                            <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-zinc-500 dark:text-zinc-400 font-medium">
                              <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                                {item.artistName}
                              </span>

                              {item.label && (
                                <>
                                  <span className="text-zinc-300 dark:text-zinc-600">•</span>
                                  <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 flex items-center gap-1">
                                    <Tag className="w-2.5 h-2.5 text-zinc-400" />
                                    <span>{item.label}</span>
                                  </span>
                                </>
                              )}

                              {item.upc && (
                                <>
                                  <span className="text-zinc-300 dark:text-zinc-600">•</span>
                                  <button
                                    type="button"
                                    onClick={() => copySingleItem(item, "upc")}
                                    className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 flex items-center gap-1 transition-colors"
                                    title={t("Click to copy UPC barcode", "Нажмите для копирования штрихкода UPC")}
                                  >
                                    <Barcode className="w-2.5 h-2.5 text-zinc-400" />
                                    <span>{item.upc}</span>
                                    {isCopiedUPC && (
                                      <Check className="w-2.5 h-2.5 text-emerald-500 stroke-[3]" />
                                    )}
                                  </button>
                                </>
                              )}

                              {/* Tracks count & accordion toggle */}
                              {item.tracks && item.tracks.length > 1 && (
                                <>
                                  <span className="text-zinc-300 dark:text-zinc-600">•</span>
                                  <button
                                    type="button"
                                    onClick={() => toggleExpandRelease(item.id)}
                                    className="text-[11px] font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-0.5"
                                  >
                                    <span>{isExpanded ? t("Hide tracklist", "Скрыть треки") : t("Show tracklist", "Треклист")} ({item.tracks.length})</span>
                                    {isExpanded ? (
                                      <ChevronUp className="w-3 h-3" />
                                    ) : (
                                      <ChevronDown className="w-3 h-3" />
                                    )}
                                  </button>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Right: Prominent Release Date Badge & Action Buttons */}
                        <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-zinc-100 dark:border-zinc-800">
                          {/* STYLED RELEASE DATE BLOCK */}
                          <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/40 dark:to-indigo-950/40 border border-purple-200/80 dark:border-purple-800/70 shadow-2xs">
                            <div className="w-7 h-7 rounded-lg bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                              <Calendar className="w-4 h-4" />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-mono text-xs sm:text-sm font-extrabold text-purple-900 dark:text-purple-100 tracking-tight">
                                {item.releaseDate}
                              </span>
                              <span className="text-[10px] font-medium text-purple-700/80 dark:text-purple-300/80">
                                {item.humanDate}
                              </span>
                            </div>
                          </div>

                          {/* Quick Actions: Copy Line & Copy Date */}
                          <div className="flex items-center gap-1.5">
                            {/* Copy Line string */}
                            <button
                              type="button"
                              onClick={() => copySingleItem(item, "full")}
                              className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs ${
                                isCopied
                                  ? "bg-emerald-600 text-white shadow-emerald-600/20"
                                  : "bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700"
                              }`}
                              title={t("Copy distributor string: Artist - Title - Date", "Скопировать строчку: Артист - Название - Дата")}
                            >
                              {isCopied ? (
                                <>
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                  <span>{t("Copied", "Скопировано")}</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />
                                  <span>{t("Copy Line", "Строчка")}</span>
                                </>
                              )}
                            </button>

                            {/* Copy Date Only */}
                            <button
                              type="button"
                              onClick={() => copySingleItem(item, "date")}
                              className={`p-2 rounded-xl text-xs font-bold transition-all ${
                                isCopiedDate
                                  ? "bg-emerald-600 text-white"
                                  : "bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700"
                              }`}
                              title={t("Copy date only (YYYY-MM-DD)", "Скопировать только дату")}
                            >
                              {isCopiedDate ? (
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              ) : (
                                <Calendar className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Expandable Tracklist Accordion */}
                      {isExpanded && item.tracks && item.tracks.length > 0 && (
                        <div className="bg-zinc-50/70 dark:bg-zinc-800/40 p-4 border-t border-zinc-200/80 dark:border-zinc-800 flex flex-col gap-2">
                          <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1">
                            {t("Album Tracks & ISRCs:", "Треклист альбома и коды ISRC:")}
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {item.tracks.map((tr, trIdx) => (
                              <div
                                key={`lookup-tr-${item.id}-${tr.track_id || trIdx}-${trIdx}`}
                                className="p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/70 dark:border-zinc-800 flex items-center justify-between gap-2 text-xs"
                              >
                                <div className="flex items-center gap-2 min-w-0 flex-1">
                                  <span className="font-mono text-zinc-400 w-5 text-right shrink-0">
                                    {tr.track_number || trIdx + 1}.
                                  </span>
                                  <span className="font-bold text-zinc-800 dark:text-zinc-200 truncate">
                                    {tr.title}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  {tr.isrc && (
                                    <span className="font-mono text-[10px] text-zinc-400 px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800">
                                      {tr.isrc}
                                    </span>
                                  )}
                                  {tr.duration && (
                                    <span className="text-zinc-400 font-mono text-[11px]">
                                      {formatDuration(tr.duration)}
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* VIEW MODE 2: BENTO GRID CARDS (Large Covers & Rich Presentation) */}
          {/* ========================================================================= */}
          {viewMode === "cards" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayedItems.map((item, idx) => {
                const isCopied = copiedKey === `${item.id}_full`;
                return (
                  <div
                    key={`lookup-card-${item.id}-${idx}`}
                    className="rounded-3xl border border-zinc-200/90 dark:border-zinc-800 bg-white dark:bg-zinc-900 p-4 flex flex-col gap-3.5 shadow-sm hover:shadow-md transition-shadow"
                  >
                    {/* Top: Large Cover Artwork */}
                    <div
                      onClick={() =>
                        item.cover &&
                        setPreviewCover({
                          url: item.cover,
                          title: item.title,
                          artist: item.artistName
                        })
                      }
                      className="relative aspect-square w-full rounded-2xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 shadow-sm cursor-pointer group/cardcover"
                    >
                      {item.cover ? (
                        <img
                          src={item.cover}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover/cardcover:scale-105 transition-transform duration-200"
                        />
                      ) : (
                        <Disc className="w-12 h-12 text-zinc-400 absolute inset-0 m-auto" />
                      )}

                      {/* Floating Type Pill on Cover */}
                      <div className="absolute top-2.5 left-2.5">
                        <span className="px-2.5 py-1 rounded-lg text-[10px] font-extrabold bg-black/70 backdrop-blur-md text-white uppercase tracking-wider shadow-sm">
                          {item.type}
                        </span>
                      </div>

                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/cardcover:opacity-100 transition-opacity flex items-center justify-center">
                        <Eye className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    {/* Metadata Content */}
                    <div className="flex flex-col gap-1.5 flex-1">
                      <h4 className="font-extrabold text-base text-zinc-900 dark:text-zinc-50 truncate">
                        {item.title}
                      </h4>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium truncate">
                        {item.artistName}
                      </p>

                      {/* Label & UPC chips */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {item.label && (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 truncate max-w-full">
                            {item.label}
                          </span>
                        )}
                        {item.upc && (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
                            UPC: {item.upc}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Bottom: Highlighted Release Date Badge & Copy */}
                    <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <div className="flex flex-col">
                          <span className="font-mono text-xs font-bold text-zinc-900 dark:text-zinc-100">
                            {item.releaseDate}
                          </span>
                          <span className="text-[10px] text-zinc-400">
                            {item.humanDate}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => copySingleItem(item, "full")}
                        className={`p-2 rounded-xl text-xs font-bold transition-all shadow-2xs ${
                          isCopied
                            ? "bg-emerald-600 text-white"
                            : "bg-purple-600 hover:bg-purple-700 text-white"
                        }`}
                        title={t("Copy formatted line", "Скопировать строчку")}
                      >
                        {isCopied ? (
                          <Check className="w-4 h-4 stroke-[3]" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ========================================================================= */}
          {/* VIEW MODE 3: TEXT REGISTRY (Quick text block with format switcher) */}
          {/* ========================================================================= */}
          {viewMode === "text" && (
            <div className="p-4 sm:p-5 rounded-2xl bg-zinc-900 text-zinc-100 font-mono text-xs border border-zinc-800 flex flex-col gap-3 shadow-inner">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-zinc-800">
                <span className="text-zinc-400 font-sans text-xs font-semibold">
                  {t("Formatted text lines for distributors (Zvonko, ONErpm, Believe, etc.):", "Готовые строчки для дистрибьюторов (Zvonko, ONErpm, Believe и др.):")}
                </span>

                <div className="flex items-center gap-2">
                  <select
                    value={formatMode}
                    onChange={(e) => setFormatMode(e.target.value as any)}
                    className="bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs rounded-lg px-2.5 py-1 font-sans focus:outline-none"
                  >
                    <option value="artist-title-date">Артист - Название - Дата</option>
                    <option value="title-date">Название — Дата</option>
                    <option value="upc-full">UPC | Артист - Название - Дата [Лейбл]</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => copyToClipboard(formatMode)}
                    className="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-sans text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    {copiedKey === `bulk_${formatMode}` ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{t("Copied", "Скопировано")}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>{t("Copy All", "Копировать")}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <textarea
                readOnly
                rows={Math.min(displayedItems.length + 2, 16)}
                value={getFormattedLines(formatMode).join("\n")}
                className="w-full bg-transparent text-emerald-400 font-mono text-xs focus:outline-none resize-y leading-relaxed"
              />
            </div>
          )}

          {/* Bottom Catalog Transition CTA: Proceed to full ingestion */}
          {selectedArtistObj && onSelectArtist && (
            <div className="mt-2 p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30 border border-purple-200/80 dark:border-purple-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-zinc-100">
                    {t(
                      "Need audio files, covers and XML/DDEX export for these releases?",
                      "Нужно выгрузить аудиофайлы, обложки и XML/DDEX для этих релизов?"
                    )}
                  </h4>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    {t(
                      "Proceed to Step 2 to select tracks, edit metadata and download complete catalog archive.",
                      "Перейдите к Шагу 2 для выбора треков, редактирования метаданных и скачивания архива каталога."
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onSelectArtist(selectedArtistObj)}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition-colors flex items-center gap-2 shrink-0 shadow-sm"
              >
                <span>{t("Proceed to Full Catalog Transfer", "Перейти к переносу каталога")}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
