import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Download,
  CheckCircle2,
  AlertCircle,
  Loader2,
  X,
  FolderArchive,
  Maximize2,
  Sparkles,
  FileSpreadsheet,
  FileText
} from "lucide-react";
import { downloadCatalogArchive } from "./downloadHelper";

export interface ServerExportTask {
  taskId: string;
  artistName: string;
  fileName: string;
  status: "processing" | "completed" | "error" | "cancelled";
  percent: number;
  stage: number;
  statusText: string;
  totalReleases: number;
  totalTracks: number;
  processedTracks: number;
  currentReleaseTitle?: string;
  currentTrackTitle?: string;
  error?: string;
  createdAt: number;
  completedAt?: number;
  downloadUrl?: string;
  fileSize?: number;
}

interface BackgroundExportWidgetProps {
  onOpenModal?: (task: ServerExportTask) => void;
  t: (en: string, ru: string) => string;
}

export const BackgroundExportWidget: React.FC<BackgroundExportWidgetProps> = ({
  onOpenModal,
  t
}) => {
  const [task, setTask] = useState<ServerExportTask | null>(null);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [widgetError, setWidgetError] = useState<string | null>(null);

  // Poll active task from localStorage / backend
  useEffect(() => {
    let timer: NodeJS.Timeout;

    const checkTask = async () => {
      const storedTaskId = localStorage.getItem("active_catalog_export_task_id");
      if (!storedTaskId) {
        // Check latest task from server in case user returned to fresh browser
        try {
          const res = await fetch("/api/catalog/latest-task");
          const data = await res.json();
          if (data.success && data.task) {
            const serverTask: ServerExportTask = data.task;
            // Only show if recent (less than 24 hours old)
            if (Date.now() - serverTask.createdAt < 24 * 3600 * 1000) {
              setTask(serverTask);
              localStorage.setItem("active_catalog_export_task_id", serverTask.taskId);
            }
          }
        } catch (e) {}
        return;
      }

      try {
        const res = await fetch(`/api/catalog/export-task/${storedTaskId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.task) {
            setTask(data.task);
            if (data.task.status === "completed" || data.task.status === "error") {
              // Task finished
            }
          }
        } else if (res.status === 404) {
          localStorage.removeItem("active_catalog_export_task_id");
          setTask(null);
        }
      } catch (e) {}
    };

    checkTask();
    timer = setInterval(checkTask, 2000);

    const handleStorageChange = () => checkTask();
    window.addEventListener("catalog_export_task_updated", handleStorageChange);

    return () => {
      clearInterval(timer);
      window.removeEventListener("catalog_export_task_updated", handleStorageChange);
    };
  }, []);

  if (!task || isDismissed) return null;

  const isCompleted = task.status === "completed";
  const isProcessing = task.status === "processing";
  const isError = task.status === "error";

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    setWidgetError(null);
    try {
      await downloadCatalogArchive(task.taskId, task.fileName || "BackCatalog.zip");
    } catch (err: any) {
      const msg = err?.message || "Архив не найден на сервере.";
      setWidgetError(msg);
      if (onOpenModal) {
        onOpenModal(task);
      }
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    if (isCompleted || isError) {
      localStorage.removeItem("active_catalog_export_task_id");
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        transition={{ type: "spring", damping: 24, stiffness: 320 }}
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 max-w-md w-[calc(100vw-2rem)] sm:w-[420px] rounded-3xl bg-white/95 dark:bg-zinc-900/95 text-zinc-900 dark:text-zinc-100 backdrop-blur-xl border border-zinc-200/80 dark:border-zinc-800/80 shadow-2xl p-4 overflow-hidden"
      >
        {/* Subtle background glow */}
        {isCompleted ? (
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />
        ) : (
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-orange-500/15 rounded-full blur-2xl pointer-events-none" />
        )}

        <div className="relative flex items-start gap-3">
          {/* Icon */}
          <div className="shrink-0 mt-0.5">
            {isCompleted ? (
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center border border-emerald-500/30">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            ) : isError ? (
              <div className="w-10 h-10 rounded-2xl bg-rose-500/15 text-rose-500 flex items-center justify-center border border-rose-500/30">
                <AlertCircle className="w-5 h-5" />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-2xl bg-orange-500/15 text-orange-500 flex items-center justify-center border border-orange-500/30">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
            )}
          </div>

          {/* Body */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-50 truncate flex items-center gap-1.5">
                <span>{task.artistName}</span>
                <span className="text-xs font-normal text-zinc-400">
                  • {task.totalReleases} {t("releases", "рел.")}
                </span>
              </h4>

              <button
                type="button"
                onClick={handleDismiss}
                className="w-6 h-6 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 flex items-center justify-center transition-colors shrink-0"
                title={t("Close", "Закрыть")}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5 line-clamp-1">
              {isCompleted
                ? t("Catalog is ready for label transfer!", "Каталог готов к передаче лейблу!")
                : task.statusText || t("Processing in background...", "Сборка в фоне на сервере...")}
            </p>

            {/* Progress bar if processing */}
            {isProcessing && (
              <div className="mt-2.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                  <span className="flex items-center gap-1 text-orange-500 font-bold">
                    <Sparkles className="w-3 h-3" />
                    {t("Server background task", "Фоновая сборка на сервере")}
                  </span>
                  <span className="font-mono text-orange-500">{task.percent}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                  <div
                    className="h-full bg-orange-500 transition-all duration-300 rounded-full"
                    style={{ width: `${task.percent}%` }}
                  />
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-2 mt-3 pt-1">
              {isCompleted ? (
                <>
                  <button
                    type="button"
                    disabled={isDownloading}
                    onClick={handleDownloadZip}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 active:scale-95 disabled:opacity-75 disabled:pointer-events-none text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer"
                  >
                    {isDownloading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>{t("Downloading...", "Сохранение...")}</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" />
                        <span>
                          {t("Download ZIP", "Скачать ZIP")}
                          {task.fileSize ? ` (${(task.fileSize / (1024 * 1024)).toFixed(1)} MB)` : ""}
                        </span>
                      </>
                    )}
                  </button>

                  {onOpenModal && (
                    <button
                      type="button"
                      onClick={() => onOpenModal(task)}
                      className="px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                      title={t("Details & Codes", "Подробности и коды")}
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                      <span>{t("Details", "Детали")}</span>
                    </button>
                  )}
                </>
              ) : isProcessing ? (
                <>
                  {onOpenModal && (
                    <button
                      type="button"
                      onClick={() => onOpenModal(task)}
                      className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>{t("Expand window", "Развернуть окно")}</span>
                    </button>
                  )}
                  <span className="text-[11px] text-zinc-400 ml-auto">
                    {t("Zero tab lock", "Вкладку можно закрыть")}
                  </span>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    localStorage.removeItem("active_catalog_export_task_id");
                    setTask(null);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-xs font-medium text-zinc-600 dark:text-zinc-300"
                >
                  {t("Dismiss", "Скрыть")}
                </button>
              )}
            </div>

            {/* Error Notification inside Widget */}
            {widgetError && (
              <div className="mt-2.5 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs flex flex-col gap-1.5 animate-in fade-in">
                <div className="flex items-start gap-1.5 font-bold">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                  <span className="leading-snug">{widgetError}</span>
                </div>
                {onOpenModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setWidgetError(null);
                      onOpenModal(task);
                    }}
                    className="self-end px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] transition-colors cursor-pointer"
                  >
                    {t("Open details to rebuild", "Открыть для пересборки")}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
