/**
 * Professional UPC and ISRC code generators adhering to GS1 and IFPI standards.
 */

/**
 * Calculates GS1 standard check digit for 11 or 12 digit UPC/EAN base.
 */
export function calculateUpcCheckDigit(digits11: string): number {
  const digits = digits11.replace(/\D/g, "").slice(0, 11).split("").map(Number);
  while (digits.length < 11) {
    digits.unshift(0);
  }

  // Weight scheme: alternate 3 and 1 for odd/even positions from right
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    const weight = i % 2 === 0 ? 3 : 1;
    sum += digits[i] * weight;
  }

  const remainder = sum % 10;
  return remainder === 0 ? 0 : 10 - remainder;
}

/**
 * Generates a valid 12-digit standard UPC with correct GS1 check digit.
 * Uses standard music distributor prefix range (e.g. 198 or 859).
 */
export function generateValidUpc(index: number = 1): string {
  const prefix = "198"; // Standard global distributor block
  const dateSegment = String(Date.now()).slice(-6);
  const indexSegment = String(index % 100).padStart(2, "0");
  const base11 = `${prefix}${dateSegment}${indexSegment}`.slice(0, 11);
  const checkDigit = calculateUpcCheckDigit(base11);
  return `${base11}${checkDigit}`;
}

/**
 * Generates a standard IFPI compliant ISRC code:
 * Format: CC-XXX-YY-NNNNN
 * CC = 2 letters Country (e.g. RU, US, GB)
 * XXX = 3 alphanumeric characters Registrant (e.g. A01, Z99)
 * YY = 2 digits Year (e.g. 24, 25, 26)
 * NNNNN = 5 digits sequential track designation (00001 - 99999)
 */
export function generateValidIsrc(
  sequentialTrackIndex: number,
  countryCode = "RU",
  registrant = "M01",
  year?: string
): string {
  const cc = (countryCode || "RU").slice(0, 2).toUpperCase().padEnd(2, "R");
  const reg = (registrant || "M01").slice(0, 3).toUpperCase().padEnd(3, "0");
  const yr = (year || String(new Date().getFullYear()).slice(-2)).slice(0, 2);
  const num = String(Math.max(1, sequentialTrackIndex)).padStart(5, "0").slice(-5);

  return `${cc}${reg}${yr}${num}`;
}

/**
 * Batch generates UPCs and ISRCs for an entire list of releases and tracks.
 */
export function autoFillMissingCodes(
  releases: {
    release_id: string;
    upc?: string;
    tracks: { track_id: string; isrc?: string }[];
  }[],
  options: {
    countryCode?: string;
    registrant?: string;
    year?: string;
    overwriteExisting?: boolean;
  } = {}
): {
  updatedUpcs: Record<string, string>;
  updatedIsrcs: Record<string, Record<string, string>>;
} {
  const updatedUpcs: Record<string, string> = {};
  const updatedIsrcs: Record<string, Record<string, string>> = {};

  let trackCounter = 1;
  let releaseCounter = 1;

  releases.forEach((rel) => {
    // UPC
    if (!rel.upc || options.overwriteExisting) {
      updatedUpcs[rel.release_id] = generateValidUpc(releaseCounter++);
    }

    // ISRCs
    updatedIsrcs[rel.release_id] = {};
    rel.tracks.forEach((trk) => {
      if (!trk.isrc || options.overwriteExisting) {
        updatedIsrcs[rel.release_id][trk.track_id] = generateValidIsrc(
          trackCounter++,
          options.countryCode || "RU",
          options.registrant || "M01",
          options.year
        );
      }
    });
  });

  return { updatedUpcs, updatedIsrcs };
}
