export type ReleaseType = "album" | "single" | "ep" | "compilation";

export type BackCatalogExportFormat = "all_data" | "release_date_link_cover";

export interface ArtistEntity {
  artist_id: string;
  name: string;
  avatar?: string;
  releaseCount?: number;
  trackCount?: number;
  genres?: string[];
  disambiguation?: string;
  platform_links?: Record<string, string>;
  provider?: string;
}

export interface TrackEntity {
  track_id: string;
  release_id: string;
  track_number: number;
  title: string;
  artist?: string;
  artists?: string[];
  version?: string;
  isrc?: string;
  duration?: number;
  explicit?: boolean;
  previewUrl?: string;
  author_text?: string;
  author_music?: string;
}

export interface ReleaseEntity {
  release_id: string;
  artist_id: string;
  artist_name?: string;
  artists?: string[];
  version?: string;
  title: string;
  type: ReleaseType;
  release_date?: string;
  year?: string;
  cover?: string;
  upc?: string;
  label?: string; // Лейбл / дистрибьютор, через кого отгружался релиз
  distributor?: string;
  author_text?: string; // Автор текста
  author_music?: string; // Автор музыки
  link?: string; // Ссылка на релиз
  url?: string;
  tracks: TrackEntity[];
  // User selection: which tracks inside this release are chosen (if not specified, all tracks are included)
  selectedTrackIds?: string[];
  // True if this is an official artist's own release from direct discography, false if guest feature / compilation
  is_direct?: boolean;
}

export interface CatalogSelectionState {
  // Release IDs that are selected
  selectedReleaseIds: Set<string>;
  // Mapping releaseId -> Set of selected track IDs
  selectedTrackIdsMap: Record<string, Set<string>>;
}

export interface TransferDraft {
  id: string;
  updatedAt: number;
  artist: ArtistEntity;
  artists?: ArtistEntity[];
  releases: ReleaseEntity[];
  selectedReleaseIds: string[];
  selectedTrackIdsMap: Record<string, string[]>;
  step: 1 | 2 | 3 | 4 | 5;
  taskId?: string;
  exportFormat?: BackCatalogExportFormat;
}

export interface TransferHistoryItem {
  id: string;
  timestamp: number;
  artistName: string;
  artistAvatar?: string;
  artistCount?: number;
  artists?: ArtistEntity[];
  totalReleases: number;
  totalTracks: number;
  labels?: string[];
  status: "completed" | "partial";
  taskId?: string;
  zipFileName?: string;
  fileSize?: number;
  exportFormat?: BackCatalogExportFormat;
  archiveData?: {
    releases: ReleaseEntity[];
    artist: ArtistEntity;
    artists?: ArtistEntity[];
  };
}

export type WizardStep = 1 | 2 | 3 | 4 | 5;
