import React, { useState } from "react";
import { TransferDraft, TransferHistoryItem } from "./types";
import {
  Clock,
  FolderArchive,
  ArrowRight,
  Trash2,
  CheckCircle2,
  Disc,
  Music,
  Download,
  AlertCircle,
  Loader2
} from "lucide-react";
import { downloadCatalogArchive } from "./downloadHelper";

interface HistoryAndDraftsViewProps {
  drafts: TransferDraft[];
  history: TransferHistoryItem[];
  onResumeDraft: (draft: TransferDraft) => void;
  onDownloadDraftZip: (draft: TransferDraft) => void;
  onDeleteDraft: (draftId: string) => void;
  onDeleteHistoryItem: (id: string) => void;
  t: (en: string, ru: string) => string;
}

export function HistoryAndDraftsView({
  drafts,
  history,
  onResumeDraft,
  onDownloadDraftZip,
  onDeleteDraft,
  onDeleteHistoryItem,
  t
}: HistoryAndDraftsViewProps) {
  const [downloadingTaskId, setDownloadingTaskId] = useState<string | null>(null);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const handleDownloadHistoryZip = async (item: TransferHistoryItem) => {
    if (!item.taskId) return;
    setDownloadingTaskId(item.taskId);
    setHistoryError(null);
    try {
      const fileName = item.zipFileName || `${item.artistName || "Catalog"}_BackCatalog.zip`;
      await downloadCatalogArchive(item.taskId, fileName);
    } catch (err: any) {
      console.warn("History ZIP download warning:", err);
      setHistoryError(err?.message || "Не удалось скачать архив. Возможно, срок хранения файла истёк.");
    } finally {
      setDownloadingTaskId(null);
    }
  };

  if (drafts.length === 0 && history.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 mt-6">
      {historyError && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            <span>{historyError}</span>
          </div>
          <button
            type="button"
            onClick={() => setHistoryError(null)}
            className="text-xs font-bold text-rose-600 hover:text-rose-800 dark:hover:text-rose-100"
          >
            ✕
          </button>
        </div>
      )}
      {/* Active Drafts Section */}
      {drafts.length > 0 && (
        <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
              <Clock className="w-4 h-4 text-orange-500" />
              <span>{t("Saved Drafts", "Сохранённые черновики переноса")}</span>
            </h3>
            <span className="text-xs text-zinc-400">
              {t("Auto-saved locally", "Автосохранение в браузере")}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {drafts.map((draft) => {
              const readyCount = draft.selectedReleaseIds.length;
              const dateStr = new Date(draft.updatedAt).toLocaleDateString(undefined, {
                day: "numeric",
                month: "short",
                hour: "2-digit",
                minute: "2-digit"
              });

              // Extract distinct labels from selected releases
              const draftLabels: string[] = Array.from(
                new Set<string>(
                  draft.releases
                    .filter((r) => draft.selectedReleaseIds.includes(r.release_id))
                    .map((r) => r.label)
                    .filter((l): l is string => Boolean(l && l.trim().length > 0))
                )
              );

              return (
                <div
                  key={draft.id}
                  className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/70 dark:border-zinc-700/70 flex flex-col justify-between gap-3 hover:border-orange-500/40 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {draft.artist.avatar ? (
                        <img
                          src={draft.artist.avatar}
                          alt=""
                          className="w-10 h-10 rounded-xl object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-bold">
                          <Music className="w-5 h-5" />
                        </div>
                      )}
                      <div>
                        <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100">
                          {draft.artist.name} — {t("Back-Catalog", "Бэк-каталог")}
                        </h4>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                          {readyCount} {t("releases chosen", "релизов выбрано")} • {t("Step", "Шаг")}{" "}
                          {draft.step}
                        </p>
                        {/* Labels row */}
                        <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {t("Label:", "Лейбл:")}
                          </span>
                          {draftLabels.length > 0 ? (
                            draftLabels.map((lbl) => (
                              <span
                                key={lbl}
                                className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
                              >
                                {lbl}
                              </span>
                            ))
                          ) : (
                            <span className="text-[11px] text-zinc-400 italic">
                              {t("Not specified", "Не указан")}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteDraft(draft.id)}
                      className="text-zinc-400 hover:text-red-500 p-1.5 transition-colors"
                      title={t("Delete draft", "Удалить черновик")}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-zinc-200/50 dark:border-zinc-700/50 text-xs gap-2">
                    <span className="text-zinc-400">{dateStr}</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onDownloadDraftZip(draft)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer"
                        title={t("Download ZIP archive of this draft", "Скачать ZIP-архив этого черновика")}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{t("Download ZIP", "Скачать ZIP")}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onResumeDraft(draft)}
                        className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold flex items-center gap-1.5 transition-all shadow-xs"
                      >
                        <span>{t("Continue", "Продолжить")}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Completed Transfers History */}
      {history.length > 0 && (
        <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-2xl border border-zinc-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
              <FolderArchive className="w-4 h-4 text-emerald-500" />
              <span>{t("Export History", "История экспорта каталогов")}</span>
            </h3>
            <span className="text-xs text-zinc-400">
              {history.length} {t("completed archives", "созданных архивов")}
            </span>
          </div>

          <div className="divide-y divide-zinc-100 dark:divide-zinc-800 rounded-xl border border-zinc-200/70 dark:border-zinc-800 overflow-hidden">
            {history.map((item) => {
              const dateStr = new Date(item.timestamp).toLocaleDateString(undefined, {
                day: "numeric",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
              });

              return (
                <div
                  key={item.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100">
                        {item.artistName}
                      </h4>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                        {item.totalReleases} {t("releases", "релизов")} • {item.totalTracks}{" "}
                        {t("tracks", "треков")} • {dateStr}
                      </p>
                      {item.labels && item.labels.length > 0 && (
                        <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {t("Label:", "Лейбл:")}
                          </span>
                          {item.labels.map((lbl) => (
                            <span
                              key={lbl}
                              className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
                            >
                              {lbl}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    {item.taskId && (
                      <button
                        type="button"
                        disabled={downloadingTaskId === item.taskId}
                        onClick={() => handleDownloadHistoryZip(item)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer disabled:opacity-60"
                        title={t("Download ZIP archive", "Скачать готовый ZIP архив")}
                      >
                        {downloadingTaskId === item.taskId ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />
                        ) : (
                          <Download className="w-3.5 h-3.5" />
                        )}
                        <span>{t("Download ZIP", "Скачать ZIP")}</span>
                      </button>
                    )}

                    <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      {t("Completed", "Сформирован")}
                    </span>

                    <button
                      type="button"
                      onClick={() => onDeleteHistoryItem(item.id)}
                      className="p-2 rounded-lg text-zinc-400 hover:text-red-500 transition-colors"
                      title={t("Delete from history", "Удалить из истории")}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
