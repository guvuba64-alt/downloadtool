import React, { useState, useEffect } from 'react';
import { X, Check, Copy, RefreshCw, AlertCircle, Shield, Globe, Key, User, LogOut, ExternalLink, Lock, Sparkles, HelpCircle, ChevronUp, ChevronDown } from 'lucide-react';
import { VkIcon } from './Icons';
import { safeParseResponse } from '../utils/safeFetch';

interface VkUser {
  id: number;
  firstName: string;
  lastName: string;
  photo?: string;
  screenName?: string;
}

interface VkAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  t: (en: string, ru: string) => string;
}

export const VkAuthModal: React.FC<VkAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  t,
}) => {
  const [loginMode, setLoginMode] = useState<'token' | 'cookie' | 'password' | 'proxy'>('token');
  
  // Auth fields
  const [vkToken, setVkToken] = useState('');
  const [vkCookieString, setVkCookieString] = useState('');
  const [vkLogin, setVkLogin] = useState('');
  const [vkPassword, setVkPassword] = useState('');
  const [vkCode2fa, setVkCode2fa] = useState('');
  const [need2fa, setNeed2fa] = useState(false);
  const [showTokenGuide, setShowTokenGuide] = useState(false);

  // Status & loading
  const [isLoading, setIsLoading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [vkUser, setVkUser] = useState<VkUser | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);

  // Proxy state
  const [vkProxyUrl, setVkProxyUrl] = useState('');
  const [vkProxyEnabled, setVkProxyEnabled] = useState(false);
  const [isTestingProxy, setIsTestingProxy] = useState(false);
  const [isSavingProxy, setIsSavingProxy] = useState(false);
  const [proxyTestResult, setProxyTestResult] = useState<{ success: boolean; message: string; ip?: string; latencyMs?: number; country?: string } | null>(null);

  const [vkClientId, setVkClientId] = useState('');
  const [vkClientSecret, setVkClientSecret] = useState('');
  const [useCustomClient, setUseCustomClient] = useState(false);

  useEffect(() => {
    if (isOpen) {
      checkStatus();
      loadProxySettings();
      setErrorMessage(null);
      setSuccessMessage(null);
      try {
        const savedTok = localStorage.getItem('vk_auth_token');
        if (savedTok && !vkToken) setVkToken(savedTok);
        const savedCookies = localStorage.getItem('vk_auth_cookies');
        if (savedCookies && !vkCookieString) setVkCookieString(savedCookies);
      } catch (e) {}
    }
  }, [isOpen]);

  const handleTokenInput = (val: string) => {
    let cleanVal = val.trim();
    // If user pasted a full redirect URL: https://oauth.vk.com/blank.html#access_token=vk1.a...&expires_in=0&user_id=123
    if (cleanVal.includes('access_token=')) {
      try {
        const match = cleanVal.match(/access_token=([^&]+)/);
        if (match && match[1]) {
          cleanVal = match[1];
        }
      } catch (e) {}
    }
    setVkToken(cleanVal);
  };

  const checkStatus = async () => {
    setIsVerifying(true);
    try {
      const res = await fetch('/api/vk/status');
      const data = await safeParseResponse(res);
      if (data.connected && data.user) {
        setIsConnected(true);
        setVkUser(data.user);
      } else {
        setIsConnected(false);
        setVkUser(null);
      }
    } catch (e) {
      setIsConnected(false);
    } finally {
      setIsVerifying(false);
    }
  };

  const loadProxySettings = async () => {
    try {
      const res = await fetch('/api/vk/proxy');
      const data = await safeParseResponse(res);
      if (data) {
        setVkProxyEnabled(Boolean(data.enabled));
        setVkProxyUrl(data.proxyUrl || '');
      }
    } catch (e) {}
  };

  const copyConsoleScript = () => {
    const script = `copy(document.cookie); alert("✅ Куки VK (vk.com / vk.ru) скопированы в буфер! Теперь вставьте их в поле окна авторизации.");`;
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 3000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const payload: any = { mode: loginMode };
      if (loginMode === 'token') {
        let tokenToSubmit = vkToken.trim();
        if (tokenToSubmit.includes('access_token=')) {
          const match = tokenToSubmit.match(/access_token=([^&]+)/);
          if (match && match[1]) tokenToSubmit = match[1];
        }
        payload.token = tokenToSubmit;
      } else if (loginMode === 'cookie') {
        payload.cookieString = vkCookieString.trim();
      } else if (loginMode === 'password') {
        payload.login = vkLogin.trim();
        payload.password = vkPassword;
        if (vkCode2fa) payload.code2fa = vkCode2fa.trim();
        if (useCustomClient && vkClientId.trim() && vkClientSecret.trim()) {
          payload.clientId = vkClientId.trim();
          payload.clientSecret = vkClientSecret.trim();
        }
      }

      const res = await fetch('/api/vk/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await safeParseResponse(res);
      if (res.ok && data.success) {
        setIsConnected(true);
        setVkUser(data.user);
        setNeed2fa(false);
        if (loginMode === 'token' && vkToken.trim()) {
          try { localStorage.setItem('vk_auth_token', vkToken.trim()); } catch(e) {}
        } else if (loginMode === 'cookie' && vkCookieString.trim()) {
          try { localStorage.setItem('vk_auth_cookies', vkCookieString.trim()); } catch(e) {}
        }
        setSuccessMessage(t('Successfully authorized in VK! Credentials saved persistently.', 'Успешная авторизация в VK! Данные сохранены навсегда.'));
        if (onSuccess) onSuccess();
      } else {
        if (data.need2fa) {
          setNeed2fa(true);
        }
        setErrorMessage(data.error || t('Authorization failed', 'Ошибка авторизации'));
      }
    } catch (err: any) {
      setErrorMessage(err.message || t('Connection error', 'Ошибка соединения с сервером'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      const res = await fetch('/api/vk/disconnect', { method: 'POST' });
      await safeParseResponse(res).catch(() => {});
      try {
        localStorage.removeItem('vk_auth_token');
        localStorage.removeItem('vk_auth_cookies');
      } catch(e) {}
      setIsConnected(false);
      setVkUser(null);
      setSuccessMessage(t('Disconnected from VK', 'Вы вышли из аккаунта VK'));
      if (onSuccess) onSuccess();
    } catch (e: any) {
      setErrorMessage(e.message);
    }
  };

  const handleTestProxy = async () => {
    if (!vkProxyUrl.trim()) return;
    setIsTestingProxy(true);
    setProxyTestResult(null);
    try {
      const res = await fetch('/api/vk/proxy/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxyUrl: vkProxyUrl.trim() }),
      });
      const data = await safeParseResponse(res);
      setProxyTestResult(data);
    } catch (e: any) {
      setProxyTestResult({ success: false, message: e.message });
    } finally {
      setIsTestingProxy(false);
    }
  };

  const handleSaveProxy = async () => {
    setIsSavingProxy(true);
    try {
      const res = await fetch('/api/vk/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: vkProxyEnabled, proxyUrl: vkProxyUrl.trim() }),
      });
      const data = await safeParseResponse(res);
      if (data.success) {
        setSuccessMessage(t('Proxy settings saved', 'Настройки прокси сохранены'));
      }
    } catch (e: any) {
      setErrorMessage(e.message);
    } finally {
      setIsSavingProxy(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white dark:bg-[#18181b] border border-zinc-200/80 dark:border-white/10 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-zinc-100 dark:border-white/5 flex items-center justify-between bg-zinc-50/50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#0077FF] text-white flex items-center justify-center shadow-md shadow-[#0077FF]/25">
              <VkIcon className="w-6 h-6 fill-current" />
            </div>
            <div>
              <h3 className="font-bold text-base text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
                <span>{t('VK Authorization', 'Авторизация VK (vk.ru / vk.com)')}</span>
                {isConnected && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    {t('Active', 'Активна')}
                  </span>
                )}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {t('Connect account for audio search and metadata', 'Подключение для поиска аудиозаписей, ISRC и лейблов')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-white/5 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Alerts */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 rounded-2xl text-xs text-rose-600 dark:text-rose-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-2xl text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
              <Check className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Active User Card if connected */}
          {isConnected && vkUser && (
            <div className="p-4 bg-blue-50/70 dark:bg-[#0077FF]/10 border border-[#0077FF]/20 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                {vkUser.photo ? (
                  <img 
                    src={vkUser.photo} 
                    alt={vkUser.firstName} 
                    className="w-12 h-12 rounded-2xl object-cover border border-[#0077FF]/30 shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-[#0077FF] text-white flex items-center justify-center font-bold text-lg shadow-sm">
                    {vkUser.firstName?.[0] || 'V'}
                  </div>
                )}
                <div>
                  <div className="font-bold text-sm text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
                    <span>{vkUser.firstName} {vkUser.lastName}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#0077FF]/15 text-[#0077FF] dark:text-blue-300">
                      ID: {vkUser.id}
                    </span>
                  </div>
                  <div className="text-xs text-zinc-500 dark:text-zinc-400">
                    {vkUser.screenName ? `@${vkUser.screenName}` : t('Connected via VK Session', 'Авторизовано через VK Сессию')}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDisconnect}
                className="p-2 text-zinc-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-colors"
                title={t('Disconnect account', 'Выйти из аккаунта')}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Tabs */}
          <div className="flex bg-zinc-100 dark:bg-zinc-800/70 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => setLoginMode('cookie')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all ${
                loginMode === 'cookie'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {t('Cookie / Session', 'Cookie / Сессия')}
            </button>
            <button
              type="button"
              onClick={() => setLoginMode('token')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1 ${
                loginMode === 'token'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              <Key className="w-3 h-3" />
              {t('VK Token', 'Токен VK')}
            </button>
            <button
              type="button"
              onClick={() => setLoginMode('password')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all ${
                loginMode === 'password'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {t('Login & Password', 'Логин / Пароль')}
            </button>
            <button
              type="button"
              onClick={() => setLoginMode('proxy')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1 ${
                loginMode === 'proxy'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              <Globe className="w-3 h-3" />
              {t('Proxy', 'Прокси')}
              {vkProxyEnabled && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
            </button>
          </div>

          {/* TAB 1: COOKIE */}
          {loginMode === 'cookie' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-4 bg-blue-50/80 dark:bg-[#0077FF]/10 border border-[#0077FF]/20 rounded-2xl text-xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-950 dark:text-blue-200 flex items-center gap-1.5">
                    ⚡ {t('1-Click Express Bypass (vk.com / vk.ru):', '⚡ Быстрый вход через куки (в 1 клик):')}
                  </span>
                  <button
                    type="button"
                    onClick={copyConsoleScript}
                    className="px-2.5 py-1 bg-[#0077FF] hover:bg-[#0066dd] text-white rounded-lg font-bold text-[11px] transition-all flex items-center gap-1 shadow-sm"
                  >
                    {copiedScript ? (
                      <>
                        <Check className="w-3 h-3 text-white" />
                        {t('Copied!', 'Скопировано!')}
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        {t('Copy Script', 'Скопировать скрипт')}
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-blue-900/90 dark:text-blue-300 leading-relaxed">
                  {t(
                    '1. Open vk.com or vk.ru in your browser -> Press F12 (Console).\n2. Click "Copy Script" above, paste into console and press Enter.\n3. Paste the copied remixsid / cookies into the field below.',
                    '1. Откройте vk.com или vk.ru в браузере -> Нажмите F12 (вкладка Консоль).\n2. Нажмите «Скопировать скрипт» выше, вставьте в консоль и нажмите Enter.\n3. Вставьте полученные куки (remixsid) в поле ниже.'
                  )}
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 uppercase tracking-wider">
                  {t('Cookie string (remixsid=... or JSON)', 'Строка Cookie (remixsid=... или JSON)')}
                </label>
                <textarea
                  rows={4}
                  value={vkCookieString}
                  onChange={(e) => setVkCookieString(e.target.value)}
                  placeholder="remixsid=...; remixnsid=...; or [ { name: 'remixsid', ... } ]"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-3 text-xs focus:ring-2 focus:ring-[#0077FF] focus:border-transparent outline-none font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || !vkCookieString.trim()}
                className="w-full bg-[#0077FF] hover:bg-[#0066dd] text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md shadow-[#0077FF]/25 flex items-center justify-center gap-2 text-xs disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <VkIcon className="w-4 h-4 fill-current" />}
                <span>{isLoading ? t('Verifying session...', 'Проверка куки VK...') : t('Save and Authorize', 'Сохранить и войти')}</span>
              </button>
            </form>
          )}

          {/* TAB 2: TOKEN */}
          {loginMode === 'token' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-4 bg-blue-50/70 dark:bg-[#0077FF]/10 border border-[#0077FF]/20 rounded-2xl text-xs space-y-3">
                <div className="font-bold text-[#0077FF] dark:text-blue-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-[#0077FF]" />
                    {t('Fast Token Generator (1-Click):', 'Быстрое получение токена (в 1 клик):')}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-600 dark:text-zinc-300 leading-relaxed">
                  {t(
                    '1. Click the button below to authorize via official VK OAuth.\n2. Click "Allow" ("Разрешить").\n3. Copy the URL from browser address bar (starts with oauth.vk.com/blank.html#access_token=...) and paste below.',
                    '1. Нажмите кнопку ниже для авторизации через официальный VK OAuth.\n2. Нажмите «Разрешить» на открывшейся странице.\n3. Скопируйте адресную строку (oauth.vk.com/blank.html#access_token=...) и вставьте в поле ниже (токен извлечется автоматически).'
                  )}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <a
                    href="https://oauth.vk.com/authorize?client_id=6121396&scope=audio,offline,status,wall&response_type=token&redirect_uri=https://oauth.vk.com/blank.html"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0077FF] hover:bg-[#0066dd] text-white rounded-xl font-bold text-xs shadow-sm transition-all"
                  >
                    <VkIcon className="w-3.5 h-3.5 fill-current" />
                    <span>{t('Get Token (VK Admin)', 'Получить токен (VK Admin)')}</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                  <a
                    href="https://oauth.vk.com/authorize?client_id=2685278&scope=audio,offline,status,wall&response_type=token&redirect_uri=https://oauth.vk.com/blank.html"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/15 text-zinc-800 dark:text-zinc-200 rounded-xl font-semibold text-xs transition-all"
                  >
                    <span>{t('Kate Mobile Link', 'Kate Mobile')}</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                  <a
                    href="https://oauth.vk.com/authorize?client_id=2274003&scope=audio,offline,status,wall&response_type=token&redirect_uri=https://oauth.vk.com/blank.html"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/15 text-zinc-800 dark:text-zinc-200 rounded-xl font-semibold text-xs transition-all"
                  >
                    <span>{t('VK Android Link', 'VK Android')}</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 uppercase tracking-wider">
                  {t('Access Token or Redirect URL', 'Access Token или ссылка после авторизации')}
                </label>
                <input
                  type="text"
                  value={vkToken}
                  onChange={(e) => handleTokenInput(e.target.value)}
                  placeholder="https://oauth.vk.com/blank.html#access_token=vk1.a... или сам токен"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-3 text-xs focus:ring-2 focus:ring-[#0077FF] focus:border-transparent outline-none font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || !vkToken.trim()}
                className="w-full bg-[#0077FF] hover:bg-[#0066dd] text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md shadow-[#0077FF]/25 flex items-center justify-center gap-2 text-xs disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <VkIcon className="w-4 h-4 fill-current" />}
                <span>{isLoading ? t('Validating token...', 'Проверка токена...') : t('Authorize with Token', 'Авторизоваться по токену')}</span>
              </button>
            </form>
          )}

          {/* TAB 3: PASSWORD */}
          {loginMode === 'password' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-3.5 bg-amber-50/80 dark:bg-amber-500/10 border border-amber-200/80 dark:border-amber-500/20 rounded-2xl text-xs space-y-1.5 text-amber-900 dark:text-amber-300">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>{t('Important note regarding password login:', 'Важно о прямом входе по логину и паролю:')}</span>
                </div>
                <p className="text-[11px] leading-relaxed text-amber-800 dark:text-amber-300/90">
                  {t(
                    'VK security blocks direct password authorization for server IP addresses and third-party apps with "client_secret is incorrect". If login fails, please use the "VK Token" (1-Click) or "Cookie" tab which work 100% reliably.',
                    'VK блокирует прямой вход по паролю для серверных IP и сторонних клиентов с ошибкой «client_secret is incorrect». Если вход не удаётся, воспользуйтесь вкладкой «Токен VK» (в 1 клик) или «Куки» — они работают стабильно и без блокировок.'
                  )}
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                  {t('Phone or Email', 'Телефон или Email')}
                </label>
                <input
                  type="text"
                  value={vkLogin}
                  onChange={(e) => setVkLogin(e.target.value)}
                  placeholder="+79991234567"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-[#0077FF] focus:border-transparent outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                  {t('Password', 'Пароль')}
                </label>
                <input
                  type="password"
                  value={vkPassword}
                  onChange={(e) => setVkPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-[#0077FF] focus:border-transparent outline-none"
                  required
                />
              </div>

              {/* Custom App Credentials Toggle */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => setUseCustomClient(!useCustomClient)}
                  className="text-[11px] font-semibold text-[#0077FF] hover:underline flex items-center gap-1"
                >
                  <span>{useCustomClient ? t('▾ Hide custom App ID / Secret', '▾ Скрыть свой App ID / Secret') : t('▸ Use custom VK Standalone App ID & Secret', '▸ Использовать свой App ID и Защищенный ключ')}</span>
                </button>

                {useCustomClient && (
                  <div className="mt-2.5 p-3.5 bg-zinc-50 dark:bg-white/5 border border-zinc-200/70 dark:border-white/10 rounded-2xl space-y-2.5 animate-in fade-in">
                    <div className="space-y-1">
                      <label className="block text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">
                        {t('Application ID (client_id)', 'ID приложения (client_id)')}
                      </label>
                      <input
                        type="text"
                        value={vkClientId}
                        onChange={(e) => setVkClientId(e.target.value)}
                        placeholder="Например: 2274003 или свой ID из vk.com/apps"
                        className="w-full text-zinc-900 dark:text-zinc-50 bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-[#0077FF]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">
                        {t('Secure Key (client_secret)', 'Защищённый ключ (client_secret)')}
                      </label>
                      <input
                        type="password"
                        value={vkClientSecret}
                        onChange={(e) => setVkClientSecret(e.target.value)}
                        placeholder="Защищённый ключ из настроек приложения"
                        className="w-full text-zinc-900 dark:text-zinc-50 bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-[#0077FF]"
                      />
                    </div>
                  </div>
                )}
              </div>

              {need2fa && (
                <div className="space-y-1.5 p-3 bg-amber-50 dark:bg-amber-500/10 border border-amber-300 dark:border-amber-500/30 rounded-2xl animate-in fade-in">
                  <label className="block text-xs font-bold text-amber-900 dark:text-amber-300">
                    {t('2FA Confirmation Code (SMS / App)', 'Код подтверждения 2FA (SMS / Приложение VK)')}
                  </label>
                  <input
                    type="text"
                    value={vkCode2fa}
                    onChange={(e) => setVkCode2fa(e.target.value)}
                    placeholder="123456"
                    className="w-full text-zinc-900 dark:text-zinc-50 bg-white dark:bg-[#1c1c1e] border border-amber-300 dark:border-amber-500/40 rounded-xl px-4 py-2 text-xs font-mono font-bold focus:ring-2 focus:ring-[#0077FF] outline-none"
                    required
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#0077FF] hover:bg-[#0066dd] text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md shadow-[#0077FF]/25 flex items-center justify-center gap-2 text-xs disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <VkIcon className="w-4 h-4 fill-current" />}
                <span>{isLoading ? t('Logging in...', 'Вход в VK...') : t('Sign In', 'Войти')}</span>
              </button>
            </form>
          )}

          {/* TAB 4: PROXY */}
          {loginMode === 'proxy' && (
            <div className="space-y-4">
              <div className="p-4 bg-zinc-50 dark:bg-white/5 border border-zinc-200/70 dark:border-white/10 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-[#0077FF]" />
                      {t('Use Proxy for VK', 'Использовать прокси для VK')}
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      {t('Routes VK authentication and searches through proxy IP', 'Маршрутизирует запросы к VK через выделенный IP-адрес')}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setVkProxyEnabled(!vkProxyEnabled)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      vkProxyEnabled ? 'bg-[#0077FF]' : 'bg-zinc-300 dark:bg-zinc-700'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        vkProxyEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                    {t('Proxy Address (HTTP / SOCKS5)', 'Адрес прокси')}
                  </label>
                  <input
                    type="text"
                    value={vkProxyUrl}
                    onChange={(e) => setVkProxyUrl(e.target.value)}
                    placeholder="http://login:pass@ip:port или ip:port"
                    className="w-full text-zinc-900 dark:text-zinc-50 bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-[#0077FF] outline-none font-mono"
                  />
                </div>

                {proxyTestResult && (
                  <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    proxyTestResult.success 
                      ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                      : 'bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20'
                  }`}>
                    {proxyTestResult.success ? <Check className="w-4 h-4 text-emerald-500" /> : <AlertCircle className="w-4 h-4 text-rose-500" />}
                    <span>{proxyTestResult.message || (proxyTestResult.success ? `Онлайн (${proxyTestResult.latencyMs}ms)` : 'Ошибка')}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={handleTestProxy}
                  disabled={isTestingProxy || !vkProxyUrl.trim()}
                  className="flex-1 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingProxy ? 'animate-spin text-[#0077FF]' : ''}`} />
                  {isTestingProxy ? t('Testing...', 'Проверка...') : t('Test Connection', 'Проверить связь')}
                </button>
                <button
                  type="button"
                  onClick={handleSaveProxy}
                  disabled={isSavingProxy}
                  className="flex-1 bg-[#0077FF] hover:bg-[#0066dd] text-white font-semibold py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs shadow-sm disabled:opacity-50"
                >
                  {isSavingProxy ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  {isSavingProxy ? t('Saving...', 'Сохранение...') : t('Save Proxy', 'Сохранить прокси')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
