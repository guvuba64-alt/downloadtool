import React, { useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
import { RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export function PdfPreview({ url, t }: { url: string, t?: (en: string, ru: string) => string }) {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState(1);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setPageNumber(1);
  }

  return (
    <div className="w-full h-full flex flex-col items-center bg-zinc-200/50 dark:bg-black overflow-y-auto">
      <Document
        file={url}
        onLoadSuccess={onDocumentLoadSuccess}
        loading={
          <div className="flex flex-col items-center justify-center p-12 text-zinc-400">
             <RefreshCw className="w-8 h-8 animate-spin mb-4 text-zinc-300" />
             <p>{t ? t("Loading preview...", "Загрузка предпросмотра...") : "Загрузка предпросмотра..."}</p>
          </div>
        }
        className="flex flex-col items-center py-4 px-2"
      >
        <div className="shadow-lg rounded bg-white">
          <Page 
            pageNumber={pageNumber} 
            renderTextLayer={false}
            renderAnnotationLayer={false}
            width={Math.min(window.innerWidth - 64, 800)}
            className="rounded"
          />
        </div>
      </Document>
      
      {numPages && numPages > 1 && (
        <div className="flex items-center gap-4 my-4 p-2 bg-white dark:bg-zinc-800 rounded-xl shadow-sm">
          <button 
            disabled={pageNumber <= 1} 
            onClick={() => setPageNumber(prev => prev - 1)}
            className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <p className="text-sm font-medium">
            {t ? t(`Page ${pageNumber} of ${numPages}`, `Страница ${pageNumber} из ${numPages}`) : `Страница ${pageNumber} из ${numPages}`}
          </p>
          <button 
            disabled={pageNumber >= numPages} 
            onClick={() => setPageNumber(prev => prev + 1)}
            className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 disabled:opacity-50"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}
