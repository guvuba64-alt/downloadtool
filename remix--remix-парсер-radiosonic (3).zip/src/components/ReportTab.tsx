import { TelegramIcon } from './Icons';
import { PdfPreview } from "./PdfPreview";
import { SignaturePad } from "./SignaturePad";
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { UploadCloud, Send, FileText, Download, TrendingUp, DollarSign, Filter, RefreshCw, BarChart2, PieChart as PieChartIcon, Settings, X, Plus, Users, Save, Printer, ChevronDown, Check } from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { jsPDF } from 'jspdf';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

interface RawRow {
  artist: string;
  artistId: string;
  release: string;
  track: string;
  streams: number;
  royalty: number; // calculated total for the row
  royaltyMaster?: number;
  royaltyPub?: number;
  currency: string;
  country: string;
  platform: string;
  rightsType?: 'authors' | 'related' | 'unknown';
  periodRaw?: string;
  period?: { startYear: number, startMonth: number, endYear: number, endMonth: number, sortKey: string } | null;
  truncated?: boolean;
}

interface Rule {
  level: 'global' | 'artist' | 'release' | 'track';
  artistId?: string;
  releaseKey?: string;
  trackKey?: string;
  artistShare: number; // percentage 0-100
  reason?: string;
  note?: string;
}

interface ReportTabProps {
  t: (en: string, ru: string) => string;
  lang: 'en' | 'ru';
  onTgLogsUpdate?: React.Dispatch<React.SetStateAction<any[]>>;
}

export function ReportTab({ t, lang, onTgLogsUpdate }: ReportTabProps) {
  const [rawData, setRawData] = useState<RawRow[]>([]);
  const [rules, setRules] = useState<Record<string, Rule>>({});
  const [parseWarnings, setParseWarnings] = useState<{level: 'error' | 'warning', message: string, rowNumbers?: number[]}[]>([]);
  const [parseSummary, setParseSummary] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [globalLabelShare, setGlobalLabelShare] = useState<number | string>(30); // Global fallback, 30% label, 70% artist

  const [targetCurrency, setTargetCurrency] = useState("RUB");
  const [exchangeRates, setExchangeRates] = useState<Record<string, number>>({"RUB": 1, "USD": 95, "EUR": 105});
  const [cbrRates, setCbrRates] = useState<Record<string, number>>({"RUB": 1});
  const [cbrTimestamp, setCbrTimestamp] = useState<number | null>(null);

  React.useEffect(() => {
    const fetchCBR = async () => {
      try {
        const res = await fetch("https://www.cbr-xml-daily.ru/daily_json.js");
        const data = await res.json();
        
        const rates: Record<string, number> = { "RUB": 1 };
        if (data.Valute) {
          Object.values(data.Valute).forEach((v: any) => {
            rates[v.CharCode] = (v.Value / v.Nominal); // Ensure nominal adjustment (e.g. 100 KZT)
          });
        }
        setCbrRates(rates);

        if (data.Timestamp) {
            setCbrTimestamp(new Date(data.Timestamp).getTime());
        }
      } catch (e) {
        console.error("Failed to fetch CBR rates:", e);
      }
    };
    fetchCBR();
  }, []);

  // Recalculate rates when targetCurrency or CBR data changes
  React.useEffect(() => {
    if (Object.keys(cbrRates).length <= 1) return; // Wait until fetched

    setExchangeRates(prev => {
        const newRates = { ...prev };
        ['RUB', 'USD', 'EUR', 'KZT', 'GBP', 'BYN'].forEach(c => {
            if (newRates[c] === undefined) newRates[c] = 1;
        });

        const targetRateInRub = cbrRates[targetCurrency] || 1;
        
        Object.keys(newRates).forEach(curr => {
            if (cbrRates[curr] !== undefined) {
                newRates[curr] = cbrRates[curr] / targetRateInRub;
            }
        });
        return newRates;
    });
  }, [targetCurrency, cbrRates]);


  const [selectedArtist, setSelectedArtist] = useState<string | null>(null);
  const [isRuleModalOpen, setIsRuleModalOpen] = useState(false);
  const [tempRule, setTempRule] = useState<Rule>({ level: 'artist', artistShare: 70 });

  
  const [filterText, setFilterText] = useState("");
  const [selectedFilterArtists, setSelectedFilterArtists] = useState<string[]>([]);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [selectedArtistId, setSelectedArtistId] = useState<string | null>(null);
  
  const [globalNote, setGlobalNote] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeView, setActiveView] = useState<'overview' | 'raw'>('overview');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  const parseNumber = (val: any) => {
    if (typeof val === 'number') return val;
    if (val === null || val === undefined || val === '') return 0;
    
    let str = String(val).trim().replace(/[\s\xA0]/g, ''); // remove spaces and non-breaking spaces
    // Remove currency symbols or unwanted text just in case
    str = str.replace(/[^0-9\,\.\-]/g, '');
    if (!str) return 0;
    
    const lastComma = str.lastIndexOf(',');
    const lastDot = str.lastIndexOf('.');
    
    if (lastComma > -1 && lastDot > -1) {
      if (lastComma > lastDot) {
        str = str.replace(/\./g, '').replace(',', '.');
      } else {
        str = str.replace(/,/g, '');
      }
    } else if (lastComma > -1) {
      const commaCount = (str.match(/,/g) || []).length;
      if (commaCount > 1) {
        str = str.replace(/,/g, '');
      } else {
        if (str.length - lastComma === 4) {
           str = str.replace(/,/g, '');
        } else {
           str = str.replace(',', '.');
        }
      }
    }
    
    return parseFloat(str) || 0;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setLoadingMsg(t("Reading file into memory...", "Чтение файла в память..."));
    
    // allow UI to update
    await new Promise(r => setTimeout(r, 50));

    try {
      const fileName = file.name.toLowerCase();
      let aoa: any[][] = [];

      if (fileName.endsWith('.csv') || fileName.endsWith('.tsv') || fileName.endsWith('.txt')) {
        setLoadingMsg(t("Parsing text document...", "Чтение текстового документа..."));
        await new Promise(r => setTimeout(r, 50));
        
        const text = await file.text();
        
        // Use papaparse for robust, blazing-fast CSV parsing
        const parsedCsv = Papa.parse(text, {
          skipEmptyLines: 'greedy',
        });
        
        aoa = parsedCsv.data as any[][];
      } else {
        const buffer = await file.arrayBuffer();
        
        setLoadingMsg(t("Parsing Excel structure...", "Анализ структуры Excel..."));
        await new Promise(r => setTimeout(r, 50));

        const wb = XLSX.read(buffer, { type: 'array', dense: true });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        
        setLoadingMsg(t("Extracting rows...", "Извлечение строк..."));
        await new Promise(r => setTimeout(r, 50));

        aoa = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
      }


      // Normalize period logic
      const normalizePeriod = (raw: string) => {
        if (!raw) return null;
        const s = raw.trim();
        let m;
        // 1-3.2025 -> Q1 2025 (months 1 to 3)
        if ((m = s.match(/^(\d{1,2})-(\d{1,2})\.(\d{4})$/))) {
          const startMonth = parseInt(m[1], 10);
          const endMonth = parseInt(m[2], 10);
          const year = parseInt(m[3], 10);
          return { startYear: year, startMonth, endYear: year, endMonth, sortKey: `${year}-${String(startMonth).padStart(2, '0')}..${year}-${String(endMonth).padStart(2, '0')}` };
        }
        // 4.2025 -> Month 4 2025
        if ((m = s.match(/^(\d{1,2})\.(\d{4})$/))) {
          const month = parseInt(m[1], 10);
          const year = parseInt(m[2], 10);
          return { startYear: year, startMonth: month, endYear: year, endMonth: month, sortKey: `${year}-${String(month).padStart(2, '0')}` };
        }
        // 2025-03 -> ISO month
        if ((m = s.match(/^(\d{4})-(\d{2})$/))) {
          const year = parseInt(m[1], 10);
          const month = parseInt(m[2], 10);
          return { startYear: year, startMonth: month, endYear: year, endMonth: month, sortKey: `${year}-${String(month).padStart(2, '0')}` };
        }
        return null;
      };

      // Detect blocks (sections) with headers
      const blocks: { startIdx: number, endIdx: number, headers: string[], rightsType: 'related' | 'authors' | 'unknown' }[] = [];
      let currentBlockStart = -1;
      
      for (let i = 0; i < aoa.length; i++) {
        const row = aoa[i] || [];
        const stringCount = row.filter(cell => typeof cell === 'string' && cell.trim().length > 0).length;
        const rowStr = row.join('').toLowerCase();
        const knownHeaderKeywords = ['artist', 'артист', 'исполнитель', 'track', 'трек', 'title', 'название', 'release', 'релиз', 'album', 'альбом', 'royalty', 'роялти', 'доход', 'revenue', 'earning', 'period', 'период', 'streams', 'прослушивания', 'amount', 'сумма', 'количество', 'кол-во', 'колво', 'country', 'страна', 'платформа', 'platform', 'площадка', 'произведение', 'композиция'];
        let hasKnownHeaders = 0;
        row.forEach(cell => {
           const cellStr = String(cell || '').toLowerCase().trim();
           if (knownHeaderKeywords.some(k => cellStr === k || cellStr.includes(k))) {
              hasKnownHeaders++;
           }
        });

        if (stringCount >= 3 && hasKnownHeaders >= 3) {
          if (currentBlockStart !== -1) {
             blocks[blocks.length - 1].endIdx = i - 1;
          }
          
          let rightsType: 'related' | 'authors' | 'unknown' = 'unknown';
          for (let j = Math.max(0, i - 3); j < i; j++) {
             const preRowStr = (aoa[j] || []).join('').toLowerCase();
             if (preRowStr.includes('смежные права') || preRowStr.includes('master') || preRowStr.includes('смежн')) rightsType = 'related';
             else if (preRowStr.includes('авторские права') || preRowStr.includes('publishing') || preRowStr.includes('авторск')) rightsType = 'authors';
          }
          
          blocks.push({
             startIdx: i,
             endIdx: aoa.length,
             headers: row.map(h => String(h || '').toLowerCase().replace(/[^a-zа-яё0-9]/gi, '')),
             rightsType
          });
          currentBlockStart = i;
        }
      }
      
      if (blocks.length === 0) {
        blocks.push({
            startIdx: 0, endIdx: aoa.length, headers: (aoa[0] || []).map(h => String(h || '').toLowerCase().replace(/[^a-zа-яё0-9]/gi, '')), rightsType: 'unknown'
        });
      }

      const parsed: RawRow[] = [];
      const warnings: {level: 'error' | 'warning', message: string, rowNumbers: number[]}[] = [];
      let authorsCount = 0;
      let relatedCount = 0;
      let unknownCount = 0;
      
      for (const block of blocks) {
        if (block.rightsType === 'authors') authorsCount++;
        else if (block.rightsType === 'related') relatedCount++;
        else unknownCount++;
        
        const headers = block.headers;
        const usedCols: number[] = [];
        const getCol = (aliases: string[]) => {
          const normHeaders = headers.map(h => h ? h.toString().toLowerCase().replace(/[\s_\.\/\\-]+/g, '') : '');
          for (const a of aliases) {
            const idx = normHeaders.findIndex((h, i) => !usedCols.includes(i) && h === a);
            if (idx !== -1) { usedCols.push(idx); return idx; }
          }
          for (const a of aliases) {
            const idx = normHeaders.findIndex((h, i) => !usedCols.includes(i) && h && (h.startsWith(a) || h.endsWith(a)));
            if (idx !== -1) { usedCols.push(idx); return idx; }
          }
          for (const a of aliases) {
            const idx = normHeaders.findIndex((h, i) => !usedCols.includes(i) && h && h.includes(a));
            if (idx !== -1) { usedCols.push(idx); return idx; }
          }
          return -1;
        };

        // Match columns precisely to avoid false positives
        const colCurrency = getCol(['currency', 'валюта', 'curr']);
        // Remove generic 'код' from country as it can match 'штрих-код' or 'isrc' and shift the country column
        const colCountry = getCol(['country', 'страна', 'territory', 'территория', 'регион', 'region', 'geo', 'гео', 'государство', 'терр']);
        const colPlatform = getCol(['platform', 'платформа', 'store', 'магазин', 'dsp', 'service', 'сервис', 'partner', 'площадка', 'контрагент', 'источник', 'провайдер', 'provider', 'витрина', 'магазины', 'ресурс']);
        const colStreams = getCol(['количествоскачиванийпрослушиваний', 'скачиванияпрослушивания', 'downloadsstreams', 'количествопрослушиваний', 'колвопрослушиваний', 'streams', 'stream', 'прослушивания', 'прослушиван', 'стрим', 'стримов', 'quantity', 'count', 'sales', 'unit', 'qty', 'количество', 'колво', 'view', 'просмотр', 'единиц', 'продажи', 'показы', 'трафик', 'totalquantity', 'total']);
        
        const colMaster = getCol(['смежныеправа', 'смежн', 'master', 'фонограм', 'neighboring']);
        const colPub = getCol(['авторскиеправа', 'авторск', 'publishing', 'mechanical', 'composition']);
        
        const colRoyalty = getCol(['netrevenue', 'payable', 'выплатакперечислению', 'итоговаясумма', 'royalty', 'роялти', 'доход', 'revenue', 'earning', 'прибыль', 'сумма', 'total', 'amount', 'net', 'выплата', 'вознаграждение', 'начислено', 'суммадохода', 'суммавыплаты', 'руб']);
        
        const colArtist = getCol(['mainartist', 'displayartist', 'primaryartist', 'artistname', 'artist', 'имяартиста', 'артист', 'исполнитель', 'creator', 'band', 'author', 'автор', 'клиент', 'названиегруппы']);
        const colRelease = getCol(['releasetitle', 'albumtitle', 'названиерелиза', 'названиеальбома', 'release', 'релиз', 'album', 'альбом', 'project', 'продукт', 'upc', 'каталог', 'catalog', 'названиепродукта', 'сборник', 'релиза', 'наименованиерелиза']);
        const colTrack = getCol(['tracktitle', 'songtitle', 'названиетрека', 'названиепесни', 'track', 'трек', 'song', 'песня', 'title', 'название', 'asset', 'произведение', 'фонограмма', 'isrc', 'композиция', 'оригинальноеназвание', 'трека', 'наимениованиетрека', 'наименование']);
        const colPeriod = getCol(['period', 'период', 'month', 'месяц', 'quarter', 'квартал', 'date', 'дата']);

        const CHUNK_SIZE = 25000;
        const blockRows = aoa.slice(block.startIdx + 1, block.endIdx + 1);

        for (let i = 0; i < blockRows.length; i += CHUNK_SIZE) {
          setLoadingMsg(t(`Processing block rows ${i.toLocaleString()} of ${blockRows.length.toLocaleString()}...`, `Обработка строк блока: ${i.toLocaleString()} из ${blockRows.length.toLocaleString()}...`));
          await new Promise(r => setTimeout(r, 0));

          const chunk = blockRows.slice(i, i + CHUNK_SIZE);
          for (let rIdx = 0; rIdx < chunk.length; rIdx++) {
            const row = chunk[rIdx];
            const actualRowNumber = block.startIdx + 1 + i + rIdx + 1; // 1-indexed

            if (!row || row.length === 0) continue;
            
            const firstColStr = String(row[0] || '').trim().toLowerCase();
            if (/^(итого|total|grand total|итог|всего|sum|общий доход|общая сумма|аванс|доля|к доплате|баланс|balance)/.test(firstColStr)) continue;

            const rawMaster = colMaster >= 0 ? parseNumber(row[colMaster]) : 0;
            const rawPub = colPub >= 0 ? parseNumber(row[colPub]) : 0;
            const rawGen = colRoyalty >= 0 ? parseNumber(row[colRoyalty]) : 0;
            
            let finalRoyalty = rawGen;
            if (rawMaster > 0 || rawPub > 0) finalRoyalty = Math.max(rawGen, rawMaster + rawPub);

            let artistVal = colArtist >= 0 && row[colArtist] ? String(row[colArtist]).trim() : '';
            // Remove legal names inside parentheses (often used by Zvonko/NDA), even if truncated
            artistVal = artistVal.replace(/\s*\([^)]*\)/g, '').replace(/\s*\([^)]*$/, '').trim();
                        let releaseVal = colRelease >= 0 && row[colRelease] ? String(row[colRelease]).trim() : '';
            let trackVal = colTrack >= 0 && row[colTrack] ? String(row[colTrack]).trim() : '';
            
            // Fallbacks if one is missing
            if (!releaseVal && trackVal) releaseVal = trackVal;
            if (!trackVal && releaseVal) trackVal = releaseVal;
            const periodRaw = colPeriod >= 0 && row[colPeriod] ? String(row[colPeriod]).trim() : '';
            
            if (!artistVal && !releaseVal && !trackVal) continue;

            // Handle truncated artists
            let isTruncated = false;
            let openParens = (artistVal.match(/\(/g) || []).length;
            let closeParens = (artistVal.match(/\)/g) || []).length;
            if (openParens > closeParens) isTruncated = true;

            const artistId = artistVal.replace(/^\uFEFF/, '').trim().toLowerCase();
            const period = normalizePeriod(periodRaw);

            if (periodRaw && !period) {
                warnings.push({level: 'warning', message: `Unrecognized period format: "${periodRaw}"`, rowNumbers: [actualRowNumber]});
            }
            if (isTruncated) {
                warnings.push({level: 'warning', message: `Artist name has unbalanced parentheses (might be truncated): "${artistVal}"`, rowNumbers: [actualRowNumber]});
            }
            if (!artistVal) {
                warnings.push({level: 'warning', message: `Missing artist name`, rowNumbers: [actualRowNumber]});
            }

            parsed.push({
              artist: artistVal || '—',
              artistId: artistId || '—',
              release: releaseVal || '—',
              track: trackVal || '—',
              streams: colStreams >= 0 ? parseNumber(row[colStreams]) : 0,
              royalty: finalRoyalty,
              royaltyMaster: rawMaster,
              royaltyPub: rawPub,
              currency: colCurrency >= 0 && row[colCurrency] ? String(row[colCurrency]).trim() : 'RUB',
              country: colCountry >= 0 && row[colCountry] ? String(row[colCountry]).trim() : '—',
              platform: colPlatform >= 0 && row[colPlatform] ? String(row[colPlatform]).trim() : '—',
              rightsType: block.rightsType,
              periodRaw,
              period,
              truncated: isTruncated
            });
          }
        }
      }

      const uniqueCurrencies = Array.from(new Set(parsed.map(r => r.currency)));
      setExchangeRates(prev => {
        const newRates = { ...prev };
        uniqueCurrencies.forEach(c => {
          if (newRates[c] === undefined) {
            newRates[c] = 1;
          }
        });
        return newRates;
      });
      
      if (uniqueCurrencies.length > 0 && !uniqueCurrencies.includes(targetCurrency)) {
          setTargetCurrency(uniqueCurrencies[0]);
      }

      // Group warnings by message to avoid thousands of individual warnings
      const groupedWarnings: Record<string, {level: 'error'|'warning', message: string, rowNumbers: number[]}> = {};
      warnings.forEach(w => {
          if (!groupedWarnings[w.message]) {
              groupedWarnings[w.message] = { level: w.level, message: w.message, rowNumbers: [] };
          }
          if (w.rowNumbers && groupedWarnings[w.message].rowNumbers.length < 5) {
              groupedWarnings[w.message].rowNumbers.push(...w.rowNumbers);
          }
      });
      setParseWarnings(Object.values(groupedWarnings));
      
      let summaryText = ``;
      if (blocks.length > 1) {
          summaryText = `Найдено ${blocks.length} раздела(ов): Авторские права (${authorsCount}), Смежные права (${relatedCount}), Неизвестно (${unknownCount})`;
      }
      setParseSummary(summaryText);

      setRawData(parsed);
      setActiveView('overview');
      setCurrentPage(1);
    } catch (err) {
      console.error(err);
      alert(t("Failed to parse file. Please upload a valid Excel or CSV file.", "Не удалось обработать файл. Загрузите корректный Excel или CSV файл."));
    } finally {
      setIsLoading(false);
      setLoadingMsg("");
    }
  };


  const [calculatedData, setCalculatedData] = useState<{
    totalRoyalty: number;
    totalArtistPayout: number;
    totalLabelRevenue: number;
    totalStreams: number;
    artistStats: Record<string, { name: string, streams: number, royalty: number, payout: number }>;
    artistCount: number;
  }>({
    totalRoyalty: 0,
    totalArtistPayout: 0,
    totalLabelRevenue: 0,
    totalStreams: 0,
    artistStats: {},
    artistCount: 0
  });
  const [isCalculating, setIsCalculating] = useState(false);

  React.useEffect(() => {
    if (rawData.length === 0) return;
    setIsCalculating(true);

    const timer = setTimeout(() => {
      let totalRoyalty = 0;
      let totalArtistPayout = 0;
      let totalLabelRevenue = 0;
      let totalStreams = 0;
      const artistStats: Record<string, { name: string, streams: number, royalty: number, payout: number }> = {};

      // Helper to generate normalized keys
      const norm = (s: string) => (s || '').trim().toLowerCase();

      rawData.forEach(row => {
        const rate = exchangeRates[row.currency] || 1;
        const convertedRoyalty = row.royalty * rate;

        totalRoyalty += convertedRoyalty;
        totalStreams += row.streams;

        const aId = row.artistId;
        const rKey = norm(row.release);
        const tKey = norm(row.track);

        const trackRule = rules[`track:${aId}:${rKey}:${tKey}`];
        const releaseRule = rules[`release:${aId}:${rKey}`];
        const artistRule = rules[`artist:${aId}`];

        const rule = trackRule || releaseRule || artistRule;
        const artistSharePct = rule ? rule.artistShare : (100 - (Number(globalLabelShare) || 0));
        
        const artistCut = convertedRoyalty * (artistSharePct / 100);
        const labelCut = convertedRoyalty - artistCut;

        totalArtistPayout += artistCut;
        totalLabelRevenue += labelCut;

        if (!artistStats[aId]) {
          artistStats[aId] = { name: row.artist, streams: 0, royalty: 0, payout: 0 };
        }
        artistStats[aId].streams += row.streams;
        artistStats[aId].royalty += convertedRoyalty;
        artistStats[aId].payout += artistCut;
      });

      setCalculatedData({
        totalRoyalty,
        totalArtistPayout,
        totalLabelRevenue,
        totalStreams,
        artistStats,
        artistCount: Object.keys(artistStats).length
      });
      setIsCalculating(false);
    }, 50);

    return () => clearTimeout(timer);
  }, [rawData, rules, globalLabelShare, exchangeRates]);

  const topArtists = useMemo(() => {
    return Object.entries(calculatedData.artistStats).map(([id, stats]: [string, any]) => ({ id, ...stats }))
      .sort((a, b) => b.royalty - a.royalty)
      .slice(0, 10);
  }, [calculatedData]);

  const filteredArtists = useMemo(() => {
    let searchTerms: string[] = [];
    if (filterText) {
      searchTerms = filterText.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    }
    
    return Object.entries(calculatedData.artistStats).map(([id, stats]: [string, any]) => ({ id, ...stats }))
      .filter(a => {
        const matchesSelection = selectedFilterArtists.length > 0 && selectedFilterArtists.includes(a.name);
        const nameLower = a.name.toLowerCase();
        const matchesText = searchTerms.length > 0 && searchTerms.some(term => nameLower.includes(term));
        
        if (selectedFilterArtists.length === 0 && searchTerms.length === 0) return true;
        
        return matchesSelection || matchesText;
      })
      .sort((a, b) => b.royalty - a.royalty);
  }, [calculatedData, filterText, selectedFilterArtists]);

  // Derive unique artist names for the dropdown
  const allArtistNames = useMemo(() => {
    const rawFilter = filterText.trim().toLowerCase();
    const isComma = rawFilter.includes(',');
    return Object.values(calculatedData.artistStats)
      .map((stats: any) => stats.name)
      .filter((name: string) => {
          if (isComma || !rawFilter) return true;
          return name.toLowerCase().includes(rawFilter);
      })
      .sort((a, b) => a.localeCompare(b));
  }, [calculatedData, filterText]);

  const pieData = [
    { name: t("Artist Payout", "Выплаты артистам"), value: calculatedData.totalArtistPayout, color: '#3b82f6' },
    { name: t("Label Revenue", "Доход лейбла"), value: calculatedData.totalLabelRevenue, color: '#10b981' }
  ];

  
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [mobilePdfTab, setMobilePdfTab] = useState<'settings' | 'preview'>('settings');
  const [pdfReportType, setPdfReportType] = useState<'full' | 'artist' | 'payout' | 'filtered'>('artist');
  const [pdfDetailedMaster, setPdfDetailedMaster] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [pdfTargetArtist, setPdfTargetArtist] = useState<any>(null);
  
  const [reportFormat, setReportFormat] = useState<'general' | 'rightsholder'>('rightsholder');
  const [includeHolderDetails, setIncludeHolderDetails] = useState(false);
  const [holderDetails, setHolderDetails] = useState({
    fullName: "",
    phone: "",
    passport: "",
    inn: "",
    bankDetails: ""
  });
  
  const [pdfLang, setPdfLang] = useState<'ru' | 'en'>(lang);
  const [pdfSettings, setPdfSettings] = useState({
    documentTitle: "ROYALTY REPORT",
    reportPeriod: "All Periods",
    reportDate: new Date().toLocaleDateString('ru-RU'),
    distributorName: "NOVA Distribution",
    distributorType: "Цифровой дистрибьютор",
    distributorWebsite: "novadistribution.com",
    distributorEmail: "info@novadistribution.com",
    distributorPhone: "+7 (495) 123-45-67",
    rightsHolderSignature: null as string | null,
    distributorSignature: null as string | null
  });
  const [isExporting, setIsExporting] = useState(false);
  const [tgToken, setTgToken] = useState(() => {
    const saved = localStorage.getItem('tgToken') || '';
    if (!saved || saved.includes('AhZV1M')) {
      return '8828948443:AAHSY6sBNh0isvlNvM-jt500CWYXTyjxHO0';
    }
    return saved;
  });
  const [tgContacts, setTgContacts] = useState<{id: string, label: string, enabled: boolean}[]>(() => {
    try { return JSON.parse(localStorage.getItem('tgContacts') || '[]'); }
    catch { return []; }
  });
  const tgContactsRef = useRef(tgContacts);
  useEffect(() => { tgContactsRef.current = tgContacts; }, [tgContacts]);
  const [newContactId, setNewContactId] = useState('');
  const [newContactLabel, setNewContactLabel] = useState('');

  const updateTgContacts = (newContacts: {id: string, label: string, enabled: boolean}[]) => {
    setTgContacts(newContacts);
    localStorage.setItem('tgContacts', JSON.stringify(newContacts));
    window.dispatchEvent(new CustomEvent('tg-config-update'));
  };
  const [isSendingTg, setIsSendingTg] = useState(false);
  const [tgStatus, setTgStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [tgMessage, setTgMessage] = useState(() => localStorage.getItem('tgMessage') || '');

  const [tgSendType, setTgSendType] = useState<'pdf' | 'text' | 'photo' | 'video' | 'sticker'>(() => (localStorage.getItem('tgSendType') as any) || 'pdf');
  const [tgManualMode, setTgManualMode] = useState(false);
  const [tgManualId, setTgManualId] = useState('');
  const [tgAttachmentUrl, setTgAttachmentUrl] = useState(() => localStorage.getItem('tgAttachmentUrl') || '');
  const [tgStickerPack, setTgStickerPack] = useState('');
  const [tgStickers, setTgStickers] = useState<any[]>([]);
  const [tgIsLoadingStickers, setTgIsLoadingStickers] = useState(false);
  // tgLogs moved to parent

  const updateTgLogs = (updateFn: any) => {
    if (onTgLogsUpdate) {
       onTgLogsUpdate(updateFn);
    }
  };




  const loadStickers = async () => {
    const tokens = tgToken.split(/[\s,]+/).filter(t => t.trim() !== '');
    if (!tokens.length) {
      alert(t("Please enter a Bot Token first", "Пожалуйста, введите токен бота сначала"));
      return;
    }
    let packName = tgStickerPack.trim();
    if (packName.includes('/addstickers/')) {
      packName = packName.split('/addstickers/')[1].split('/')[0].split('?')[0];
    }
    if (!packName) return;
    
    setTgIsLoadingStickers(true);
    setTgStickers([]);
    try {
      let data: any = null;
      try {
        const proxyRes = await fetch(`/api/tg/stickers-proxy?token=${encodeURIComponent(tokens[0])}&packName=${encodeURIComponent(packName)}`);
        if (proxyRes.ok) {
          data = await proxyRes.json();
        }
      } catch (e) {}

      if (!data || !data.ok) {
        const res = await fetch(`https://api.telegram.org/bot${tokens[0]}/getStickerSet?name=${packName}`);
        data = await res.json();
      }

      if (!data || !data.ok) throw new Error(data?.description || 'Failed to load sticker pack');
      
      const rawStickers = (data.result?.stickers || []).slice(0, 50);
      const loaded = [];
      for (const s of rawStickers) {
         const fileId = s.thumbnail?.file_id || s.file_id;
         try {
           const fileProxyRes = await fetch(`/api/tg/file-proxy?token=${encodeURIComponent(tokens[0])}&fileId=${encodeURIComponent(fileId)}`).catch(() => null);
           if (fileProxyRes && fileProxyRes.ok) {
             const fileData = await fileProxyRes.json().catch(() => null);
             if (fileData && fileData.ok && fileData.full_url) {
               loaded.push({
                  file_id: s.file_id,
                  url: fileData.full_url,
                  is_animated: s.is_animated,
                  is_video: s.is_video
               });
               continue;
             }
           }
         } catch(e) {}
         
         const fileRes = await fetch(`https://api.telegram.org/bot${tokens[0]}/getFile?file_id=${fileId}`).catch(() => null);
         if (fileRes && fileRes.ok) {
           const fileData = await fileRes.json().catch(() => null);
           if (fileData && fileData.ok) {
              loaded.push({
                 file_id: s.file_id,
                 url: `https://api.telegram.org/file/bot${tokens[0]}/${fileData.result.file_path}`,
                 is_animated: s.is_animated,
                 is_video: s.is_video
              });
           }
         }
      }
      setTgStickers(loaded);
    } catch(err: any) {
      alert(err.message || 'Error loading stickers');
    } finally {
      setTgIsLoadingStickers(false);
    }
  };




  const generateArtistPdf = async (artist: any) => {
    setPdfTargetArtist(artist);
    
    const rule = rules[`artist:${artist.id}`];
    const artistRows = rawData.filter(r => (r.artistId || '').trim().toLowerCase() === artist.id || (r.artist || '').trim().toLowerCase() === artist.id);
    const rowPeriod = artistRows[0]?.period;
    const currentPeriod = rowPeriod ? `${rowPeriod.startYear}.${rowPeriod.startMonth}` : (pdfSettings.reportPeriod || "2026");
    
    setPdfSettings(prev => ({
      ...prev,
      documentTitle: pdfLang === 'ru' ? "ОТЧЁТ РОЯЛТИ" : "ROYALTY REPORT",
      reportPeriod: currentPeriod
    }));
    
    setIsPdfModalOpen(true);
  };

  const openGlobalPdfModal = () => {
    setPdfTargetArtist(null);
    setPdfSettings(prev => ({
      ...prev,
      documentTitle: pdfLang === 'ru' ? "ОТЧЁТ РОЯЛТИ (МАСТЕР)" : "MASTER ROYALTY REPORT"
    }));
    setIsPdfModalOpen(true);
  };

  const getPdfDataParams = () => {
    if (pdfTargetArtist) {
      const artist = pdfTargetArtist;
      const rule = rules[`artist:${artist.id}`];
      const artistSharePercent = rule ? rule.artistShare : (100 - (Number(globalLabelShare) || 0));
      const artistRows = rawData.filter(r => (r.artistId || '').trim().toLowerCase() === artist.id || (r.artist || '').trim().toLowerCase() === artist.id);
      
            const platformsMap: Record<string, { streams: number, gross: number, platform: string, release: string, track: string }> = {};
      artistRows.forEach(r => {
         const p = r.platform || '—';
         const t = r.track || '—';
         const rel = r.release || '—';
         const key = `${rel}|${t}|${p}`;
         if (!platformsMap[key]) platformsMap[key] = { streams: 0, gross: 0, platform: p, release: rel, track: t };
         platformsMap[key].streams += r.streams;
         const rate = exchangeRates[r.currency] || 1;
         platformsMap[key].gross += (r.royalty * rate);
      });
      
      const platforms = Object.entries(platformsMap).map(([key, data]) => {
         const commissionAmount = data.gross * ((100 - artistSharePercent) / 100);
         const netRevenue = data.gross - commissionAmount;
         return {
           name: data.platform,
           release: data.release,
           track: data.track,
           platform: data.platform,
           streams: data.streams,
           grossRevenue: data.gross,
           commissionAmount,
           netRevenue
         };
      }).sort((a, b) => b.grossRevenue - a.grossRevenue);

      return {
        documentTitle: pdfSettings.documentTitle,
        reportNumber: "ND-" + new Date().getFullYear() + "-" + Math.floor(Math.random()*10000),
        reportPeriod: pdfSettings.reportPeriod,
        reportDate: pdfSettings.reportDate,
        currency: targetCurrency,
        rightsHolderSignature: pdfSettings.rightsHolderSignature,
        distributorSignature: pdfSettings.distributorSignature,
        rightsHolder: {
          name: artist.name,
          type: "Исполнитель",
          id: artist.id,
          country: artistRows[0]?.country || "—",
          email: "—"
        },
        distributor: {
          name: pdfSettings.distributorName,
          type: pdfSettings.distributorType,
          website: pdfSettings.distributorWebsite,
          email: pdfSettings.distributorEmail,
          phone: pdfSettings.distributorPhone
        },
        platforms,
        totals: {
          streams: artist.streams,
          gross: artist.royalty,
          commission: artist.royalty - artist.payout,
          net: artist.payout
        },
        note: rule?.note,
        reason: rule?.reason,
        artistSharePercent,
        reportFormat,
        includeHolderDetails,
        holderDetails
      };
        } else {
      let sourceArtists = Object.entries(calculatedData.artistStats).map(([id, stats]: [string, any]) => ({ id, ...stats })).sort((a, b) => b.royalty - a.royalty);
      let targetList = sourceArtists;
      if (pdfReportType === 'artist') targetList = topArtists;
      else if (pdfReportType === 'filtered') targetList = filteredArtists;

      let platforms: any[] = [];
      let totalStreams = 0;
      let totalGross = 0;
      let totalCommission = 0;
      let totalNet = 0;

      if (pdfDetailedMaster) {
         const targetArtistIds = new Set(targetList.map(a => a.id));
         const matchingRows = rawData.filter(r => {
             const aid1 = (r.artistId || '').trim().toLowerCase();
             const aid2 = (r.artist || '').trim().toLowerCase();
             return targetArtistIds.has(aid1) || targetArtistIds.has(aid2);
         });

         const platformsMap: Record<string, { streams: number, gross: number, artist: string, platform: string, release: string, track: string }> = {};
         matchingRows.forEach(r => {
             const a = r.artist || '—';
             const p = r.platform || '—';
             const t = r.track || '—';
             const rel = r.release || '—';
             const key = `${a}|${rel}|${t}|${p}`;
             if (!platformsMap[key]) platformsMap[key] = { streams: 0, gross: 0, artist: a, platform: p, release: rel, track: t };
             platformsMap[key].streams += r.streams;
             const rate = exchangeRates[r.currency] || 1;
             platformsMap[key].gross += (r.royalty * rate);
         });

         platforms = Object.values(platformsMap).map((data) => {
             const artistIdStr = data.artist.trim().toLowerCase();
             const rule = rules[`artist:${artistIdStr}`];
             const artistSharePercent = rule ? rule.artistShare : (100 - (Number(globalLabelShare) || 0));
             const commissionAmount = data.gross * ((100 - artistSharePercent) / 100);
             const netRevenue = data.gross - commissionAmount;

             totalStreams += data.streams;
             totalGross += data.gross;
             totalCommission += commissionAmount;
             totalNet += netRevenue;

             return {
               artist: data.artist,
               name: data.platform,
               release: data.release,
               track: data.track,
               platform: data.platform,
               streams: data.streams,
               grossRevenue: data.gross,
               commissionAmount,
               netRevenue
             };
         }).sort((a, b) => b.grossRevenue - a.grossRevenue);
      } else {
         platforms = targetList.map((a: any) => {
           const commissionAmount = a.royalty - a.payout;
           totalStreams += a.streams;
           totalGross += a.royalty;
           totalCommission += commissionAmount;
           totalNet += a.payout;

           return {
             name: a.name,
             streams: a.streams,
             grossRevenue: a.royalty,
             commissionAmount,
             netRevenue: a.payout
           };
         });
      }

      return {
        documentTitle: pdfSettings.documentTitle || t("ОТЧЁТ РОЯЛТИ", "ROYALTY REPORT"),
        reportNumber: "ND-" + new Date().getFullYear() + "-" + Math.floor(Math.random()*10000),
        reportPeriod: pdfSettings.reportPeriod || "All Periods",
        reportDate: pdfSettings.reportDate || new Date().toLocaleDateString('ru-RU'),
        currency: targetCurrency,
        rightsHolderSignature: pdfSettings.rightsHolderSignature,
        distributorSignature: pdfSettings.distributorSignature,
        rightsHolder: {
          name: "Все артисты / Каталог",
          type: "Каталог",
          id: "ALL",
          country: "—",
          email: "—"
        },
        distributor: {
          name: pdfSettings.distributorName,
          type: pdfSettings.distributorType,
          website: pdfSettings.distributorWebsite,
          email: pdfSettings.distributorEmail,
          phone: pdfSettings.distributorPhone
        },
        platforms,
        totals: {
          streams: totalStreams,
          gross: totalGross,
          commission: totalCommission,
          net: totalNet
        },
        note: null,
        reason: null,
        artistSharePercent: 0,
        reportFormat,
        includeHolderDetails,
        holderDetails,
        detailedMaster: pdfDetailedMaster
      };
    }
  };

  React.useEffect(() => {
    if (!isPdfModalOpen) return;
    const timer = setTimeout(async () => {
      try {
        const { generateRoyaltyStatement } = await import('../lib/pdfGenerator');
        const data = getPdfDataParams();
        const url = await generateRoyaltyStatement(data, !pdfTargetArtist, true, pdfLang);
        setPreviewUrl(url as string);
      } catch (err) {
        console.error("Preview err", err);
      }
    }, 600);
    return () => clearTimeout(timer);
  }, [isPdfModalOpen, pdfSettings, pdfReportType, pdfDetailedMaster, pdfTargetArtist, calculatedData, targetCurrency, globalNote, globalLabelShare, topArtists, filteredArtists, rules, pdfLang]);

  
  const sendPdfToTelegram = async () => {
    if (!tgToken) {
       alert(t("Please enter Bot Tokens", "Пожалуйста, введите токены ботов"));
       return;
    }
    if (!tgManualMode && tgContacts.filter(c => c.enabled).length === 0) {
       alert(t("Please enable at least one Chat ID", "Пожалуйста, выберите хотя бы один Chat ID"));
       return;
    }
    if (tgManualMode && !tgManualId.trim()) {
       alert(t("Please enter a target ID", "Пожалуйста, введите целевой ID"));
       return;
    }
    
    setIsSendingTg(true);
    setTgStatus('idle');
    try {
      const tokens = tgToken.split(/[\s,]+/).filter(t => t.trim() !== '');
      const chatIds = tgManualMode ? [tgManualId.trim()] : tgContacts.filter(c => c.enabled).map(c => c.id);
      
      if (tokens.length === 0) throw new Error('No Bot Tokens');
      if (chatIds.length === 0) throw new Error('No Chat IDs');
      if (tgSendType !== 'pdf' && tgSendType !== 'text' && !tgAttachmentUrl) {
         alert(t("Please provide an attachment or select a sticker", "Пожалуйста, выберите стикер или укажите файл"));
         setIsSendingTg(false);
         setTgStatus('idle');
         return;
      }

      let pdfBlob: any = null;
      let filename = '';
      let pdfBase64 = '';

      if (tgSendType === 'pdf') {
        const data = getPdfDataParams();
        const { generateRoyaltyStatement } = await import('../lib/pdfGenerator');
        pdfBlob = await generateRoyaltyStatement(data, !pdfTargetArtist, 'blob', pdfLang);
        filename = `Royalty_Statement_${(data.rightsHolder?.name || 'Report').replace(/[^a-zA-Z0-9а-яА-Я]/g, '_')}.pdf`;
        
        if (pdfBlob) {
          try {
            pdfBase64 = await new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.onloadend = () => {
                const res = reader.result as string;
                const b64 = res.includes(',') ? res.split(',')[1] : res;
                resolve(b64);
              };
              reader.onerror = reject;
              reader.readAsDataURL(pdfBlob);
            });
          } catch (e) {
            console.error("Blob to base64 error", e);
          }
        }
      }
      
      let successCount = 0;
      const errorReasons: string[] = [];
      
      const logs = chatIds.map(id => ({
        chatId: id,
        label: tgManualMode ? id : (tgContacts.find(c => c.id === id)?.label || id),
        status: 'queued' as const
      }));
      updateTgLogs(logs);

      for (const token of tokens) {
        for (const chatId of chatIds) {
          const formData = new FormData();
          formData.append('chat_id', chatId);
          
          let endpoint = 'sendDocument';
          
          if (tgSendType === 'sticker' && tgMessage && tgMessage.trim() !== '') {
             const textData = new FormData();
             textData.append('chat_id', chatId);
             textData.append('text', tgMessage);
             try {
               await fetch(`/api/tg/send-proxy`, {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ token, chatId, text: tgMessage, endpoint: 'sendMessage' })
               }).catch(() => null);
             } catch(e) {}
             await new Promise(r => setTimeout(r, 600));
          }
          
          if (tgSendType === 'pdf') {
            formData.append('document', pdfBlob, filename);
            if (tgMessage && tgMessage.trim() !== '') {
              formData.append('caption', tgMessage);
            }
          } else if (tgSendType === 'text') {
            endpoint = 'sendMessage';
            formData.append('text', tgMessage && tgMessage.trim() !== '' ? tgMessage : '...');
          } else {
            endpoint = 'send' + tgSendType.charAt(0).toUpperCase() + tgSendType.slice(1);
            formData.append(tgSendType, tgAttachmentUrl);
            if (tgSendType !== 'sticker' && tgMessage && tgMessage.trim() !== '') {
              formData.append('caption', tgMessage);
            }
          }
          
          try {
            let attempt = 0;
            let success = false;
            let lastErrDesc = '';

            while (attempt < 3 && !success) {
              let tgData: any = null;

              // 1. First attempt: via server proxy (bypasses browser CORS & network blocks)
              try {
                const proxyRes = await fetch('/api/tg/send-proxy', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    token,
                    chatId,
                    endpoint,
                    sendType: tgSendType,
                    text: tgMessage && tgMessage.trim() !== '' ? tgMessage : '...',
                    caption: tgMessage || '',
                    fileBase64: pdfBase64 || undefined,
                    fileName: filename || undefined,
                    fileUrl: tgAttachmentUrl || undefined
                  })
                });
                tgData = await proxyRes.json().catch(() => null);
              } catch (e: any) {
                lastErrDesc = e?.message || 'Proxy network error';
              }

              // 2. Fallback attempt: direct Telegram API
              if (!tgData) {
                try {
                  const directRes = await fetch(`https://api.telegram.org/bot${token}/${endpoint}`, {
                    method: 'POST',
                    body: formData
                  });
                  tgData = await directRes.json().catch(() => null);
                } catch (directErr: any) {
                  lastErrDesc = directErr?.message || 'Direct network error';
                }
              }

              if (tgData && tgData.ok) {
                successCount++;
                updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'sent' } : l));
                success = true;
                await new Promise(r => setTimeout(r, 800)); // Respect Telegram rate limits
              } else {
                const desc = tgData?.description || lastErrDesc || 'Unknown error';
                lastErrDesc = desc;

                if (tgData?.error_code === 429) {
                  const retryAfter = tgData?.parameters?.retry_after || 5;
                  await new Promise(r => setTimeout(r, retryAfter * 1000 + 500));
                  attempt++;
                } else {
                  // Human-readable Telegram error descriptions
                  let humanError = desc;
                  if (desc.includes('chat not found')) {
                    humanError = 'Чат не найден: откройте бота в TG и нажмите /start';
                  } else if (desc.includes('bot was blocked')) {
                    humanError = 'Бот заблокирован пользователем';
                  } else if (desc.includes('Unauthorized') || desc.includes('Not Found')) {
                    humanError = 'Неверный токен бота (Unauthorized)';
                  } else if (desc.includes('user is deactivated')) {
                    humanError = 'Аккаунт Telegram удалён';
                  }

                  errorReasons.push(`${chatId}: ${humanError}`);
                  updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error', errorMessage: humanError } : l));
                  await new Promise(r => setTimeout(r, 600));
                  break;
                }
              }
            }
            if (!success) {
              updateTgLogs(prev => prev.map(l => l.chatId === chatId && l.status === 'queued' ? { ...l, status: 'error', errorMessage: lastErrDesc || 'Rate limit exceeded (429)' } : l));
            }
          } catch(err: any) {
            const errM = err?.message || 'Error';
            errorReasons.push(`${chatId}: ${errM}`);
            updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error', errorMessage: errM } : l));
          }
        }
      }
      
      if (successCount === 0 && chatIds.length > 0) {
        const uniqueReasons = Array.from(new Set(errorReasons.filter(Boolean)));
        const reasonText = uniqueReasons.length > 0 ? `:\n${uniqueReasons.join('\n')}` : '';
        throw new Error(`${t("Failed to send report to Telegram", "Не удалось отправить отчёт в Telegram")}${reasonText}`);
      }
      
      setTgStatus('success');
      setTimeout(() => setTgStatus('idle'), 3000);
      
    } catch (e: any) {
      console.error(e);
      setTgStatus('error');
      alert(e?.message || t("Failed to send report to Telegram", "Не удалось отправить отчёт в Telegram"));
      setTimeout(() => setTgStatus('idle'), 3000);
    } finally {
      setIsSendingTg(false);
    }
  };

  const performPdfExport = async () => {
    setIsExporting(true);
    await new Promise(r => setTimeout(r, 50));
    try {
      const { generateRoyaltyStatement } = await import('../lib/pdfGenerator');
      const data = getPdfDataParams();
      await generateRoyaltyStatement(data, !pdfTargetArtist, false, pdfLang);
      setIsPdfModalOpen(false);
    } catch (err) {
      console.error(err);
      alert(t("Failed to generate PDF.", "Не удалось сгенерировать PDF."));
    } finally {
      setIsExporting(false);
    }
  };

    
  const openRuleModal = (artistId: string, _artistName: string) => {
    setSelectedArtistId(artistId);
    setTempRule(rules[`artist:${artistId}`] || { level: 'artist', artistId, artistShare: 100 - (Number(globalLabelShare) || 0), note: '', reason: '' });
    setIsRuleModalOpen(true);
  };

  const applyRule = () => {
    if (selectedArtistId) {
      const key = `artist:${selectedArtistId}`;
      setRules(prev => ({ ...prev, [key]: tempRule }));
    }
    setIsRuleModalOpen(false);
  };
const exportXLSX = async () => {
    setIsExporting(true);
    await new Promise(r => setTimeout(r, 50));
    try {
      const rows = Object.entries(calculatedData.artistStats).map(([id, stats]: [string, any]) => ({
        "Артист": stats.name,
        "Прослушивания": stats.streams,
        "Общий доход": Number(stats.royalty.toFixed(2)),
        "Комиссия": Number((stats.royalty - stats.payout).toFixed(2)),
        "К выплате": Number(stats.payout.toFixed(2))
      })).sort((a, b) => b["К выплате"] - a["К выплате"]);

      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Выплаты");
      XLSX.writeFile(wb, `Royalty_Payouts_${new Date().toISOString().split('T')[0]}.xlsx`);
    } catch (e) {
      console.error(e);
    } finally {
      setIsExporting(false);
    }
  };

  if (rawData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 px-4 text-center">

        <div className="w-24 h-24 mb-6 rounded-3xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-500 shadow-inner">
          <UploadCloud className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-3">
          {t("Royalty Parser System", "Система Royalty Парсер")}
        </h2>
        <p className="text-zinc-500 dark:text-zinc-400 max-w-md mx-auto mb-8 leading-relaxed">
          {t("Upload your raw royalty reports (XLSX, CSV) to automatically parse, filter, assign shares, and generate payouts.", "Загрузите исходный отчёт по роялти (XLSX, CSV), чтобы автоматически рассчитать доли артистов, применить правила и получить готовые выплаты.")}
        </p>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="bg-black hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-black font-semibold py-3 px-8 rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95 flex items-center gap-3"
          disabled={isLoading}
        >
          {isLoading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
          {isLoading ? (loadingMsg || t("Processing...", "Обработка...")) : t("Upload Report", "Загрузить отчёт")}
        </button>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".csv, .xlsx, .xls"
          onChange={handleFileUpload}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">

      
      {parseSummary && (
        <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 p-4 rounded-xl text-sm flex items-center justify-between">
            <span><strong>{t("Parse Summary", "Результат парсинга")}:</strong> {parseSummary}</span>
        </div>
      )}

      {parseWarnings.length > 0 && (
        <details className="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-900/30 rounded-xl overflow-hidden group">
          <summary className="p-4 cursor-pointer text-amber-800 dark:text-amber-500 font-semibold flex items-center gap-2 select-none">
            <span className="text-lg">⚠</span> {parseWarnings.length} {t("warnings during import (click to expand)", "предупреждений при импорте (нажмите чтобы развернуть)")}
          </summary>
          <div className="px-4 pb-4 max-h-64 overflow-y-auto">
            <ul className="list-disc pl-5 space-y-1 text-sm text-amber-700 dark:text-amber-400">
              {parseWarnings.map((w, i) => (
                <li key={i}>
                  {w.message} {w.rowNumbers && w.rowNumbers.length > 0 && <span className="opacity-75"> (rows: {w.rowNumbers.join(', ')}{w.rowNumbers.length === 5 ? '...' : ''})</span>}
                </li>
              ))}
            </ul>
          </div>
        </details>
      )}

      {isPdfModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#1c1c1e] w-full h-full sm:w-[95vw] sm:h-[95vh] sm:rounded-3xl flex flex-col shadow-2xl overflow-hidden">
            <div className="flex justify-between items-center p-4 border-b border-zinc-200 dark:border-zinc-800 shrink-0">
              <h3 className="text-xl font-bold">{t("Export PDF", "Экспорт PDF")}</h3>
              <button onClick={() => setIsPdfModalOpen(false)} className="p-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-white/10 dark:hover:bg-white/20 rounded-full transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Mobile Tabs */}
            <div className="flex lg:hidden border-b border-zinc-200 dark:border-zinc-800 shrink-0">
              <button 
                onClick={() => setMobilePdfTab('settings')}
                className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${mobilePdfTab === 'settings' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
              >{t("Settings", "Настройки")}</button>
              <button 
                onClick={() => setMobilePdfTab('preview')}
                className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${mobilePdfTab === 'preview' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
              >{t("Preview", "Предпросмотр")}</button>
            </div>

            <div className="flex flex-1 overflow-hidden min-h-0 relative">
              {/* Left Column - Settings */}
              <div className={`w-full lg:w-[450px] shrink-0 lg:border-r border-zinc-200 dark:border-zinc-800 p-4 lg:p-6 overflow-y-auto space-y-6 ${mobilePdfTab === 'settings' ? 'block' : 'hidden lg:block'}`}>
                
                {!pdfTargetArtist && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="block text-sm font-medium mb-1">{t("Who to include in the report?", "Кого включить в отчёт?")}</label>
                      <select 
                        value={pdfReportType} 
                        onChange={e => setPdfReportType(e.target.value as any)}
                        className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors"
                      >
                        <option value="full">{t("Full Report (All rows)", "Полный отчёт")}</option>
                        <option value="artist">{t("Top 200 Artists", "Топ 200 артистов")}</option>
                        <option value="filtered">{t("Filtered Artists", "Отфильтрованные артисты")}</option>
                      </select>
                    </div>

                    <label className="flex items-center gap-3 p-3 bg-zinc-50 dark:bg-zinc-800/50 rounded-xl cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
                      <input 
                        type="checkbox" 
                        checked={pdfDetailedMaster}
                        onChange={e => setPdfDetailedMaster(e.target.checked)}
                        className="w-5 h-5 rounded border-zinc-300 text-blue-600 focus:ring-blue-500 bg-white dark:bg-black/20" 
                      />
                      <div>
                        <div className="text-sm font-medium">{t("Detailed Report", "Детализированный отчёт")}</div>
                        <div className="text-xs text-zinc-500 dark:text-zinc-400">{t("Include releases and tracks", "Включить релизы и треки")}</div>
                      </div>
                    </label>
                  </div>
                )}

                <div className="space-y-4">
                  
                {/* Format Settings */}
                <div className="space-y-4 pb-4 border-b border-zinc-200 dark:border-zinc-800">
                  <h4 className="font-semibold text-lg flex items-center gap-2"><Settings className="w-5 h-5 text-blue-500"/>{t("Document Type", "Тип документа")}</h4>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => setReportFormat('general')}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all ${reportFormat === 'general' ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300' : 'border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800/50 text-zinc-600 dark:text-zinc-400'}`}
                    > {t("General Report", "Общий отчёт")} <span className="block text-xs font-normal opacity-70 mt-1">{t("Without rights holder signatures", "Без подписей правообладателя")}</span>
                    </button>
                    <button 
                      onClick={() => setReportFormat('rightsholder')}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all ${reportFormat === 'rightsholder' ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300' : 'border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800/50 text-zinc-600 dark:text-zinc-400'}`}
                    > {t("Rights Holder Statement", "Акт Правообладателя")} <span className="block text-xs font-normal opacity-70 mt-1">{t("Details and parties signatures", "Реквизиты и подписи сторон")}</span>
                    </button>
                  </div>

                  {reportFormat === 'rightsholder' && (
                    <div className="pt-2">
                      <label className="flex items-center gap-3 p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 cursor-pointer">
                        <div className="relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" style={{ backgroundColor: includeHolderDetails ? '#3b82f6' : '#d1d5db' }}>
                           <input type="checkbox" className="sr-only" checked={includeHolderDetails} onChange={e => setIncludeHolderDetails(e.target.checked)} />
                           <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${includeHolderDetails ? 'translate-x-6' : 'translate-x-1'}`}/>
                        </div>
                        <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">{t("Include full details", "Включить полные реквизиты")}</span>
                      </label>
                      
                      {includeHolderDetails && (
                        <div className="mt-4 space-y-3 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 bg-blue-50/50 dark:bg-blue-900/10">
                          <input type="text" placeholder={t("Rights Holder Full Name", "ФИО Правообладателя")} value={holderDetails.fullName} onChange={e => setHolderDetails({...holderDetails, fullName: e.target.value})} className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2.5 text-sm outline-none focus:border-blue-500" />
                          <input type="text" placeholder={t("Phone", "Телефон")} value={holderDetails.phone} onChange={e => setHolderDetails({...holderDetails, phone: e.target.value})} className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2.5 text-sm outline-none focus:border-blue-500" />
                          <input type="text" placeholder={t("Passport details", "Паспортные данные")} value={holderDetails.passport} onChange={e => setHolderDetails({...holderDetails, passport: e.target.value})} className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2.5 text-sm outline-none focus:border-blue-500" />
                          <input type="text" placeholder={t("Tax ID", "ИНН")} value={holderDetails.inn} onChange={e => setHolderDetails({...holderDetails, inn: e.target.value})} className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2.5 text-sm outline-none focus:border-blue-500" />
                          <textarea placeholder={t("Bank Details", "Банковские реквизиты (Счет, БИК, Банк)")} value={holderDetails.bankDetails} onChange={e => setHolderDetails({...holderDetails, bankDetails: e.target.value})} className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2.5 text-sm outline-none focus:border-blue-500 min-h-[80px]" />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-lg flex items-center gap-2"><FileText className="w-5 h-5 text-blue-500"/> {t("Report Language", "Язык отчёта")}</h4>
                  <div className="flex gap-2">
                      <button
                        onClick={() => {
                            setPdfLang('ru');
                            setPdfSettings(prev => ({
                                ...prev,
                                documentTitle: prev.documentTitle === "ROYALTY REPORT" || prev.documentTitle === "MASTER ROYALTY REPORT" ? (pdfReportType === 'full' ? "ОТЧЁТ РОЯЛТИ (МАСТЕР)" : "ОТЧЁТ РОЯЛТИ") : prev.documentTitle
                            }));
                        }}
                        className={`flex-1 py-2 text-sm font-medium rounded-xl border transition-all ${pdfLang === 'ru' ? 'bg-blue-500 text-white border-blue-500' : 'bg-white dark:bg-black/20 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-white/10 hover:border-blue-500/50'}`}
                      >
                        Русский
                      </button>
                      <button
                        onClick={() => {
                            setPdfLang('en');
                            setPdfSettings(prev => ({
                                ...prev,
                                documentTitle: prev.documentTitle === "ОТЧЁТ РОЯЛТИ" || prev.documentTitle === "ОТЧЁТ РОЯЛТИ (МАСТЕР)" ? (pdfReportType === 'full' ? "MASTER ROYALTY REPORT" : "ROYALTY REPORT") : prev.documentTitle
                            }));
                        }}
                        className={`flex-1 py-2 text-sm font-medium rounded-xl border transition-all ${pdfLang === 'en' ? 'bg-blue-500 text-white border-blue-500' : 'bg-white dark:bg-black/20 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-white/10 hover:border-blue-500/50'}`}
                      >
                        English
                      </button>
                  </div>
                </div>

                <div className="space-y-4 mt-6">
                  <h4 className="font-semibold text-lg flex items-center gap-2"><FileText className="w-5 h-5 text-blue-500"/> {t("Document Data", "Данные документа")}</h4>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Document Title", "Название документа")}</label>
                    <input type="text" value={pdfSettings.documentTitle} onChange={e => setPdfSettings({...pdfSettings, documentTitle: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Report Period", "Период отчёта")}</label>
                      <input type="text" value={pdfSettings.reportPeriod} onChange={e => setPdfSettings({...pdfSettings, reportPeriod: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Generation Date", "Дата формирования")}</label>
                      <input type="text" value={pdfSettings.reportDate} onChange={e => setPdfSettings({...pdfSettings, reportDate: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                  </div>
                </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-lg flex items-center gap-2"><Users className="w-5 h-5 text-purple-500"/>{t("Distributor / Label Details", "Реквизиты Дистрибьютора / Лейбла")}</h4>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Name", "Название")}</label>
                    <input type="text" value={pdfSettings.distributorName} onChange={e => setPdfSettings({...pdfSettings, distributorName: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Type", "Тип")}</label>
                      <input type="text" value={pdfSettings.distributorType} onChange={e => setPdfSettings({...pdfSettings, distributorType: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Website", "Сайт")}</label>
                      <input type="text" value={pdfSettings.distributorWebsite} onChange={e => setPdfSettings({...pdfSettings, distributorWebsite: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("E-mail (not printed)", "E-mail (не выводится)")}</label>
                      <input type="text" value={pdfSettings.distributorEmail} onChange={e => setPdfSettings({...pdfSettings, distributorEmail: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Phone", "Телефон")}</label>
                      <input type="text" value={pdfSettings.distributorPhone} onChange={e => setPdfSettings({...pdfSettings, distributorPhone: e.target.value})} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-6 pt-4 border-t border-zinc-200 dark:border-zinc-800 ">
                  <h4 className="font-semibold text-lg flex items-center gap-2"><Settings className="w-5 h-5 text-emerald-500"/>{t("Signatures (Draw)", "Подписи сторон (Нарисуйте)")}</h4>
                  <SignaturePad title={t("Rights Holder Signature", "Подпись Правообладателя")} onChange={(v) => setPdfSettings({...pdfSettings, rightsHolderSignature: v})} />
                  <SignaturePad title={t("Label \/ Distributor Signature", "Подпись Лейбла / Дистрибьютора")} onChange={(v) => setPdfSettings({...pdfSettings, distributorSignature: v})} />
                </div>
                
                {localStorage.getItem('adminTgId') === '8160231965' && (
                <div className="space-y-4 pt-4 border-t border-zinc-200 dark:border-zinc-800 pb-24 lg:pb-8">
                  <h4 className="font-semibold text-lg flex items-center gap-2 text-blue-500"><TelegramIcon className="w-5 h-5"/> {t("Telegram Export", "Экспорт в Telegram")}</h4>

                  <h4 className="font-semibold text-lg flex items-center gap-2 text-blue-500"><TelegramIcon className="w-5 h-5"/> {t("Telegram Export", "Экспорт в Telegram")}</h4>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Bot Tokens (comma or newline separated)", "Токены ботов (через запятую или с новой строки)")}</label>
                    <textarea value={tgToken} onChange={e => {setTgToken(e.target.value); localStorage.setItem('tgToken', e.target.value); window.dispatchEvent(new CustomEvent('tg-config-update'));}} placeholder={t("e.g. 123:ABC..., 456:DEF...", "напр. 123:ABC..., 456:DEF...")} rows={2} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors resize-y" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between mb-2">
                       <label className="block text-sm font-medium text-zinc-500">{t("Recipients (Chat IDs)", "Получатели (Chat ID)")}</label>
                       <label className="flex items-center gap-2 cursor-pointer bg-zinc-100 dark:bg-zinc-800 px-2 py-1 rounded-lg select-none hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors">
                          <input type="checkbox" checked={tgManualMode} onChange={e => setTgManualMode(e.target.checked)} className="rounded border-zinc-300 text-blue-600 focus:ring-blue-500" />
                          <span className="text-xs font-semibold text-zinc-600 dark:text-zinc-300">{t("Manual Input", "Ручной ввод")}</span>
                       </label>
                    </div>
                    
                    {tgManualMode ? (
                      <div className="bg-blue-50/50 dark:bg-blue-900/10 p-3 rounded-xl border border-blue-100 dark:border-blue-900/30">
                        <input type="text" value={tgManualId} onChange={e => setTgManualId(e.target.value)} placeholder={t("Enter Chat ID or Username...", "Введите Chat ID...")} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                        <p className="text-[10px] text-zinc-500 mt-2">{t("This will send directly without saving to the database.", "Сообщение будет отправлено напрямую без сохранения ID в базу контактов.")}</p>
                      </div>
                    ) : (
                      <>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input type="text" value={newContactId} onChange={e => setNewContactId(e.target.value)} placeholder="ID (123456...)" className="flex-[2] w-full min-w-0 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors text-sm" />
                          <input type="text" value={newContactLabel} onChange={e => setNewContactLabel(e.target.value)} placeholder={t("Name (Ilya, Yamix)", "Имя (Илья, Yamix)")} className="flex-[3] w-full min-w-0 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors text-sm" />
                          <button onClick={() => {
                            if (newContactId.trim()) {
                              updateTgContacts([...tgContacts, { id: newContactId.trim(), label: newContactLabel.trim(), enabled: true }]);
                              setNewContactId('');
                              setNewContactLabel('');
                            }
                          }} className="w-full sm:w-auto px-4 py-3 sm:py-2 bg-blue-500 text-white font-bold rounded-xl hover:bg-blue-600 transition-colors active:scale-95 flex items-center justify-center">
                            <Plus className="w-5 h-5" />
                          </button>
                        </div>
                        {tgContacts.length > 0 && (
                          <div className="mt-3 space-y-1 max-h-48 overflow-y-auto border border-zinc-200 dark:border-zinc-700 rounded-xl p-2 bg-zinc-50 dark:bg-black/10">
                            {tgContacts.map((contact, idx) => (
                              <div key={idx} className="flex items-center justify-between gap-2 p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 rounded-lg transition-colors group">
                                <label className="flex items-center gap-3 flex-1 cursor-pointer select-none">
                                  <input type="checkbox" checked={contact.enabled} onChange={e => {
                                    const nc = [...tgContacts];
                                    nc[idx].enabled = e.target.checked;
                                    updateTgContacts(nc);
                                  }} className="w-5 h-5 rounded border-zinc-300 text-blue-600 focus:ring-blue-500 cursor-pointer" />
                                  <div className="flex flex-col">
                                    <span className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{contact.label || t("Unnamed", "Без имени")}</span>
                                    <span className="text-xs text-zinc-500">{contact.id}</span>
                                  </div>
                                </label>
                                <button onClick={() => {
                                  const nc = tgContacts.filter((_, i) => i !== idx);
                                  updateTgContacts(nc);
                                }} className="p-2 text-zinc-400 hover:text-red-500 opacity-50 group-hover:opacity-100 transition-all rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20">
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Send Mode", "Режим отправки")}</label>
                    <select value={tgSendType} onChange={e => {setTgSendType(e.target.value as any); localStorage.setItem('tgSendType', e.target.value)}} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors">
                      <option value="pdf">{t("Send PDF Report", "Отправить PDF отчёт")}</option>
                      <option value="text">{t("Send Text Message Only", "Только текстовое сообщение")}</option>
                      <option value="photo">{t("Send Photo", "Отправить фото")}</option>
                      <option value="video">{t("Send Video", "Отправить видео")}</option>
                      <option value="sticker">{t("Send Sticker", "Отправить стикер")}</option>
                    </select>
                  </div>
                  {tgSendType === 'sticker' && (
                    <div className="space-y-2 border border-zinc-200 dark:border-zinc-700 p-3 rounded-xl bg-zinc-50/50 dark:bg-black/10">
                      <label className="block text-sm font-medium text-zinc-500">{t("Sticker Pack Link or Name", "Ссылка на пак или название")}</label>
                      <div className="flex gap-2">
                        <input type="text" value={tgStickerPack} onChange={e => setTgStickerPack(e.target.value)} placeholder="https://t.me/addstickers/..." className="flex-1 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-black/20 p-2 outline-none focus:border-blue-500 transition-colors text-sm" />
                        <button onClick={loadStickers} disabled={tgIsLoadingStickers} className="px-4 py-2 bg-blue-500 text-white font-bold rounded-xl hover:bg-blue-600 transition-colors active:scale-95 text-sm">
                          {tgIsLoadingStickers ? <RefreshCw className="w-4 h-4 animate-spin" /> : t("Load", "Загрузить")}
                        </button>
                      </div>
                      
                      {tgStickers.length > 0 && (
                        <div className="grid grid-cols-5 sm:grid-cols-8 gap-2 mt-2 max-h-48 overflow-y-auto p-1">
                          {tgStickers.map((s, i) => (
                             <button key={i} onClick={() => setTgAttachmentUrl(s.file_id)} className={`relative rounded-lg p-1 border-2 transition-all ${tgAttachmentUrl === s.file_id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-transparent hover:border-zinc-300 dark:hover:border-zinc-600'}`}>
                               <img src={s.url} alt="Sticker" className="w-full h-auto object-contain" />
                               {(s.is_animated || s.is_video) && <div className="absolute bottom-0 right-0 bg-black/50 text-white text-[10px] px-1 rounded-tl-lg">ANIM</div>}
                             </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {(tgSendType === 'photo' || tgSendType === 'video') && (
                    <div>
                      <label className="block text-sm font-medium mb-1 text-zinc-500">{t("Attachment URL or File ID", "Ссылка на файл или File ID из Telegram")}</label>
                      <input type="text" value={tgAttachmentUrl} onChange={e => {setTgAttachmentUrl(e.target.value); localStorage.setItem('tgAttachmentUrl', e.target.value)}} placeholder={t("e.g. https://... or File ID", "напр. https://... или File ID")} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors" />
                    </div>
                  )}
                  <div>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <label className="block text-sm font-medium text-zinc-500">{tgSendType === 'text' ? t("Message Text", "Текст сообщения") : t("Message / Caption", "Подпись / Сообщение к файлу")}</label>
                      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                        {[
                          { label: t("News", "Новость"), text: t("🚀 <b>Новость:</b>\n\n", "🚀 <b>News:</b>\n\n") },
                          { label: t("Report", "Отчет"), text: t("📊 <b>Ваш Отчёт готов!</b>\n\nВы можете просмотреть новые данные в панели.", "📊 <b>Your Report is ready!</b>\n\nYou can view new data in the panel.") },
                          { label: t("Important", "Важное"), text: t("⚠️ <b>ВАЖНОЕ ОБНОВЛЕНИЕ:</b>\n\n", "⚠️ <b>IMPORTANT UPDATE:</b>\n\n") }
                        ].map((tpl, i) => (
                           <button
                             key={i}
                             onClick={() => {
                               const newVal = tgMessage ? tgMessage + "\n\n" + tpl.text : tpl.text;
                               setTgMessage(newVal);
                               localStorage.setItem('tgMessage', newVal);
                             }}
                             className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-[10px] font-semibold text-zinc-600 dark:text-zinc-400 rounded-lg whitespace-nowrap transition-colors"
                           >
                             {tpl.label}
                           </button>
                        ))}
                      </div>
                    </div>
                    <textarea value={tgMessage} onChange={e => {setTgMessage(e.target.value); localStorage.setItem('tgMessage', e.target.value)}} placeholder={tgSendType === 'text' ? t("Type your message here...", "Введите ваше сообщение...") : t("e.g. Q2 Royalty Report", "напр. Отчёт за 2 кв.")} rows={3} className="w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-black/20 p-3 outline-none focus:border-blue-500 transition-colors resize-y" />
                  </div>
                </div>
                )}
              </div>

              {/* Right Column - Preview PDF */}
              <div className={`flex-1 bg-zinc-100/50 dark:bg-black/20 p-0 sm:p-2 lg:p-4 flex-col relative min-h-0 ${mobilePdfTab === 'preview' ? 'flex' : 'hidden lg:flex'}`}>
                 {previewUrl ? (
                   <PdfPreview url={previewUrl} t={t} />
                 ) : (
                   <div className="w-full h-full flex flex-col items-center justify-center text-zinc-400">
                      <RefreshCw className="w-10 h-10 animate-spin mb-4 text-zinc-300" />
                      <p>{t("Generating preview...", "Генерация предпросмотра...")}</p>
                   </div>
                 )}
                 <div className="absolute bottom-6 right-4 lg:bottom-8 lg:right-8 flex gap-3">

                    <button onClick={sendPdfToTelegram} disabled={isExporting || isSendingTg} className={`px-6 py-3 lg:px-8 lg:py-4 rounded-2xl text-white font-bold shadow-xl transition-all active:scale-95 flex items-center gap-2 text-base lg:text-lg ${tgStatus === 'success' ? 'bg-emerald-500' : tgStatus === 'error' ? 'bg-red-500' : 'bg-blue-500 hover:bg-blue-600'}`}>
                      {isSendingTg ? <RefreshCw className="w-5 h-5 animate-spin" /> : tgStatus === 'success' ? <Check className="w-5 h-5" /> : tgStatus === 'error' ? <X className="w-5 h-5" /> : <TelegramIcon className="w-5 h-5" />}
                      <span className="hidden sm:inline">{t("Send to Telegram", "Отправить в Telegram")}</span>
                    </button>

                    <button onClick={performPdfExport} disabled={isExporting} className="px-6 py-3 lg:px-8 lg:py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xl transition-all active:scale-95 flex items-center gap-2 text-base lg:text-lg">
                      {isExporting ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
{t("Download PDF", "Скачать PDF")}
</button>
                 </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header Stats */}
      <div className="bg-white dark:bg-[#1c1c1e] rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 mb-2 overflow-hidden">
        <div className="p-4 border-b border-zinc-100 dark:border-white/5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex bg-zinc-100 dark:bg-black/30 p-1 rounded-xl">
            <button
              onClick={() => setActiveView('overview')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-colors ${activeView === 'overview' ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200'}`}
            >
              {t("Overview", "Сводка")}
            </button>
            <button
              onClick={() => setActiveView('raw')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-colors ${activeView === 'raw' ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200'}`}
            >
              {t("Raw Data", "Исходные данные")}
            </button>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">{t("Global Label Share %", "Общая доля Лейбла %")}:</span>
              <input
                type="number"
                min="0"
                max="100"
                value={globalLabelShare}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === '') {
                    setGlobalLabelShare('');
                    return;
                  }
                  const num = parseInt(val, 10);
                  if (!isNaN(num) && num >= 0 && num <= 100) {
                    setGlobalLabelShare(num.toString());
                  }
                }}
                className="w-20 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
            <button onClick={() => setRawData([])} className="text-red-500 hover:text-red-600 text-xs px-3 py-2 rounded-lg bg-red-50 dark:bg-red-900/20 font-medium">
              {t("Clear Data", "Очистить данные")}
            </button>
          </div>
        </div>

        <div className="p-4 border-b border-zinc-100 dark:border-white/5 bg-zinc-50/50 dark:bg-black/10">
            <div className="flex items-center gap-2 mb-3">
              <h4 className="text-sm font-bold text-zinc-900 dark:text-white">{t("Currency Exchange Rates", "Курс валют")}</h4>
              {cbrTimestamp && (
                <span className="text-xs text-zinc-500 dark:text-zinc-400 bg-zinc-200/50 dark:bg-white/5 px-2 py-1 rounded-md">
                  {lang === 'ru' ? 'Данные ЦБ РФ на ' : 'CBR data from '} {new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(cbrTimestamp))}
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-4 items-end">
              <div>
                <label className="block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1">
                  {t("Target Currency", "Целевая валюта")}
                </label>
                <select
                  value={targetCurrency}
                  onChange={e => setTargetCurrency(e.target.value)}
                  className="w-24 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-white/10 bg-white dark:bg-black/20 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                >
                  {Array.from(new Set(['RUB', 'USD', 'EUR', 'KZT', 'GBP', 'BYN', ...Object.keys(exchangeRates)])).map(currency => (
                    <option key={currency} value={currency}>{currency}</option>
                  ))}
                </select>
              </div>
              {Object.keys(exchangeRates).filter(currency => currency !== targetCurrency).map(currency => (
                <div key={currency} className="flex items-center gap-2">
                  <div className="text-zinc-400 text-sm">1 {currency} =</div>
                  <div>
                    <label className="block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1 opacity-0 hidden sm:block">
                      Rate
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={exchangeRates[currency]}
                      onChange={e => setExchangeRates(prev => ({...prev, [currency]: parseFloat(e.target.value) || 0}))}
                      className="w-24 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-white/10 bg-white dark:bg-black/20 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    />
                  </div>
                  <div className="text-zinc-400 text-sm">{targetCurrency}</div>
                </div>
              ))}
            </div>
          </div>

        <div className="p-4">
          <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
            <span>{t("Global Report Note", "Общее примечание к отчёту")}</span>
          </label>
          <textarea
            rows={2}
            placeholder={t("Add a summary or note to this report before exporting...", "Добавьте описание или примечание к этому отчёту перед экспортом...")}
            value={globalNote}
            onChange={(e) => setGlobalNote(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
          />
        </div>
      </div>

      {activeView === 'overview' ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 flex flex-col">
          <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mb-1 flex items-center gap-2"><DollarSign className="w-4 h-4 text-emerald-500"/> {t("Total Royalty", "Общий Доход (RAW)")}</span>
          <span className="text-3xl font-bold text-zinc-900 dark:text-white">{calculatedData.totalRoyalty.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-lg text-zinc-400">{targetCurrency}</span></span>
        </div>
        <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 flex flex-col relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity"><Users className="w-16 h-16"/></div>
          <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mb-1 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-blue-500"/> {t("Artist Payout", "Выплата Артистам")}</span>
          <span className="text-3xl font-bold text-blue-600 dark:text-blue-400">{calculatedData.totalArtistPayout.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-lg opacity-70">{targetCurrency}</span></span>
        </div>
        <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 flex flex-col">
          <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mb-1 flex items-center gap-2"><BarChart2 className="w-4 h-4 text-indigo-500"/> {t("Label Revenue", "Доход Лейбла")}</span>
          <span className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{calculatedData.totalLabelRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-lg opacity-70">{targetCurrency}</span></span>
        </div>
        <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 flex flex-col">
          <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mb-1">{t("Artists", "Артисты")}</span>
          <span className="text-3xl font-bold text-zinc-900 dark:text-white">{calculatedData.artistCount}</span>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10">
          <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" /> {t("Top Artists Revenue", "Доходы топ артистов")}
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topArtists} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" opacity={0.2} />
                <XAxis dataKey="name" tick={{fill: '#888', fontSize: 12}} />
                <YAxis tick={{fill: '#888', fontSize: 12}} />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#1c1c1e', borderColor: '#333', color: '#fff', borderRadius: '12px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Legend />
                <Bar dataKey="royalty" name={t("Royalty", "Доход")} fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="payout" name={t("Payout", "Выплата")} fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-[#1c1c1e] p-6 rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10">
          <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-6 flex items-center gap-2">
            <PieChartIcon className="w-5 h-5" /> {t("Revenue Split", "Разделение дохода")}
          </h3>
          <div className="h-72 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  formatter={(value: number) => value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  contentStyle={{ backgroundColor: '#1c1c1e', borderColor: '#333', color: '#fff', borderRadius: '12px' }}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Artists Payouts Table */}
      <div className="bg-white dark:bg-[#1c1c1e] rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 overflow-hidden">
        <div className="p-6 border-b border-zinc-100 dark:border-white/5 flex flex-col md:flex-row gap-4 items-center justify-between">
          <h3 className="font-bold text-lg text-zinc-900 dark:text-white">{t("Artist Payouts", "Выплаты Артистам")}</h3>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex flex-col items-start gap-2">
              <div className="relative w-full sm:w-72">
                <Filter className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input 
                  type="text" 
                  placeholder={t("Filter by artist (comma separated)...", "Поиск по артистам (через запятую)...")}
                  value={filterText}
                  onChange={e => {
                    setFilterText(e.target.value);
                    if (!isFilterDropdownOpen) setIsFilterDropdownOpen(true);
                  }}
                  onFocus={() => setIsFilterDropdownOpen(true)}
                  className="pl-9 pr-10 py-2 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 w-full"
                />
                <button 
                  onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-500"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
              
              {isFilterDropdownOpen && (
                <div className="absolute top-11 mt-1 w-full max-h-64 overflow-y-auto bg-white dark:bg-[#1c1c1e] border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-lg z-50">
                  <div className="sticky top-0 bg-white dark:bg-[#1c1c1e] border-b border-zinc-100 dark:border-zinc-800 p-2 flex justify-end">
                     <button onClick={() => setIsFilterDropdownOpen(false)} className="text-xs text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 px-2 py-1 bg-zinc-100 dark:bg-zinc-800 rounded-lg">{t("Close", "Закрыть")}</button>
                  </div>
                  {allArtistNames.map(name => {
                    const isSelected = selectedFilterArtists.includes(name);
                    return (
                      <div 
                        key={name}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedFilterArtists(prev => prev.filter(n => n !== name));
                          } else {
                            setSelectedFilterArtists(prev => [...prev, name]);
                          }
                        }}
                        className="px-4 py-2.5 flex items-center justify-between hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer text-sm"
                      >
                        <span className="truncate">{name}</span>
                        {isSelected && <Check className="w-4 h-4 text-blue-500 shrink-0" />}
                      </div>
                    );
                  })}
                  {allArtistNames.length === 0 && (
                    <div className="p-4 text-sm text-zinc-500 text-center">{t("No artists found", "Артисты не найдены")}</div>
                  )}
                </div>
              )}
              
              {selectedFilterArtists.length > 0 && (
                <div className="flex flex-wrap gap-1.5 w-full sm:w-72 mt-1">
                  {selectedFilterArtists.map(name => (
                    <div key={name} className="flex items-center gap-1 pl-2 pr-1 py-1 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-medium border border-blue-500/20">
                      <span className="truncate max-w-[120px]" title={name}>{name}</span>
                      <button 
                        onClick={() => setSelectedFilterArtists(prev => prev.filter(n => n !== name))}
                        className="p-0.5 rounded hover:bg-blue-500/20"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => setSelectedFilterArtists([])}
                    className="text-xs text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 ml-1 py-1"
                  >
                    {t("Clear", "Сбросить")}
                  </button>
                </div>
              )}
            </div>
            <button onClick={openGlobalPdfModal} className="flex items-center gap-2 px-5 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl text-sm font-semibold shadow-sm transition-all active:scale-95">
              <Printer className="w-4 h-4" /> PDF
            </button>
            <button onClick={exportXLSX} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-sm font-semibold shadow-sm transition-all active:scale-95">
              <Download className="w-4 h-4" /> XLSX
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-zinc-600 dark:text-zinc-400">
            <thead className="bg-zinc-50 dark:bg-black/20 text-zinc-500 dark:text-zinc-400 uppercase text-xs font-semibold">
              <tr>
                <th className="px-6 py-4">{t("Artist", "Артист")}</th>
                <th className="px-6 py-4">{t("Streams", "Стримы")}</th>
                <th className="px-6 py-4">{t("Raw Royalty", "Исходный Доход")}</th>
                <th className="px-6 py-4">{t("Share (Artist/Label)", "Доля (Артист/Лейбл)")}</th>
                <th className="px-6 py-4">{t("Artist Payout", "К выплате")}</th>
                <th className="px-6 py-4">{t("Actions", "Действия")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-white/5">
              {filteredArtists.map((artist, idx) => {
                const rule = rules[`artist:${artist.id}`];
                const artistShare = rule ? rule.artistShare : (100 - (Number(globalLabelShare) || 0));
                const labelShare = 100 - artistShare;
                
                return (
                  <tr key={idx} className="hover:bg-zinc-50/50 dark:hover:bg-white/[0.02] transition-colors group">
                    <td className="px-6 py-4 font-medium text-zinc-900 dark:text-white">
                      {artist.name}
                      {rule?.note && <span className="block text-xs text-blue-500 mt-1">{rule.note}</span>}
                    </td>
                    <td className="px-6 py-4">{artist.streams.toLocaleString()}</td>
                    <td className="px-6 py-4">{artist.royalty.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${rule ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' : 'bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-300'}`}>
                        {artistShare}% / {labelShare}%
                      </span>
                    </td>
                    <td className="px-6 py-4 font-semibold text-zinc-900 dark:text-white">{artist.payout.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td className="px-6 py-4 flex gap-2">
                      <button 
                        onClick={() => openRuleModal(artist.id, artist.name)}
                        className="p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-white/5 dark:hover:bg-white/10 transition-colors text-zinc-600 dark:text-zinc-300"
                        title={t("Edit Rules", "Изменить правила")}
                      >
                        <Settings className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => generateArtistPdf(artist)}
                        className="p-2 rounded-lg bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/30 dark:hover:bg-blue-900/50 transition-colors text-blue-600 dark:text-blue-400"
                        title={t("Download Statement", "Скачать отчёт")}
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredArtists.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-zinc-500">
                    {t("No artists found.", "Артисты не найдены.")}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
        </>
      ) : (
        <div className="bg-white dark:bg-[#1c1c1e] rounded-3xl shadow-sm border border-zinc-200/50 dark:border-white/10 overflow-hidden">
          <div className="p-6 border-b border-zinc-100 dark:border-white/5 flex flex-col md:flex-row gap-4 items-center justify-between">
            <h3 className="font-bold text-lg text-zinc-900 dark:text-white">{t("Raw Data", "Исходные данные")}</h3>
            <div className="text-sm text-zinc-500">
              {t("Total rows:", "Всего строк:")} {rawData.length}
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-zinc-600 dark:text-zinc-400">
              <thead className="bg-zinc-50 dark:bg-black/20 text-zinc-500 dark:text-zinc-400 uppercase text-xs font-semibold">
                <tr>
                  <th className="px-6 py-4">{t("Artist", "Артист")}</th>
                  <th className="px-6 py-4">{t("Release", "Релиз")}</th>
                  <th className="px-6 py-4">{t("Track", "Трек")}</th>
                  <th className="px-6 py-4">{t("Platform", "Платформа")}</th>
                  <th className="px-6 py-4">{t("Country", "Страна")}</th>
                  <th className="px-6 py-4">{t("Streams", "Стримы")}</th>
                  <th className="px-6 py-4">{t("Royalty", "Доход")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-white/5">
                {rawData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage).map((row, idx) => (
                  <tr key={idx} className="hover:bg-zinc-50/50 dark:hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4 font-medium text-zinc-900 dark:text-white truncate max-w-[200px]" title={row.artist}>{row.artist}</td>
                    <td className="px-6 py-4 truncate max-w-[200px]" title={row.release}>{row.release}</td>
                    <td className="px-6 py-4 truncate max-w-[200px]" title={row.track}>{row.track}</td>
                    <td className="px-6 py-4">{row.platform}</td>
                    <td className="px-6 py-4">{row.country}</td>
                    <td className="px-6 py-4">{row.streams.toLocaleString()}</td>
                    <td className="px-6 py-4">{row.royalty.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {row.currency}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {rawData.length > itemsPerPage && (
            <div className="p-4 border-t border-zinc-100 dark:border-white/5 flex items-center justify-between bg-zinc-50 dark:bg-black/10">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => p - 1)}
                className="px-4 py-2 rounded-lg bg-zinc-200 dark:bg-white/10 text-zinc-700 dark:text-zinc-300 disabled:opacity-50 text-sm font-medium"
              >
                {t("Previous", "Назад")}
              </button>
              <span className="text-sm text-zinc-500">
                {t("Page", "Страница")} {currentPage} {t("of", "из")} {Math.ceil(rawData.length / itemsPerPage)}
              </span>
              <button
                disabled={currentPage >= Math.ceil(rawData.length / itemsPerPage)}
                onClick={() => setCurrentPage(p => p + 1)}
                className="px-4 py-2 rounded-lg bg-zinc-200 dark:bg-white/10 text-zinc-700 dark:text-zinc-300 disabled:opacity-50 text-sm font-medium"
              >
                {t("Next", "Вперёд")}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Rule Edit Modal */}
      {isRuleModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1c1c1e] rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-zinc-200/50 dark:border-white/10 animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-zinc-100 dark:border-white/5 flex items-center justify-between">
              <h3 className="font-bold text-lg text-zinc-900 dark:text-white">{t("Edit Artist Rules", "Настройки Артиста")}</h3>
              <button onClick={() => setIsRuleModalOpen(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
                  {t("Artist Share (%)", "Доля Артиста (%)")}
                </label>
                <input 
                  type="number" 
                  min="0" max="100" step="1"
                  value={tempRule.artistShare}
                  onChange={(e) => setTempRule({ ...tempRule, artistShare: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
                <p className="mt-2 text-xs text-zinc-500">
                  {t("Label share will be automatically calculated as", "Доля лейбла будет автоматически рассчитана как")}: {100 - tempRule.artistShare}%
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
                  {t("Reason", "Причина")}
                </label>
                <input 
                  type="text" 
                  placeholder={t("e.g. Contract update", "напр. Обновление договора")}
                  value={tempRule.reason || ''}
                  onChange={(e) => setTempRule({ ...tempRule, reason: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
                  {t("Note", "Примечание")}
                </label>
                <textarea 
                  rows={3}
                  placeholder={t("Additional details...", "Дополнительные подробности...")}
                  value={tempRule.note || ''}
                  onChange={(e) => setTempRule({ ...tempRule, note: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
                />
              </div>

            </div>
            <div className="px-6 py-4 border-t border-zinc-100 dark:border-white/5 flex justify-end gap-3 bg-zinc-50 dark:bg-black/10">
              <button 
                onClick={() => setIsRuleModalOpen(false)}
                className="px-5 py-2.5 rounded-xl font-medium text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-white/10 transition-colors"
              >
                {t("Cancel", "Отмена")}
              </button>
              <button 
                onClick={applyRule}
                className="px-5 py-2.5 rounded-xl font-medium bg-blue-600 text-white hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                {t("Save Rule", "Сохранить")}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
