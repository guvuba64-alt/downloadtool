import React from 'react';
import { RefreshCw } from 'lucide-react';
import { TelegramIcon } from './Icons';

export const BotStatusIndicator = ({ botName, botStatus, setIsBotInfoOpen, t }: any) => {
  return (
    <div onClick={() => setIsBotInfoOpen(true)} className="bot-status-container inline-flex items-center gap-3 text-sm font-semibold px-5 py-2.5 rounded-full bg-white/60 dark:bg-black/40 backdrop-blur-xl border border-zinc-200 dark:border-white/10 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.1)] transition-all hover:scale-[1.05] active:scale-[0.98] cursor-pointer" title={botName ? t("Click for Bot Info", "Нажмите для инфо о боте") : "Telegram Bot Status"}>
      <div className="flex items-center gap-2 border-r border-zinc-200 dark:border-zinc-700 pr-3">
        <TelegramIcon className="w-4 h-4 text-blue-500 drop-shadow-sm" />
        <span className="text-zinc-800 dark:text-zinc-100 tracking-wide">
          {botName ? (botName.length > 12 ? botName.substring(0,12)+'...' : botName) : "Bot"}
        </span>
      </div>
      
      {botStatus === 'checking' ? (
        <span className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400 uppercase text-[10px] tracking-wider">
          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> {t("Checking", "Проверка")}
        </span>
      ) : botStatus === 'online' ? (
        <span className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 uppercase text-[10px] tracking-wider">
          <span className="relative flex h-2.5 w-2.5 shadow-[0_0_8px_rgba(16,185,129,0.6)] rounded-full">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          Online
        </span>
      ) : (
        <span className="flex items-center gap-2 text-red-600 dark:text-red-400 uppercase text-[10px] tracking-wider">
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 shadow-[0_0_8px_rgba(239,68,68,0.6)] bg-red-500"></span>
          Offline
        </span>
      )}
    </div>
  );
};
