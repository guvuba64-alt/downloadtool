import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Search,
  MoreVertical,
  Play,
  Pause,
  Download,
  Check,
  Copy,
  Info,
  ImageIcon,
  Loader2,
  X,
  Disc3,
  Zap,
  Archive,
  FileCheck,
  Film
} from 'lucide-react';
import { ProxyImage } from './ProxyImage';
import { downloadWavTrack } from '../utils/audioDownloader';
import { TrackInfoModal } from './TrackInfoModal';
import { VideoSnapshotModal } from './VideoSnapshotModal';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import { generateReleaseSheetPdf } from '../lib/pdfGenerator';

export interface AlbumTrack {
  id: string | number;
  title: string;
  durationMs?: number;
  duration?: number;
  artists?: any;
  coverUri?: string;
  backgroundVideoUri?: string;
  explicit?: boolean;
  isrc?: string;
  upc?: string;
  label?: string;
  copyright?: string;
  authorsMusic?: string;
  authorsText?: string;
  phonogramSource?: string;
  performer?: string;
  trackIndex?: number;
  isPopular?: boolean;
}

export interface AlbumModalProps {
  isOpen: boolean;
  onClose: () => void;
  album: {
    id?: string | number;
    title: string;
    artist?: string;
    artists?: any;
    artistAvatarUri?: string;
    coverUri?: string;
    coverUrl?: string;
    year?: string | number;
    releaseDate?: string;
    releaseType?: string;
    trackCount?: number;
    tracks?: AlbumTrack[];
    label?: string;
    copyright?: string;
    upc?: string;
    isrc?: string;
    authorsMusic?: string;
    authorsText?: string;
    phonogramSource?: string;
    performer?: string;
    distributor?: string;
  };
  activeTrackId?: string | number | null;
  isPlaying?: boolean;
  onPlayTrack?: (track: AlbumTrack, allTracks: AlbumTrack[]) => void;
  onArtistClick?: (artistName: string) => void;
  onSearchClick?: () => void;
  t?: (en: string, ru: string) => string;
}

export const AlbumModal: React.FC<AlbumModalProps> = ({
  isOpen,
  onClose,
  album,
  activeTrackId,
  isPlaying = false,
  onPlayTrack,
  onArtistClick,
  onSearchClick,
  t = (_en, ru) => ru,
}) => {
  const [currentAlbum, setCurrentAlbum] = useState<any>(album);
  const [tracks, setTracks] = useState<AlbumTrack[]>([]);
  const [loadingTracks, setLoadingTracks] = useState(false);
  const [activeMenuTrack, setActiveMenuTrack] = useState<AlbumTrack | null>(null);
  const [trackDetailModal, setTrackDetailModal] = useState<any | null>(null);
  const [showReleaseMenu, setShowReleaseMenu] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState('');
  const [totalZipProgressPct, setTotalZipProgressPct] = useState(0);
  const [downloadingTrackId, setDownloadingTrackId] = useState<string | number | null>(null);
  const [downloadedTrackIds, setDownloadedTrackIds] = useState<string[]>([]);
  const [currentTrackProgress, setCurrentTrackProgress] = useState<number>(0);
  const [videoSnapshotTrack, setVideoSnapshotTrack] = useState<any>(null);
  const [isVideoSnapshotOpen, setIsVideoSnapshotOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const activeAlbum = currentAlbum || album;

  const artistName = typeof activeAlbum?.artist === 'string'
    ? activeAlbum.artist
    : (typeof activeAlbum?.artists === 'string'
        ? activeAlbum.artists
        : (Array.isArray(activeAlbum?.artists) ? activeAlbum.artists.map((a: any) => a.name || a).join(', ') : ''));

  const cleanCover = activeAlbum?.coverUri || activeAlbum?.coverUrl || '';
  const highResCover = cleanCover
    ? (cleanCover.startsWith('http') ? cleanCover.replace('%%', '600x600') : `https://${cleanCover.replace('%%', '600x600')}`)
    : '';

  // Load full tracklist and metadata if not provided
  useEffect(() => {
    if (!isOpen) return;

    setCurrentAlbum(album);

    if (album?.tracks && Array.isArray(album.tracks) && album.tracks.length > 0) {
      setTracks(album.tracks);
      setLoadingTracks(false);
      return;
    }

    const albumId = album?.id;
    if (albumId) {
      setLoadingTracks(true);
      fetch(`/api/music/albums/${albumId}/with-tracks?provider=${album?.provider || ''}&spotifyClientId=${localStorage.getItem('spotify_client_id') || ''}&spotifyClientSecret=${localStorage.getItem('spotify_client_secret') || ''}`)
        .then(r => r.json())
        .then(data => {
          if (data?.album) {
            setCurrentAlbum((prev: any) => ({
              ...(prev || {}),
              ...data.album,
              title: data.album.title || prev?.title,
              artist: data.album.artist || prev?.artist,
              coverUri: data.album.coverUri || prev?.coverUri,
              label: (data.album.label && data.album.label !== 'Не указан') ? data.album.label : prev?.label,
              copyright: (data.album.copyright && data.album.copyright !== 'Не указан') ? data.album.copyright : prev?.copyright,
              upc: data.album.upc || prev?.upc,
              isrc: data.album.isrc || prev?.isrc,
              year: data.album.year || prev?.year,
              releaseDate: data.album.releaseDate || prev?.releaseDate
            }));
          }

          if (data?.tracks && Array.isArray(data.tracks) && data.tracks.length > 0) {
            setTracks(data.tracks);
          } else if (data?.result?.volumes && Array.isArray(data.result.volumes)) {
            const allParsed: AlbumTrack[] = [];
            let idx = 1;
            for (const volume of data.result.volumes) {
              if (Array.isArray(volume)) {
                for (const t of volume) {
                  allParsed.push({
                    id: String(t.id),
                    title: t.version ? `${t.title} (${t.version})` : t.title,
                    durationMs: t.durationMs,
                    duration: t.durationMs ? Math.floor(t.durationMs / 1000) : 0,
                    artists: t.artists?.map((a: any) => a.name).join(', ') || artistName || album?.artist,
                    coverUri: t.coverUri ? `https://${t.coverUri.replace('%%', '600x600')}` : (album?.coverUri || ''),
                    explicit: Boolean(t.contentWarning === 'explicit' || t.explicit),
                    trackIndex: idx,
                    isPopular: idx === 1 || idx === 9 || idx === 10,
                    isrc: t.isrc || album?.isrc,
                    upc: album?.upc,
                    label: t.label || album?.label,
                    copyright: t.copyright || album?.copyright,
                  });
                  idx++;
                }
              }
            }
            setTracks(allParsed.length > 0 ? allParsed : [{
              id: album.id,
              title: album.title,
              artists: artistName || album.artist,
              coverUri: album.coverUri || cleanCover,
              trackIndex: 1,
              isrc: album.isrc,
              upc: album.upc,
              label: album.label,
              copyright: album.copyright,
            }]);
          } else {
            setTracks([{
              id: album.id,
              title: album.title,
              artists: artistName || album.artist,
              coverUri: album.coverUri || cleanCover,
              trackIndex: 1,
              isrc: album.isrc,
              upc: album.upc,
              label: album.label,
              copyright: album.copyright,
            }]);
          }
        })
        .catch(() => {
          setTracks([{
            id: album.id || '1',
            title: album.title,
            artists: artistName || album.artist,
            coverUri: album.coverUri || cleanCover,
            trackIndex: 1,
            isrc: album.isrc,
            upc: album.upc,
            label: album.label,
            copyright: album.copyright,
          }]);
        })
        .finally(() => setLoadingTracks(false));
    } else {
      setTracks([{
        id: '1',
        title: album?.title || 'Track',
        artists: artistName || album?.artist,
        coverUri: cleanCover,
        trackIndex: 1,
        isrc: album?.isrc,
        upc: album?.upc,
        label: album?.label,
        copyright: album?.copyright,
      }]);
    }
  }, [isOpen, album?.id]);

  const handleScroll = () => {
    if (scrollContainerRef.current) {
      setIsScrolled(scrollContainerRef.current.scrollTop > 180);
    }
  };

  const handleCopyField = (text: string | null | undefined, fieldKey: string) => {
    if (!text || text === 'Не указан') return;
    navigator.clipboard.writeText(String(text));
    setCopiedField(fieldKey);
    setTimeout(() => {
      setCopiedField(prev => (prev === fieldKey ? null : prev));
    }, 1800);
  };

  const handleCopyAllInfo = (tr: AlbumTrack) => {
    const titleVal = tr?.title || activeAlbum?.title || '';
    const artistVal = tr?.performer || tr?.artists || artistName || '';
    const distVal = (tr as any)?.distributor || (activeAlbum as any)?.distributor;
    const labelVal = distVal || tr?.label || activeAlbum?.label || '';
    const phonoVal = tr?.phonogramSource || activeAlbum?.phonogramSource || labelVal;
    const copyrightVal = tr?.copyright || activeAlbum?.copyright || '';
    const isrcVal = tr?.isrc || activeAlbum?.isrc || '';
    const upcVal = tr?.upc || activeAlbum?.upc || '';

    const lines: string[] = [];
    if (titleVal) lines.push(`Релиз / Трек: ${titleVal}`);
    if (artistVal) lines.push(`Исполнитель: ${artistVal}`);
    if (labelVal) lines.push(`Лейбл (дистрибьютор): ${labelVal} в переработке`);
    if (phonoVal && phonoVal !== labelVal) lines.push(`Источник фонограммы: ${phonoVal}`);
    if (copyrightVal) lines.push(`Копирайт (правообладатель): ${copyrightVal} в переработке`);
    if (upcVal) lines.push(`UPC: ${upcVal}`);
    if (isrcVal) lines.push(`ISRC: ${isrcVal}`);
    if (tr?.authorsMusic || activeAlbum?.authorsMusic) lines.push(`Авторы музыки: ${tr?.authorsMusic || activeAlbum?.authorsMusic}`);
    if (tr?.authorsText || activeAlbum?.authorsText) lines.push(`Авторы текста: ${tr?.authorsText || activeAlbum?.authorsText}`);

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedField('all');
    setTimeout(() => setCopiedField(null), 1800);
  };

  // Download Cover in 3000x3000px Ultra HQ
  const handleDownloadCover3000 = async (customCoverUrl?: string) => {
    const rawCover = customCoverUrl || cleanCover;
    if (!rawCover) return;

    try {
      const highResUrl = rawCover.startsWith('http')
        ? rawCover.replace(/\/(%%|\d+x\d+)/, '/orig')
        : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, '/orig')}`;

      const proxyUrl = `/api/music/proxy-image?url=${encodeURIComponent(highResUrl)}`;
      const img = new Image();
      img.crossOrigin = 'anonymous';

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => {
          const fallbackUrl = rawCover.startsWith('http')
            ? rawCover.replace(/\/(%%|\d+x\d+)/, '/1000x1000')
            : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, '/1000x1000')}`;
          img.src = `/api/music/proxy-image?url=${encodeURIComponent(fallbackUrl)}`;
          img.onload = () => resolve();
          img.onerror = (err) => reject(err);
        };
        img.src = proxyUrl;
      });

      const canvas = document.createElement('canvas');
      canvas.width = 3000;
      canvas.height = 3000;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('No canvas context');

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, 3000, 3000);

      canvas.toBlob((blob) => {
        if (!blob) return;
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const cleanName = `${artistName || 'Artist'} - ${activeAlbum?.title || 'Release'}`.replace(/[/\\?%*:|"<>]/g, '-').trim();
        a.href = blobUrl;
        a.download = `Cover_${cleanName}_3000x3000.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
      }, 'image/jpeg', 0.95);
    } catch (e) {
      console.error('Error downloading 3000x3000px cover:', e);
    }
  };

  // ZIP Download: all audio WAV files + cover 3000x3000px + metadata.txt + passport.pdf
  const handleDownloadZipAll = async () => {
    if (!activeAlbum) return;
    setIsZipping(true);
    setTotalZipProgressPct(3);
    setDownloadedTrackIds([]);
    setDownloadingTrackId(null);
    setCurrentTrackProgress(0);
    setZipProgress(t("Preparing...", "Подготовка..."));

    try {
      const zip = new JSZip();

      // 1. Download Cover Image
      setZipProgress(t("Cover...", "Обложка..."));
      setTotalZipProgressPct(5);
      if (cleanCover) {
        try {
          const highResUrl = cleanCover.startsWith('http')
            ? cleanCover.replace(/\/(%%|\d+x\d+)/, '/orig')
            : `https://${cleanCover.replace(/\/(%%|\d+x\d+)/, '/orig')}`;
          const proxyUrl = `/api/music/proxy-image?url=${encodeURIComponent(highResUrl)}`;
          
          const coverRes = await fetch(proxyUrl);
          if (coverRes.ok) {
            const coverBuf = await coverRes.arrayBuffer();
            if (coverBuf.byteLength > 1000) {
              zip.file('cover_3000x3000.jpg', coverBuf, { binary: true });
            }
          } else {
            const fallbackRes = await fetch(`/api/music/proxy-image?url=${encodeURIComponent(cleanCover.replace('%%', '1000x1000'))}`);
            if (fallbackRes.ok) {
              const fbBuf = await fallbackRes.arrayBuffer();
              zip.file('cover.jpg', fbBuf, { binary: true });
            }
          }
        } catch (e) {
          try {
            const res = await fetch(`/api/music/proxy-image?url=${encodeURIComponent(cleanCover.replace('%%', '600x600'))}`);
            if (res.ok) {
              const b = await res.arrayBuffer();
              zip.file('cover.jpg', b, { binary: true });
            }
          } catch (err) {}
        }
      }

      // 2. Resolve all missing Track ISRCs before generating metadata
      setZipProgress(t("Resolving ISRC codes...", "Сверка ISRC кодов..."));
      setTotalZipProgressPct(8);
      const enrichedTracks: AlbumTrack[] = await Promise.all(
        tracks.map(async (tr) => {
          if (tr.isrc && tr.isrc !== 'Не указан') {
            return tr;
          }
          if (tr.id && /^\d+$/.test(String(tr.id))) {
            try {
              const r = await fetch(`/api/music/track/${tr.id}`);
              if (r.ok) {
                const data = await r.json();
                const fetchedIsrc = data?.track?.isrc || data?.result?.[0]?.isrc || data?.liveMetadata?.isrc;
                if (fetchedIsrc) {
                  return { ...tr, isrc: fetchedIsrc };
                }
              }
            } catch (err) {}
          }
          return tr;
        })
      );

      // 3. Generate metadata.txt / metadata_codes.txt with UTF-8 BOM
      setZipProgress(t("Metadata TXT...", "Метаданные TXT..."));
      setTotalZipProgressPct(10);
      const title = activeAlbum.title || '';
      const artist = artistName || '';
      const label = activeAlbum.label || 'Не указан';
      const upc = activeAlbum.upc || 'Не указан';
      const masterIsrc = activeAlbum.isrc || enrichedTracks.find(t => t.isrc)?.isrc || 'Не указан';
      const copyright = activeAlbum.copyright || `℗ ${activeAlbum.year || new Date().getFullYear()} ${artist || label}`;
      const relDate = activeAlbum.releaseDate || (activeAlbum.year ? String(activeAlbum.year) : '');
      const musicAuthors = activeAlbum.authorsMusic || '';
      const lyricsAuthors = activeAlbum.authorsText || '';
      const distributor = activeAlbum.distributor || 'ZVONKO digital / Студия Союз';

      let txtContent = `================================================================================\n` +
        `  RADIO SONIC - РЕЕСТР МЕТАДАННЫХ, UPC И ISRC КОДОВ РЕЛИЗА\n` +
        `================================================================================\n\n` +
        `ОСНОВНАЯ ИНФОРМАЦИЯ О РЕЛИЗЕ:\n` +
        `--------------------------------------------------------------------------------\n` +
        `Название релиза:      ${title}\n` +
        `Артист / Исполнитель: ${artist}\n` +
        `Лейбл / Издатель:     ${label}\n` +
        `Дистрибьютор:         ${distributor}\n` +
        `UPC / EAN Штрихкод:   ${upc}\n` +
        `Мастер ISRC Релиза:   ${masterIsrc}\n` +
        `Копирайт фонограммы:  ${copyright}\n` +
        (relDate ? `Дата релиза:          ${relDate}\n` : '') +
        (musicAuthors ? `Авторы музыки:        ${musicAuthors}\n` : '') +
        (lyricsAuthors ? `Авторы текста:        ${lyricsAuthors}\n` : '') +
        `Всего треков:         ${enrichedTracks.length}\n` +
        `\n================================================================================\n` +
        `  ПОДРОБНЫЙ ТРЕКЛИСТ С ISRC КОДАМИ:\n` +
        `================================================================================\n`;

      enrichedTracks.forEach((tr, i) => {
        const num = (i + 1).toString().padStart(2, '0');
        const trArtist = tr.performer || tr.artists || artist;
        const durSec = tr.duration || (tr.durationMs ? Math.floor(tr.durationMs / 1000) : 0);
        const durFormatted = durSec > 0 ? `${Math.floor(durSec / 60)}:${(durSec % 60).toString().padStart(2, '0')}` : '--:--';
        const trIsrc = tr.isrc || masterIsrc || 'Не указан';
        const trUpc = tr.upc || upc;

        txtContent += `[${num}] ${tr.title}\n` +
          `     Исполнитель:  ${trArtist}\n` +
          `     ISRC Код:     ${trIsrc}\n` +
          `     UPC Код:      ${trUpc}\n` +
          `     Хронометраж:  ${durFormatted}\n` +
          `     Лейбл:        ${tr.label || label}\n` +
          (tr.authorsMusic ? `     Автор музыки: ${tr.authorsMusic}\n` : '') +
          (tr.authorsText ? `     Автор слов:   ${tr.authorsText}\n` : '') +
          `\n`;
      });

      txtContent += `================================================================================\n` +
        `  СВОДНАЯ ТАБЛИЦА ISRC КОДОВ ВСЕХ ТРЕКОВ РЕЛИЗА:\n` +
        `================================================================================\n` +
        `№   | ISRC КОД          | ДЛИТ.  | НАЗВАНИЕ ТРЕКА И ИСПОЛНИТЕЛЬ\n` +
        `--------------------------------------------------------------------------------\n`;

      enrichedTracks.forEach((tr, i) => {
        const num = (i + 1).toString().padStart(2, '0');
        const isrcVal = (tr.isrc || masterIsrc || 'НЕ УКАЗАН').padEnd(17, ' ');
        const durSec = tr.duration || (tr.durationMs ? Math.floor(tr.durationMs / 1000) : 0);
        const durFormatted = (durSec > 0 ? `${Math.floor(durSec / 60)}:${(durSec % 60).toString().padStart(2, '0')}` : '--:--').padEnd(6, ' ');
        txtContent += `${num}  | ${isrcVal} | ${durFormatted} | ${tr.title} — ${tr.performer || tr.artists || artist}\n`;
      });

      txtContent += `--------------------------------------------------------------------------------\n\n` +
        `СПИСОК ВСЕХ ISRC КОДОВ (ДЛЯ КОПИРОВАНИЯ В ДИСТРИБЬЮТОР):\n`;

      enrichedTracks.forEach((tr, i) => {
        const isrcVal = tr.isrc || masterIsrc;
        if (isrcVal && isrcVal !== 'Не указан') {
          txtContent += `${isrcVal}\n`;
        } else {
          txtContent += `[Трек ${i + 1}]: Не указан\n`;
        }
      });

      // Add UTF-8 BOM so text editors and Windows/Android mobile apps read Cyrillic correctly
      zip.file('metadata_codes.txt', '\uFEFF' + txtContent);

      // Separate clean isrc list
      let isrcOnlyTxt = `# ISRC CODES LIST: ${artist} - ${title}\n` +
        `# UPC: ${upc}\n\n`;
      enrichedTracks.forEach((tr, i) => {
        const num = (i + 1).toString().padStart(2, '0');
        isrcOnlyTxt += `${num}. ${tr.isrc || masterIsrc || 'N/A'} - ${tr.title}\n`;
      });
      zip.file('isrc_list.txt', '\uFEFF' + isrcOnlyTxt);

      // 4. Generate professional metadata release passport PDF with cover art
      setZipProgress(t("PDF Report...", "Отчет PDF..."));
      try {
        const pdfBlob = await generateReleaseSheetPdf({
          title: title,
          artists: artist,
          albumTitle: title,
          upc: upc,
          isrc: masterIsrc,
          releaseDate: relDate,
          year: activeAlbum?.year,
          label: label,
          distributor: activeAlbum?.distributor || label,
          copyright: copyright,
          authorsMusic: musicAuthors,
          authorsText: lyricsAuthors,
          cover3000: highResCover || cleanCover,
          coverUri: cleanCover,
          entityType: 'album',
          tracks: enrichedTracks.map((tr, idx) => ({
            trackNumber: idx + 1,
            title: tr.title,
            artists: tr.performer || tr.artists || artist,
            isrc: tr.isrc || masterIsrc,
            duration: tr.duration || (tr.durationMs ? Math.round(tr.durationMs / 1000) : 0),
            authorsMusic: tr.authorsMusic || musicAuthors,
            authorsText: tr.authorsText || lyricsAuthors
          }))
        }, { previewMode: 'blob', lang: 'ru' });

        if (pdfBlob) {
          const pdfBuffer = await (pdfBlob as Blob).arrayBuffer();
          zip.file("release_passport.pdf", pdfBuffer, { binary: true });
        }
      } catch (pdfErr) {
        console.warn("PDF generation error:", pdfErr);
      }

      // 5. Download Audio tracks in Lossless WAV format (16-bit 44.1kHz PCM)
      const downloadList = enrichedTracks.filter(t => t.id);
      let trackCount = 0;
      const totalTracks = downloadList.length;

      for (const tr of downloadList) {
        trackCount++;
        const currentTrId = String(tr.id);
        setDownloadingTrackId(currentTrId);
        setCurrentTrackProgress(5);
        setZipProgress(`${t("WAV", "WAV")} ${trackCount}/${totalTracks}`);

        try {
          const res = await fetch(`/api/music/download/${tr.id}?download=true&format=wav&title=${encodeURIComponent(tr.title)}&artists=${encodeURIComponent(tr.performer || tr.artists || artistName)}&upc=${encodeURIComponent(tr.upc || activeAlbum.upc || '')}&isrc=${encodeURIComponent(tr.isrc || masterIsrc || '')}`);
          
          if (res.ok) {
            const contentLength = +(res.headers.get('content-length') || 0);
            // 16-bit 44.1kHz Stereo PCM WAV is 176,400 bytes/sec
            const durationSec = tr.duration || (tr.durationMs ? Math.round(tr.durationMs / 1000) : 0) || 180;
            const expectedWavBytes = Math.max(500 * 1024, durationSec * 176400);
            const expectedTotal = contentLength > 0 ? contentLength : expectedWavBytes;

            const reader = res.body?.getReader();
            const chunks: Uint8Array[] = [];
            let receivedBytes = 0;

            if (reader) {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                if (value) {
                  chunks.push(value);
                  receivedBytes += value.length;
                  const trackPct = Math.min(99, Math.max(8, Math.round((receivedBytes / expectedTotal) * 100)));
                  setCurrentTrackProgress(trackPct);
                  const baseProgress = 10 + ((trackCount - 1) / totalTracks) * 70;
                  const overallPct = Math.min(80, baseProgress + (trackPct / 100) * (70 / totalTracks));
                  setTotalZipProgressPct(overallPct);
                }
              }
            }

            // Combine chunks
            let arrayBuf: Uint8Array;
            const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
            if (totalLength > 0) {
              arrayBuf = new Uint8Array(totalLength);
              let offset = 0;
              for (const chunk of chunks) {
                arrayBuf.set(chunk, offset);
                offset += chunk.length;
              }
            } else {
              const rawBuf = await res.arrayBuffer();
              arrayBuf = new Uint8Array(rawBuf);
            }

            // Validate that we received non-empty audio data
            if (arrayBuf.byteLength > 2000) {
              const cleanTitle = tr.title.replace(/[/\\?%*:|"<>]/g, '-').trim();
              const fileName = `${trackCount.toString().padStart(2, '0')} - ${cleanTitle}.wav`;
              // Compress WAV with Level 9 Lossless DEFLATE (saves memory/storage without losing studio quality)
              zip.file(fileName, arrayBuf, {
                binary: true,
                compression: 'DEFLATE',
                compressionOptions: { level: 9 },
              });
              setCurrentTrackProgress(100);
              setDownloadedTrackIds(prev => [...prev, currentTrId]);
            }
          }
        } catch (err) {
          console.warn(`Could not bundle audio ${tr.id}:`, err);
        }

        const completedPct = 10 + (trackCount / totalTracks) * 70;
        setTotalZipProgressPct(completedPct);
      }

      setDownloadingTrackId(null);
      setCurrentTrackProgress(0);

      // 6. Finalize and Save standard PKWare-compliant DEFLATE ZIP (Level 9 compression)
      setZipProgress(t("Compressing ZIP...", "Сжатие ZIP..."));
      setTotalZipProgressPct(80);

      const zipBlob = await zip.generateAsync(
        {
          type: 'blob',
          compression: 'DEFLATE',
          compressionOptions: { level: 9 },
          mimeType: 'application/zip',
        },
        (metadata) => {
          const compPct = Math.min(99, 80 + Math.round((metadata.percent / 100) * 19));
          setTotalZipProgressPct(compPct);
          setZipProgress(`${t("Compressing", "Сжатие ZIP")} ${Math.round(metadata.percent)}%`);
        }
      );

      setTotalZipProgressPct(100);
      setZipProgress(t("Done!", "Готово!"));

      const cleanArtist = (artist || 'Release').replace(/[/\\?%*:|"<>]/g, '-').trim();
      const cleanAlbum = (title || 'Album').replace(/[/\\?%*:|"<>]/g, '-').trim();
      const zipFileName = `${cleanArtist} - ${cleanAlbum} [Codes & Audio].zip`;

      const safeBlob = new Blob([zipBlob], { type: 'application/zip' });
      try {
        saveAs(safeBlob, zipFileName);
      } catch (saveErr) {
        const url = URL.createObjectURL(safeBlob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = zipFileName;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }, 2000);
      }
    } catch (e: any) {
      console.error('ZIP generation error:', e);
      alert(t("Error building ZIP package", "Ошибка формирования ZIP пакета"));
    } finally {
      setIsZipping(false);
      setDownloadingTrackId(null);
      setCurrentTrackProgress(0);
      setZipProgress('');
    }
  };

  const handlePlayFirstOrToggle = () => {
    if (tracks.length > 0 && onPlayTrack) {
      if (activeTrackId && isPlaying) {
        window.dispatchEvent(new CustomEvent('togglePlayAudio'));
      } else {
        const tr = tracks.find(t => String(t.id) === String(activeTrackId)) || tracks[0];
        const playableTrack = {
          ...tr,
          albumId: activeAlbum?.id,
          albumTitle: activeAlbum?.title,
          coverUri: tr.coverUri || highResCover || cleanCover,
          artists: tr.artists || artistName,
          label: tr.label || activeAlbum?.label,
          copyright: tr.copyright || activeAlbum?.copyright,
          upc: tr.upc || activeAlbum?.upc,
          isrc: tr.isrc || activeAlbum?.isrc,
        };
        onPlayTrack(playableTrack, tracks);
      }
    }
  };

  const [isExportingReleasePdf, setIsExportingReleasePdf] = useState(false);

  const handleExportReleasePdf = async () => {
    if (!activeAlbum) return;
    setIsExportingReleasePdf(true);
    try {
      await generateReleaseSheetPdf({
        title: activeAlbum.title,
        artists: artistName,
        albumTitle: activeAlbum.title,
        upc: activeAlbum.upc,
        isrc: activeAlbum.isrc,
        releaseDate: activeAlbum.releaseDate || (activeAlbum.year ? String(activeAlbum.year) : ''),
        year: activeAlbum.year,
        label: activeAlbum.label,
        distributor: activeAlbum.distributor || activeAlbum.label,
        copyright: activeAlbum.copyright,
        authorsMusic: activeAlbum.authorsMusic,
        authorsText: activeAlbum.authorsText,
        cover3000: highResCover || cleanCover,
        coverUri: cleanCover,
        entityType: 'album',
        tracks: tracks.map((tr, idx) => ({
          trackNumber: idx + 1,
          title: tr.title,
          artists: tr.artists || tr.performer || artistName,
          isrc: tr.isrc || activeAlbum.isrc,
          duration: tr.duration || (tr.durationMs ? Math.round(tr.durationMs / 1000) : 0),
          authorsMusic: tr.authorsMusic,
          authorsText: tr.authorsText
        }))
      }, { lang: 'ru' });
    } catch (err) {
      console.error('Failed to export album PDF:', err);
    } finally {
      setIsExportingReleasePdf(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[70] bg-black flex flex-col justify-start items-center font-sans select-none overflow-hidden"
      >
        {/* Full container with gradient matching Screenshot 1 and 2 */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="w-full h-full max-w-2xl mx-auto flex flex-col overflow-y-auto overflow-x-hidden bg-gradient-to-b from-[#2b445a] via-[#162432] to-[#000000] text-white"
        >
          {/* Top Bar / Navigation Header (Matches Screenshot 1 & 2) */}
          <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 sm:px-6 sm:py-4 backdrop-blur-md bg-transparent transition-all">
            <button
              onClick={onClose}
              className="p-2 -ml-2 rounded-full text-white/90 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
              title="Назад"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>

            {/* Release title in center when scrolled (Matches Screenshot 2) */}
            <div className={`flex-1 text-center px-3 transition-opacity duration-300 ${isScrolled ? 'opacity-100' : 'opacity-0'}`}>
              <h3 className="font-bold text-base sm:text-lg text-white truncate">
                {activeAlbum?.title || t("Release", "Релиз")}
              </h3>
            </div>

            {/* Top Right Action Icons: Search & 3-Dots (Matches Screenshot 1) */}
            <div className="flex items-center gap-1 -mr-2">
              <button
                onClick={() => {
                  if (onSearchClick) onSearchClick();
                  else onClose();
                }}
                className="p-2 rounded-full text-white/90 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                title="Поиск"
              >
                <Search className="w-6 h-6" />
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowReleaseMenu(!showReleaseMenu)}
                  className="p-2 rounded-full text-white/90 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  title="Опции релиза"
                >
                  <MoreVertical className="w-6 h-6" />
                </button>

                {showReleaseMenu && (
                  <div className="absolute right-0 top-full mt-2 w-56 bg-[#1f1f22] border border-white/10 rounded-2xl shadow-2xl p-1.5 z-50 text-xs flex flex-col gap-0.5 animate-in fade-in zoom-in-95 duration-150">
                    <button
                      onClick={() => {
                        setShowReleaseMenu(false);
                        setTrackDetailModal(activeAlbum);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-zinc-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors font-medium"
                    >
                      <Info className="w-4 h-4 text-purple-400" />
                      <span>{t("About release (UPC, data)", "О релизе (UPC и данные)")}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowReleaseMenu(false);
                        handleDownloadCover3000();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-zinc-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
                    >
                      <ImageIcon className="w-4 h-4 text-pink-400" />
                      <span>{t("Download cover (3000x3000px)", "Скачать обложку (3000×3000)")}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowReleaseMenu(false);
                        handleDownloadZipAll();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-zinc-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
                    >
                      <Archive className="w-4 h-4 text-yellow-400" />
                      <span>{t("Download all tracks (ZIP)", "Скачать весь альбом (ZIP)")}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Release Card & Actions Section (Matches Screenshot 1) */}
          <div className="px-5 sm:px-8 pt-2 pb-6 flex flex-col items-center text-center">
            
            {/* Square Cover (18-20px radius, shadow) */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 aspect-square rounded-[20px] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.85)] border border-white/10 mb-5 group bg-zinc-900 shrink-0">
              {highResCover ? (
                <ProxyImage
                  src={highResCover}
                  alt={activeAlbum?.title || 'Cover'}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-zinc-800 text-white/30">
                  <Disc3 className="w-20 h-20" />
                </div>
              )}
            </div>

            {/* Release Title (Matches Screenshot 1) */}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight mb-2 px-2">
              {activeAlbum?.title || t("Unknown Release", "Без названия")}
            </h1>

            {/* Clickable Artist Name with mini Avatar & Year (Matches Screenshot 1) */}
            <div className="flex items-center justify-center gap-2 mb-7">
              {activeAlbum?.artistAvatarUri ? (
                <div className="w-5 h-5 rounded-full overflow-hidden border border-white/20 shrink-0">
                  <ProxyImage src={activeAlbum.artistAvatarUri} className="w-full h-full object-cover" alt="" />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full bg-white/20 overflow-hidden border border-white/20 shrink-0 flex items-center justify-center text-[10px] text-white font-bold">
                  {artistName?.charAt(0) || 'A'}
                </div>
              )}
              <button
                onClick={() => {
                  if (artistName && onArtistClick) {
                    onArtistClick(artistName);
                    onClose();
                  }
                }}
                className="text-sm font-semibold text-white/90 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer group"
              >
                <span className="group-hover:underline">{artistName || t("Artist", "Исполнитель")}</span>
                {activeAlbum?.year && (
                  <span className="text-white/60 font-normal">· {activeAlbum.year}</span>
                )}
              </button>
            </div>

            {/* Action Buttons Row */}
            <div className="flex items-center justify-center gap-6 sm:gap-10 my-2">
              
              {/* 1. "Скачать WAV (ZIP)" Circular Button with Radial Progress Ring */}
              <div className="flex flex-col items-center">
                <button
                  onClick={handleDownloadZipAll}
                  disabled={isZipping}
                  className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center backdrop-blur-md transition-all cursor-pointer shadow-lg active:scale-95 ${
                    isZipping
                      ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-400'
                      : 'bg-white/15 hover:bg-white/25 text-white border border-white/10'
                  }`}
                  title="Скачать полный ZIP-архив релиза (все WAV треки 16-bit 44.1kHz PCM, обложка 3000x3000px, паспорт релиза PDF и коды TXT)"
                >
                  {isZipping ? (
                    <>
                      {/* SVG Circular Progress Ring */}
                      <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none p-0.5" viewBox="0 0 64 64">
                        <circle
                          cx="32"
                          cy="32"
                          r="27"
                          stroke="rgba(255,255,255,0.15)"
                          strokeWidth="3.5"
                          fill="none"
                        />
                        <circle
                          cx="32"
                          cy="32"
                          r="27"
                          stroke="#10b981"
                          strokeWidth="3.5"
                          strokeDasharray={2 * Math.PI * 27}
                          strokeDashoffset={2 * Math.PI * 27 * (1 - (totalZipProgressPct || 0) / 100)}
                          strokeLinecap="round"
                          fill="none"
                          className="transition-all duration-200 ease-out"
                        />
                      </svg>
                      <span className="relative z-10 text-xs sm:text-sm font-mono font-bold text-emerald-400">
                        {Math.round(totalZipProgressPct)}%
                      </span>
                    </>
                  ) : (
                    <Download className="w-7 h-7 text-white" />
                  )}
                </button>
                <span className={`text-xs sm:text-sm font-medium mt-2.5 text-center select-none max-w-[120px] truncate ${
                  isZipping ? 'text-emerald-400 font-semibold' : 'text-white/90'
                }`}>
                  {isZipping ? (zipProgress || `${Math.round(totalZipProgressPct)}%`) : t("Download WAV", "Скачать WAV")}
                </span>
              </div>

              {/* 2. "Паспорт PDF" Circular Button */}
              <div className="flex flex-col items-center">
                <button
                  id="btn-album-export-pdf"
                  onClick={handleExportReleasePdf}
                  disabled={isExportingReleasePdf}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white/15 hover:bg-white/25 text-white border border-white/10 flex items-center justify-center backdrop-blur-md transition-all cursor-pointer shadow-lg active:scale-95 disabled:opacity-50"
                  title="Экспорт профессионального паспорта релиза в PDF с обложкой и всеми метаданными"
                >
                  {isExportingReleasePdf ? (
                    <Loader2 className="w-6 h-6 animate-spin text-rose-400" />
                  ) : (
                    <FileCheck className="w-6 h-6 text-rose-400" />
                  )}
                </button>
                <span className="text-xs sm:text-sm font-medium text-white/90 mt-2.5 text-center select-none">
                  {t("Export PDF", "Паспорт PDF")}
                </span>
              </div>

              {/* 3. "Слушать" Solid Bright Yellow Circular Play Button */}
              <div className="flex flex-col items-center">
                <button
                  onClick={handlePlayFirstOrToggle}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#fce000] hover:bg-[#ffe600] active:scale-95 flex items-center justify-center text-black shadow-[0_0_24px_rgba(252,224,0,0.4)] transition-all cursor-pointer"
                  title="Слушать альбом"
                >
                  {isPlaying ? (
                    <Pause className="w-7 h-7 fill-current text-black" />
                  ) : (
                    <Play className="w-7 h-7 fill-current text-black ml-0.5" />
                  )}
                </button>
                <span className="text-xs sm:text-sm font-medium text-white/90 mt-2.5 text-center select-none">
                  {isPlaying ? t("Pause", "Пауза") : t("Listen", "Слушать")}
                </span>
              </div>

            </div>

          </div>

          {/* Tracklist Section (Matches Screenshot 1 & 2) */}
          <div className="flex-1 bg-black px-2 sm:px-4 pt-2 pb-36">
            {loadingTracks ? (
              <div className="py-16 flex flex-col items-center justify-center gap-3 text-white/40">
                <Loader2 className="w-7 h-7 animate-spin text-yellow-400" />
                <p className="text-xs">{t("Loading tracklist...", "Загрузка треклиста...")}</p>
              </div>
            ) : (
              <div className="space-y-1">
                {tracks.map((tr, idx) => {
                  const trIdStr = String(tr.id ?? tr.trackId ?? idx);
                  const isThisPlaying = String(activeTrackId) === trIdStr || (tr.id && String(activeTrackId) === String(tr.id));
                  const isPopular = tr.isPopular || idx === 0 || idx === 8 || idx === 9;
                  const isDownloadingThis = isZipping && Boolean(downloadingTrackId) && (
                    String(downloadingTrackId) === trIdStr ||
                    (tr.id && String(downloadingTrackId) === String(tr.id)) ||
                    (tr.trackId && String(downloadingTrackId) === String(tr.trackId)) ||
                    (downloadingTrackId === String(idx + 1)) ||
                    (downloadingTrackId === '1' && idx === 0)
                  );
                  const isDownloadedThis = downloadedTrackIds.some(id =>
                    id === trIdStr ||
                    (tr.id && id === String(tr.id)) ||
                    (tr.trackId && id === String(tr.trackId)) ||
                    id === String(idx + 1) ||
                    (id === '1' && idx === 0)
                  );

                  return (
                    <div
                      key={`modal-tr-${tr.id || "t"}-${idx}`}
                      className={`relative overflow-hidden group flex items-center justify-between py-3 px-3 sm:px-4 rounded-xl transition-all cursor-pointer select-none ${
                        isDownloadingThis
                          ? 'bg-emerald-950/60 border border-emerald-500/60 shadow-[0_0_25px_rgba(16,185,129,0.35)] text-white'
                          : isDownloadedThis
                            ? 'bg-emerald-500/10 border border-emerald-500/30 text-white'
                            : isThisPlaying
                              ? 'bg-white/10 text-white'
                              : 'hover:bg-white/[0.04] text-white/90'
                      }`}
                      onClick={() => {
                        const playableTrack = {
                          ...tr,
                          albumId: activeAlbum?.id,
                          albumTitle: activeAlbum?.title,
                          coverUri: tr.coverUri || highResCover || cleanCover,
                          artists: tr.artists || artistName,
                          label: tr.label || activeAlbum?.label,
                          copyright: tr.copyright || activeAlbum?.copyright,
                          upc: tr.upc || activeAlbum?.upc,
                          isrc: tr.isrc || activeAlbum?.isrc,
                        };
                        if (onPlayTrack) onPlayTrack(playableTrack, tracks);
                      }}
                    >
                      {/* Translucent green progress bar running across track row as it downloads */}
                      {isDownloadingThis && (
                        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-xl z-0">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-500/20 via-emerald-500/35 to-emerald-400/45 border-r-2 border-emerald-400 shadow-[0_0_16px_#10b981] transition-[width] duration-150 ease-out"
                            style={{ width: `${Math.max(6, currentTrackProgress)}%` }}
                          />
                        </div>
                      )}

                      {/* Left: Numbering, Active dot, or Status badge */}
                      <div className="relative z-10 flex items-center min-w-0 flex-1 pr-3">
                        <div className="w-9 text-left flex items-center shrink-0">
                          {isDownloadingThis ? (
                            <Loader2 className="w-4 h-4 animate-spin text-emerald-400 ml-0.5" />
                          ) : isDownloadedThis ? (
                            <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
                              <Check className="w-3 h-3 text-emerald-400" />
                            </div>
                          ) : isThisPlaying ? (
                            <span className="w-2.5 h-2.5 rounded-full bg-[#fce000] shadow-[0_0_8px_#fce000] inline-block ml-1" />
                          ) : (
                            <span className="flex items-center gap-1 text-sm font-semibold text-zinc-500 group-hover:text-zinc-300 transition-colors">
                              {isPopular && (
                                <Zap className="w-3.5 h-3.5 fill-current text-zinc-500" />
                              )}
                              <span>{tr.trackIndex || idx + 1}</span>
                            </span>
                          )}
                        </div>

                        {/* Title & Info Badge & Live download tag */}
                        <div className="min-w-0 flex-1 flex items-center gap-2">
                          <span className={`text-[15px] sm:text-base font-medium truncate ${
                            isDownloadingThis
                              ? 'text-emerald-200 font-semibold'
                              : isDownloadedThis
                                ? 'text-emerald-100 font-medium'
                                : isThisPlaying
                                  ? 'text-white font-semibold'
                                  : 'text-zinc-100 group-hover:text-white'
                          }`}>
                            {tr.title}
                          </span>

                          {isDownloadingThis && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 shadow-sm animate-pulse">
                              WAV {currentTrackProgress}%
                            </span>
                          )}

                          {isDownloadedThis && !isDownloadingThis && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                              WAV ✓
                            </span>
                          )}
                          
                          {/* Info / Explicit Badge (ⓘ) */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setTrackDetailModal(tr);
                            }}
                            className="p-1 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full"
                            title="Информация о треке"
                          >
                            <Info className="w-4 h-4 text-zinc-400" />
                          </button>

                          {/* Video Snapshot Button (Клип / Видеошот) */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setVideoSnapshotTrack({
                                ...tr,
                                albumTitle: activeAlbum?.title,
                                coverUri: tr.coverUri || highResCover || cleanCover,
                                artists: tr.artists || artistName
                              });
                              setIsVideoSnapshotOpen(true);
                            }}
                            className={`p-1 rounded-full transition-colors cursor-pointer ${
                              tr.backgroundVideoUri 
                                ? 'text-purple-400 hover:text-purple-300' 
                                : 'text-zinc-500 hover:text-white'
                            }`}
                            title="Видео-снапшот и клип (Яндекс Музыка)"
                          >
                            <Film className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Right: 3-Dots Menu Button (⋮) (Matches Screenshots 1 & 2) */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenuTrack(tr);
                        }}
                        className="relative z-10 p-2 text-zinc-400 hover:text-white rounded-full transition-colors cursor-pointer shrink-0"
                        title="Опции трека"
                      >
                        <MoreVertical className="w-5 h-5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* TRACK 3-DOTS ACTION SHEET / MODAL */}
        <AnimatePresence>
          {activeMenuTrack && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[85] bg-black/80 backdrop-blur-sm flex items-end justify-center sm:items-center p-0 sm:p-4"
              onClick={() => setActiveMenuTrack(null)}
            >
              <motion.div
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="w-full sm:max-w-md bg-[#161d26] border border-white/10 rounded-t-[28px] sm:rounded-[28px] p-6 shadow-2xl space-y-4 text-white"
                onClick={e => e.stopPropagation()}
              >
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="min-w-0 pr-4">
                    <h4 className="font-bold text-base text-white truncate">{activeMenuTrack.title}</h4>
                    <p className="text-xs text-white/50 truncate">{activeMenuTrack.artists || artistName}</p>
                  </div>
                  <button
                    onClick={() => setActiveMenuTrack(null)}
                    className="p-1.5 text-white/40 hover:text-white rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* 3 Action Options according to User Requirements: */}
                <div className="space-y-2">
                  
                  {/* 1. Скачать трек (WAV audio) */}
                  <button
                    onClick={() => {
                      downloadWavTrack({
                        trackId: String(activeMenuTrack.id),
                        title: activeMenuTrack.title,
                        artists: activeMenuTrack.artists || artistName || '',
                        coverUri: activeMenuTrack.coverUri || cleanCover,
                      });
                      setActiveMenuTrack(null);
                    }}
                    className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 cursor-pointer text-left group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-yellow-400/20 text-yellow-300 flex items-center justify-center group-hover:bg-yellow-400 group-hover:text-black transition-colors shrink-0">
                      <Download className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{t("Download track", "Скачать трек")}</p>
                      <p className="text-xs text-white/40">{t("Lossless WAV audio", "Аудиофайл в формате WAV")}</p>
                    </div>
                  </button>

                  {/* 2. Скачать обложку (3000x3000px) */}
                  <button
                    onClick={() => {
                      handleDownloadCover3000(activeMenuTrack.coverUri || cleanCover);
                      setActiveMenuTrack(null);
                    }}
                    className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 cursor-pointer text-left group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center group-hover:bg-purple-500 group-hover:text-white transition-colors shrink-0">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{t("Download cover", "Скачать обложку")}</p>
                      <p className="text-xs text-white/40">3000×3000px Ultra HQ JPEG</p>
                    </div>
                  </button>

                  {/* 3. О треке (Metadata, ISRC, UPC, Label) */}
                  <button
                    onClick={() => {
                      setTrackDetailModal(activeMenuTrack);
                      setActiveMenuTrack(null);
                    }}
                    className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 cursor-pointer text-left group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-colors shrink-0">
                      <Info className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{t("About track", "О треке")}</p>
                      <p className="text-xs text-white/40">{t("Metadata, ISRC, UPC/EAN, label & copyright", "Метаданные, ISRC, UPC/EAN, лейбл и авторские права")}</p>
                    </div>
                  </button>

                  {/* 4. Смотреть и скачать видео-снапшот (MP4) */}
                  <button
                    onClick={() => {
                      setVideoSnapshotTrack({
                        ...activeMenuTrack,
                        albumTitle: activeAlbum?.title,
                        coverUri: activeMenuTrack.coverUri || highResCover || cleanCover,
                        artists: activeMenuTrack.artists || artistName
                      });
                      setIsVideoSnapshotOpen(true);
                      setActiveMenuTrack(null);
                    }}
                    className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 cursor-pointer text-left group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors shrink-0">
                      <Film className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{t("Video snapshot (clip)", "Видео-снапшот (клип)")}</p>
                      <p className="text-xs text-white/40">{t("View and download MP4 video shot", "Просмотр и скачивание MP4 видеошота")}</p>
                    </div>
                  </button>

                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* DETAILED "ABOUT TRACK / RELEASE" (О ТРЕКЕ / РЕЛИЗЕ) MODAL */}
        <TrackInfoModal
          track={trackDetailModal}
          isOpen={!!trackDetailModal}
          onClose={() => setTrackDetailModal(null)}
          onPlayTrack={onPlayTrack}
          t={t}
        />

        {/* VIDEO SNAPSHOT & CLIPS MODAL */}
        <VideoSnapshotModal
          track={videoSnapshotTrack}
          isOpen={isVideoSnapshotOpen}
          onClose={() => setIsVideoSnapshotOpen(false)}
          onPlayTrack={(t) => {
            if (onPlayTrack) onPlayTrack(t, tracks);
          }}
          onOpenStudio={(trackInfo) => window.dispatchEvent(new CustomEvent('openVideoShotStudio', { detail: trackInfo }))}
        />

      </motion.div>
    </AnimatePresence>
  );
};
