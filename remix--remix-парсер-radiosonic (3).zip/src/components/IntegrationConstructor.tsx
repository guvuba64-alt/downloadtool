import React, { useState, useEffect } from "react";
import {
  Sliders,
  Bot,
  Globe,
  Radio,
  Sparkles,
  Play,
  Pause,
  Download,
  Check,
  Copy,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Send,
  Zap,
  Volume2,
  Share2,
  Lock,
  Layers,
  Palette,
  Terminal,
  Activity,
  CheckCircle2,
  AlertCircle,
  Eye,
  Settings2,
  Music,
  FileCode,
  Smartphone,
  Server,
  UserCheck
} from "lucide-react";

interface IntegrationConstructorProps {
  t: (en: string, ru: string) => string;
  activeApiKey?: string;
  onNavigateToApiKeys?: () => void;
}

export const IntegrationConstructor: React.FC<IntegrationConstructorProps> = ({
  t,
  activeApiKey = "pk_live_pro_developer_demo",
  onNavigateToApiKeys
}) => {
  // Main target environment: "website" | "telegram" | "discord" | "limits"
  const [targetPlatform, setTargetPlatform] = useState<"website" | "telegram" | "discord" | "limits">("website");

  // Global Presets
  const [activePreset, setActivePreset] = useState<string>("custom");

  // ==========================================
  // 1. LIMITS & CAPABILITIES CONFIGURATION
  // ==========================================
  const [limitsConfig, setLimitsConfig] = useState({
    dailyLimit: 25,
    quality: "320k" as "192k" | "320k" | "lossless",
    allowDownload: true,
    allowLossless: true,
    forceSubscription: false,
    channelUsername: "music_label_official",
    watermark: "🎧 Скачано через Music Platform Bot",
    cooldownSec: 5,
    enableCaptcha: false
  });

  // Simulated user session for testing limits in real-time
  const [userSimulationState, setUserSimulationState] = useState({
    usedToday: 3,
    subscribed: true
  });

  // ==========================================
  // 2. WEBSITE & WIDGET DESIGNER CONFIGURATION
  // ==========================================
  const [widgetDesign, setWidgetDesign] = useState({
    theme: "cyberpunk" as "dark" | "light" | "cyberpunk" | "sunset" | "emerald" | "glassmorphism",
    borderRadius: "rounded-2xl" as "rounded-lg" | "rounded-2xl" | "rounded-full",
    accentColor: "#9333ea",
    title: "Deep Resonance",
    artist: "Soundtrack Unit",
    trackId: "12278456",
    coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&h=500&fit=crop",
    showWaveform: true,
    showDownloadBtn: true,
    showQualityBadge: true,
    showShareBtn: true,
    showLimitsCounter: true,
    playerWidth: "560px",
    autoplay: false
  });

  // Widget live playback state
  const [isPlayingWidget, setIsPlayingWidget] = useState(false);
  const [widgetProgress, setWidgetProgress] = useState(35);
  const [copiedCodeType, setCopiedCodeType] = useState<string | null>(null);

  // ==========================================
  // 3. TELEGRAM BOT RUNNER & SIMULATOR
  // ==========================================
  const [tgBotConfig, setTgBotConfig] = useState({
    token: "7123456789:AAF-demo_bot_token_telegram_live_2026",
    botName: "StereoWave Music Bot",
    welcomeText: "👋 Привет! Отправь мне название песни или ссылку (Яндекс, Spotify, VK, OK.RU), и я мгновенно пришлю трек!",
    mode: "auto_download" as "auto_download" | "preview_only" | "inline_search",
    isRunning: true
  });
  const [tgTokenStatus, setTgTokenStatus] = useState<any>(null);
  const [isVerifyingTgToken, setIsVerifyingTgToken] = useState(false);

  // Telegram Chat Simulator
  const [chatMessages, setChatMessages] = useState<Array<{
    id: string;
    sender: "user" | "bot";
    text: string;
    time: string;
    trackPayload?: any;
    buttons?: any[];
  }>>([
    {
      id: "m1",
      sender: "bot",
      text: `🎧 <b>StereoWave Music Bot</b>\n\n👋 Привет! Отправь мне название песни или ссылку (Яндекс, Spotify, VK, OK.RU), и я мгновенно пришлю трек!\n\n📊 <i>Ваш суточный лимит: 3/25 треков\nКачество звука: 320 KBPS</i>`,
      time: "12:00",
      buttons: [
        [{ text: "🔥 Топ треков сегодня", callback_data: "top" }, { text: "💎 Мой лимит", callback_data: "limits" }],
        [{ text: "🔍 Как искать музыку?", callback_data: "help" }]
      ]
    }
  ]);
  const [simulatorInput, setSimulatorInput] = useState("Miyagi & Эндшпиль");
  const [isSimulatingBot, setIsSimulatingBot] = useState(false);

  // ==========================================
  // 4. DISCORD BOT RUNNER & SIMULATOR
  // ==========================================
  const [discordConfig, setDiscordConfig] = useState({
    token: "ODk4NzY1NDMyMTA5ODc2NTQz.demo.discord_token",
    prefix: "!play",
    activity: "Lossless Hi-Fi Streaming 24/7",
    channel: "#general-music"
  });
  const [discordCommandInput, setDiscordCommandInput] = useState("!play The Weeknd Blinding Lights");
  const [isSimulatingDiscord, setIsSimulatingDiscord] = useState(false);
  const [discordLastEmbed, setDiscordLastEmbed] = useState<any>({
    title: "🎶 Now Playing in #general-music",
    description: "**[The Weeknd - Blinding Lights](/api/v1/stream?id=12278456)**\nby **The Weeknd**",
    color: "#5865F2",
    thumbnail: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop",
    duration: "3:20",
    bitrate: "320 kbps HQ",
    requestedBy: "ServerDJ#2026"
  });

  // Apply quick presets
  const handleApplyPreset = (presetKey: string) => {
    setActivePreset(presetKey);
    if (presetKey === "tg_downloader") {
      setTargetPlatform("telegram");
      setLimitsConfig(prev => ({
        ...prev,
        dailyLimit: 30,
        quality: "320k",
        allowDownload: true,
        forceSubscription: false
      }));
    } else if (presetKey === "site_player") {
      setTargetPlatform("website");
      setWidgetDesign(prev => ({
        ...prev,
        theme: "cyberpunk",
        borderRadius: "rounded-2xl",
        accentColor: "#9333ea",
        showWaveform: true,
        showDownloadBtn: true
      }));
    } else if (presetKey === "discord_radio") {
      setTargetPlatform("discord");
      setDiscordConfig(prev => ({
        ...prev,
        prefix: "!play",
        activity: "Lossless Hi-Fi Radio 24/7"
      }));
    } else if (presetKey === "monetized_limits") {
      setTargetPlatform("limits");
      setLimitsConfig(prev => ({
        ...prev,
        dailyLimit: 5,
        quality: "192k",
        allowDownload: false,
        forceSubscription: true,
        channelUsername: "vip_music_channel"
      }));
    }
  };

  // Verify Telegram Bot Token
  const handleVerifyTelegramToken = async () => {
    if (!tgBotConfig.token) return;
    setIsVerifyingTgToken(true);
    try {
      const res = await fetch("/api/v1/constructor/bot/verify-token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: tgBotConfig.token })
      });
      const data = await res.json();
      setTgTokenStatus(data);
    } catch (e: any) {
      setTgTokenStatus({ success: false, error: e.message || "Ошибка подключения" });
    } finally {
      setIsVerifyingTgToken(false);
    }
  };

  // Simulate Telegram bot message (Real auto-execution)
  const handleSendSimulatorMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = (customText !== undefined ? customText : simulatorInput).trim();
    if (!textToSend || isSimulatingBot) return;

    const userMsg = {
      id: "u_" + Date.now(),
      sender: "user" as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    setChatMessages(prev => [...prev, userMsg]);
    setSimulatorInput("");
    setIsSimulatingBot(true);

    try {
      const res = await fetch("/api/v1/constructor/bot/simulate-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageText: textToSend,
          userState: userSimulationState,
          limitsConfig,
          botConfig: {
            name: tgBotConfig.botName,
            welcomeMessage: tgBotConfig.welcomeText
          }
        })
      });
      const data = await res.json();

      if (data.quota) {
        setUserSimulationState(prev => ({
          ...prev,
          usedToday: data.quota.usedToday
        }));
      }

      const botMsg = {
        id: "b_" + Date.now(),
        sender: "bot" as const,
        text: data.replyText || "Трек найден!",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        trackPayload: data.track,
        buttons: data.buttons
      };
      setChatMessages(prev => [...prev, botMsg]);
    } catch (err: any) {
      setChatMessages(prev => [
        ...prev,
        {
          id: "err_" + Date.now(),
          sender: "bot",
          text: `⚠️ Ошибка выполнения: ${err.message}`,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setIsSimulatingBot(false);
    }
  };

  // Simulate Discord Command Execution
  const handleSimulateDiscordCommand = async () => {
    if (!discordCommandInput.trim() || isSimulatingDiscord) return;
    setIsSimulatingDiscord(true);
    try {
      const res = await fetch("/api/v1/constructor/discord/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command: discordCommandInput,
          prefix: discordConfig.prefix
        })
      });
      const data = await res.json();
      if (data.success && data.embed) {
        setDiscordLastEmbed({
          title: data.embed.title,
          description: data.embed.description,
          color: "#5865F2",
          thumbnail: data.embed.thumbnail?.url || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop",
          duration: data.embed.fields?.[0]?.value || "3:45",
          bitrate: data.embed.fields?.[1]?.value || "320 kbps HQ",
          requestedBy: data.embed.fields?.[2]?.value || "DiscordUser#1337"
        });
      }
    } catch (e) {
      console.error("Discord simulation error", e);
    } finally {
      setIsSimulatingDiscord(false);
    }
  };

  // Helper copy text
  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCodeType(type);
    setTimeout(() => setCopiedCodeType(null), 2500);
  };

  // Widget embed codes
  const autoScriptTag = `<script src="${window.location.origin}/embed.js" data-track-id="${widgetDesign.trackId}" data-theme="${widgetDesign.theme}" data-title="${encodeURIComponent(widgetDesign.title)}" data-artist="${encodeURIComponent(widgetDesign.artist)}"></script>`;
  const iframeCode = `<iframe src="${window.location.origin}/embed/player?id=${widgetDesign.trackId}&theme=${widgetDesign.theme}&title=${encodeURIComponent(widgetDesign.title)}&artist=${encodeURIComponent(widgetDesign.artist)}" width="100%" height="110" frameborder="0" style="border-radius: 18px; max-width: 560px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);" allow="autoplay"></iframe>`;
  const reactCode = `import React from "react";

export const MusicWidget = () => (
  <iframe
    src="${window.location.origin}/embed/player?id=${widgetDesign.trackId}&theme=${widgetDesign.theme}&title=${encodeURIComponent(widgetDesign.title)}&artist=${encodeURIComponent(widgetDesign.artist)}"
    width="100%"
    height="110"
    style={{ borderRadius: "18px", maxWidth: "560px", border: "none", boxShadow: "0 10px 30px rgba(0,0,0,0.2)" }}
    allow="autoplay"
  />
);`;

  // Download standalone HTML page
  const handleDownloadHtmlPage = () => {
    const fullHtml = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${widgetDesign.title} - ${widgetDesign.artist} | Official Player</title>
  <style>
    body {
      margin: 0;
      padding: 20px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: #09090b;
      font-family: system-ui, -apple-system, sans-serif;
      color: #fff;
    }
    .widget-container { width: 100%; max-width: 560px; }
  </style>
</head>
<body>
  <div class="widget-container">
    <div id="music-player-widget"></div>
  </div>
  ${autoScriptTag}
</body>
</html>`;
    const blob = new Blob([fullHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `music-player-${widgetDesign.trackId}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header & Preset Bar */}
      <div className="bg-gradient-to-br from-purple-950/40 via-zinc-900 to-black border border-purple-500/20 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              {t("Visual No-Code Builder & Live Runner", "Визуальный Конструктор & Авто-Исполнение")}
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {t("Automated Constructor: Sites, Telegram Bots & Discord", "Конструктор: Сайты, Telegram-Боты и Discord")}
            </h2>
            <p className="text-zinc-400 text-sm max-w-2xl mt-1.5 leading-relaxed">
              {t(
                "Configure design, limits, audio formats and capabilities visually. The engine automatically executes scripts, validates tokens and runs live bots without writing a single line of backend code.",
                "Настраивайте дизайн, квоты, форматы аудио и возможности визуально. Движок сам исполняет скрипты, валидирует ботов в облаке и выдает готовые виджеты без ручной правки кода."
              )}
            </p>
          </div>

          {/* Quick 1-Click Presets */}
          <div className="flex flex-wrap items-center gap-2 bg-black/40 backdrop-blur-md p-2 rounded-2xl border border-white/10 shrink-0">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider px-2">Пресеты:</span>
            <button
              onClick={() => handleApplyPreset("site_player")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activePreset === "site_player" ? "bg-purple-600 text-white shadow-lg" : "text-zinc-300 hover:bg-white/10"
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              Виджет Сайта
            </button>
            <button
              onClick={() => handleApplyPreset("tg_downloader")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activePreset === "tg_downloader" ? "bg-blue-600 text-white shadow-lg" : "text-zinc-300 hover:bg-white/10"
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              Telegram Бот
            </button>
            <button
              onClick={() => handleApplyPreset("discord_radio")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activePreset === "discord_radio" ? "bg-indigo-600 text-white shadow-lg" : "text-zinc-300 hover:bg-white/10"
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              Discord Бот
            </button>
            <button
              onClick={() => handleApplyPreset("monetized_limits")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activePreset === "monetized_limits" ? "bg-amber-600 text-white shadow-lg" : "text-zinc-300 hover:bg-white/10"
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              Платные Лимиты
            </button>
          </div>
        </div>

        {/* Primary Target Platform Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-6 pt-6 border-t border-white/10">
          <button
            onClick={() => setTargetPlatform("website")}
            className={`flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-sm transition-all ${
              targetPlatform === "website"
                ? "bg-purple-600 text-white shadow-lg shadow-purple-600/30 scale-[1.02]"
                : "bg-white/5 hover:bg-white/10 text-zinc-300"
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>1. Сайт & Виджет</span>
          </button>
          <button
            onClick={() => setTargetPlatform("telegram")}
            className={`flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-sm transition-all ${
              targetPlatform === "telegram"
                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 scale-[1.02]"
                : "bg-white/5 hover:bg-white/10 text-zinc-300"
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>2. Telegram-Бот</span>
          </button>
          <button
            onClick={() => setTargetPlatform("discord")}
            className={`flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-sm transition-all ${
              targetPlatform === "discord"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 scale-[1.02]"
                : "bg-white/5 hover:bg-white/10 text-zinc-300"
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>3. Discord-Бот</span>
          </button>
          <button
            onClick={() => setTargetPlatform("limits")}
            className={`flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-sm transition-all ${
              targetPlatform === "limits"
                ? "bg-amber-600 text-white shadow-lg shadow-amber-600/30 scale-[1.02]"
                : "bg-white/5 hover:bg-white/10 text-zinc-300"
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>4. Лимиты & Права</span>
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 1. WEBSITE WIDGET & PLAYER DESIGNER                            */}
      {/* ============================================================== */}
      {targetPlatform === "website" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls & Design Settings (Left side: 5 cols) */}
          <div className="lg:col-span-5 bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-white/5">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-purple-500" />
                <h3 className="font-black text-lg text-zinc-900 dark:text-white">Дизайн и Оформление</h3>
              </div>
              <span className="text-xs font-mono text-purple-500 bg-purple-500/10 px-2.5 py-1 rounded-lg">Auto-CSS</span>
            </div>

            {/* Theme Picker */}
            <div>
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                Цветовая тема виджета
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "cyberpunk", label: "Cyberpunk", color: "bg-yellow-400" },
                  { id: "dark", label: "Dark Studio", color: "bg-zinc-800" },
                  { id: "light", label: "Pure Light", color: "bg-zinc-100" },
                  { id: "sunset", label: "Sunset Glow", color: "bg-gradient-to-r from-pink-500 to-purple-600" },
                  { id: "emerald", label: "Emerald Wave", color: "bg-emerald-500" },
                  { id: "glassmorphism", label: "Glass Frost", color: "bg-white/20 backdrop-blur-md" }
                ].map(th => (
                  <button
                    key={th.id}
                    onClick={() => setWidgetDesign(prev => ({ ...prev, theme: th.id as any }))}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                      widgetDesign.theme === th.id
                        ? "border-purple-500 bg-purple-500/10 text-purple-600 dark:text-purple-400 shadow-sm"
                        : "border-zinc-200 dark:border-white/10 hover:bg-zinc-50 dark:hover:bg-white/5 text-zinc-700 dark:text-zinc-300"
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full ${th.color} border border-black/10`} />
                    <span>{th.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Border Radius */}
            <div>
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                Форма и Скругления
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "rounded-lg", label: "Грани (8px)" },
                  { id: "rounded-2xl", label: "Плавный (16px)" },
                  { id: "rounded-full", label: "Капсула Pill" }
                ].map(r => (
                  <button
                    key={r.id}
                    onClick={() => setWidgetDesign(prev => ({ ...prev, borderRadius: r.id as any }))}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center ${
                      widgetDesign.borderRadius === r.id
                        ? "border-purple-500 bg-purple-500/10 text-purple-600 dark:text-purple-400"
                        : "border-zinc-200 dark:border-white/10 hover:bg-zinc-50 dark:hover:bg-white/5 text-zinc-700 dark:text-zinc-300"
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Elements Toggles */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">
                Включаемые возможности в плеере
              </label>
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Кнопка прямого скачивания MP3</span>
                <input
                  type="checkbox"
                  checked={widgetDesign.showDownloadBtn}
                  onChange={e => setWidgetDesign(prev => ({ ...prev, showDownloadBtn: e.target.checked }))}
                  className="w-4 h-4 accent-purple-600 rounded"
                />
              </label>
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Анимированный волновой эквалайзер</span>
                <input
                  type="checkbox"
                  checked={widgetDesign.showWaveform}
                  onChange={e => setWidgetDesign(prev => ({ ...prev, showWaveform: e.target.checked }))}
                  className="w-4 h-4 accent-purple-600 rounded"
                />
              </label>
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Индикатор качества звука (320k / Lossless)</span>
                <input
                  type="checkbox"
                  checked={widgetDesign.showQualityBadge}
                  onChange={e => setWidgetDesign(prev => ({ ...prev, showQualityBadge: e.target.checked }))}
                  className="w-4 h-4 accent-purple-600 rounded"
                />
              </label>
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Счётчик оставшихся прослушиваний (Лимит)</span>
                <input
                  type="checkbox"
                  checked={widgetDesign.showLimitsCounter}
                  onChange={e => setWidgetDesign(prev => ({ ...prev, showLimitsCounter: e.target.checked }))}
                  className="w-4 h-4 accent-purple-600 rounded"
                />
              </label>
            </div>

            {/* Track Info Customizer */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">
                Тестовый трек для демонстрации
              </label>
              <input
                type="text"
                value={widgetDesign.title}
                onChange={e => setWidgetDesign(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Название трека"
                className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
              />
              <input
                type="text"
                value={widgetDesign.artist}
                onChange={e => setWidgetDesign(prev => ({ ...prev, artist: e.target.value }))}
                placeholder="Имя артиста"
                className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
              />
            </div>
          </div>

          {/* Live Preview & One-Click Auto-Embed Runner (Right side: 7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Live Interactive Player Preview */}
            <div className="bg-gradient-to-br from-zinc-900 to-black border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                    Живой Предпросмотр Виджета
                  </span>
                </div>
                <a
                  href={`/embed/player?id=${widgetDesign.trackId}&theme=${widgetDesign.theme}&title=${encodeURIComponent(widgetDesign.title)}&artist=${encodeURIComponent(widgetDesign.artist)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
                >
                  <span>Открыть в новом окне</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Dynamic Styled Player Box */}
              <div className="flex items-center justify-center py-6">
                <div
                  className={`w-full max-w-[520px] transition-all p-4 sm:p-5 flex items-center gap-4 ${
                    widgetDesign.borderRadius
                  } ${
                    widgetDesign.theme === "cyberpunk"
                      ? "bg-black/90 border-2 border-yellow-400 shadow-[0_0_25px_rgba(250,204,21,0.25)] text-yellow-300"
                      : widgetDesign.theme === "light"
                      ? "bg-white text-zinc-900 border border-zinc-200 shadow-xl"
                      : widgetDesign.theme === "sunset"
                      ? "bg-gradient-to-r from-purple-900/90 via-pink-900/80 to-zinc-900 border border-pink-500/30 text-white shadow-[0_0_30px_rgba(236,72,153,0.2)]"
                      : widgetDesign.theme === "emerald"
                      ? "bg-zinc-900 border border-emerald-500/40 text-emerald-100 shadow-[0_0_25px_rgba(16,185,129,0.2)]"
                      : widgetDesign.theme === "glassmorphism"
                      ? "bg-white/10 backdrop-blur-xl border border-white/20 text-white shadow-2xl"
                      : "bg-[#18181b] text-white border border-white/10 shadow-2xl"
                  }`}
                >
                  <img
                    src={widgetDesign.coverUrl}
                    alt="Cover"
                    className="w-16 h-16 rounded-xl object-cover shadow-md shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-bold text-sm truncate">{widgetDesign.title}</div>
                      {widgetDesign.showQualityBadge && (
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {limitsConfig.quality.toUpperCase()}
                        </span>
                      )}
                    </div>
                    <div className="text-xs opacity-70 truncate mt-0.5">{widgetDesign.artist}</div>

                    {/* Waveform / Progress Bar */}
                    <div className="mt-3 flex items-center gap-3">
                      <button
                        onClick={() => setIsPlayingWidget(!isPlayingWidget)}
                        className="w-8 h-8 rounded-full bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center shrink-0 transition-transform active:scale-95 shadow-md"
                      >
                        {isPlayingWidget ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                      </button>

                      <div className="flex-1 flex items-center gap-2">
                        {widgetDesign.showWaveform ? (
                          <div className="flex items-center gap-1 h-5 flex-1 cursor-pointer" onClick={() => setWidgetProgress(Math.floor(Math.random() * 80) + 10)}>
                            {[40, 65, 30, 85, 95, 55, 75, 45, 90, 60, 35, 80, 50, 70, 90, 40].map((h, i) => (
                              <div
                                key={i}
                                style={{ height: `${h}%` }}
                                className={`w-1 rounded-full transition-all duration-300 ${
                                  (i / 16) * 100 <= widgetProgress
                                    ? "bg-purple-500"
                                    : "bg-white/20"
                                } ${isPlayingWidget ? "animate-pulse" : ""}`}
                              />
                            ))}
                          </div>
                        ) : (
                          <div className="flex-1 h-1.5 rounded-full bg-white/20 relative overflow-hidden">
                            <div style={{ width: `${widgetProgress}%` }} className="h-full bg-purple-500 rounded-full" />
                          </div>
                        )}
                        <span className="text-[10px] font-mono opacity-60 tabular-nums">01:14</span>
                      </div>

                      {widgetDesign.showDownloadBtn && (
                        <a
                          href={`/api/v1/stream?id=${widgetDesign.trackId}&format=mp3`}
                          download=""
                          className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-white"
                          title="Скачать MP3"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    {widgetDesign.showLimitsCounter && (
                      <div className="mt-2 text-[10px] opacity-60 flex items-center justify-between">
                        <span>Суточный лимит:</span>
                        <span className="font-mono font-bold">Осталось {Math.max(0, limitsConfig.dailyLimit - userSimulationState.usedToday)} из {limitsConfig.dailyLimit}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Auto-Execution & Embed Code Snippets */}
            <div className="bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-100 dark:border-white/5">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500" />
                  <h4 className="font-bold text-zinc-900 dark:text-white">Автоматическое встраивание на любой сайт</h4>
                </div>
                <button
                  onClick={handleDownloadHtmlPage}
                  className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  Скачать готовую HTML страницу
                </button>
              </div>

              {/* One-Line Auto-Executing Script */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                    Вариант 1: Вставка в 1 строчку (Скрипт выполнится сам)
                  </span>
                  <button
                    onClick={() => handleCopy(autoScriptTag, "autoScript")}
                    className="text-xs text-purple-600 dark:text-purple-400 font-bold flex items-center gap-1 hover:opacity-80"
                  >
                    {copiedCodeType === "autoScript" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedCodeType === "autoScript" ? "Скопировано!" : "Скопировать"}
                  </button>
                </div>
                <pre className="p-3 bg-zinc-900 text-purple-300 font-mono text-xs rounded-xl overflow-x-auto border border-white/5">
                  {autoScriptTag}
                </pre>
                <p className="text-[11px] text-zinc-500 mt-1">
                  💡 Просто вставьте эту строчку в Tilda, WordPress, Webflow или любой HTML файл. Скрипт сам создаст плеер и подключит стриминг!
                </p>
              </div>

              {/* Standard Iframe Code */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                    Вариант 2: HTML Iframe
                  </span>
                  <button
                    onClick={() => handleCopy(iframeCode, "iframe")}
                    className="text-xs text-purple-600 dark:text-purple-400 font-bold flex items-center gap-1 hover:opacity-80"
                  >
                    {copiedCodeType === "iframe" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedCodeType === "iframe" ? "Скопировано!" : "Скопировать"}
                  </button>
                </div>
                <pre className="p-3 bg-zinc-900 text-zinc-300 font-mono text-xs rounded-xl overflow-x-auto border border-white/5">
                  {iframeCode}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. TELEGRAM BOT CONSTRUCTOR & LIVE CHAT SIMULATOR              */}
      {/* ============================================================== */}
      {targetPlatform === "telegram" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Bot Settings & Cloud Runner (Left side: 5 cols) */}
          <div className="lg:col-span-5 bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-white/5">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-blue-500" />
                <h3 className="font-black text-lg text-zinc-900 dark:text-white">Параметры Telegram Бота</h3>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                tgBotConfig.isRunning ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : "bg-zinc-500/10 text-zinc-400"
              }`}>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                {tgBotConfig.isRunning ? "Cloud Runner: ONLINE" : "OFFLINE"}
              </span>
            </div>

            {/* Token Input & Live Verifier */}
            <div>
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                Bot Token (от @BotFather)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={tgBotConfig.token}
                  onChange={e => setTgBotConfig(prev => ({ ...prev, token: e.target.value }))}
                  placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
                  className="flex-1 text-xs font-mono px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
                />
                <button
                  onClick={handleVerifyTelegramToken}
                  disabled={isVerifyingTgToken}
                  className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 flex items-center gap-1 transition-all disabled:opacity-50 shadow-sm"
                >
                  {isVerifyingTgToken ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                  Проверить
                </button>
              </div>

              {tgTokenStatus && (
                <div className={`mt-2 p-2.5 rounded-xl text-xs flex items-center gap-2 ${
                  tgTokenStatus.success ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"
                }`}>
                  {tgTokenStatus.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                  <span>{tgTokenStatus.message || tgTokenStatus.error}</span>
                </div>
              )}
            </div>

            {/* Bot Name & Greeting Text */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Отображаемое имя бота
                </label>
                <input
                  type="text"
                  value={tgBotConfig.botName}
                  onChange={e => setTgBotConfig(prev => ({ ...prev, botName: e.target.value }))}
                  className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Приветствие команды /start
                </label>
                <textarea
                  rows={3}
                  value={tgBotConfig.welcomeText}
                  onChange={e => setTgBotConfig(prev => ({ ...prev, welcomeText: e.target.value }))}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white resize-none"
                />
              </div>
            </div>

            {/* Capabilities Toggles */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">
                Возможности бота
              </label>
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <div>
                  <div className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Отправка аудиофайлом в чат</div>
                  <div className="text-[11px] text-zinc-500">Пользователь сразу получает .mp3 прямо в Telegram</div>
                </div>
                <input
                  type="checkbox"
                  checked={limitsConfig.allowDownload}
                  onChange={e => setLimitsConfig(prev => ({ ...prev, allowDownload: e.target.checked }))}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 cursor-pointer">
                <div>
                  <div className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">Обязательная подписка (Force Sub)</div>
                  <div className="text-[11px] text-zinc-500">Требовать подписку на @{limitsConfig.channelUsername} перед выдачей песен</div>
                </div>
                <input
                  type="checkbox"
                  checked={limitsConfig.forceSubscription}
                  onChange={e => setLimitsConfig(prev => ({ ...prev, forceSubscription: e.target.checked }))}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
              </label>
            </div>

            {/* Cloud Runner Control Button */}
            <div className="pt-2">
              <button
                onClick={() => setTgBotConfig(prev => ({ ...prev, isRunning: !prev.isRunning }))}
                className={`w-full py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg ${
                  tgBotConfig.isRunning
                    ? "bg-emerald-600 hover:bg-emerald-500 text-white"
                    : "bg-blue-600 hover:bg-blue-500 text-white"
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{tgBotConfig.isRunning ? "Бот запущен в облаке (Нажмите для паузы)" : "Запустить бота в облаке"}</span>
              </button>
            </div>
          </div>

          {/* Interactive Telegram Chat Simulator (Right side: 7 cols) */}
          <div className="lg:col-span-7 bg-zinc-950 border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[640px]">
            {/* TG Header */}
            <div className="p-4 bg-zinc-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-black text-sm shadow-md">
                  SW
                </div>
                <div>
                  <div className="font-bold text-sm text-white flex items-center gap-1.5">
                    <span>{tgBotConfig.botName}</span>
                    <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.2 rounded font-mono">bot</span>
                  </div>
                  <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>online • готовит ответы за 120ms</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono text-zinc-400 block">Суточная квота тестера:</span>
                <span className="text-xs font-bold text-amber-400">{userSimulationState.usedToday} / {limitsConfig.dailyLimit} треков</span>
              </div>
            </div>

            {/* Chat Body */}
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-[#0e1621]">
              {chatMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 text-xs sm:text-sm shadow-md leading-relaxed ${
                      msg.sender === "user"
                        ? "bg-[#2b5278] text-white rounded-br-none"
                        : "bg-[#182533] text-zinc-100 border border-white/5 rounded-bl-none"
                    }`}
                  >
                    <div
                      dangerouslySetInnerHTML={{ __html: msg.text }}
                      className="whitespace-pre-wrap"
                    />

                    {/* Audio Track Payload card */}
                    {msg.trackPayload && (
                      <div className="mt-3 p-3 rounded-xl bg-black/40 border border-white/10 flex items-center gap-3">
                        <img
                          src={msg.trackPayload.coverUri}
                          alt=""
                          className="w-12 h-12 rounded-lg object-cover shadow-sm shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-white truncate">{msg.trackPayload.title}</div>
                          <div className="text-[11px] text-zinc-400 truncate">{msg.trackPayload.artists}</div>
                          <div className="mt-1.5 flex items-center gap-2">
                            <a
                              href={msg.trackPayload.streamUrl}
                              download=""
                              className="px-2.5 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] flex items-center gap-1 shadow-sm"
                            >
                              <Download className="w-3 h-3" />
                              Скачать аудио
                            </a>
                            <span className="text-[10px] text-zinc-400 font-mono">320 kbps</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Telegram Inline Buttons */}
                    {msg.buttons && msg.buttons.length > 0 && (
                      <div className="mt-3 pt-2 border-t border-white/10 space-y-1.5">
                        {msg.buttons.map((row: any[], rIdx: number) => (
                          <div key={rIdx} className="grid grid-cols-2 gap-1.5">
                            {row.map((btn: any, bIdx: number) => (
                              <button
                                key={bIdx}
                                onClick={() => {
                                  if (btn.callback_data === "limits") {
                                    handleSendSimulatorMessage(undefined, "/limits");
                                  } else if (btn.callback_data === "help") {
                                    handleSendSimulatorMessage(undefined, "/help");
                                  } else if (btn.callback_data === "check_sub") {
                                    setUserSimulationState(prev => ({ ...prev, subscribed: true }));
                                    handleSendSimulatorMessage(undefined, "/start");
                                  } else if (btn.url) {
                                    window.open(btn.url, "_blank");
                                  }
                                }}
                                className="w-full py-1.5 px-2.5 rounded-lg bg-[#243547] hover:bg-[#2e4257] text-sky-300 font-medium text-[11px] text-center truncate transition-colors"
                              >
                                {btn.text}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="text-[10px] text-zinc-400 text-right mt-1 opacity-70">
                      {msg.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Chat Input & Quick Command Trigger */}
            <div className="p-3 bg-zinc-900 border-t border-white/10 space-y-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider shrink-0">Быстрый тест:</span>
                {["/start", "/limits", "Miyagi", "Queen Bohemian", "https://music.yandex.ru/track/12278456"].map(cmd => (
                  <button
                    key={cmd}
                    onClick={() => handleSendSimulatorMessage(undefined, cmd)}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-300 text-[11px] font-mono whitespace-nowrap transition-colors"
                  >
                    {cmd}
                  </button>
                ))}
              </div>

              <form onSubmit={handleSendSimulatorMessage} className="flex gap-2">
                <input
                  type="text"
                  value={simulatorInput}
                  onChange={e => setSimulatorInput(e.target.value)}
                  placeholder="Отправьте название трека или ссылку..."
                  className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-black/50 text-white focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  disabled={!simulatorInput.trim() || isSimulatingBot}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
                >
                  {isSimulatingBot ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>Отправить</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. DISCORD BOT CONSTRUCTOR & COMMAND RUNNER                     */}
      {/* ============================================================== */}
      {targetPlatform === "discord" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Discord Settings (Left: 5 cols) */}
          <div className="lg:col-span-5 bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-white/5">
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-indigo-500" />
                <h3 className="font-black text-lg text-zinc-900 dark:text-white">Конструктор Discord Бота</h3>
              </div>
              <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-lg">Voice Ready</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                Discord Bot Token
              </label>
              <input
                type="text"
                value={discordConfig.token}
                onChange={e => setDiscordConfig(prev => ({ ...prev, token: e.target.value }))}
                className="w-full text-xs font-mono px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Префикс команд
                </label>
                <input
                  type="text"
                  value={discordConfig.prefix}
                  onChange={e => setDiscordConfig(prev => ({ ...prev, prefix: e.target.value }))}
                  className="w-full text-sm font-mono px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Голосовой канал
                </label>
                <input
                  type="text"
                  value={discordConfig.channel}
                  onChange={e => setDiscordConfig(prev => ({ ...prev, channel: e.target.value }))}
                  className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                Статус активности в Discord
              </label>
              <input
                type="text"
                value={discordConfig.activity}
                onChange={e => setDiscordConfig(prev => ({ ...prev, activity: e.target.value }))}
                className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 text-zinc-900 dark:text-white"
              />
            </div>

            <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300 space-y-2">
              <div className="font-bold flex items-center gap-1.5 text-indigo-400">
                <Zap className="w-4 h-4" />
                Автоматическое воспроизведение в Voice-канале:
              </div>
              <p>
                Бот автоматически принимает аудиопоток с нашего сервера через эндпоинт <code>/api/v1/stream?id=...&apiKey=...</code> и передает его в голосовой канал Discord с битрейтом 320 kbps без задержек.
              </p>
            </div>
          </div>

          {/* Discord Live Command Simulator (Right: 7 cols) */}
          <div className="lg:col-span-7 bg-[#2B2D31] border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-indigo-500" />
                  <span className="font-bold text-white text-sm"># general-music • Discord Command Simulator</span>
                </div>
                <span className="text-xs font-mono text-zinc-400">Voice 64kbps / 320kbps</span>
              </div>

              {/* Discord Embed Response Card */}
              {discordLastEmbed && (
                <div className="bg-[#1E1F22] rounded-xl p-4 border-l-4 border-[#5865F2] shadow-md max-w-lg space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="font-bold text-white text-sm">{discordLastEmbed.title}</div>
                      <div
                        className="text-xs text-zinc-300 mt-1"
                        dangerouslySetInnerHTML={{ __html: discordLastEmbed.description }}
                      />
                    </div>
                    {discordLastEmbed.thumbnail && (
                      <img
                        src={discordLastEmbed.thumbnail}
                        alt=""
                        className="w-16 h-16 rounded-lg object-cover shadow-sm shrink-0"
                      />
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-[11px]">
                    <div>
                      <span className="text-zinc-500 block uppercase font-bold text-[9px]">Длительность</span>
                      <span className="text-white font-mono">{discordLastEmbed.duration}</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 block uppercase font-bold text-[9px]">Битрейт</span>
                      <span className="text-emerald-400 font-bold">{discordLastEmbed.bitrate}</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 block uppercase font-bold text-[9px]">Запросил</span>
                      <span className="text-indigo-300">{discordLastEmbed.requestedBy}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Command Trigger Bar */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={discordCommandInput}
                  onChange={e => setDiscordCommandInput(e.target.value)}
                  placeholder="!play название песни или ссылка..."
                  className="flex-1 bg-[#383A40] text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/5 focus:outline-none focus:border-indigo-500 font-mono"
                />
                <button
                  onClick={handleSimulateDiscordCommand}
                  disabled={isSimulatingDiscord}
                  className="px-4 py-2.5 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md"
                >
                  {isSimulatingDiscord ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>Выполнить</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] text-zinc-400">Команды для теста:</span>
                {["!play Weeknd", "!play Hans Zimmer", "!queue", "!lyrics"].map(cmd => (
                  <button
                    key={cmd}
                    onClick={() => {
                      setDiscordCommandInput(cmd);
                    }}
                    className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-zinc-300 text-[10px] font-mono"
                  >
                    {cmd}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. LIMITS, QUOTAS & MONETIZATION ENGINE                        */}
      {/* ============================================================== */}
      {targetPlatform === "limits" && (
        <div className="bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-white/10 rounded-3xl p-6 sm:p-8 shadow-sm space-y-8">
          <div className="flex items-center justify-between pb-4 border-b border-zinc-100 dark:border-white/5">
            <div>
              <h3 className="text-xl font-black text-zinc-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-amber-500" />
                <span>Движок Лимитов, Прав и Возможностей</span>
              </h3>
              <p className="text-xs text-zinc-500 mt-1">
                Единый центр управления квотами для сайтов, ботов и дискорд-серверов. Изменения вступают в силу мгновенно.
              </p>
            </div>
            <span className="text-xs font-bold text-amber-500 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/20">
              Quotas Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Daily Quota Slider */}
            <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                  Суточный лимит треков
                </label>
                <span className="text-sm font-black font-mono text-purple-600 dark:text-purple-400">
                  {limitsConfig.dailyLimit} треков/день
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                value={limitsConfig.dailyLimit}
                onChange={e => setLimitsConfig(prev => ({ ...prev, dailyLimit: parseInt(e.target.value) || 1 }))}
                className="w-full accent-purple-600"
              />
              <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                <span>1 (Демо)</span>
                <span>25 (Стандарт)</span>
                <span>100 (VIP)</span>
              </div>
            </div>

            {/* Quality Selector */}
            <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 space-y-3">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">
                Качество звука
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "192k", label: "192k MP3" },
                  { id: "320k", label: "320k HQ" },
                  { id: "lossless", label: "FLAC 24-bit" }
                ].map(q => (
                  <button
                    key={q.id}
                    onClick={() => setLimitsConfig(prev => ({ ...prev, quality: q.id as any }))}
                    className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all text-center ${
                      limitsConfig.quality === q.id
                        ? "border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400"
                        : "border-zinc-200 dark:border-white/10 text-zinc-600 dark:text-zinc-400"
                    }`}
                  >
                    {q.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Anti-spam Cooldown */}
            <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                  Задержка между запросами
                </label>
                <span className="text-sm font-black font-mono text-blue-500">
                  {limitsConfig.cooldownSec} сек
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                value={limitsConfig.cooldownSec}
                onChange={e => setLimitsConfig(prev => ({ ...prev, cooldownSec: parseInt(e.target.value) || 0 }))}
                className="w-full accent-blue-600"
              />
              <p className="text-[11px] text-zinc-500">
                Защита от флуда и спама в ботах и на сайтах.
              </p>
            </div>
          </div>

          {/* Channel Subscription Gate */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-950/30 to-purple-950/30 border border-blue-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-blue-400" />
                <h4 className="font-bold text-white text-sm">Обязательная подписка на Telegram-канал (Монетизация & Аудитория)</h4>
              </div>
              <input
                type="checkbox"
                checked={limitsConfig.forceSubscription}
                onChange={e => setLimitsConfig(prev => ({ ...prev, forceSubscription: e.target.checked }))}
                className="w-5 h-5 accent-blue-600 rounded"
              />
            </div>
            <p className="text-xs text-zinc-400">
              Если включено, пользователь не сможет скачивать музыку или запускать треки, пока не подпишется на ваш официальный канал спонсора или лейбла.
            </p>
            {limitsConfig.forceSubscription && (
              <div className="flex items-center gap-2 max-w-md">
                <span className="text-sm text-zinc-400 font-mono">@</span>
                <input
                  type="text"
                  value={limitsConfig.channelUsername}
                  onChange={e => setLimitsConfig(prev => ({ ...prev, channelUsername: e.target.value.replace(/^@/, '') }))}
                  placeholder="username_вашего_канала"
                  className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-black/40 text-white font-mono"
                />
              </div>
            )}
          </div>

          {/* Reset Simulated Quota for testing */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
            <div>
              <div className="text-sm font-bold text-zinc-800 dark:text-zinc-200">Тестирование счётчика лимитов</div>
              <div className="text-xs text-zinc-500">
                Текущий расход в сессии симулятора: <b>{userSimulationState.usedToday}</b> из <b>{limitsConfig.dailyLimit}</b> треков
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setUserSimulationState(prev => ({ ...prev, usedToday: 0 }))}
                className="px-3 py-1.5 rounded-xl bg-zinc-200 dark:bg-white/10 hover:bg-zinc-300 dark:hover:bg-white/20 text-xs font-bold text-zinc-800 dark:text-zinc-200"
              >
                Сбросить на 0
              </button>
              <button
                onClick={() => setUserSimulationState(prev => ({ ...prev, usedToday: limitsConfig.dailyLimit }))}
                className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 text-xs font-bold border border-red-500/20"
              >
                Исчерпать лимит
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
