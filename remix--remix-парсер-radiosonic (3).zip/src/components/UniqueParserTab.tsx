import React, { useState, useRef, useEffect } from "react";
import { 
  Search, Loader2, Check, Copy, Disc, Download, FileText, ExternalLink,
  Upload, FileCode, X, Sparkles, AlertCircle, RefreshCw, CheckCircle2,
  Calendar, User, Music, Tag, FileCheck, Layers, Eye, Play, Pause,
  Volume2, VolumeX, SkipBack, SkipForward, Music2, Headphones, Radio,
  ShieldCheck, Terminal, ClipboardPaste, Lock
} from "lucide-react";
import { OkRuIcon, SpotifyIcon, YandexMusicIcon, YoutubeMusicIcon } from "./Icons";
import { PrivateAccessGate } from "./PrivateAccessGate";
import { generateReleaseSheetPdf } from "../lib/pdfGenerator";

interface ParsedReleaseResult {
  success?: boolean;
  found?: boolean;
  notFound?: boolean;
  entityType?: "single" | "album";
  platform?: "okru" | "yandex" | "spotify" | "youtube" | "apple" | "deezer" | "vk" | "zvuk" | "isrc" | "upc" | "search";
  title?: string;
  artists?: string;
  pseudonym?: string;
  albumTitle?: string;
  releaseDate?: string;
  year?: number | string;
  coverUri?: string;
  cover3000?: string;
  isrc?: string;
  upc?: string;
  authorsMusic?: string;
  authorsText?: string;
  durationMs?: number;
  copyright?: string | null;
  pLine?: string | null;
  cLine?: string | null;
  copyrightOwnerName?: string | null;
  copyrightOwnerId?: number | string | null;
  label?: string | null;
  distributor?: string | null;
  playUrl?: string | null;
  releaseId?: number | string | null;
  idForDownload?: number | string | null;
  umaPayload?: string | null;
  track?: any;
  tracks?: Array<{
    id?: string | number;
    trackNumber?: number;
    title: string;
    artists?: string;
    pseudonym?: string;
    authorsMusic?: string;
    authorsText?: string;
    isrc?: string;
    upc?: string;
    durationMs?: number;
    playUrl?: string;
    copyright?: string;
    copyrightOwnerName?: string;
    copyrightOwnerId?: number | string;
  }>;
  message?: string;
  error?: string;
  deepScan?: any;
}

export function UniqueParserTab({ 
  t, 
  hasOkRuSession, 
  okRuUserName, 
  onShowOkRuLogin, 
  onDisconnectOkRu 
}: { 
  t: (key: string, fallback?: string) => string;
  hasOkRuSession: boolean;
  okRuUserName: string | null;
  onShowOkRuLogin: () => void;
  onDisconnectOkRu: () => void;
}) {
  // Private Circle Access State (Вход в закрытый парсер)
  const [hasPrivateAccess, setHasPrivateAccess] = useState<boolean>(() => {
    try {
      return localStorage.getItem("private_circle_auth") === "true";
    } catch (e) {
      return false;
    }
  });
  const [privateAccessKey, setPrivateAccessKey] = useState<string>(() => {
    try {
      return localStorage.getItem("private_circle_key") || "";
    } catch (e) {
      return "";
    }
  });

  const [inputMode, setInputMode] = useState<"link" | "devtools" | "json_file">("link");
  const [url, setUrl] = useState("");
  const [jsonText, setJsonText] = useState("");
  const [devtoolsText, setDevtoolsText] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ParsedReleaseResult | null>(null);
  const [error, setError] = useState("");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Audio Player State
  const [currentTrack, setCurrentTrack] = useState<{
    id?: string | number;
    title: string;
    artists?: string;
    isrc?: string;
    playUrl?: string;
    durationMs?: number;
    trackNumber?: number;
    copyrightOwnerName?: string | null;
    copyrightOwnerId?: number | string | null;
  } | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [audioLoading, setAudioLoading] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Update current track when result arrives
  useEffect(() => {
    if (result) {
      if (result.tracks && result.tracks.length > 0) {
        const first = result.tracks[0];
        const pUrl = first.playUrl || `/api/music/download/${first.id || encodeURIComponent(first.title)}?title=${encodeURIComponent(first.title)}&artists=${encodeURIComponent(first.pseudonym || first.artists || result.artists || '')}&isrc=${first.isrc || ''}&upc=${result.upc || ''}`;
        setCurrentTrack({
          id: first.id,
          title: first.title,
          artists: first.pseudonym || first.artists || result.artists,
          isrc: first.isrc,
          playUrl: pUrl,
          durationMs: first.durationMs,
          trackNumber: first.trackNumber || 1,
          copyrightOwnerName: first.copyrightOwnerName || result.copyrightOwnerName,
          copyrightOwnerId: first.copyrightOwnerId || result.copyrightOwnerId
        });
      } else if (result.title) {
        const pUrl = result.playUrl || `/api/music/download/${encodeURIComponent(result.title)}?title=${encodeURIComponent(result.title)}&artists=${encodeURIComponent(result.pseudonym || result.artists || '')}&isrc=${result.isrc || ''}&upc=${result.upc || ''}`;
        setCurrentTrack({
          id: result.isrc || result.title,
          title: result.title,
          artists: result.pseudonym || result.artists,
          isrc: result.isrc,
          playUrl: pUrl,
          durationMs: result.durationMs,
          trackNumber: 1,
          copyrightOwnerName: result.copyrightOwnerName,
          copyrightOwnerId: result.copyrightOwnerId
        });
      }
      setIsPlaying(false);
      setCurrentTime(0);
    }
  }, [result]);

  const copyToClipboard = (text: string, key: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => {
      setCopiedKey((prev) => (prev === key ? null : prev));
    }, 2000);
  };

  const handleCopyAll = () => {
    if (!result) return;
    const lines = [
      `🎵 Название: ${result.title || "—"}`,
      `👤 Псевдоним / Исполнитель: ${result.pseudonym || result.artists || "—"}`,
      result.albumTitle ? `💿 Альбом: ${result.albumTitle}` : null,
      `📅 Дата релиза: ${result.releaseDate || result.year || "—"}`,
      `🏷️ ISRC: ${result.isrc || "—"}`,
      `📊 UPC: ${result.upc || "—"}`,
      `🎼 Автор музыки: ${result.authorsMusic || "—"}`,
      `✍️ Автор текста: ${result.authorsText || "—"}`,
      `🏢 Лейбл (загрузивший релиз): ${result.label || "—"}`,
      result.distributor ? `🚀 Дистрибьютор: ${result.distributor}` : null,
      `🟠 COPYRIGHT (издатель — проверено на OK.RU): ${result.copyright || (result.copyrightOwnerName ? `℗ ${result.year || ''} ${result.copyrightOwnerName}` : null) || "Не найден на OK.RU"}`,
      result.copyrightOwnerId ? `🆔 Copyright Owner ID: ${result.copyrightOwnerId}` : null,
      result.cover3000 || result.coverUri ? `🖼️ Обложка (3000x3000): ${result.cover3000 || result.coverUri}` : null,
    ].filter(Boolean).join("\n");

    copyToClipboard(lines, "all");
  };

  const handleDownloadTxtReport = () => {
    if (!result) return;
    const tracksList = result.tracks?.length 
      ? result.tracks.map((trk, i) => 
          `[Трек ${i + 1}] ${trk.title}\n` +
          `  Исполнитель/Псевдоним: ${trk.pseudonym || trk.artists || result.artists || "—"}\n` +
          `  ISRC: ${trk.isrc || "—"}\n` +
          `  Автор музыки: ${trk.authorsMusic || result.authorsMusic || "—"}\n` +
          `  Автор текста: ${trk.authorsText || result.authorsText || "—"}\n` +
          `  Лейбл: ${trk.label || result.label || "—"}\n` +
          `  COPYRIGHT (OK.RU): ${trk.copyright || (trk.copyrightOwnerName ? `℗ ${result.year || ''} ${trk.copyrightOwnerName}` : null) || result.copyright || (result.copyrightOwnerName ? `℗ ${result.year || ''} ${result.copyrightOwnerName}` : null) || "Не найден"}\n`
        ).join("\n")
      : "Одиночный релиз (Single)";

    const reportContent = `========================================================
ОТЧЁТ О РЕЛИЗЕ (МУЛЬТИПЛАТФОРМЕННЫЙ ПАРСЕР)
Платформы: OK.RU / Яндекс Музыка / Spotify / YouTube Music
========================================================
Название: ${result.title || "—"}
Псевдоним / Исполнитель: ${result.pseudonym || result.artists || "—"}
Альбом: ${result.albumTitle || "—"}
Дата релиза: ${result.releaseDate || result.year || "—"}
ISRC: ${result.isrc || "—"}
UPC: ${result.upc || "—"}
Автор музыки (Композитор): ${result.authorsMusic || "—"}
Автор текста (Слова): ${result.authorsText || "—"}
Лейбл (загрузивший релиз): ${result.label || "—"}
Дистрибьютор: ${result.distributor || "—"}
--------------------------------------------------------
COPYRIGHT (издатель — проверено на OK.RU): ${result.copyright || (result.copyrightOwnerName ? `℗ ${result.year || ''} ${result.copyrightOwnerName}` : null) || "Не найден на OK.RU"}
Copyright Owner ID (OK.RU): ${result.copyrightOwnerId || "—"}
Прямая ссылка на обложку 3000x3000: ${result.cover3000 || result.coverUri || "—"}
--------------------------------------------------------
ТРЕКИ В РЕЛИЗЕ (${result.tracks?.length || 1}):
${tracksList}
========================================================
`;

    const blob = new Blob([reportContent], { type: "text/plain;charset=utf-8" });
    const urlBlob = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = urlBlob;
    link.download = `release_${(result.title || "metadata").replace(/[\s/\\?%*:|"<>]+/g, "_")}.txt`;
    link.click();
    URL.revokeObjectURL(urlBlob);
  };

  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const handleExportPdf = async () => {
    if (!result) return;
    setIsExportingPdf(true);
    try {
      await generateReleaseSheetPdf(result, { lang: "ru" });
    } catch (err) {
      console.error("Failed to generate release sheet PDF:", err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleDownloadCover = async (coverUrl: string) => {
    if (!coverUrl) return;
    try {
      const res = await fetch(coverUrl);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `cover_3000x3000_${(result?.title || "release").replace(/[\s/\\?%*:|"<>]+/g, "_")}.jpg`;
      link.click();
      URL.revokeObjectURL(blobUrl);
    } catch (e) {
      window.open(coverUrl, "_blank");
    }
  };

  const handleDownloadAudio = (audioUrl: string | undefined, title: string, format: "mp3" | "wav", trackId?: string | number, isrc?: string) => {
    const safeTitle = (title || "track").replace(/[/\\?%*:|"<>]/g, "-").trim() || "track";
    let targetUrl = "";
    if (format === "wav") {
      targetUrl = `/api/music/download-wav?url=${encodeURIComponent(audioUrl || "")}&id=${encodeURIComponent(String(trackId || ""))}&title=${encodeURIComponent(safeTitle)}&isrc=${encodeURIComponent(isrc || "")}`;
    } else {
      if (audioUrl && audioUrl.startsWith("http")) {
        targetUrl = audioUrl;
      } else {
        targetUrl = `/api/music/download/${trackId || encodeURIComponent(safeTitle)}?format=mp3&download=true&title=${encodeURIComponent(safeTitle)}&isrc=${encodeURIComponent(isrc || "")}`;
      }
    }

    const a = document.createElement("a");
    a.href = targetUrl;
    a.download = `${safeTitle}.${format}`;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try { document.body.removeChild(a); } catch (e) {}
    }, 250);
  };

  // Audio Playback Controls
  const togglePlay = () => {
    if (!audioRef.current || !currentTrack?.playUrl) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      setAudioLoading(true);
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setAudioLoading(false);
      }).catch((e) => {
        console.warn("Playback error:", e);
        setIsPlaying(false);
        setAudioLoading(false);
      });
    }
  };

  const handleSelectTrack = (trk: any, index: number) => {
    const trackPlayUrl = trk.playUrl || `/api/music/download/${trk.id || encodeURIComponent(trk.title)}?title=${encodeURIComponent(trk.title)}&artists=${encodeURIComponent(trk.pseudonym || trk.artists || result?.artists || '')}&isrc=${trk.isrc || ''}&upc=${result?.upc || ''}`;
    const newTrack = {
      id: trk.id || `trk_${index + 1}`,
      title: trk.title,
      artists: trk.pseudonym || trk.artists || result?.artists,
      isrc: trk.isrc,
      playUrl: trackPlayUrl,
      durationMs: trk.durationMs,
      trackNumber: trk.trackNumber || index + 1,
      copyrightOwnerName: trk.copyrightOwnerName || result?.copyrightOwnerName,
      copyrightOwnerId: trk.copyrightOwnerId || result?.copyrightOwnerId
    };
    setCurrentTrack(newTrack);
    setIsPlaying(true);
    setAudioLoading(true);
    if (audioRef.current) {
      audioRef.current.src = trackPlayUrl;
      audioRef.current.play()
        .then(() => setAudioLoading(false))
        .catch(() => {
          setIsPlaying(false);
          setAudioLoading(false);
        });
    }
  };

  const handlePrevTrack = () => {
    if (!result?.tracks || result.tracks.length <= 1 || !currentTrack) return;
    const currentIndex = result.tracks.findIndex(t => t.title === currentTrack.title);
    const prevIndex = currentIndex > 0 ? currentIndex - 1 : result.tracks.length - 1;
    handleSelectTrack(result.tracks[prevIndex], prevIndex);
  };

  const handleNextTrack = () => {
    if (!result?.tracks || result.tracks.length <= 1 || !currentTrack) return;
    const currentIndex = result.tracks.findIndex(t => t.title === currentTrack.title);
    const nextIndex = currentIndex < result.tracks.length - 1 ? currentIndex + 1 : 0;
    handleSelectTrack(result.tracks[nextIndex], nextIndex);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
      setIsMuted(val === 0);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume || 0.85;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const executeParse = async (payloadString: string) => {
    if (!payloadString.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    setIsPlaying(false);

    try {
      const res = await fetch("/api/music/universal-parse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: payloadString.trim(), mode: "auto" }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || data.message || "Не удалось обработать запрос.");
      }

      if (data.notFound) {
        setError(data.message || "Метаданные или релиз не найдены.");
      } else {
        setResult(data);
      }
    } catch (err: any) {
      setError(err.message || "Ошибка при парсинге. Проверьте данные и повторите попытку.");
    } finally {
      setLoading(false);
    }
  };

  const handleLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    executeParse(url);
  };

  const handleJsonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jsonText.trim()) return;
    executeParse(jsonText);
  };

  const handleDevToolsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!devtoolsText.trim()) return;
    executeParse(devtoolsText);
  };

  const handlePasteDevTools = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setDevtoolsText(text);
        executeParse(text);
      }
    } catch (e) {
      setError("Не удалось автоматически прочитать буфер обмена. Пожалуйста, вставьте текст с помощью Ctrl+V в поле ниже.");
    }
  };

  const loadScreenshotSample = () => {
    const sample = JSON.stringify({
      albums: [{ id: 123006510465992, ensemble: "slava platit, brxzilec", name: "КРУЖИТ X MYLANCORE HOODTRAP" }],
      commercial: true,
      commercialGenre: 10,
      commercialUserType: 3,
      country: "RU",
      image: "https://i.mycdn.me/image?id=123006510465992&t=50&plc=WEB&tkn=*sample",
      play: "https://musicd.okcdn.ru/v0/stream/sample.mp3",
      track: {
        id: 123435560199294,
        albumId: 123006510465992,
        copyrightOwnerId: 159,
        copyrightOwnerName: "SP DIGITAL",
        ctx: "album:123006510465992|1",
        duration: 166,
        editRestricted: true,
        ensemble: "slava platit, brxzilec",
        giftPrice: 7,
        idForDownload: 125784866808286,
        imageUrl: "https://i.mycdn.me/image?id=123006510465992&t=50&plc=WEB&tkn=*sample",
        isDownloadAllowed: true,
        masterArtistId: -1809132430,
        name: "КРУЖИТ X MYLANCORE HOODTRAP",
        releaseId: 154021500,
        size: 6672717,
        umaPayload: "{\n  \"uma\": true\n}"
      }
    }, null, 2);
    setDevtoolsText(sample);
    executeParse(sample);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processJsonFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processJsonFile(files[0]);
    }
  };

  const processJsonFile = (file: File) => {
    setUploadedFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      if (content) {
        setJsonText(content);
        executeParse(content);
      }
    };
    reader.onerror = () => {
      setError("Ошибка чтения файла JSON.");
    };
    reader.readAsText(file);
  };

  const quickSamples = [
    { label: "Яндекс Музыка", url: "https://music.yandex.ru/album/32770244/track/128670559" },
    { label: "Spotify", url: "https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT" },
    { label: "YouTube Music", url: "https://music.youtube.com/watch?v=kXYiU_JCYtU" },
    { label: "OK.ru Трек", url: "https://ok.ru/music/track/123429066867960" }
  ];

  return (
    <div className="flex flex-col h-full bg-[#fbfbfb] dark:bg-[#0e0e10] text-zinc-900 dark:text-zinc-100 overflow-y-auto font-sans">
      
      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        src={currentTrack?.playUrl}
        onTimeUpdate={() => {
          if (audioRef.current) setCurrentTime(audioRef.current.currentTime);
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) setDuration(audioRef.current.duration || 0);
          setAudioLoading(false);
        }}
        onEnded={() => {
          setIsPlaying(false);
          handleNextTrack();
        }}
        onError={() => {
          setAudioLoading(false);
          setIsPlaying(false);
        }}
      />

      {/* Minimalist Top Bar */}
      <div className="px-6 py-5 border-b border-zinc-200/80 dark:border-white/[0.08] bg-white/90 dark:bg-[#141417]/90 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-semibold tracking-tight text-zinc-900 dark:text-white">
                Универсальный парсер релизов
              </h2>
              <div className="flex items-center gap-1">
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-white/10 text-zinc-600 dark:text-zinc-300">
                  <YandexMusicIcon className="w-3 h-3" /> Яндекс
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-white/10 text-zinc-600 dark:text-zinc-300">
                  <SpotifyIcon className="w-3 h-3" /> Spotify
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  <OkRuIcon className="w-3 h-3" /> OK.RU
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-white/10 text-zinc-600 dark:text-zinc-300">
                  <YoutubeMusicIcon className="w-3 h-3" /> YouTube
                </span>
              </div>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
              Обложки 3000x3000, коды UPC и ISRC, авторы музыки и текста, дата релиза, псевдоним и COPYRIGHT из OK.RU
            </p>
          </div>

          {/* Action badges: Private Circle & OK.RU Session */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Private Circle Status */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-600 dark:text-amber-400 text-xs font-semibold shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span>{t("Circle Access", "Закрытый круг")}: <span className="font-mono text-zinc-700 dark:text-zinc-200">{privateAccessKey || "VIP"}</span></span>
              <button
                onClick={() => {
                  try {
                    localStorage.removeItem("private_circle_auth");
                    localStorage.removeItem("private_circle_key");
                  } catch (e) {}
                  setHasPrivateAccess(false);
                  setPrivateAccessKey("");
                }}
                className="ml-1 p-1 hover:bg-amber-500/20 rounded-md text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
                title={t("Lock parser & exit closed circle", "Заблокировать парсер / Сменить инвайт-код")}
              >
                <Lock className="w-3 h-3" />
              </button>
            </div>

            {!hasOkRuSession ? (
              <button
                id="btn-okru-auth"
                onClick={onShowOkRuLogin}
                className="text-xs font-medium bg-orange-500 hover:bg-orange-600 text-white py-1.5 px-3.5 rounded-xl transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
              >
                <OkRuIcon className="w-3.5 h-3.5 fill-current" />
                <span>Авторизация OK.ru</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 py-1 px-2.5 rounded-xl text-xs text-emerald-600 dark:text-emerald-400">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="font-medium">{okRuUserName || "Сессия OK.ru"}</span>
                <button
                  onClick={onDisconnectOkRu}
                  title="Отключить"
                  className="text-zinc-400 hover:text-red-500 transition-colors ml-1"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="p-6 max-w-5xl w-full mx-auto space-y-6 flex-1">
        
        {/* Input Switcher */}
        <div className="bg-white dark:bg-[#141417] p-5 rounded-2xl border border-zinc-200/80 dark:border-white/[0.08] shadow-sm">
          
          <div className="flex items-center gap-2 border-b border-zinc-100 dark:border-white/[0.06] pb-3 mb-4">
            <button
              type="button"
              onClick={() => setInputMode("link")}
              className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                inputMode === "link"
                  ? "bg-orange-500 text-white shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5"
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>Ссылка / Поиск</span>
            </button>

            <button
              type="button"
              onClick={() => setInputMode("devtools")}
              className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                inputMode === "devtools"
                  ? "bg-orange-500 text-white shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5"
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>DevTools Play (Сеть)</span>
            </button>

            <button
              type="button"
              onClick={() => setInputMode("json_file")}
              className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                inputMode === "json_file"
                  ? "bg-orange-500 text-white shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5"
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Файл JSON из OK.ru</span>
            </button>
          </div>

          {/* Mode 1: Link or Query */}
          {inputMode === "link" && (
            <form onSubmit={handleLinkSubmit} className="space-y-4">
              <div className="relative">
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="Вставьте ссылку на трек/альбом (Spotify, Яндекс Музыка, OK.RU, YouTube) или UPC / ISRC..."
                  className="w-full pl-11 pr-32 py-3.5 bg-zinc-50 dark:bg-[#1a1a1e] border border-zinc-200 dark:border-white/[0.1] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-zinc-900 dark:text-white placeholder-zinc-400"
                />
                <Search className="w-4 h-4 text-zinc-400 absolute left-4 top-1/2 -translate-y-1/2" />
                
                <button
                  type="submit"
                  disabled={loading || !url.trim()}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Парсинг...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Извлечь всё</span>
                    </>
                  )}
                </button>
              </div>

              {/* Samples */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[11px] text-zinc-400">Примеры:</span>
                {quickSamples.map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setUrl(sample.url);
                      executeParse(sample.url);
                    }}
                    className="text-[11px] font-medium px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-white/5 hover:bg-zinc-200 dark:hover:bg-white/10 text-zinc-600 dark:text-zinc-400 transition-colors"
                  >
                    {sample.label}
                  </button>
                ))}
              </div>
            </form>
          )}

          {/* Mode 2: DevTools Network Play */}
          {inputMode === "devtools" && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-orange-500/10 border border-orange-500/20 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                <div className="text-zinc-700 dark:text-zinc-300">
                  <span className="font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider block mb-1">
                    Авто-извлечение из вкладки Network / Play
                  </span>
                  Скопируйте в DevTools ответ на запрос <code className="px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono text-orange-500">web-api/music/play</code> (или Preview/Response) и вставьте сюда. Система мгновенно извлечет <strong className="text-orange-600 dark:text-orange-300">copyrightOwnerName</strong>, <strong className="text-orange-600 dark:text-orange-300">idForDownload</strong>, аудиопоток и метаданные.
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handlePasteDevTools}
                    className="px-3 py-1.5 bg-white dark:bg-[#1a1a1e] border border-zinc-200 dark:border-white/10 hover:border-orange-500 text-zinc-700 dark:text-zinc-200 font-medium rounded-lg transition-colors flex items-center gap-1.5 text-xs shadow-sm"
                  >
                    <ClipboardPaste className="w-3.5 h-3.5 text-orange-500" />
                    <span>Вставить из буфера</span>
                  </button>
                  <button
                    type="button"
                    onClick={loadScreenshotSample}
                    className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white font-medium rounded-lg transition-colors flex items-center gap-1.5 text-xs shadow-sm"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Пример SP DIGITAL</span>
                  </button>
                </div>
              </div>

              <form onSubmit={handleDevToolsSubmit} className="space-y-3">
                <textarea
                  rows={5}
                  value={devtoolsText}
                  onChange={(e) => setDevtoolsText(e.target.value)}
                  placeholder={`Вставьте JSON или JS Preview из DevTools Network:\n{\n  "commercial": true,\n  "play": "https://musicd.okcdn.ru/...",\n  "track": {\n    "copyrightOwnerName": "SP DIGITAL",\n    "copyrightOwnerId": 159,\n    "idForDownload": 125784866808286,\n    "releaseId": 154021500\n  }\n}`}
                  className="w-full p-3 font-mono text-xs bg-zinc-50 dark:bg-[#1a1a1e] border border-zinc-200 dark:border-white/[0.1] rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-zinc-900 dark:text-white leading-relaxed"
                />
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-400">
                    {devtoolsText ? `${devtoolsText.length} символов` : "Поддерживаются JSON, JS-объекты и cURL команды"}
                  </span>
                  <button
                    type="submit"
                    disabled={loading || !devtoolsText.trim()}
                    className="px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Парсинг данных...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Извлечь Copyright & Play</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Mode 2: Drag and Drop JSON */}
          {inputMode === "json_file" && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleFileDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
                  isDragging 
                    ? "border-orange-500 bg-orange-500/5" 
                    : "border-zinc-200 dark:border-white/10 hover:border-zinc-300 dark:hover:border-white/20 bg-zinc-50/50 dark:bg-[#1a1a1e]/50"
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept=".json,application/json,text/plain"
                  className="hidden"
                />
                
                <Upload className="w-8 h-8 text-zinc-400 mx-auto mb-3" />
                <div className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                  {uploadedFileName ? uploadedFileName : "Перетащите JSON файл из OK.ru или нажмите для выбора"}
                </div>
                <div className="text-xs text-zinc-400 mt-1">
                  Поддерживаются сохранённые ответы API OK.RU (с полями track, album, trackSet, etc.)
                </div>
              </div>

              {jsonText && (
                <form onSubmit={handleJsonSubmit} className="space-y-2">
                  <textarea
                    rows={4}
                    value={jsonText}
                    onChange={(e) => setJsonText(e.target.value)}
                    placeholder="Или вставьте текст JSON напрямую..."
                    className="w-full p-3 font-mono text-xs bg-zinc-50 dark:bg-[#1a1a1e] border border-zinc-200 dark:border-white/[0.1] rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-zinc-900 dark:text-white"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={loading || !jsonText.trim()}
                      className="px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 shadow-sm"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Обработка...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Распарсить JSON</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-sm text-red-600 dark:text-red-400">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <div className="flex-1">{error}</div>
            <button onClick={() => setError("")} className="text-red-400 hover:text-red-500">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Loading Spinner */}
        {loading && (
          <div className="p-8 bg-white dark:bg-[#141417] rounded-2xl border border-zinc-200/80 dark:border-white/[0.08] text-center space-y-3">
            <Loader2 className="w-6 h-6 text-orange-500 animate-spin mx-auto" />
            <div className="text-sm font-semibold text-zinc-900 dark:text-white">
              Извлечение метаданных, ISRC кодов и обложки 3000x3000...
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Поиск UPC, ISRC по всем трекам, авторов музыки и текста, проверка официального COPYRIGHT из OK.RU
            </p>
          </div>
        )}

        {/* RESULT PRESENTATION (MINIMALIST & PRECISE) */}
        {result && (
          <div className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-zinc-100 dark:bg-[#141417] dark:border-white/[0.08]">
            <div className="p-6 md:p-10 space-y-8">
              
              {/* Cover & General Actions Header */}
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="w-32 h-32 md:w-44 md:h-44 shrink-0 rounded-3xl overflow-hidden shadow-lg border border-zinc-100 dark:border-zinc-800 relative group">
                  <img
                    src={result.cover3000 || result.coverUri || "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=800&auto=format&fit=crop&q=80"}
                    alt={result.title || "Cover"}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <button
                    type="button"
                    onClick={() => handleDownloadCover(result.cover3000 || result.coverUri || "")}
                    disabled={!result.cover3000 && !result.coverUri}
                    className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white disabled:opacity-0"
                    title="Скачать обложку 3000x3000"
                  >
                    <Download className="w-7 h-7" />
                  </button>
                  <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[9px] font-bold text-white tracking-wider pointer-events-none">
                    3000x3000
                  </div>
                </div>

                <div className="space-y-4 pt-1 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-semibold text-zinc-900 dark:text-white bg-zinc-100 dark:bg-white/10 px-2.5 py-1 rounded-md">
                      {result.entityType === "album" ? "💿 Альбомный релиз" : "🎵 Сингл / Трек"}
                    </span>
                    <span className="text-xs font-bold text-zinc-600 dark:text-zinc-300 bg-zinc-100 dark:bg-white/10 px-2.5 py-1 rounded-md uppercase">
                      {result.platform || "OK.RU"}
                    </span>
                    {result.tracks && result.tracks.length > 0 && (
                      <span className="text-xs font-semibold text-orange-600 dark:text-orange-400 bg-orange-500/10 px-2.5 py-1 rounded-md">
                        {result.tracks.length} треков с ISRC
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyAll}
                      className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 active:scale-95 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
                    >
                      {copiedKey === "all" ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Скопировано!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Копировать всё</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleDownloadTxtReport}
                      className="px-4 py-2 rounded-xl bg-zinc-100 dark:bg-white/10 hover:bg-zinc-200 dark:hover:bg-white/15 text-zinc-700 dark:text-zinc-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Отчёт (.txt)</span>
                    </button>

                    <button
                      id="btn-export-pdf-release-sheet"
                      type="button"
                      onClick={handleExportPdf}
                      disabled={isExportingPdf}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 active:scale-95 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                      title="Экспорт профессионального паспорта релиза в PDF с обложкой и полными метаданными"
                    >
                      {isExportingPdf ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Генерация PDF...</span>
                        </>
                      ) : (
                        <>
                          <FileCheck className="w-4 h-4" />
                          <span>Export as PDF</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* INTEGRATED AUDIO PLAYER */}
              <div className="bg-zinc-900 text-white rounded-2xl p-5 md:p-6 shadow-md border border-zinc-800 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
                      {isPlaying ? (
                        <div className="flex items-end gap-0.5 h-4">
                          <span className="w-1 bg-orange-400 animate-bounce h-3 rounded-full" />
                          <span className="w-1 bg-orange-400 animate-bounce h-4 rounded-full [animation-delay:0.2s]" />
                          <span className="w-1 bg-orange-400 animate-bounce h-2 rounded-full [animation-delay:0.4s]" />
                        </div>
                      ) : (
                        <Music2 className="w-5 h-5 text-orange-400" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="text-xs font-bold text-orange-400 tracking-wider uppercase flex flex-wrap items-center gap-1.5">
                        <span>Аудиоплеер</span>
                        {currentTrack?.trackNumber && (
                          <span className="text-zinc-400">• Трек #{currentTrack.trackNumber}</span>
                        )}
                        {(currentTrack?.copyrightOwnerName || result.copyrightOwnerName) && (
                          <span className="ml-1.5 px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 font-mono text-[10px] font-semibold flex items-center gap-1 border border-orange-500/30">
                            <ShieldCheck className="w-3 h-3 text-orange-400" />
                            <span>Правообладатель OK.RU: <strong>{currentTrack?.copyrightOwnerName || result.copyrightOwnerName}</strong></span>
                            {(currentTrack?.copyrightOwnerId || result.copyrightOwnerId) && (
                              <span className="opacity-75">#{currentTrack?.copyrightOwnerId || result.copyrightOwnerId}</span>
                            )}
                          </span>
                        )}
                      </div>
                      <div className="text-base font-bold text-white truncate">
                        {currentTrack?.title || result.title || "Аудиозапись"}
                      </div>
                      <div className="text-xs text-zinc-400 truncate flex items-center gap-2">
                        <span>{currentTrack?.artists || result.pseudonym || result.artists || "Исполнитель"}</span>
                        {(currentTrack?.isrc || result.isrc) && (
                          <span className="font-mono text-zinc-500">• ISRC: {currentTrack?.isrc || result.isrc}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Player Quick Downloads */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleDownloadAudio(currentTrack?.playUrl, currentTrack?.title || result.title || "track", "mp3", currentTrack?.id, currentTrack?.isrc)}
                      className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-all flex items-center gap-1.5"
                      title="Скачать трек в MP3"
                    >
                      <Download className="w-3.5 h-3.5 text-orange-400" />
                      <span>MP3</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDownloadAudio(currentTrack?.playUrl, currentTrack?.title || result.title || "track", "wav", currentTrack?.id, currentTrack?.isrc)}
                      className="px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-xs font-semibold transition-all flex items-center gap-1.5 border border-indigo-500/30"
                      title="Конвертировать и скачать трек в WAV"
                    >
                      <Download className="w-3.5 h-3.5 text-indigo-400" />
                      <span>WAV</span>
                    </button>
                  </div>
                </div>

                {/* Progress Bar & Seek */}
                <div className="space-y-1.5 pt-1">
                  <input
                    type="range"
                    min={0}
                    max={duration || 30}
                    step={0.1}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-1.5 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                  />
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                    <span>{formatTime(currentTime)}</span>
                    <span>{duration ? formatTime(duration) : (currentTrack?.durationMs ? formatTime(currentTrack.durationMs / 1000) : "0:30")}</span>
                  </div>
                </div>

                {/* Controls & Volume */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
                  <div className="flex items-center gap-3">
                    {result.tracks && result.tracks.length > 1 && (
                      <button
                        type="button"
                        onClick={handlePrevTrack}
                        className="p-2 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white transition-colors"
                        title="Предыдущий трек"
                      >
                        <SkipBack className="w-4 h-4" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={togglePlay}
                      className="w-11 h-11 rounded-full bg-orange-500 hover:bg-orange-600 active:scale-95 text-white flex items-center justify-center transition-all shadow-md"
                      title={isPlaying ? "Пауза" : "Воспроизвести"}
                    >
                      {audioLoading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : isPlaying ? (
                        <Pause className="w-5 h-5 fill-current" />
                      ) : (
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      )}
                    </button>

                    {result.tracks && result.tracks.length > 1 && (
                      <button
                        type="button"
                        onClick={handleNextTrack}
                        className="p-2 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white transition-colors"
                        title="Следующий трек"
                      >
                        <SkipForward className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Volume Slider */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleMute}
                      className="text-zinc-400 hover:text-white transition-colors"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.01}
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-20 md:w-24 h-1.5 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                    />
                  </div>
                </div>
              </div>

              {/* Data List */}
              <div className="space-y-6 md:space-y-8 pt-2">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-100 dark:border-white/10">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    Метаданные релиза & Идентификаторы
                  </span>
                  <button
                    id="btn-export-pdf-in-metadata-section"
                    type="button"
                    onClick={handleExportPdf}
                    disabled={isExportingPdf}
                    className="px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 text-xs font-bold transition-all flex items-center gap-1.5 border border-red-500/20 cursor-pointer disabled:opacity-50"
                    title="Экспорт профессионального паспорта релиза в PDF с обложкой и всеми полями"
                  >
                    {isExportingPdf ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Создание PDF...</span>
                      </>
                    ) : (
                      <>
                        <FileCheck className="w-3.5 h-3.5" />
                        <span>Export as PDF</span>
                      </>
                    )}
                  </button>
                </div>
                
                {result.title && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      TRACK TITLE
                    </div>
                    <div className="text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white tracking-tight flex items-center gap-3">
                      {result.title}
                      <button onClick={() => copyToClipboard(result.title || "", "title")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "title" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {(result.pseudonym || result.artists) && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      ARTIST (PSEUDONYM)
                    </div>
                    <div className="text-xl md:text-2xl font-semibold text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                      {result.pseudonym || result.artists}
                      <button onClick={() => copyToClipboard(result.pseudonym || result.artists || "", "artist")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "artist" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {(result.releaseDate || result.year) && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      RELEASE DATE
                    </div>
                    <div className="text-xl md:text-2xl font-normal text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                      {result.releaseDate || result.year}
                      <button onClick={() => copyToClipboard(result.releaseDate || result.year?.toString() || "", "date")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "date" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {/* RECORD LABEL (ЛЕЙБЛ ЗАГРУЗИВШИЙ РЕЛИЗ) */}
                <div>
                  <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                    ЛЕЙБЛ (ЗАГРУЗИВШИЙ РЕЛИЗ) / RECORD LABEL
                  </div>
                  <div className="text-lg md:text-xl font-medium text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                    <span className={result.label ? "" : "text-zinc-400 dark:text-zinc-500 text-base italic"}>
                      {result.label || "Не указан в источнике"}
                    </span>
                    {result.label && (
                      <button onClick={() => copyToClipboard(result.label || "", "label")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors" title="Копировать лейбл">
                        {copiedKey === "label" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    )}
                  </div>
                </div>

                {result.distributor && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      DISTRIBUTOR
                    </div>
                    <div className="text-lg md:text-xl font-medium text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                      {result.distributor}
                      <button onClick={() => copyToClipboard(result.distributor || "", "distributor")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "distributor" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {/* COPYRIGHT (ИЗДАТЕЛЬ РЕЛИЗА — ПРОВЕРКА ИСКЛЮЧИТЕЛЬНО НА OK.RU) */}
                <div className="p-4 md:p-6 bg-orange-50/70 dark:bg-orange-500/5 rounded-2xl border border-orange-200/70 dark:border-orange-500/20 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-orange-200/50 dark:border-orange-500/10 pb-3">
                    <div className="text-[11px] font-bold text-orange-600 dark:text-orange-400 uppercase tracking-widest flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-orange-500" />
                      <span>COPYRIGHT (ПРОВЕРКА ИСКЛЮЧИТЕЛЬНО НА OK.RU)</span>
                    </div>
                    {result.copyrightOwnerName ? (
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-orange-200/70 dark:bg-orange-950/60 text-orange-900 dark:text-orange-300 font-bold border border-orange-300/60 dark:border-orange-500/30 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        Издатель подтвержден в OK.RU: {result.copyrightOwnerName}
                      </span>
                    ) : (
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-zinc-200/70 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 font-medium border border-zinc-300/60 dark:border-zinc-700">
                        Не найден в реестре OK.RU
                      </span>
                    )}
                  </div>

                  <div>
                    <div className="text-[10px] text-orange-800/70 dark:text-orange-400/70 font-semibold mb-1 uppercase tracking-wider">
                      Издатель релиза (Copyright / P-Line из Одноклассников)
                    </div>
                    <div className="text-xl md:text-3xl font-black text-orange-950 dark:text-orange-200 tracking-tight flex items-center gap-3">
                      {result.copyright || result.copyrightOwnerName ? (
                        <>
                          <span>{result.copyright || (result.copyrightOwnerName ? `℗ ${result.year || ''} ${result.copyrightOwnerName}` : '')}</span>
                          <button 
                            type="button"
                            onClick={() => copyToClipboard(result.copyright || result.copyrightOwnerName || "", "ok_owner")} 
                            className="p-1 rounded-lg text-orange-400 hover:text-orange-600 hover:bg-orange-100 dark:hover:bg-orange-900/30 transition-colors"
                            title="Скопировать copyright издателя"
                          >
                            {copiedKey === "ok_owner" ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                          </button>
                        </>
                      ) : (
                        <span className="text-base font-medium text-zinc-400 dark:text-zinc-500">
                          Не найден на OK.RU
                        </span>
                      )}
                    </div>
                    {result.copyrightOwnerId && (
                      <div className="text-xs text-orange-700/80 dark:text-orange-300/80 mt-1 font-mono font-medium">
                        ID Правообладателя: #{result.copyrightOwnerId}
                      </div>
                    )}
                  </div>

                  {/* DevTools Technical Parameters Grid */}
                  {(result.releaseId || result.idForDownload || result.track?.id || result.track?.albumId || result.umaPayload) && (
                    <div className="pt-2 border-t border-orange-200/40 dark:border-orange-500/10">
                      <div className="text-[10px] font-bold text-orange-700/60 dark:text-orange-400/60 uppercase tracking-wider mb-2">
                        Технические идентификаторы из вкладки Play (DevTools Network)
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                        {result.releaseId && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">Release ID</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-between">
                              <span>{result.releaseId}</span>
                              <button onClick={() => copyToClipboard(String(result.releaseId), "rel_id")} className="text-zinc-400 hover:text-orange-500">
                                {copiedKey === "rel_id" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        )}

                        {result.idForDownload && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">idForDownload</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-between">
                              <span className="truncate">{result.idForDownload}</span>
                              <button onClick={() => copyToClipboard(String(result.idForDownload), "dl_id")} className="text-zinc-400 hover:text-orange-500">
                                {copiedKey === "dl_id" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        )}

                        {result.track?.id && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">Track ID</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-between">
                              <span className="truncate">{result.track.id}</span>
                              <button onClick={() => copyToClipboard(String(result.track.id), "trk_id")} className="text-zinc-400 hover:text-orange-500">
                                {copiedKey === "trk_id" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        )}

                        {result.track?.albumId && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">Album ID</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-between">
                              <span className="truncate">{result.track.albumId}</span>
                              <button onClick={() => copyToClipboard(String(result.track.albumId), "alb_id")} className="text-zinc-400 hover:text-orange-500">
                                {copiedKey === "alb_id" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        )}

                        {result.track?.duration && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">Длительность</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200">
                              {result.track.duration} сек ({Math.floor(result.track.duration / 60)}:{String(result.track.duration % 60).padStart(2, '0')})
                            </div>
                          </div>
                        )}

                        {result.track?.size && (
                          <div className="p-2.5 rounded-xl bg-white/80 dark:bg-black/20 border border-orange-200/40 dark:border-orange-500/10">
                            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">Размер аудиофайла</div>
                            <div className="font-mono text-xs font-bold text-zinc-800 dark:text-zinc-200">
                              {(result.track.size / 1024 / 1024).toFixed(2)} МБ
                            </div>
                          </div>
                        )}
                      </div>

                      {result.umaPayload && (
                        <div className="mt-2.5 p-2.5 rounded-xl bg-white/80 dark:bg-black/30 border border-orange-200/40 dark:border-orange-500/10 flex items-center justify-between text-xs">
                          <span className="text-zinc-500 font-mono text-[11px]">UMA Payload: <code className="text-orange-600 dark:text-orange-300 font-mono">{typeof result.umaPayload === 'string' ? result.umaPayload : JSON.stringify(result.umaPayload)}</code></span>
                          <button 
                            onClick={() => copyToClipboard(typeof result.umaPayload === 'string' ? result.umaPayload : JSON.stringify(result.umaPayload), "uma")}
                            className="px-2 py-1 rounded bg-orange-100 dark:bg-orange-950/50 hover:bg-orange-200 text-orange-700 dark:text-orange-300 text-[10px] font-semibold transition-colors flex items-center gap-1"
                          >
                            {copiedKey === "uma" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                            <span>Копировать</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {result.upc && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      UPC BARCODE
                    </div>
                    <div className="text-2xl md:text-3xl font-mono font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-3">
                      {result.upc}
                      <button onClick={() => copyToClipboard(result.upc || "", "upc")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "upc" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {result.isrc && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      ISRC CODE (MAIN / TRACK 1)
                    </div>
                    <div className="text-2xl md:text-3xl font-mono font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-3">
                      {result.isrc}
                      <button onClick={() => copyToClipboard(result.isrc || "", "isrc")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "isrc" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {result.authorsMusic && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      MUSIC AUTHOR (COMPOSER)
                    </div>
                    <div className="text-lg md:text-xl font-normal text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                      {result.authorsMusic}
                      <button onClick={() => copyToClipboard(result.authorsMusic || "", "music_author")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "music_author" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {result.authorsText && (
                  <div>
                    <div className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                      LYRICS AUTHOR (TEXT)
                    </div>
                    <div className="text-lg md:text-xl font-normal text-zinc-800 dark:text-zinc-200 tracking-tight flex items-center gap-3">
                      {result.authorsText}
                      <button onClick={() => copyToClipboard(result.authorsText || "", "text_author")} className="text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-colors">
                        {copiedKey === "text_author" ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

              </div>
              
              {/* Tracklist table if multi-track album */}
              {result.tracks && result.tracks.length > 0 && (
                <div className="mt-8 border-t border-zinc-100 dark:border-white/[0.08] pt-8 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                      <Layers className="w-4 h-4 text-orange-500" />
                      <span>Треклист релиза ({result.tracks.length} треков)</span>
                    </h4>
                    <span className="text-xs text-zinc-400">
                      Нажмите на любой трек для воспроизведения в плеере
                    </span>
                  </div>
  
                  <div className="divide-y divide-zinc-100 dark:divide-white/[0.06] text-xs">
                    {result.tracks.map((trk, idx) => {
                      const isThisActive = currentTrack?.title === trk.title;
                      return (
                        <div 
                          key={idx} 
                          className={`py-3 flex items-center justify-between gap-3 px-3 rounded-xl transition-all ${
                            isThisActive 
                              ? "bg-orange-500/10 dark:bg-orange-500/15 border border-orange-500/30" 
                              : "hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer" onClick={() => handleSelectTrack(trk, idx)}>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (isThisActive) {
                                  togglePlay();
                                } else {
                                  handleSelectTrack(trk, idx);
                                }
                              }}
                              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                                isThisActive && isPlaying 
                                  ? "bg-orange-500 text-white" 
                                  : "bg-zinc-100 dark:bg-white/10 text-zinc-600 dark:text-zinc-300 hover:bg-orange-500 hover:text-white"
                              }`}
                              title={isThisActive && isPlaying ? "Пауза" : "Воспроизвести"}
                            >
                              {isThisActive && isPlaying ? (
                                <Pause className="w-3.5 h-3.5 fill-current" />
                              ) : (
                                <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                              )}
                            </button>

                            <span className="text-zinc-400 font-mono w-4 shrink-0 text-center">
                              {trk.trackNumber || idx + 1}
                            </span>

                            <div className="min-w-0">
                              <div className={`font-semibold truncate ${isThisActive ? "text-orange-600 dark:text-orange-400" : "text-zinc-900 dark:text-white"}`}>
                                {trk.title}
                              </div>
                              <div className="text-[11px] text-zinc-500 dark:text-zinc-400 flex flex-wrap items-center gap-1.5 mt-0.5">
                                <span>{trk.pseudonym || trk.artists || result.artists}</span>
                                {trk.isrc && (
                                  <>
                                    <span>•</span>
                                    <span className="font-mono bg-zinc-100 dark:bg-white/10 px-1.5 py-0.2 rounded text-[10px] text-zinc-800 dark:text-zinc-200">
                                      ISRC: {trk.isrc}
                                    </span>
                                  </>
                                )}
                                {trk.copyrightOwnerName && (
                                  <>
                                    <span>•</span>
                                    <span className="text-orange-600 dark:text-orange-400 font-medium">
                                      OK.RU: {trk.copyrightOwnerName}
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
    
                          <div className="flex items-center gap-1 shrink-0">
                            {trk.isrc && (
                              <button
                                type="button"
                                onClick={() => copyToClipboard(trk.isrc || "", `isrc_${idx}`)}
                                className="p-1.5 rounded hover:bg-zinc-200 dark:hover:bg-white/10 text-zinc-400 hover:text-zinc-900 dark:hover:text-white text-[11px] font-mono flex items-center gap-1"
                                title="Копировать ISRC"
                              >
                                {copiedKey === `isrc_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => handleDownloadAudio(trk.playUrl, trk.title, "mp3", trk.id, trk.isrc)}
                              className="px-2 py-1 rounded bg-orange-50 dark:bg-orange-500/10 hover:bg-orange-100 dark:hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 text-[11px] font-bold transition-all flex items-center gap-1"
                              title="Скачать MP3"
                            >
                              <Download className="w-3 h-3" />
                              <span>MP3</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDownloadAudio(trk.playUrl, trk.title, "wav", trk.id, trk.isrc)}
                              className="px-2 py-1 rounded bg-indigo-50 dark:bg-indigo-500/10 hover:bg-indigo-100 dark:hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-[11px] font-bold transition-all flex items-center gap-1"
                              title="Скачать WAV"
                            >
                              <Download className="w-3 h-3" />
                              <span>WAV</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Raw JSON Data */}
              <div className="mt-12 bg-[#12141a] rounded-3xl p-6 md:p-8 shadow-inner">
                <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                  <h3 className="text-sm font-bold text-white tracking-widest uppercase">Raw JSON Data</h3>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => copyToClipboard(JSON.stringify(result, null, 2), "raw")}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all flex items-center gap-1"
                    >
                      {copiedKey === "raw" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy JSON</span>
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <pre className="text-xs font-mono text-zinc-400 leading-relaxed max-h-96 overflow-y-auto">
                    {JSON.stringify(result, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
