import { TelegramIcon } from './Icons';
import React, { useEffect, useState, useCallback } from 'react';
import { 
  Send, Check, X, RefreshCw, Download, Trash2, AlertCircle, 
  AlertTriangle, Info, Search, Filter, Terminal, Copy, CheckCheck, 
  ChevronDown, ChevronUp, FileText, Bug, Bot, Sparkles
} from 'lucide-react';
import { TelegramAiBotConfig } from './TelegramAiBotConfig';

interface SystemLogEntry {
  id: string;
  timestamp: string;
  level: 'error' | 'warn' | 'info' | 'debug';
  category: 'yandex' | 'audio' | 'proxy' | 'auth' | 'okru' | 'metadata' | 'client' | 'system' | 'telegram';
  message: string;
  details?: any;
  endpoint?: string;
  status?: number;
}

export const LogsTab = ({ 
  t, 
  logs 
}: { 
  t: (en: string, ru: string) => string;
  logs: {chatId: string, label: string, status: 'queued'|'sent'|'error', errorMessage?: string}[];
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'system' | 'telegram' | 'ai_bot'>('system');
  const [systemLogs, setSystemLogs] = useState<SystemLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [stats, setStats] = useState({ errors: 0, warnings: 0, info: 0, total: 0 });

  const fetchLogs = useCallback(async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedLevel !== 'all') params.append('level', selectedLevel);
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      if (searchQuery.trim()) params.append('search', searchQuery.trim());
      params.append('limit', '300');

      const res = await fetch(`/api/system/logs?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setSystemLogs(data.logs || []);
        if (data.stats) {
          setStats({
            errors: data.stats.errors || 0,
            warnings: data.stats.warnings || 0,
            info: data.stats.info || 0,
            total: data.total || 0
          });
        }
      }
    } catch (e) {
      console.error('Failed to fetch system logs:', e);
    } finally {
      if (!silent) setIsLoading(false);
    }
  }, [selectedLevel, selectedCategory, searchQuery]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  // Auto-refresh interval
  useEffect(() => {
    if (!autoRefresh || activeSubTab !== 'system') return;
    const interval = setInterval(() => {
      fetchLogs(true);
    }, 3000);
    return () => clearInterval(interval);
  }, [autoRefresh, activeSubTab, fetchLogs]);

  const handleClearLogs = async () => {
    if (!window.confirm(t('Are you sure you want to clear all system logs?', 'Вы уверены, что хотите очистить все логи?'))) {
      return;
    }
    try {
      const res = await fetch('/api/system/logs', { method: 'DELETE' });
      if (res.ok) {
        fetchLogs();
      }
    } catch (e) {
      console.error('Failed to clear logs:', e);
    }
  };

  const handleDownloadLogs = (format: 'log' | 'json') => {
    window.open(`/api/system/logs/download?format=${format}`, '_blank');
  };

  const handleCopyLog = (log: SystemLogEntry, e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `[${log.timestamp}] [${log.level.toUpperCase()}] [${log.category.toUpperCase()}] ${log.message}\n` +
      (log.endpoint ? `Endpoint: ${log.endpoint}\n` : '') +
      (log.status ? `Status: ${log.status}\n` : '') +
      (log.details ? `Details: ${JSON.stringify(log.details, null, 2)}` : '');

    navigator.clipboard.writeText(text);
    setCopiedId(log.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatTimestamp = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit', fractionalSecondDigits: 3 });
    } catch {
      return iso;
    }
  };

  return (
    <div className="flex flex-col gap-4 sm:gap-6 max-w-5xl mx-auto w-full px-1 sm:px-0 animate-in fade-in zoom-in-95 duration-300">
      {/* Top Header & Subtabs */}
      <div className="bg-white/70 dark:bg-[#1c1c1e]/70 backdrop-blur-xl p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5 sm:gap-3 text-zinc-900 dark:text-zinc-50">
            <Terminal className="w-6 h-6 sm:w-7 sm:h-7 text-indigo-500 shrink-0" />
            {t("System Diagnostics & Error Logs", "Диагностика и Журнал Ошибок")}
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1 leading-relaxed">
            {t("Real-time telemetry, API exception handler, and one-click log exports.", "Отслеживание ошибок API, потоков аудио и экспорт журнала логов.")}
          </p>
        </div>

        {/* View Switcher Tabs - Mobile scrollable pill bar */}
        <div className="flex items-center gap-1 bg-zinc-100 dark:bg-black/40 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl border border-zinc-200/50 dark:border-white/5 overflow-x-auto no-scrollbar w-full sm:w-auto shrink-0">
          <button
            onClick={() => setActiveSubTab('system')}
            className={`px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap min-h-[38px] ${
              activeSubTab === 'system'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm'
                : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Bug className="w-4 h-4 text-red-500 shrink-0" />
            <span>{t("System & Errors", "Ошибки и Логи")}</span>
            {stats.errors > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] font-black rounded-full bg-red-500 text-white animate-pulse">
                {stats.errors}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('telegram')}
            className={`px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap min-h-[38px] ${
              activeSubTab === 'telegram'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm'
                : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <TelegramIcon className="w-4 h-4 text-blue-500 shrink-0" />
            <span>{t("Telegram Logs", "Telegram")}</span>
            {logs.length > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400">
                {logs.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('ai_bot')}
            className={`px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap min-h-[38px] ${
              activeSubTab === 'ai_bot'
                ? 'bg-white dark:bg-zinc-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Bot className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>{t("AI Bot & Custom API", "ИИ-Бот & API")}</span>
            <span className="px-1.5 py-0.5 text-[9px] font-black rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-300 dark:border-indigo-800">
              24/7
            </span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: SYSTEM & ERROR LOGS */}
      {activeSubTab === 'system' && (
        <div className="flex flex-col gap-3.5 sm:gap-4">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
            <div 
              onClick={() => setSelectedLevel('all')}
              className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all cursor-pointer flex items-center gap-2.5 sm:gap-3 ${
                selectedLevel === 'all' 
                  ? 'bg-zinc-100/90 dark:bg-zinc-800/90 border-zinc-400 dark:border-zinc-600 shadow-xs' 
                  : 'bg-white/60 dark:bg-zinc-900/60 backdrop-blur-md border-zinc-200/50 dark:border-white/10 hover:border-zinc-300'
              }`}
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shrink-0">
                <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-lg sm:text-xl font-black text-zinc-900 dark:text-white truncate">{stats.total}</div>
                <div className="text-[10px] sm:text-xs text-zinc-500 font-medium truncate">{t("Total Events", "Всего")}</div>
              </div>
            </div>

            <div 
              onClick={() => setSelectedLevel(selectedLevel === 'error' ? 'all' : 'error')}
              className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all cursor-pointer flex items-center gap-2.5 sm:gap-3 ${
                selectedLevel === 'error'
                  ? 'bg-red-100/90 dark:bg-red-950/60 border-red-500 dark:border-red-600 shadow-xs'
                  : 'bg-red-50/50 dark:bg-red-950/20 backdrop-blur-md border-red-200/50 dark:border-red-900/30 hover:border-red-300'
              }`}
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-red-100 dark:bg-red-900/40 flex items-center justify-center text-red-600 dark:text-red-400 shrink-0">
                <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-lg sm:text-xl font-black text-red-600 dark:text-red-400 truncate">{stats.errors}</div>
                <div className="text-[10px] sm:text-xs text-red-700/70 dark:text-red-400/70 font-medium truncate">{t("Errors", "Ошибок")}</div>
              </div>
            </div>

            <div 
              onClick={() => setSelectedLevel(selectedLevel === 'warn' ? 'all' : 'warn')}
              className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all cursor-pointer flex items-center gap-2.5 sm:gap-3 ${
                selectedLevel === 'warn'
                  ? 'bg-amber-100/90 dark:bg-amber-950/60 border-amber-500 dark:border-amber-600 shadow-xs'
                  : 'bg-amber-50/50 dark:bg-amber-950/20 backdrop-blur-md border-amber-200/50 dark:border-amber-900/30 hover:border-amber-300'
              }`}
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
                <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-lg sm:text-xl font-black text-amber-600 dark:text-amber-400 truncate">{stats.warnings}</div>
                <div className="text-[10px] sm:text-xs text-amber-700/70 dark:text-amber-400/70 font-medium truncate">{t("Warnings", "Предупрежд.")}</div>
              </div>
            </div>

            <div 
              onClick={() => setSelectedLevel(selectedLevel === 'info' ? 'all' : 'info')}
              className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all cursor-pointer flex items-center gap-2.5 sm:gap-3 ${
                selectedLevel === 'info'
                  ? 'bg-blue-100/90 dark:bg-blue-950/60 border-blue-500 dark:border-blue-600 shadow-xs'
                  : 'bg-blue-50/50 dark:bg-blue-950/20 backdrop-blur-md border-blue-200/50 dark:border-blue-900/30 hover:border-blue-300'
              }`}
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                <Info className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-lg sm:text-xl font-black text-blue-600 dark:text-blue-400 truncate">{stats.info}</div>
                <div className="text-[10px] sm:text-xs text-blue-700/70 dark:text-blue-400/70 font-medium truncate">{t("Info Messages", "Инфо")}</div>
              </div>
            </div>
          </div>

          {/* Filter & Action Toolbar */}
          <div className="bg-white/70 dark:bg-[#1c1c1e]/70 backdrop-blur-xl p-3 sm:p-4 rounded-2xl border border-zinc-200/50 dark:border-white/10 shadow-sm flex flex-col gap-3">
            {/* Search Input */}
            <div className="relative w-full">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder={t("Filter logs by keyword, endpoint, error text...", "Поиск по тексту ошибки, пути, коду...")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-8 py-2.5 bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 outline-none focus:ring-2 focus:ring-indigo-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-zinc-600 dark:hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Quick Filter Pills (Especially thumb-friendly on mobile) */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
              <button
                type="button"
                onClick={() => setSelectedLevel('all')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all ${
                  selectedLevel === 'all'
                    ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900'
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200'
                }`}
              >
                {t("All", "Все")} ({stats.total})
              </button>
              <button
                type="button"
                onClick={() => setSelectedLevel('error')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex items-center gap-1 ${
                  selectedLevel === 'error'
                    ? 'bg-red-600 text-white'
                    : 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100'
                }`}
              >
                <span>🚨 {t("Errors", "Ошибки")}</span>
                <span>({stats.errors})</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedLevel('warn')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex items-center gap-1 ${
                  selectedLevel === 'warn'
                    ? 'bg-amber-500 text-black'
                    : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 hover:bg-amber-100'
                }`}
              >
                <span>⚠️ {t("Warnings", "Предупреждения")}</span>
                <span>({stats.warnings})</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedLevel('info')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex items-center gap-1 ${
                  selectedLevel === 'info'
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100'
                }`}
              >
                <span>ℹ️ {t("Info", "Инфо")}</span>
                <span>({stats.info})</span>
              </button>
            </div>

            {/* Selectors & Actions Grid on Mobile, Flex on Desktop */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-1 border-t border-zinc-100 dark:border-white/5">
              {/* Dropdowns row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 flex-1 min-w-0">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs sm:text-sm font-semibold text-zinc-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 min-h-[38px]"
                >
                  <option value="all">{t("All Categories", "Все категории")}</option>
                  <option value="telegram">Telegram Бот & Сообщения</option>
                  <option value="yandex">Яндекс Музыка API</option>
                  <option value="audio">Аудио / WAV / FFmpeg</option>
                  <option value="metadata">UPC & ISRC парсер</option>
                  <option value="proxy">Прокси & Геолокация</option>
                  <option value="auth">Авторизация</option>
                  <option value="system">Система</option>
                </select>

                <div className="flex items-center gap-1.5">
                  {/* Auto-Refresh Toggle */}
                  <button
                    type="button"
                    onClick={() => setAutoRefresh(!autoRefresh)}
                    title={autoRefresh ? "Автообновление включено (каждые 3 сек)" : "Автообновление выключено"}
                    className={`flex-1 sm:flex-initial px-3 py-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all min-h-[38px] ${
                      autoRefresh
                        ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400'
                        : 'bg-zinc-100 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-500'
                    }`}
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${autoRefresh ? 'animate-spin' : ''}`} />
                    <span>{autoRefresh ? t('Auto 3s: ON', 'Авто: 3с') : t('Auto: OFF', 'Авто: Выкл')}</span>
                  </button>

                  {/* Manual Refresh Button */}
                  <button
                    type="button"
                    onClick={() => fetchLogs()}
                    disabled={isLoading}
                    className="p-2.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 transition-colors min-w-[38px] min-h-[38px] flex items-center justify-center"
                    title="Обновить вручную"
                  >
                    <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Action Buttons: Export & Clear */}
              <div className="flex items-center gap-1.5 shrink-0 pt-1 sm:pt-0">
                <button
                  type="button"
                  onClick={() => handleDownloadLogs('log')}
                  className="flex-1 sm:flex-initial px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all active:scale-95 min-h-[38px]"
                  title="Скачать журнал логов в формате .LOG"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t("Export .LOG", ".LOG")}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadLogs('json')}
                  className="flex-1 sm:flex-initial px-3 py-2 bg-zinc-800 hover:bg-zinc-900 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all min-h-[38px]"
                  title="Скачать журнал логов в формате JSON"
                >
                  <span>JSON</span>
                </button>

                <button
                  type="button"
                  onClick={handleClearLogs}
                  className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-xl transition-colors min-w-[38px] min-h-[38px] flex items-center justify-center"
                  title="Очистить все логи"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Logs List Table / Stream - Mobile Optimized Card Stream */}
          <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl rounded-2xl sm:rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm overflow-hidden">
            {systemLogs.length === 0 ? (
              <div className="p-10 sm:p-16 text-center">
                <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-400 mx-auto mb-3">
                  <Terminal className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm sm:text-base text-zinc-800 dark:text-zinc-200 mb-1">
                  {t("No log entries match your criteria", "Журнал логов пуст или нет совпадений")}
                </h4>
                <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                  {t("System events, API responses, and errors will automatically appear here.", "События и ошибки будут появляться здесь в реальном времени.")}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-zinc-100 dark:divide-white/5 font-mono text-xs">
                {systemLogs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const isError = log.level === 'error';
                  const isWarn = log.level === 'warn';

                  return (
                    <div 
                      key={log.id}
                      onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                      className={`p-3 sm:p-4 transition-colors cursor-pointer hover:bg-zinc-50/80 dark:hover:bg-white/[0.02] ${
                        isError ? 'bg-red-50/30 dark:bg-red-950/10' :
                        isWarn ? 'bg-amber-50/30 dark:bg-amber-950/10' : ''
                      }`}
                    >
                      {/* Responsive Card Content: Header Row with metadata on mobile, then full message */}
                      <div className="flex flex-col gap-2">
                        {/* Meta Bar: Level, Category, Timestamp, Copy & Expand */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-1.5 min-w-0">
                            {/* Severity Badge */}
                            <span className={`px-2 py-0.5 rounded-md font-bold uppercase tracking-wider text-[10px] shrink-0 ${
                              isError ? 'bg-red-500 text-white' :
                              isWarn ? 'bg-amber-500 text-black' :
                              'bg-blue-500 text-white'
                            }`}>
                              {log.level}
                            </span>

                            {/* Category Badge */}
                            <span className="px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 text-[10px] font-semibold shrink-0">
                              {log.category}
                            </span>

                            {/* Timestamp */}
                            <span className="text-zinc-400 dark:text-zinc-500 text-[10px] sm:text-[11px] shrink-0">
                              {formatTimestamp(log.timestamp)}
                            </span>
                          </div>

                          {/* Quick Action Icons */}
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={(e) => handleCopyLog(log, e)}
                              className="p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 min-w-[30px] min-h-[30px] flex items-center justify-center"
                              title="Скопировать запись"
                            >
                              {copiedId === log.id ? (
                                <CheckCheck className="w-3.5 h-3.5 text-emerald-500" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <div className="text-zinc-400 p-1">
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </div>
                          </div>
                        </div>

                        {/* Full-width Log Message */}
                        <div className={`font-medium break-words text-xs sm:text-sm font-sans leading-relaxed ${
                          isError ? 'text-red-700 dark:text-red-300 font-semibold' :
                          isWarn ? 'text-amber-800 dark:text-amber-300' :
                          'text-zinc-800 dark:text-zinc-200'
                        }`}>
                          {log.message}
                        </div>
                      </div>

                      {/* Expandable Details Box */}
                      {isExpanded && (
                        <div className="mt-3 pt-3 border-t border-zinc-200/50 dark:border-white/5 flex flex-col gap-2">
                          {log.endpoint && (
                            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                              <span className="text-zinc-400">Endpoint:</span>
                              <span className="text-indigo-600 dark:text-indigo-400 font-mono break-all">{log.endpoint}</span>
                              {log.status && (
                                <span className="px-1.5 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-bold text-[10px]">
                                  HTTP {log.status}
                                </span>
                              )}
                            </div>
                          )}

                          {log.details && (
                            <div className="p-2.5 sm:p-3 bg-zinc-950 text-emerald-400 rounded-xl overflow-x-auto text-[10px] sm:text-[11px] leading-relaxed shadow-inner">
                              <pre className="whitespace-pre-wrap sm:whitespace-pre break-all sm:break-normal font-mono">
                                {typeof log.details === 'string' ? log.details : JSON.stringify(log.details, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: TELEGRAM BROADCAST LOGS */}
      {activeSubTab === 'telegram' && (
        <div className="bg-white/70 dark:bg-[#1c1c1e]/70 backdrop-blur-xl p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-zinc-200/50 dark:border-white/10 shadow-sm relative overflow-hidden">
          <h3 className="text-lg sm:text-xl font-bold tracking-tight mb-4 flex items-center gap-2.5 sm:gap-3 text-zinc-900 dark:text-zinc-100">
            <TelegramIcon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-500 shrink-0" />
            {t("Telegram Broadcast Logs", "Журнал отправки в Telegram")}
          </h3>
          
          {logs.length === 0 ? (
            <div className="text-center p-8 sm:p-12 text-zinc-500 text-xs sm:text-sm">
              {t("No broadcast logs available. Send a report from the Report tab.", "Журнал пуст. Начните рассылку из вкладки Отчёт.")}
            </div>
          ) : (
            <div className="space-y-2">
              {logs.map((log, i) => (
                <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3 sm:p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/50">
                  <span className="font-semibold text-xs sm:text-sm text-zinc-900 dark:text-zinc-100 break-words">{log.label}</span>
                  <span className={`self-start sm:self-auto text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shrink-0 ${
                    log.status === 'sent' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                    log.status === 'error' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' :
                    'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                  }`}>
                    {log.status === 'sent' && <Check className="w-3.5 h-3.5" />}
                    {log.status === 'error' && <X className="w-3.5 h-3.5" />}
                    {log.status === 'queued' && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    
                    {log.status === 'sent' ? t("Sent", "Отправлено") :
                     log.status === 'error' ? t("Error", "Ошибка") :
                     t("Queued", "В очереди")}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: TELEGRAM AI BOT & CUSTOM API */}
      {activeSubTab === 'ai_bot' && (
        <TelegramAiBotConfig
          t={t}
          onViewTelegramLogs={() => {
            setActiveSubTab('system');
            setSelectedCategory('telegram');
          }}
        />
      )}
    </div>
  );
};

