import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Film, Download, Play, Pause, Volume2, VolumeX, 
  CheckCircle2, AlertCircle, Loader2, Maximize2, Check,
  Music, ExternalLink, Sparkles, Scissors, Layers, PlusCircle
} from 'lucide-react';
import { ProxyImage } from './ProxyImage';
import { PlatformBrandIcon } from './PlatformIcons';

export interface VideoSnapshotModalProps {
  track: any | null;
  isOpen: boolean;
  onClose: () => void;
  onPlayTrack?: (track: any) => void;
  onOpenStudio?: (trackInfo?: { title?: string; artist?: string; coverUrl?: string; audioUrl?: string }) => void;
}

export function VideoSnapshotModal({
  track,
  isOpen,
  onClose,
  onPlayTrack,
  onOpenStudio,
}: VideoSnapshotModalProps) {
  const [loading, setLoading] = useState(true);
  const [snapshotData, setSnapshotData] = useState<any>(null);
  const [activePlatformId, setActivePlatformId] = useState<string>('yandex');
  const [activeTab, setActiveTab] = useState<'video' | 'clip'>('video');
  const [selectedClipIndex, setSelectedClipIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [videoLoadError, setVideoLoadError] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!isOpen || !track) {
      setSnapshotData(null);
      setLoading(false);
      setVideoLoadError(false);
      return;
    }
    setVideoLoadError(false);

    const rawId = String(track.id || '');
    const cleanId = rawId.replace(/^(ya_|track_|t_|sp_|spotify:track:|dz_|deezer:)/, '');
    const platform = track.platform || (rawId.startsWith('sp_') ? 'spotify' : (rawId.startsWith('dz_') ? 'deezer' : 'yandex'));
    const title = track.title || '';
    const artist = Array.isArray(track.artists)
      ? track.artists.map((a: any) => (typeof a === 'string' ? a : a.name)).join(', ')
      : (typeof track.artists === 'string' ? track.artists : '');
    const isrc = track.isrc || '';

    setLoading(true);
    fetch(`/api/music/track/${encodeURIComponent(cleanId)}/video-snapshot?platform=${encodeURIComponent(platform)}&isrc=${encodeURIComponent(isrc)}&title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data && data.success) {
          setSnapshotData(data);
          if (data.availablePlatforms && data.availablePlatforms.length > 0 && data.availablePlatforms.some((p: any) => p.streamUrl)) {
            const firstValid = data.availablePlatforms.find((p: any) => p.streamUrl);
            setActivePlatformId(firstValid.platform);
            setActiveTab('video');
          } else if (data.hasVideoSnapshot && data.videoSnapshot?.streamUrl) {
            setActivePlatformId(data.platform || 'yandex');
            setActiveTab('video');
          } else if (Array.isArray(data.clips) && data.clips.length > 0 && data.clips[0]?.streamUrl) {
            setActiveTab('clip');
          }
        } else {
          setSnapshotData(null);
        }
      })
      .catch((err) => {
        console.error('Error fetching video snapshot:', err);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [isOpen, track]);

  if (!isOpen || !track) return null;

  const title = track.title || snapshotData?.title || 'Трек';
  const artist = Array.isArray(track.artists)
    ? track.artists.map((a: any) => (typeof a === 'string' ? a : a.name)).join(', ')
    : (typeof track.artists === 'string' ? track.artists : (snapshotData?.artist || ''));

  const coverUri = track.coverUri || (Array.isArray(track.albums) && track.albums[0]?.coverUri) || snapshotData?.coverUri;
  const formattedCover = coverUri 
    ? (coverUri.startsWith('http') ? coverUri.replace('%%', '400x400') : `https://${coverUri.replace('%%', '400x400')}`)
    : null;

  const availablePlatforms = snapshotData?.availablePlatforms || [];
  const currentPlatformObj = availablePlatforms.find((p: any) => p.platform === activePlatformId) || availablePlatforms[0];

  const hasSnapshot = Boolean(
    (currentPlatformObj?.streamUrl || snapshotData?.videoSnapshot?.streamUrl) && 
    (currentPlatformObj?.type !== 'snippet' || currentPlatformObj?.hasVideo)
  );

  const clips = snapshotData?.clips || [];
  const hasClips = clips.length > 0;

  const currentVideoUrl = (activeTab === 'video' && currentPlatformObj?.streamUrl)
    ? currentPlatformObj.streamUrl
    : (activeTab === 'video' && snapshotData?.videoSnapshot?.streamUrl)
      ? snapshotData.videoSnapshot.streamUrl
      : (hasClips && clips[selectedClipIndex]?.streamUrl ? clips[selectedClipIndex].streamUrl : null);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const handleDownload = () => {
    const downloadUrl = (activeTab === 'video' && currentPlatformObj?.downloadUrl)
      ? currentPlatformObj.downloadUrl
      : (activeTab === 'video' && snapshotData?.videoSnapshot?.downloadUrl)
        ? snapshotData.videoSnapshot.downloadUrl
        : (hasClips && clips[selectedClipIndex]?.downloadUrl ? clips[selectedClipIndex].downloadUrl : null);

    if (!downloadUrl) return;

    setIsDownloading(true);
    try {
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 2500);
    } catch (err) {
      console.error('Download failed', err);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-[120] flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.22 }}
          className="relative w-full max-w-[420px] h-[92vh] max-h-[820px] bg-black rounded-[32px] overflow-hidden shadow-[0_25px_70px_rgba(0,0,0,0.95)] border border-white/15 flex flex-col justify-between"
          onClick={(e) => e.stopPropagation()}
        >
          {loading ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 text-white/70">
              <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
              <p className="text-sm font-medium">Проверка видеошотов (Яндекс, Spotify Canvas, Deezer)...</p>
            </div>
          ) : (currentVideoUrl && !videoLoadError) ? (
            /* FULL-BLEED VERTICAL VIDEO */
            <>
              {/* Background ambient video glow */}
              <video
                src={currentVideoUrl}
                autoPlay
                loop
                muted
                playsInline
                poster={formattedCover || undefined}
                onError={() => setVideoLoadError(true)}
                className="absolute inset-0 w-full h-full object-cover blur-3xl scale-110 opacity-40 pointer-events-none -z-10"
              />

              {/* Main Full-Size Video Shot */}
              <video
                ref={videoRef}
                src={currentVideoUrl}
                autoPlay
                loop
                muted={isMuted}
                playsInline
                poster={formattedCover || undefined}
                onError={() => setVideoLoadError(true)}
                className="absolute inset-0 w-full h-full object-cover cursor-pointer select-none"
                onClick={togglePlay}
              />

              {/* Top Vignette Gradient */}
              <div className="absolute inset-x-0 top-0 h-36 bg-gradient-to-b from-black/85 via-black/40 to-transparent pointer-events-none z-10" />

              {/* Bottom Vignette Gradient */}
              <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black/95 via-black/70 to-transparent pointer-events-none z-10" />

              {/* Top Floating Controls Bar */}
              <div className="relative z-20 flex items-center justify-between p-4 px-5">
                <button
                  onClick={onClose}
                  className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/15 text-white/80 hover:text-white flex items-center justify-center transition-colors shadow-lg cursor-pointer"
                  title="Закрыть"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-white/90 text-xs font-semibold shadow-lg">
                  <Film className="w-3.5 h-3.5 text-yellow-400" />
                  <span>
                    {activePlatformId === 'spotify' 
                      ? 'Spotify Canvas' 
                      : (activePlatformId === 'deezer' ? 'Deezer Сниппет' : 'Яндекс Видеошот')}
                  </span>
                </div>

                {/* Action buttons: Mute & Fullscreen */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={toggleMute}
                    className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/15 text-white/80 hover:text-white flex items-center justify-center transition-colors shadow-lg cursor-pointer"
                    title={isMuted ? 'Включить звук' : 'Выключить звук'}
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-purple-400" />}
                  </button>
                  <button
                    onClick={handleFullscreen}
                    className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/15 text-white/80 hover:text-white flex items-center justify-center transition-colors shadow-lg cursor-pointer"
                    title="На весь экран"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Center Play/Pause Indicator (shows when paused) */}
              {!isPlaying && (
                <div 
                  className="absolute inset-0 flex items-center justify-center cursor-pointer z-15 select-none"
                  onClick={togglePlay}
                >
                  <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-2xl transition-transform hover:scale-110">
                    <Play className="w-7 h-7 fill-white ml-1" />
                  </div>
                </div>
              )}

              {/* Bottom Floating Info & Actions */}
              <div className="relative z-20 p-5 pt-0 flex flex-col gap-2.5">
                {/* Platform Switcher Chips */}
                {availablePlatforms.length > 1 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                    {availablePlatforms.map((p: any) => (
                      <button
                        key={p.platform}
                        onClick={() => {
                          setActivePlatformId(p.platform);
                          setActiveTab('video');
                        }}
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md transition-all flex items-center gap-1.5 shrink-0 ${
                          activePlatformId === p.platform && activeTab === 'video'
                            ? (p.platform === 'spotify' 
                                ? 'bg-green-600 text-white shadow-md' 
                                : p.platform === 'deezer' 
                                  ? 'bg-purple-600 text-white shadow-md' 
                                  : 'bg-yellow-500 text-black font-bold shadow-md')
                            : 'bg-black/60 text-white/70 hover:text-white border border-white/15'
                        }`}
                      >
                        <PlatformBrandIcon platformId={p.platform} size="sm" />
                        <span>{p.name}</span>
                      </button>
                    ))}
                    {hasClips && clips.map((clip: any, idx: number) => (
                      <button
                        key={clip.clipId || idx}
                        onClick={() => {
                          setActiveTab('clip');
                          setSelectedClipIndex(idx);
                        }}
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md transition-all shrink-0 ${
                          activeTab === 'clip' && selectedClipIndex === idx
                            ? 'bg-red-600 text-white shadow-md'
                            : 'bg-black/60 text-white/70 hover:text-white border border-white/15'
                        }`}
                      >
                        Клип #{idx + 1}
                      </button>
                    ))}
                  </div>
                )}

                {/* Track Details */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {formattedCover && (
                      <div className="w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-white/20 shadow-md">
                        <ProxyImage src={formattedCover} alt="" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-white font-bold text-sm truncate drop-shadow">{title}</p>
                      <p className="text-white/70 text-xs truncate drop-shadow">{artist}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {onPlayTrack && (
                      <button
                        onClick={() => {
                          onPlayTrack(track);
                          onClose();
                        }}
                        className="p-2.5 rounded-full bg-white/15 hover:bg-white/25 text-white backdrop-blur-md border border-white/20 transition-all active:scale-95 shadow-lg"
                        title="Включить в плеере"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Main Download Button */}
                <button
                  onClick={handleDownload}
                  disabled={isDownloading}
                  className={`w-full py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm transition-all shadow-xl active:scale-98 flex items-center justify-center gap-2 cursor-pointer ${
                    downloadSuccess 
                      ? 'bg-emerald-500 text-white'
                      : 'bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 hover:brightness-110 text-black shadow-amber-900/40 font-black'
                  }`}
                >
                  {isDownloading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                      <span>Скачивание видеофайла...</span>
                    </>
                  ) : downloadSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Видео сохранено!</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>
                        {activePlatformId === 'spotify' 
                          ? 'Скачать Spotify Canvas (MP4)' 
                          : activePlatformId === 'deezer' 
                            ? 'Скачать Deezer Сниппет' 
                            : 'Скачать видеошот 404×720 (MP4)'}
                      </span>
                    </>
                  )}
                </button>

                {/* Quick Link to VideoShot Studio */}
                {onOpenStudio && (
                  <button
                    onClick={() => {
                      onOpenStudio({
                        title,
                        artist,
                        coverUrl: formattedCover || undefined,
                        audioUrl: currentPlatformObj?.previewAudioUrl
                      });
                      onClose();
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white/90 text-xs font-semibold backdrop-blur-md border border-white/15 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Scissors className="w-3.5 h-3.5 text-yellow-400" />
                    <span>Сделать свой видеошот в Студии (404×720)</span>
                  </button>
                )}
              </div>
            </>
          ) : (
            /* Fallback if distributor did not upload a video snapshot */
            <div className="flex-1 p-6 flex flex-col items-center justify-between text-center">
              <div className="w-full flex justify-end">
                <button
                  onClick={onClose}
                  className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col items-center max-w-xs">
                {formattedCover ? (
                  <div className="w-32 h-32 rounded-3xl overflow-hidden mb-4 shadow-2xl border border-white/10">
                    <ProxyImage src={formattedCover} alt="" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-white/30 mb-4">
                    <Film className="w-10 h-10" />
                  </div>
                )}

                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold mb-3">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Видеошот не загружен дистрибьютором</span>
                </div>

                <h3 className="text-white font-bold text-base mb-1">{title}</h3>
                <p className="text-white/60 text-xs mb-3">{artist}</p>
                <p className="text-white/45 text-xs leading-relaxed mb-4">
                  Для данного трека в сервисах Яндекс Музыка, Spotify и Deezer видеошот ещё не добавлен. Вы можете создать его прямо сейчас по официальным техническим требованиям 404×720!
                </p>

                {onOpenStudio && (
                  <button
                    onClick={() => {
                      onOpenStudio({
                        title,
                        artist,
                        coverUrl: formattedCover || undefined
                      });
                      onClose();
                    }}
                    className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 hover:brightness-110 text-black font-black text-xs shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mb-2"
                  >
                    <Sparkles className="w-4 h-4 fill-black" />
                    <span>Создать видеошот для этого трека</span>
                  </button>
                )}
              </div>

              <button
                onClick={onClose}
                className="w-full py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold transition-colors"
              >
                Закрыть
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
