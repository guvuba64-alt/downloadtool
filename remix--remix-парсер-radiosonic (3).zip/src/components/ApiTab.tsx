import React, { useState, useEffect } from "react";
import {
  Code,
  Key,
  Server,
  Terminal,
  Play,
  Copy,
  Check,
  RefreshCw,
  Zap,
  ExternalLink,
  BookOpen,
  Layers,
  Sparkles,
  Bot,
  HelpCircle,
  FileCode,
  Database,
  ArrowRight,
  ShieldCheck,
  Cpu,
  AlertCircle,
  Globe,
  Radio,
  Send,
  Sliders,
  CheckCircle2,
  XCircle,
  Flame,
  Volume2,
  Share2,
  Music,
  Download
} from "lucide-react";
import { TelegramAiBotConfig } from "./TelegramAiBotConfig";
import { IntegrationConstructor } from "./IntegrationConstructor";

interface ApiTabProps {
  t: (en: string, ru: string) => string;
  onNavigateToLogs?: () => void;
}

interface KeyVerifyResult {
  valid: boolean;
  key: string;
  maskedKey: string;
  name: string;
  planId: "free_sandbox" | "pro_full_api" | "enterprise";
  planName: string;
  tier: string;
  status: string;
  quota: {
    maxDailyRequests: number;
    usedToday: number;
    remainingToday: number;
    totalRequestsAllTime: number;
    rateLimit: string;
  };
  capabilities: {
    losslessStreaming: boolean;
    allowedFormats: string[];
    webhooks: boolean;
    multiPlatformSearch: boolean;
    cdpOkRuBypass: boolean;
  };
}

export const ApiTab: React.FC<ApiTabProps> = ({ t, onNavigateToLogs }) => {
  const [activeSubTab, setActiveSubTab] = useState<
    "constructor" | "keys_and_plans" | "rest_api" | "integrations" | "ai_gateways" | "openapi" | "faq"
  >("constructor");

  // API Key & Plan state
  const [apiKey, setApiKey] = useState<string>("pk_live_pro_developer_demo");
  const [keyVerifyData, setKeyVerifyData] = useState<KeyVerifyResult | null>(null);
  const [isVerifyingKey, setIsVerifyingKey] = useState<boolean>(false);
  const [keyError, setKeyError] = useState<string | null>(null);
  const [newKeyName, setNewKeyName] = useState<string>("My Bot Integration Key");
  const [newKeyTier, setNewKeyTier] = useState<"free_sandbox" | "pro_full_api" | "enterprise">("pro_full_api");
  const [isGeneratingKey, setIsGeneratingKey] = useState<boolean>(false);
  const [keyList, setKeyList] = useState<any[]>([]);
  const [copiedKey, setCopiedKey] = useState<boolean>(false);
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [isSwitchingPlan, setIsSwitchingPlan] = useState<boolean>(false);
  const [planSwitchSuccess, setPlanSwitchSuccess] = useState<string | null>(null);

  // REST API Playground state
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>("resolve");
  const [queryUrl, setQueryUrl] = useState<string>("https://music.yandex.ru/track/12278456");
  const [streamId, setStreamId] = useState<string>("12278456");
  const [streamFormat, setStreamFormat] = useState<string>("mp3");
  const [isRequesting, setIsRequesting] = useState<boolean>(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseLatency, setResponseLatency] = useState<number | null>(null);
  const [copiedResponse, setCopiedResponse] = useState<boolean>(false);
  const [codeLang, setCodeLang] = useState<"curl" | "js" | "python">("curl");

  // Integrations state
  const [integrationCategory, setIntegrationCategory] = useState<"telegram" | "website" | "discord" | "webhooks" | "backend">("telegram");
  const [embedTrackId, setEmbedTrackId] = useState<string>("12278456");
  const [embedTitle, setEmbedTitle] = useState<string>("Deep Resonance");
  const [embedArtist, setEmbedArtist] = useState<string>("Soundtrack Unit");
  const [embedTheme, setEmbedTheme] = useState<"dark" | "light">("dark");
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  // Webhook Tester state
  const [webhookUrl, setWebhookUrl] = useState<string>("https://httpbin.org/post");
  const [webhookEvent, setWebhookEvent] = useState<string>("track.resolved");
  const [isTestingWebhook, setIsTestingWebhook] = useState<boolean>(false);
  const [webhookResult, setWebhookResult] = useState<any>(null);

  // OpenAPI / Raw Yandex API Explorer state
  const [customEndpoint, setCustomEndpoint] = useState<string>("tracks/12278456");
  const [isFetchingCustom, setIsFetchingCustom] = useState<boolean>(false);
  const [customResult, setCustomResult] = useState<any>(null);

  // Verify Key on Mount or when apiKey changes
  const verifyCurrentKey = async (keyToTest?: string) => {
    const targetKey = (keyToTest !== undefined ? keyToTest : apiKey).trim();
    if (!targetKey) {
      setKeyVerifyData(null);
      return;
    }
    setIsVerifyingKey(true);
    setKeyError(null);
    try {
      const res = await fetch(`/api/v1/keys/verify?apiKey=${encodeURIComponent(targetKey)}`);
      const data = await res.json();
      if (res.ok && data.success) {
        setKeyVerifyData(data);
      } else {
        setKeyError(data.error || "Ключ не прошел проверку");
        setKeyVerifyData(null);
      }
    } catch (e: any) {
      setKeyError(e.message || "Ошибка соединения с сервером");
      setKeyVerifyData(null);
    } finally {
      setIsVerifyingKey(false);
    }
  };

  // Fetch list of keys
  const loadKeyList = async () => {
    try {
      const res = await fetch("/api/v1/keys/list");
      const data = await res.json();
      if (data.keys) {
        setKeyList(data.keys);
      }
    } catch (e) {
      // fallback
    }
  };

  useEffect(() => {
    verifyCurrentKey("pk_live_pro_developer_demo");
    loadKeyList();
  }, []);

  // Handle Generate New Key
  const handleGenerateKey = async (tier: "free_sandbox" | "pro_full_api" | "enterprise") => {
    setIsGeneratingKey(true);
    setPlanSwitchSuccess(null);
    try {
      const res = await fetch("/api/v1/keys/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: tier,
          name: newKeyName || `${tier === "pro_full_api" ? "PRO" : tier === "enterprise" ? "Enterprise" : "Sandbox"} Key`,
          email: "developer@sandbox.local"
        })
      });
      const data = await res.json();
      const generatedKey = data.apiKey || data.key;
      if (generatedKey) {
        setApiKey(generatedKey);
        await verifyCurrentKey(generatedKey);
        await loadKeyList();
        setPlanSwitchSuccess(t(`Key generated successfully: ${generatedKey}`, `Ключ успешно создан: ${generatedKey}`));
        setTimeout(() => setPlanSwitchSuccess(null), 4000);
      }
    } catch (e: any) {
      setKeyError(e.message || "Не удалось сгенерировать ключ");
    } finally {
      setIsGeneratingKey(false);
    }
  };

  // Handle Switch Plan for Current Key
  const handleSwitchPlan = async (targetPlanId: "free_sandbox" | "pro_full_api" | "enterprise") => {
    setIsSwitchingPlan(true);
    setPlanSwitchSuccess(null);
    try {
      const res = await fetch("/api/v1/keys/switch-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: apiKey,
          targetPlanId
        })
      });
      const data = await res.json();
      if (data.success) {
        await verifyCurrentKey(apiKey);
        await loadKeyList();
        setPlanSwitchSuccess(t(`Plan upgraded to ${data.planName}!`, `Тариф успешно обновлен: ${data.planName}!`));
        setTimeout(() => setPlanSwitchSuccess(null), 4000);
      }
    } catch (e: any) {
      setKeyError(e.message || "Ошибка обновления тарифа");
    } finally {
      setIsSwitchingPlan(false);
    }
  };

  // Run Playground Request
  const handleExecuteRequest = async () => {
    setIsRequesting(true);
    setApiResponse(null);
    setResponseStatus(null);
    setResponseLatency(null);

    const startTime = Date.now();

    try {
      let targetUrl = "";
      const headers: Record<string, string> = {
        Accept: "application/json"
      };
      if (apiKey.trim()) {
        headers["x-api-key"] = apiKey.trim();
      }

      if (selectedEndpoint === "resolve") {
        targetUrl = `/api/v1/track/resolve?url=${encodeURIComponent(queryUrl)}`;
      } else if (selectedEndpoint === "stream") {
        targetUrl = `/api/v1/stream?id=${encodeURIComponent(streamId)}&format=${encodeURIComponent(streamFormat)}&redirect=false`;
      } else if (selectedEndpoint === "verify") {
        targetUrl = `/api/v1/keys/verify?apiKey=${encodeURIComponent(apiKey.trim())}`;
      } else if (selectedEndpoint === "info") {
        targetUrl = `/api/v1/info`;
      } else if (selectedEndpoint === "plans") {
        targetUrl = `/api/v1/plans`;
      } else if (selectedEndpoint === "faq") {
        targetUrl = `/api/v1/faq`;
      }

      const res = await fetch(targetUrl, { headers });
      const latency = Date.now() - startTime;
      setResponseStatus(res.status);
      setResponseLatency(latency);

      const data = await res.json();
      setApiResponse(data);
      // If we just verified, update verify state
      if (selectedEndpoint === "verify" && data.success) {
        setKeyVerifyData(data);
      }
    } catch (err: any) {
      setResponseStatus(500);
      setResponseLatency(Date.now() - startTime);
      setApiResponse({ error: err.message || "Network Error" });
    } finally {
      setIsRequesting(false);
    }
  };

  // Run Custom Yandex OpenAPI Request
  const handleFetchCustom = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!customEndpoint.trim()) return;
    setIsFetchingCustom(true);
    setCustomResult(null);
    try {
      const res = await fetch("/api/music/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: customEndpoint.trim() }),
      });
      const data = await res.json();
      setCustomResult(data);
    } catch (err: any) {
      setCustomResult({ error: err.message });
    } finally {
      setIsFetchingCustom(false);
    }
  };

  // Test Webhook
  const handleTestWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!webhookUrl.trim()) return;
    setIsTestingWebhook(true);
    setWebhookResult(null);
    try {
      const res = await fetch("/api/v1/webhooks/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          webhookUrl: webhookUrl.trim(),
          event: webhookEvent
        })
      });
      const data = await res.json();
      setWebhookResult(data);
    } catch (err: any) {
      setWebhookResult({ error: err.message });
    } finally {
      setIsTestingWebhook(false);
    }
  };

  // Generate Code Snippet
  const getCodeSnippet = () => {
    const origin = typeof window !== "undefined" ? window.location.origin : "https://api.music-platform.app";
    const authHeader = apiKey ? `-H "x-api-key: ${apiKey}" ` : "";

    if (selectedEndpoint === "resolve") {
      const url = `${origin}/api/v1/track/resolve?url=${encodeURIComponent(queryUrl)}`;
      if (codeLang === "curl") {
        return `curl -X GET "${url}" \\\n  ${authHeader}-H "Accept: application/json"`;
      }
      if (codeLang === "js") {
        return `const response = await fetch("${url}", {\n  headers: {\n    ${apiKey ? `"x-api-key": "${apiKey}",\n    ` : ""}"Accept": "application/json"\n  }\n});\nconst data = await response.json();\nconsole.log(data);`;
      }
      if (codeLang === "python") {
        return `import requests\n\nurl = "${url}"\nheaders = {\n    ${apiKey ? `"x-api-key": "${apiKey}",\n    ` : ""}"Accept": "application/json"\n}\nresponse = requests.get(url, headers=headers)\nprint(response.json())`;
      }
    } else if (selectedEndpoint === "stream") {
      const url = `${origin}/api/v1/stream?id=${encodeURIComponent(streamId)}&format=${encodeURIComponent(streamFormat)}`;
      if (codeLang === "curl") {
        return `curl -L -X GET "${url}" \\\n  ${authHeader}-o "track.${streamFormat}"`;
      }
      if (codeLang === "js") {
        return `// Direct audio stream redirection:\nconst streamUrl = "${url}";\nconst audio = new Audio(streamUrl);\naudio.play();`;
      }
      if (codeLang === "python") {
        return `import requests\n\nurl = "${url}"\nwith requests.get(url, stream=True) as r:\n    r.raise_for_status()\n    with open("track.${streamFormat}", "wb") as f:\n        for chunk in r.iter_content(chunk_size=8192):\n            f.write(chunk)`;
      }
    }

    return `curl -X GET "${origin}/api/v1/${selectedEndpoint}" ${authHeader}`;
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const originUrl = typeof window !== "undefined" ? window.location.origin : "https://api.music-platform.app";
  const embedCode = `<iframe src="${originUrl}/embed/player?id=${encodeURIComponent(embedTrackId)}&title=${encodeURIComponent(embedTitle)}&artist=${encodeURIComponent(embedArtist)}&theme=${embedTheme}" width="100%" height="110" frameborder="0" allow="autoplay" style="border-radius:18px; overflow:hidden;"></iframe>`;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Banner & Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-zinc-900 via-zinc-950 to-black text-white p-6 sm:p-8 border border-white/10 shadow-2xl">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -top-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                REST API v1.0 Operational
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                Тариф PRO: Lossless & Webhooks
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                <Send className="w-3.5 h-3.5" />
                Интеграция в Telegram & Сайты
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              <Server className="w-7 h-7 text-purple-400" />
              {t("Developer API, Plans & Integrations", "API, Тарифы и Интеграции в Боты / Сайты")}
            </h1>
            <p className="text-zinc-400 text-sm max-w-2xl leading-relaxed">
              {t(
                "Multi-platform music resolution across 21+ services, direct lossless streaming, ready-made code for your own Telegram bots (Python/Node), embeddable web widgets, and tier subscription management.",
                "Мультиплатформенное распознавание треков по 21+ стримингам, прямой lossless-стриминг, готовые модули для ваших Telegram-ботов (Python/Node.js), встраиваемые плееры для сайтов и управление тарифами API."
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => {
                setActiveSubTab("keys_and_plans");
              }}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              {t("Manage Keys & Plans", "Тарифы и Ключи")}
            </button>
            <button
              onClick={() => setActiveSubTab("integrations")}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-zinc-200 text-xs font-bold transition-all border border-white/10 flex items-center gap-2"
            >
              <Code className="w-4 h-4 text-purple-400" />
              {t("Bot & Website SDK", "Интеграция в Боты & Сайты")}
            </button>
          </div>
        </div>
      </div>

      {/* Main Subtabs Navigation */}
      <div className="flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab("constructor")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "constructor"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          {t("Constructor (Sites, Bots, Discord)", "Конструктор (Сайты, Боты, Discord)")}
          <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 font-bold uppercase">
            No-Code
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab("keys_and_plans")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "keys_and_plans"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Key className="w-4 h-4" />
          {t("Plans & API Keys", "Тарифы и Ключи API")}
          {keyVerifyData && (
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
              {keyVerifyData.tier}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab("integrations")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "integrations"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Send className="w-4 h-4" />
          {t("Integrations (Bots, Sites, Apps)", "Интеграция (Боты, Сайты, Виджеты)")}
        </button>

        <button
          onClick={() => setActiveSubTab("rest_api")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "rest_api"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Zap className="w-4 h-4" />
          {t("REST API Playground (/api/v1/*)", "REST API Песочница (/api/v1/*)")}
        </button>

        <button
          onClick={() => setActiveSubTab("ai_gateways")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "ai_gateways"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Bot className="w-4 h-4" />
          {t("AI Gateways & Telegram Bot", "ИИ-Шлюзы & Telegram-Бот")}
        </button>

        <button
          onClick={() => setActiveSubTab("openapi")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "openapi"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Database className="w-4 h-4" />
          {t("OpenAPI & Yandex Music", "OpenAPI & Яндекс Музыка")}
        </button>

        <button
          onClick={() => setActiveSubTab("faq")}
          className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeSubTab === "faq"
              ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
              : "text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          {t("FAQ & Guides", "FAQ & Что такое API")}
        </button>
      </div>

      {/* =========================================================================
          SUBTAB 0: NO-CODE INTEGRATION CONSTRUCTOR (Sites, Bots, Discord, Limits)
          ========================================================================= */}
      {activeSubTab === "constructor" && (
        <IntegrationConstructor
          t={t}
          activeApiKey={apiKey}
          onNavigateToApiKeys={() => setActiveSubTab("keys_and_plans")}
        />
      )}

      {/* =========================================================================
          SUBTAB 1: PLANS & API KEYS MANAGEMENT (Fixed, working keys & real tiers)
          ========================================================================= */}
      {activeSubTab === "keys_and_plans" && (
        <div className="space-y-8">
          {planSwitchSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold flex items-center gap-3 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{planSwitchSuccess}</span>
            </div>
          )}

          {/* ACTIVE KEY & HEALTH CHECK CARD */}
          <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-100 dark:border-white/5">
              <div>
                <h3 className="text-lg font-black text-zinc-900 dark:text-white flex items-center gap-2.5">
                  <Key className="w-5 h-5 text-purple-500" />
                  {t("Active API Key & Subscription Status", "Активный API Ключ и Статус Тарифа")}
                </h3>
                <p className="text-xs text-zinc-500 mt-1">
                  {t(
                    "Validated in real time by the backend engine with request quota tracking and rate limit enforcement.",
                    "Проверяется бэкендом в реальном времени с подсчётом суточной квоты и контролем ограничений."
                  )}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => verifyCurrentKey()}
                  disabled={isVerifyingKey}
                  className="px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-200 flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isVerifyingKey ? "animate-spin text-purple-500" : ""}`} />
                  {t("Verify Key", "Проверить ключ")}
                </button>
              </div>
            </div>

            {/* Key Input & Copy Bar */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center justify-between">
                <span>{t("Current Bearer Token / API Key", "Текущий токен / API Ключ")}</span>
                <span className="text-[11px] font-mono text-zinc-400">Header: x-api-key</span>
              </label>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={apiKey}
                    onChange={(e) => {
                      setApiKey(e.target.value);
                      verifyCurrentKey(e.target.value);
                    }}
                    placeholder="pk_live_... или pk_sandbox_..."
                    className="w-full px-4 py-3 rounded-2xl font-mono text-xs bg-zinc-50 dark:bg-black/40 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  {apiKey && (
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(apiKey);
                        setCopiedKey(true);
                        setTimeout(() => setCopiedKey(false), 2000);
                      }}
                      className="absolute right-2 top-2.5 px-3 py-1.5 rounded-xl bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-xs text-zinc-700 dark:text-zinc-200 flex items-center gap-1.5 transition-colors"
                    >
                      {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey ? "Скопирован" : "Копировать"}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Key Verification Live Stats */}
            {keyVerifyData ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-200/80 dark:border-white/5">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider block">Тарифный План</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-zinc-900 dark:text-white">{keyVerifyData.planName}</span>
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      keyVerifyData.planId === "pro_full_api"
                        ? "bg-purple-500/20 text-purple-400 border border-purple-500/30"
                        : keyVerifyData.planId === "enterprise"
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                        : "bg-zinc-500/20 text-zinc-400"
                    }`}>
                      {keyVerifyData.tier}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider block">Суточная Квота</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-bold text-zinc-900 dark:text-white">
                      {keyVerifyData.quota.usedToday} / {keyVerifyData.quota.maxDailyRequests}
                    </span>
                    <span className="text-xs text-emerald-500">
                      ({keyVerifyData.quota.remainingToday} ост.)
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider block">Частота (Rate Limit)</span>
                  <span className="text-sm font-mono font-bold text-purple-600 dark:text-purple-400">
                    {keyVerifyData.quota.rateLimit}
                  </span>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider block">Возможности Ключа</span>
                  <div className="flex flex-wrap gap-1 text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                      21+ Стримингов
                    </span>
                    {keyVerifyData.capabilities.losslessStreaming && (
                      <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-400 font-semibold">
                        Lossless FLAC/WAV
                      </span>
                    )}
                    {keyVerifyData.capabilities.webhooks && (
                      <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-semibold">
                        Webhooks
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{keyError || "Введите или сгенерируйте рабочий ключ API ниже для активации лимитов."}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setApiKey("pk_live_pro_developer_demo");
                    verifyCurrentKey("pk_live_pro_developer_demo");
                  }}
                  className="px-3 py-1 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shrink-0"
                >
                  Вставить PRO Демо-Ключ
                </button>
              </div>
            )}
          </div>

          {/* THREE PRICING TIERS WITH ONE-CLICK ACTIVATION */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-zinc-900 dark:text-white flex items-center gap-2.5">
                  <Sliders className="w-5 h-5 text-purple-500" />
                  {t("Pricing Plans & Capabilities", "Тарифные Планы и Возможности")}
                </h3>
                <p className="text-xs text-zinc-500 mt-0.5">
                  {t(
                    "Select a plan for your active key or instantly provision a dedicated key for that tier.",
                    "Выберите подходящий тариф для текущего ключа или сразу создайте новый ключ в данном тарифе."
                  )}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* TIER 1: FREE SANDBOX */}
              <div className={`p-6 rounded-3xl border transition-all flex flex-col justify-between ${
                keyVerifyData?.planId === "free_sandbox"
                  ? "bg-purple-50/50 dark:bg-purple-950/20 border-purple-500 ring-2 ring-purple-500/30"
                  : "bg-white dark:bg-[#18181b] border-zinc-200/80 dark:border-white/5"
              }`}>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
                      Free Sandbox
                    </span>
                    {keyVerifyData?.planId === "free_sandbox" && (
                      <span className="text-xs font-bold text-purple-600 dark:text-purple-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Активен
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="text-3xl font-black text-zinc-900 dark:text-white">0 ₽</div>
                    <div className="text-xs text-zinc-500 mt-1">навсегда для тестов</div>
                  </div>
                  <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>100 запросов / сутки</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Базовый парсинг ссылок и метаданных</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Аудио MP3 (192 kbps)</span>
                    </li>
                    <li className="flex items-center gap-2 text-zinc-400 line-through">
                      <XCircle className="w-4 h-4 text-zinc-400 shrink-0" />
                      <span>Lossless WAV & FLAC 24-bit</span>
                    </li>
                    <li className="flex items-center gap-2 text-zinc-400 line-through">
                      <XCircle className="w-4 h-4 text-zinc-400 shrink-0" />
                      <span>Real-time Webhooks</span>
                    </li>
                  </ul>
                </div>

                <div className="pt-6 mt-6 border-t border-zinc-100 dark:border-white/5">
                  <button
                    type="button"
                    onClick={() => handleSwitchPlan("free_sandbox")}
                    disabled={isSwitchingPlan || keyVerifyData?.planId === "free_sandbox"}
                    className="w-full py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-800 dark:text-zinc-200 transition-colors disabled:opacity-50"
                  >
                    {keyVerifyData?.planId === "free_sandbox" ? "Текущий тариф" : "Переключить на Free"}
                  </button>
                </div>
              </div>

              {/* TIER 2: PRO DEVELOPER (RECOMMENDED) */}
              <div className={`relative p-6 rounded-3xl border transition-all flex flex-col justify-between ${
                keyVerifyData?.planId === "pro_full_api"
                  ? "bg-gradient-to-b from-purple-900/30 to-purple-950/40 border-purple-500 ring-2 ring-purple-500 shadow-xl"
                  : "bg-white dark:bg-[#18181b] border-purple-500/40 shadow-lg"
              }`}>
                <div className="absolute -top-3 right-6 px-3 py-0.5 rounded-full text-[11px] font-black bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md">
                  РЕКОМЕНДУЕМЫЙ
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      PRO Developer
                    </span>
                    {keyVerifyData?.planId === "pro_full_api" && (
                      <span className="text-xs font-bold text-purple-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Активен
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black text-zinc-900 dark:text-white">2 490 ₽</span>
                      <span className="text-xs text-zinc-500 line-through">4 990 ₽</span>
                      <span className="text-xs font-bold text-emerald-500">-50%</span>
                    </div>
                    <div className="text-xs text-zinc-500 mt-1">в месяц (или 19 900 ₽ / год)</div>
                  </div>
                  <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-300">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span><strong>100 000 запросов / месяц</strong> (50 req/sec)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span><strong>Lossless FLAC & WAV</strong> прямой аудиостриминг</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Все 21+ стриминг-платформ (Яндекс, Spotify, Apple, OK.RU)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Real-time Webhooks о новых треках и релизах</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>До 10 рабочих API токенов для ваших ботов</span>
                    </li>
                  </ul>
                </div>

                <div className="pt-6 mt-6 border-t border-zinc-100 dark:border-white/5 space-y-2">
                  <button
                    type="button"
                    onClick={() => handleSwitchPlan("pro_full_api")}
                    disabled={isSwitchingPlan || keyVerifyData?.planId === "pro_full_api"}
                    className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 active:scale-[0.99] text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all disabled:opacity-50"
                  >
                    {keyVerifyData?.planId === "pro_full_api" ? "Тариф PRO Активен ✓" : "Активировать PRO для текущего ключа"}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenerateKey("pro_full_api")}
                    disabled={isGeneratingKey}
                    className="w-full py-2 rounded-xl bg-white/10 hover:bg-white/15 text-[11px] font-bold text-purple-300 border border-purple-500/20 transition-colors"
                  >
                    + Создать новый PRO Ключ
                  </button>
                </div>
              </div>

              {/* TIER 3: ENTERPRISE */}
              <div className={`p-6 rounded-3xl border transition-all flex flex-col justify-between ${
                keyVerifyData?.planId === "enterprise"
                  ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-500 ring-2 ring-amber-500/30"
                  : "bg-white dark:bg-[#18181b] border-zinc-200/80 dark:border-white/5"
              }`}>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      Enterprise Custom
                    </span>
                    {keyVerifyData?.planId === "enterprise" && (
                      <span className="text-xs font-bold text-amber-500 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Активен
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="text-3xl font-black text-zinc-900 dark:text-white">По запросу</div>
                    <div className="text-xs text-zinc-500 mt-1">для дистрибьюторов и лейблов</div>
                  </div>
                  <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-amber-500 shrink-0" />
                      <span><strong>Неограниченные запросы</strong> и соединения</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>Выделенный кластер и пул резидентских прокси</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>On-premise Docker / Kubernetes развертывание</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>Официальный договор, безнал и SLA 99.99%</span>
                    </li>
                  </ul>
                </div>

                <div className="pt-6 mt-6 border-t border-zinc-100 dark:border-white/5">
                  <button
                    type="button"
                    onClick={() => handleSwitchPlan("enterprise")}
                    disabled={isSwitchingPlan || keyVerifyData?.planId === "enterprise"}
                    className="w-full py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-bold text-zinc-800 dark:text-zinc-200 transition-colors disabled:opacity-50"
                  >
                    {keyVerifyData?.planId === "enterprise" ? "Enterprise Активен ✓" : "Переключить на Enterprise"}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* REGISTERED KEYS LIST */}
          <div className="bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-500" />
                {t("Project API Keys Registry", "Реестр Ключей Проекта")}
              </h3>
              <span className="text-xs font-mono text-zinc-500">{keyList.length} ключей зарегистрировано</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-zinc-100 dark:border-white/5 text-zinc-400 font-bold">
                    <th className="py-2.5 px-3">Имя Ключа</th>
                    <th className="py-2.5 px-3">Токен (Key)</th>
                    <th className="py-2.5 px-3">Тариф</th>
                    <th className="py-2.5 px-3">Запросов сегодня</th>
                    <th className="py-2.5 px-3">Лимит</th>
                    <th className="py-2.5 px-3 text-right">Действие</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-white/5">
                  {keyList.map((k) => (
                    <tr key={k.key} className="hover:bg-zinc-50/50 dark:hover:bg-white/5 transition-colors">
                      <td className="py-3 px-3 font-bold text-zinc-900 dark:text-white">{k.name}</td>
                      <td className="py-3 px-3 font-mono text-purple-600 dark:text-purple-400 font-bold">{k.maskedKey || k.key}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          k.planId === "pro_full_api"
                            ? "bg-purple-500/20 text-purple-300"
                            : k.planId === "enterprise"
                            ? "bg-amber-500/20 text-amber-300"
                            : "bg-zinc-100 dark:bg-zinc-800 text-zinc-400"
                        }`}>
                          {k.planName}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono">{k.todayRequests || 0}</td>
                      <td className="py-3 px-3 font-mono text-zinc-500">{k.rateLimit}</td>
                      <td className="py-3 px-3 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            setApiKey(k.key);
                            verifyCurrentKey(k.key);
                            setCopiedKeyId(k.key);
                            navigator.clipboard.writeText(k.key);
                            setTimeout(() => setCopiedKeyId(null), 2000);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-bold text-[11px] transition-colors"
                        >
                          {copiedKeyId === k.key ? "Выбран & Скопирован ✓" : "Выбрать"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUBTAB 2: INTEGRATIONS INTO TELEGRAM BOTS, SITES, APPS & WEBHOOKS
          ========================================================================= */}
      {activeSubTab === "integrations" && (
        <div className="space-y-6">
          {/* Integration Categories */}
          <div className="flex flex-wrap gap-2 p-1.5 bg-zinc-100 dark:bg-[#18181b] rounded-2xl border border-zinc-200 dark:border-white/5">
            {[
              { id: "telegram", label: "Telegram-Боты (Python & Node.js)", icon: Send },
              { id: "website", label: "Сайты & Встраиваемый Плеер (Widget)", icon: Globe },
              { id: "discord", label: "Discord-Боты", icon: Bot },
              { id: "webhooks", label: "Webhooks & Callback-События", icon: Radio },
              { id: "backend", label: "Backend SDK (cURL, Python, Go, PHP)", icon: Code },
            ].map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setIntegrationCategory(cat.id as any)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                    integrationCategory === cat.id
                      ? "bg-white dark:bg-purple-600 text-zinc-900 dark:text-white shadow-sm"
                      : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* 1. TELEGRAM BOT INTEGRATION */}
          {integrationCategory === "telegram" && (
            <div className="space-y-6">
              <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                      <Send className="w-4 h-4 text-blue-500" />
                      Интеграция в вашего Telegram-бота на Python (aiogram 3.x)
                    </h3>
                    <p className="text-xs text-zinc-500 mt-1">
                      Пользователь отправляет боту ссылку (Яндекс Музыка, Spotify, VK), бот распознает трек через наш API и сразу же отправляет MP3-файл прямо в чат!
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(`import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command

TG_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
API_BASE_URL = "${originUrl}/api/v1"
API_KEY = "${apiKey}"

bot = Bot(token=TG_BOT_TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start_handler(message: types.Message):
    await message.answer("👋 Привет! Отправь мне ссылку на трек (Яндекс Музыка, Spotify, VK) или название песни!")

@dp.message()
async def track_resolver_handler(message: types.Message):
    query = message.text.strip()
    status_msg = await message.answer("🔍 Распознаю трек через Multi-Music API...")

    headers = {"x-api-key": API_KEY, "Accept": "application/json"}
    async with aiohttp.ClientSession() as session:
        # 1. Запрашиваем метаданные трека
        resolve_url = f"{API_BASE_URL}/track/resolve?url={query}"
        async with session.get(resolve_url, headers=headers) as resp:
            data = await resp.json()
            if not data.get("success"):
                return await status_msg.edit_text("❌ Не удалось найти трек по этой ссылке.")

        track_data = data.get("data", {})
        title = track_data.get("title") or "Unknown Title"
        artist = track_data.get("artist") or "Unknown Artist"
        track_id = track_data.get("id") or "12278456"

        # 2. Получаем прямой стрим аудиопотока
        stream_url = f"{API_BASE_URL}/stream?id={track_id}&format=mp3"
        await status_msg.edit_text(f"🎵 Отправляю: <b>{artist} — {title}</b>", parse_mode="HTML")
        await message.answer_audio(
            audio=stream_url,
            title=title,
            performer=artist
        )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
`, "aiogram")}
                    className="px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold flex items-center gap-1.5 hover:bg-purple-100 transition-colors"
                  >
                    {copiedSnippet === "aiogram" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSnippet === "aiogram" ? "Скопировано" : "Копировать код бота"}</span>
                  </button>
                </div>

                <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-[420px] border border-white/5">
{`import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command

TG_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
API_BASE_URL = "${originUrl}/api/v1"
API_KEY = "${apiKey}"

bot = Bot(token=TG_BOT_TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start_handler(message: types.Message):
    await message.answer("👋 Привет! Отправь мне ссылку на трек (Яндекс Музыка, Spotify, VK) или название песни!")

@dp.message()
async def track_resolver_handler(message: types.Message):
    query = message.text.strip()
    status_msg = await message.answer("🔍 Распознаю трек через Multi-Music API...")

    headers = {"x-api-key": API_KEY, "Accept": "application/json"}
    async with aiohttp.ClientSession() as session:
        # 1. Запрашиваем метаданные трека
        resolve_url = f"{API_BASE_URL}/track/resolve?url={query}"
        async with session.get(resolve_url, headers=headers) as resp:
            data = await resp.json()
            if not data.get("success"):
                return await status_msg.edit_text("❌ Не удалось найти трек по этой ссылке.")

        track_data = data.get("data", {})
        title = track_data.get("title") or "Unknown Title"
        artist = track_data.get("artist") or "Unknown Artist"
        track_id = track_data.get("id") or "12278456"

        # 2. Получаем прямой стрим аудиопотока
        stream_url = f"{API_BASE_URL}/stream?id={track_id}&format=mp3"
        await status_msg.edit_text(f"🎵 Отправляю: <b>{artist} — {title}</b>", parse_mode="HTML")
        await message.answer_audio(
            audio=stream_url,
            title=title,
            performer=artist
        )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())`}
                </pre>
              </div>

              {/* Node.js Telegraf */}
              <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                    <Code className="w-4 h-4 text-emerald-500" />
                    Интеграция в Telegram-бота на Node.js (Telegraf / grammY)
                  </h3>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(`import { Telegraf } from 'telegraf';

const bot = new Telegraf(process.env.BOT_TOKEN);
const API_URL = '${originUrl}/api/v1';
const API_KEY = '${apiKey}';

bot.on('text', async (ctx) => {
  const url = ctx.message.text;
  if (!url.startsWith('http')) return;

  ctx.reply('🔍 Распознаю музыку...');
  const res = await fetch(\`\${API_URL}/track/resolve?url=\${encodeURIComponent(url)}\`, {
    headers: { 'x-api-key': API_KEY }
  });
  const data = await res.json();
  if (!data.success) return ctx.reply('Трек не найден');

  const { title, artist, id } = data.data;
  const audioUrl = \`\${API_URL}/stream?id=\${id}&format=mp3\`;

  await ctx.replyWithAudio({ url: audioUrl }, {
    title: title || 'Track',
    performer: artist || 'Artist'
  });
});

bot.launch();
`, "telegraf")}
                    className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-xs font-bold flex items-center gap-1.5 hover:bg-zinc-200 transition-colors"
                  >
                    {copiedSnippet === "telegraf" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Копировать Telegraf код</span>
                  </button>
                </div>
                <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-[260px] border border-white/5">
{`import { Telegraf } from 'telegraf';

const bot = new Telegraf(process.env.BOT_TOKEN);
const API_URL = '${originUrl}/api/v1';
const API_KEY = '${apiKey}';

bot.on('text', async (ctx) => {
  const url = ctx.message.text;
  if (!url.startsWith('http')) return;

  ctx.reply('🔍 Распознаю музыку...');
  const res = await fetch(\`\${API_URL}/track/resolve?url=\${encodeURIComponent(url)}\`, {
    headers: { 'x-api-key': API_KEY }
  });
  const data = await res.json();
  if (!data.success) return ctx.reply('Трек не найден');

  const { title, artist, id } = data.data;
  const audioUrl = \`\${API_URL}/stream?id=\${id}&format=mp3\`;

  await ctx.replyWithAudio({ url: audioUrl }, {
    title: title || 'Track',
    performer: artist || 'Artist'
  });
});

bot.launch();`}
                </pre>
              </div>
            </div>
          )}

          {/* 2. WEBSITE INTEGRATION & EMBEDDABLE PLAYER */}
          {integrationCategory === "website" && (
            <div className="space-y-6">
              {/* Embed Iframe Card */}
              <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-100 dark:border-white/5">
                  <div>
                    <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                      <Globe className="w-5 h-5 text-purple-500" />
                      Встраиваемый Виджет-Аудиоплеер (Embed Iframe)
                    </h3>
                    <p className="text-xs text-zinc-500 mt-1">
                      Вставьте одну строчку HTML-кода на ваш сайт, блог, Tilda, WordPress, Webflow или в Telegram WebApp, чтобы дать посетителям слушать музыку без скачивания.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => copyToClipboard(embedCode, "embed_code")}
                    className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 shrink-0"
                  >
                    {copiedSnippet === "embed_code" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedSnippet === "embed_code" ? "HTML Скопирован!" : "Скопировать HTML код виджета"}</span>
                  </button>
                </div>

                {/* Interactive Embed Builder */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500">Track ID / ISRC</label>
                    <input
                      type="text"
                      value={embedTrackId}
                      onChange={(e) => setEmbedTrackId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500">Название трека</label>
                    <input
                      type="text"
                      value={embedTitle}
                      onChange={(e) => setEmbedTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500">Исполнитель</label>
                    <input
                      type="text"
                      value={embedArtist}
                      onChange={(e) => setEmbedArtist(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10"
                    />
                  </div>
                </div>

                {/* Live Preview of the Embed */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block">
                    Интерактивный предпросмотр виджета на сайте:
                  </span>
                  <div className="p-4 rounded-2xl bg-zinc-100 dark:bg-black/40 border border-zinc-200 dark:border-white/5 flex justify-center">
                    <iframe
                      src={`/embed/player?id=${encodeURIComponent(embedTrackId)}&title=${encodeURIComponent(embedTitle)}&artist=${encodeURIComponent(embedArtist)}&theme=${embedTheme}`}
                      width="100%"
                      height="110"
                      className="rounded-2xl border-0 shadow-lg max-w-lg"
                    />
                  </div>
                </div>

                {/* HTML Embed Code */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block">
                    Готовый HTML код для вставки на сайт:
                  </span>
                  <pre className="p-3.5 rounded-xl bg-zinc-950 text-purple-300 font-mono text-xs overflow-x-auto border border-white/5">
                    {embedCode}
                  </pre>
                </div>
              </div>

              {/* React / Next.js Component */}
              <div className="bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                    <Code className="w-4 h-4 text-cyan-400" />
                    React / Next.js Компонент
                  </h3>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(`import React, { useState } from 'react';

export const MusicPlayer = ({ trackId = "12278456" }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const streamUrl = \`${originUrl}/api/v1/stream?id=\${trackId}&format=mp3\`;

  return (
    <div className="p-4 rounded-2xl bg-zinc-900 text-white flex items-center gap-4">
      <audio id="audioPlayer" src={streamUrl} />
      <button 
        onClick={() => {
          const el = document.getElementById('audioPlayer') as HTMLAudioElement;
          if (isPlaying) { el.pause(); setIsPlaying(false); }
          else { el.play(); setIsPlaying(true); }
        }}
        className="px-4 py-2 rounded-xl bg-purple-600 font-bold text-xs"
      >
        {isPlaying ? 'Пауза' : 'Слушать онлайн'}
      </button>
    </div>
  );
};
`, "react_code")}
                    className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-xs font-bold hover:bg-zinc-200 transition-colors"
                  >
                    Копировать React компонент
                  </button>
                </div>
                <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-[220px]">
{`import React, { useState } from 'react';

export const MusicPlayer = ({ trackId = "12278456" }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const streamUrl = \`${originUrl}/api/v1/stream?id=\${trackId}&format=mp3\`;

  return (
    <div className="p-4 rounded-2xl bg-zinc-900 text-white flex items-center gap-4">
      <audio id="audioPlayer" src={streamUrl} />
      <button 
        onClick={() => {
          const el = document.getElementById('audioPlayer');
          if (isPlaying) { el.pause(); setIsPlaying(false); }
          else { el.play(); setIsPlaying(true); }
        }}
        className="px-4 py-2 rounded-xl bg-purple-600 font-bold text-xs"
      >
        {isPlaying ? 'Пауза' : 'Слушать онлайн'}
      </button>
    </div>
  );
};`}
                </pre>
              </div>
            </div>
          )}

          {/* 3. DISCORD BOT INTEGRATION */}
          {integrationCategory === "discord" && (
            <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                    <Bot className="w-5 h-5 text-indigo-500" />
                    Музыкальный Discord-Бот на Python (discord.py)
                  </h3>
                  <p className="text-xs text-zinc-500 mt-1">
                    Воспроизведение любого распознанного трека прямо в голосовом канале Discord сервера без задержек.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(`import discord
from discord.ext import commands
import requests

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

API_KEY = "${apiKey}"
API_URL = "${originUrl}/api/v1"

@bot.command()
async def play(ctx, url: str):
    if not ctx.author.voice:
        return await ctx.send("Зайдите в голосовой канал!")
        
    voice_channel = ctx.author.voice.channel
    vc = await voice_channel.connect()

    # Запрашиваем трек
    r = requests.get(f"{API_URL}/track/resolve?url={url}", headers={"x-api-key": API_KEY})
    track = r.json().get("data", {})
    track_id = track.get("id", "12278456")
    
    stream_url = f"{API_URL}/stream?id={track_id}&format=mp3"
    await ctx.send(f"🎶 Сейчас играет: **{track.get('title')}**")
    
    vc.play(discord.FFmpegPCMAudio(stream_url))

bot.run("YOUR_DISCORD_BOT_TOKEN")
`, "discord_code")}
                  className="px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold"
                >
                  Копировать Discord код
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-[360px] border border-white/5">
{`import discord
from discord.ext import commands
import requests

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

API_KEY = "${apiKey}"
API_URL = "${originUrl}/api/v1"

@bot.command()
async def play(ctx, url: str):
    if not ctx.author.voice:
        return await ctx.send("Зайдите в голосовой канал!")
        
    voice_channel = ctx.author.voice.channel
    vc = await voice_channel.connect()

    # Запрашиваем трек
    r = requests.get(f"{API_URL}/track/resolve?url={url}", headers={"x-api-key": API_KEY})
    track = r.json().get("data", {})
    track_id = track.get("id", "12278456")
    
    stream_url = f"{API_URL}/stream?id={track_id}&format=mp3"
    await ctx.send(f"🎶 Сейчас играет: **{track.get('title')}**")
    
    vc.play(discord.FFmpegPCMAudio(stream_url))

bot.run("YOUR_DISCORD_BOT_TOKEN")`}
              </pre>
            </div>
          )}

          {/* 4. WEBHOOKS & REAL-TIME DISPATCHER */}
          {integrationCategory === "webhooks" && (
            <div className="bg-white dark:bg-[#18181b] p-6 sm:p-7 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-6">
              <div>
                <h3 className="text-base font-black text-zinc-900 dark:text-white flex items-center gap-2">
                  <Radio className="w-5 h-5 text-purple-500" />
                  Real-time Webhooks & Интерактивный Тестер
                </h3>
                <p className="text-xs text-zinc-500 mt-1">
                  Отправляйте уведомления о появлении новых треков отслеживаемых артистов прямо на эндпоинт вашего бэкенда или вебхук Telegram бота.
                </p>
              </div>

              <form onSubmit={handleTestWebhook} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-500">Ваш Webhook URL</label>
                    <input
                      type="url"
                      value={webhookUrl}
                      onChange={(e) => setWebhookUrl(e.target.value)}
                      placeholder="https://mysite.com/api/webhooks/music"
                      className="w-full px-4 py-2.5 rounded-xl font-mono text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-500">Тип События</label>
                    <select
                      value={webhookEvent}
                      onChange={(e) => setWebhookEvent(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10"
                    >
                      <option value="track.resolved">track.resolved (Трек успешно найден)</option>
                      <option value="release.new">release.new (Найден новый релиз артиста)</option>
                      <option value="audio.converted">audio.converted (Завершена конвертация в WAV/FLAC)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isTestingWebhook}
                  className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {isTestingWebhook ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
                  <span>Отправить тестовый Webhook</span>
                </button>
              </form>

              {webhookResult && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block">Результат доставки:</span>
                  <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-60 border border-white/5">
                    {JSON.stringify(webhookResult, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}

          {/* 5. BACKEND SDK & OTHER LANGUAGES */}
          {integrationCategory === "backend" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Go Snippet */}
              <div className="bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-3">
                <h4 className="font-bold text-sm text-zinc-900 dark:text-white flex items-center gap-2">
                  <Code className="w-4 h-4 text-cyan-500" /> Golang
                </h4>
                <pre className="p-3.5 rounded-xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto">
{`req, _ := http.NewRequest("GET", "${originUrl}/api/v1/track/resolve?url=" + url, nil)
req.Header.Set("x-api-key", "${apiKey}")
resp, err := http.DefaultClient.Do(req)`}
                </pre>
              </div>

              {/* PHP Snippet */}
              <div className="bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-3">
                <h4 className="font-bold text-sm text-zinc-900 dark:text-white flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" /> PHP / Laravel
                </h4>
                <pre className="p-3.5 rounded-xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto">
{`$response = Http::withHeaders([
    'x-api-key' => '${apiKey}'
])->get('${originUrl}/api/v1/track/resolve', [
    'url' => $trackUrl
]);`}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          SUBTAB 3: REST API PLAYGROUND (/api/v1/*)
          ========================================================================= */}
      {activeSubTab === "rest_api" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Request Builder */}
            <div className="lg:col-span-6 space-y-5 bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-white/5">
                <h3 className="font-black text-zinc-900 dark:text-white text-base flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-purple-500" />
                  {t("Interactive Request Builder", "Интерактивный конструктор запроса")}
                </h3>
                <span className="text-xs font-mono text-zinc-500">HTTP/1.1 REST</span>
              </div>

              {/* Endpoint Picker */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                  {t("Select Endpoint", "Выберите эндпоинт")}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: "resolve", method: "GET", path: "/api/v1/track/resolve", label: "Track Resolve" },
                    { id: "stream", method: "GET", path: "/api/v1/stream", label: "Audio Stream" },
                    { id: "verify", method: "GET", path: "/api/v1/keys/verify", label: "Verify Key" },
                    { id: "plans", method: "GET", path: "/api/v1/plans", label: "Plans & Pricing" },
                    { id: "info", method: "GET", path: "/api/v1/info", label: "API Info" },
                    { id: "faq", method: "GET", path: "/api/v1/faq", label: "API FAQ" },
                  ].map((ep) => (
                    <button
                      key={ep.id}
                      type="button"
                      onClick={() => setSelectedEndpoint(ep.id)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        selectedEndpoint === ep.id
                          ? "bg-purple-50 dark:bg-purple-950/40 border-purple-500/50 text-purple-900 dark:text-purple-200 shadow-sm"
                          : "bg-zinc-50/50 dark:bg-white/5 border-zinc-200/60 dark:border-white/5 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-white/10"
                      }`}
                    >
                      <span className="text-[10px] font-mono font-bold text-purple-600 dark:text-purple-400 block">
                        {ep.method}
                      </span>
                      <span className="text-xs font-bold truncate block">{ep.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Parameter Inputs */}
              {selectedEndpoint === "resolve" && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                    {t("Track URL or Search Query (21+ Platforms)", "Ссылка на трек или поисковый запрос (21+ платформ)")}
                  </label>
                  <input
                    type="text"
                    value={queryUrl}
                    onChange={(e) => setQueryUrl(e.target.value)}
                    placeholder="https://music.yandex.ru/track/12278456 или https://open.spotify.com/track/..."
                    className="w-full px-4 py-2.5 rounded-xl font-mono text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className="text-[11px] text-zinc-500 self-center mr-1">Пресеты:</span>
                    {[
                      { label: "Яндекс Трек", url: "https://music.yandex.ru/track/12278456" },
                      { label: "Яндекс Альбом", url: "https://music.yandex.ru/album/28472910" },
                      { label: "Spotify", url: "https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT" },
                      { label: "VK Музыка", url: "https://vk.com/audio-200123456_123456" },
                    ].map((p) => (
                      <button
                        key={p.label}
                        type="button"
                        onClick={() => setQueryUrl(p.url)}
                        className="px-2 py-1 rounded-lg text-[10px] bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 transition-colors"
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {selectedEndpoint === "stream" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Track ID / ISRC / UPC</label>
                    <input
                      type="text"
                      value={streamId}
                      onChange={(e) => setStreamId(e.target.value)}
                      placeholder="12278456"
                      className="w-full px-4 py-2.5 rounded-xl font-mono text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Audio Format</label>
                    <select
                      value={streamFormat}
                      onChange={(e) => setStreamFormat(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="mp3">MP3 (320 kbps)</option>
                      <option value="wav">Lossless WAV (16-bit / 44.1kHz)</option>
                      <option value="flac">FLAC (Lossless Audio)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* API Key Input */}
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-500" />
                    API Key Header (x-api-key)
                  </label>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="pk_live_... или pk_sandbox_..."
                    className="w-full px-4 py-2.5 pr-14 rounded-xl font-mono text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {/* Execute Button */}
              <button
                type="button"
                onClick={handleExecuteRequest}
                disabled={isRequesting}
                className="w-full py-3 px-6 rounded-2xl bg-purple-600 hover:bg-purple-500 active:scale-[0.99] text-white font-bold text-sm shadow-lg shadow-purple-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isRequesting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{t("Sending HTTP Request...", "Выполнение запроса...")}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>{t("Send Request (Execute)", "Отправить запрос")}</span>
                  </>
                )}
              </button>

              {/* Code Snippet Switcher */}
              <div className="pt-2 border-t border-zinc-100 dark:border-white/5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                    {t("Client Code Snippet", "Готовый код для клиента")}
                  </span>
                  <div className="flex items-center gap-1">
                    {(["curl", "js", "python"] as const).map((lang) => (
                      <button
                        key={lang}
                        type="button"
                        onClick={() => setCodeLang(lang)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono uppercase transition-colors ${
                          codeLang === lang
                            ? "bg-purple-600 text-white font-bold"
                            : "text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
                        }`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>
                <pre className="p-3 rounded-xl bg-zinc-900 text-zinc-300 font-mono text-[11px] overflow-x-auto border border-white/5">
                  {getCodeSnippet()}
                </pre>
              </div>
            </div>

            {/* Right Column: Live Response Viewer */}
            <div className="lg:col-span-6 space-y-4 bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-white/5">
                <div className="flex items-center gap-3">
                  <h3 className="font-black text-zinc-900 dark:text-white text-base">
                    {t("Live Server Response", "Ответ сервера")}
                  </h3>
                  {responseStatus !== null && (
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-bold font-mono ${
                        responseStatus >= 200 && responseStatus < 300
                          ? "bg-emerald-500/20 text-emerald-500 border border-emerald-500/30"
                          : responseStatus === 402
                          ? "bg-amber-500/20 text-amber-500 border border-amber-500/30"
                          : "bg-red-500/20 text-red-500 border border-red-500/30"
                      }`}
                    >
                      {responseStatus} {responseStatus === 200 ? "OK" : responseStatus === 402 ? "Payment Required" : "Status"}
                    </span>
                  )}
                  {responseLatency !== null && (
                    <span className="text-xs font-mono text-zinc-500">{responseLatency} ms</span>
                  )}
                </div>

                {apiResponse && (
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(apiResponse, null, 2));
                      setCopiedResponse(true);
                      setTimeout(() => setCopiedResponse(false), 2000);
                    }}
                    className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs flex items-center gap-1 transition-colors"
                  >
                    {copiedResponse ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedResponse ? "Copied" : "Copy JSON"}</span>
                  </button>
                )}
              </div>

              <div className="flex-1 min-h-[360px] max-h-[550px] overflow-auto rounded-2xl bg-zinc-950 p-4 font-mono text-xs text-emerald-400 border border-white/5">
                {isRequesting ? (
                  <div className="h-full flex flex-col items-center justify-center gap-3 text-zinc-500">
                    <RefreshCw className="w-6 h-6 animate-spin text-purple-500" />
                    <span className="text-xs">Processing request...</span>
                  </div>
                ) : apiResponse ? (
                  <pre className="whitespace-pre-wrap">{JSON.stringify(apiResponse, null, 2)}</pre>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-zinc-500">
                    <Terminal className="w-8 h-8 mb-2 opacity-40" />
                    <p className="font-bold text-sm text-zinc-400">
                      {t("No response yet", "Ответ пока не получен")}
                    </p>
                    <p className="text-xs max-w-sm mt-1 text-zinc-500">
                      {t(
                        "Click 'Send Request' on the left to test the API and inspect the structured JSON response in real time.",
                        "Нажмите «Отправить запрос» слева, чтобы протестировать эндпоинт и увидеть структурированный ответ в реальном времени."
                      )}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUBTAB 4: AI GATEWAYS & TELEGRAM BOT
          ========================================================================= */}
      {activeSubTab === "ai_gateways" && (
        <div className="space-y-6">
          <TelegramAiBotConfig
            t={t}
            onViewTelegramLogs={onNavigateToLogs}
          />
        </div>
      )}

      {/* =========================================================================
          SUBTAB 5: OPENAPI & YANDEX MUSIC EXPLORER
          ========================================================================= */}
      {activeSubTab === "openapi" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#18181b] p-6 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-100 dark:border-white/5">
              <div>
                <h3 className="text-lg font-black text-zinc-900 dark:text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-purple-500" />
                  {t("OpenAPI & Native Music API Specifications", "Спецификации OpenAPI и Нативный Музыкальный API")}
                </h3>
                <p className="text-xs text-zinc-500 mt-1">
                  {t(
                    "Integrates with OpenAPI schema (cherkashin.dev) and yandex_music.utils (ym.marshal.dev).",
                    "Интеграция спецификации OpenAPI (cherkashin.dev) и утилит yandex_music (ym.marshal.dev)."
                  )}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href="https://www.cherkashin.dev/yandex-music-open-api/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold border border-purple-200 dark:border-purple-800/40 flex items-center gap-1.5 hover:bg-purple-100 dark:hover:bg-purple-900/50 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  cherkashin.dev/yandex-music-open-api
                </a>
                <a
                  href="https://ym.marshal.dev/yandex_music.utils/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-bold border border-zinc-200 dark:border-zinc-700 flex items-center gap-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  ym.marshal.dev
                </a>
              </div>
            </div>

            {/* Quick Templates */}
            <div className="mt-4 space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                {t("Popular Endpoint Templates", "Шаблоны популярных эндпоинтов")}
              </label>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: "Трек (12278456)", endpoint: "tracks/12278456" },
                  { label: "Альбом с треками", endpoint: "albums/28472910/with-tracks" },
                  { label: "Стриминг инфо (Download Info)", endpoint: "tracks/12278456/download-info" },
                  { label: "Очереди (Queues)", endpoint: "queues" },
                  { label: "Моя Волна (Rotor Station)", endpoint: "rotor/station:user:onyourwave/tracks" },
                ].map((tpl) => (
                  <button
                    key={tpl.label}
                    type="button"
                    onClick={() => {
                      setCustomEndpoint(tpl.endpoint);
                      handleFetchCustom();
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs bg-zinc-100 dark:bg-white/5 hover:bg-zinc-200 dark:hover:bg-white/10 text-zinc-800 dark:text-zinc-200 font-medium transition-colors"
                  >
                    {tpl.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Request Form */}
            <form onSubmit={handleFetchCustom} className="mt-5 flex flex-col sm:flex-row gap-2">
              <span className="bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-xs flex items-center text-zinc-500 shrink-0">
                api.music.yandex.net/
              </span>
              <input
                type="text"
                value={customEndpoint}
                onChange={(e) => setCustomEndpoint(e.target.value)}
                placeholder="tracks/12278456"
                className="flex-1 px-4 py-2.5 rounded-xl font-mono text-xs bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button
                type="submit"
                disabled={!customEndpoint.trim() || isFetchingCustom}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50 shrink-0"
              >
                {isFetchingCustom ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
                {t("Execute", "Выполнить")}
              </button>
            </form>

            {/* Raw JSON Result */}
            {customResult && (
              <div className="mt-5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    Raw JSON Result
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(customResult, null, 2));
                    }}
                    className="text-xs text-purple-600 dark:text-purple-400 hover:underline"
                  >
                    {t("Copy JSON", "Скопировать JSON")}
                  </button>
                </div>
                <pre className="p-4 rounded-2xl bg-zinc-950 text-emerald-400 font-mono text-xs overflow-x-auto max-h-96 border border-white/5">
                  {JSON.stringify(customResult, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          SUBTAB 6: FAQ & ARCHITECTURE
          ========================================================================= */}
      {activeSubTab === "faq" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#18181b] p-6 sm:p-8 rounded-3xl border border-zinc-200/80 dark:border-white/5 shadow-sm space-y-8">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-purple-500" />
                {t("FAQ: Everything About API, Tokens & Architecture", "FAQ: Всё про API, Токены и Архитектуру")}
              </h2>
              <p className="text-sm text-zinc-500 mt-1">
                {t(
                  "Plain language guide on how APIs work, why tokens are needed, and how gateway failover works.",
                  "Доступное руководство: что такое API, зачем нужны ключи и как устроена защита от сбоев."
                )}
              </p>
            </div>

            {/* Section 1: Restaurant Analogy */}
            <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 p-6 rounded-2xl border border-purple-200/60 dark:border-purple-800/30 space-y-3">
              <h4 className="text-base font-black text-purple-950 dark:text-purple-200 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                1. Что такое API простыми словами? (Аналогия с Рестораном)
              </h4>
              <p className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed">
                Представьте, что вы (наше приложение или ваш Telegram-бот) пришли в ресторан. База данных Spotify, Яндекс Музыки или сервер искусственного интеллекта OpenAI — это <strong>закрытая кухня</strong>. Вы не можете просто зайти на кухню и взять ингредиенты сами.
              </p>
              <p className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed">
                <strong>API (Application Programming Interface)</strong> — это ваш <strong>Официант</strong>. Вы даёте ему заказ (API Request): <em>«Найди трек по ссылке»</em> или <em>«Сгенерируй ответ пользователю»</em>. Официант идёт на кухню, берет готовые данные и возвращает вам блюдо в строго оговоренном формате (JSON ответ). Благодаря API программы могут обмениваться миллионами сообщений в секунду без участия человека.
              </p>
            </div>

            {/* Section 2: Tokens and Security */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-zinc-50 dark:bg-white/5 p-6 rounded-2xl border border-zinc-200/80 dark:border-white/5 space-y-3">
                <h4 className="text-sm font-black text-zinc-900 dark:text-white flex items-center gap-2">
                  <Key className="w-4 h-4 text-amber-500" />
                  2. Зачем нужен Token / API Key?
                </h4>
                <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  Токен — это ваш <strong>VIP-пропуск</strong> на кухню. Серверы Telegram или OpenAI не позволят первому встречному рассылать сообщения от чужого имени или расходовать чужой баланс.
                </p>
                <ul className="list-disc pl-4 text-xs text-zinc-600 dark:text-zinc-400 space-y-1.5">
                  <li><strong>Telegram Bot Token:</strong> Строка вида <code>12345:ABCDef...</code> от @BotFather, дающая боту право слать сообщения.</li>
                  <li><strong>OpenAI / DeepSeek Key:</strong> Ключ вида <code>sk-...</code>, открывающий доступ к языковым моделям.</li>
                  <li><strong>Platform API Key (x-api-key):</strong> Ключ <code>pk_live_...</code> или <code>pk_sandbox_...</code> для нашего REST API.</li>
                </ul>
              </div>

              <div className="bg-zinc-50 dark:bg-white/5 p-6 rounded-2xl border border-zinc-200/80 dark:border-white/5 space-y-3">
                <h4 className="text-sm font-black text-zinc-900 dark:text-white flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-500" />
                  3. Ошибки шлюзов и Failover на Gemini
                </h4>
                <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  При работе с внешними провайдерами система автоматически нивелирует сбои:
                </p>
                <ul className="list-disc pl-4 text-xs text-zinc-600 dark:text-zinc-400 space-y-1.5">
                  <li><strong>402 Payment Required:</strong> Баланс шлюза исчерпан. Сервер мгновенно переходит на бесплатные модели пула (free/*) или на Gemini.</li>
                  <li><strong>404 Not Found:</strong> Запрошенная модель снята с поддержки — система подставляет активный аналог.</li>
                  <li><strong>429 Rate-Limit & Таймауты:</strong> При превышении частоты запросов запрос ставится в очередь с экспоненциальной задержкой.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
