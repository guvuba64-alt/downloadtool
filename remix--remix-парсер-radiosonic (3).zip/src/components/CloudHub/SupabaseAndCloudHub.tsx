import React, { useState, useEffect } from 'react';
import { 
  Database, Send, Key, Globe, Shield, RefreshCw, CheckCircle2, 
  AlertCircle, Copy, Check, ExternalLink, Sparkles, Terminal, 
  Radio, Search, Server, Download, Upload, Eye, EyeOff, Bot,
  Zap, ArrowRight, Play, Loader2, Lock, Unlock, Crown, UserCheck
} from 'lucide-react';
import { 
  getSupabaseConfig, 
  saveSupabaseConfig, 
  clearSupabaseConfig, 
  testSupabaseConnection 
} from '../../lib/supabase';
import { SUPABASE_SQL_SCHEMA } from '../../lib/supabaseSchema';
import { 
  CHIEF_OWNER_TG_ID, 
  isChiefOwnerAuthenticated, 
  setChiefOwnerAuthenticated, 
  revokeChiefOwner 
} from '../../utils/ownerAuth';
import { OwnerAuthModal } from '../OwnerAuthModal';
import { PlatformBrandIcon } from '../PlatformIcons';
import { NetlifyDeploymentModal } from '../NetlifyDeploymentModal';

interface TokenItem {
  provider: 'yandex' | 'vk' | 'ok_ru' | 'telegram_bot' | 'spotify';
  name: string;
  hasToken: boolean;
  maskedToken?: string;
  isValid?: boolean;
  accountName?: string;
  accountUid?: string;
  details?: Record<string, any>;
  error?: string | null;
}

interface Props {
  t?: (en: string, ru: string) => string;
  onPlayTrack?: (track: any) => void;
  onOwnerStatusChange?: (isOwner: boolean) => void;
}

export function SupabaseAndCloudHub({ t, onPlayTrack, onOwnerStatusChange }: Props) {
  // Owner Auth state
  const [isOwner, setIsOwner] = useState<boolean>(() => isChiefOwnerAuthenticated());
  const [ownerInputId, setOwnerInputId] = useState('');
  const [ownerAuthError, setOwnerAuthError] = useState('');

  const [showOwnerAuthModal, setShowOwnerAuthModal] = useState(false);
  const [showNetlifyModal, setShowNetlifyModal] = useState(false);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'supabase' | 'telegram' | 'tokens' | 'cloud_api'>('supabase');

  // Supabase states
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseAnonKey, setSupabaseAnonKey] = useState('');
  const [supabaseServiceRoleKey, setSupabaseServiceRoleKey] = useState('');
  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState<{
    isConnected: boolean;
    tablesReady?: boolean;
    pingLatencyMs?: number;
    message?: string;
    error?: string | null;
  }>({ isConnected: false });
  const [copiedSql, setCopiedSql] = useState(false);
  const [isSyncingTokens, setIsSyncingTokens] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Telegram states
  const [botToken, setBotToken] = useState('');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [isTestingBot, setIsTestingBot] = useState(false);
  const [botInfo, setBotInfo] = useState<any>(null);
  const [webhookInfo, setWebhookInfo] = useState<any>(null);
  const [botStatusMessage, setBotStatusMessage] = useState<string | null>(null);
  const [copiedCommands, setCopiedCommands] = useState(false);

  // Tokens states
  const [tokensList, setTokensList] = useState<TokenItem[]>([]);
  const [loadingTokens, setLoadingTokens] = useState(false);
  const [editingProvider, setEditingProvider] = useState<string | null>(null);
  const [editTokenValue, setEditTokenValue] = useState('');
  const [showTokenSecret, setShowTokenSecret] = useState<Record<string, boolean>>({});

  // Cloud API live tester
  const [testWaveData, setTestWaveData] = useState<any>(null);
  const [testingWave, setTestingWave] = useState(false);
  const [testSearchQuery, setTestSearchQuery] = useState('Miyagi');
  const [testSearchResults, setTestSearchResults] = useState<any[]>([]);
  const [searchingCloud, setSearchingCloud] = useState(false);

  // Check owner & load initial configs
  useEffect(() => {
    const verified = isChiefOwnerAuthenticated();
    setIsOwner(verified);

    if (verified) {
      const cfg = getSupabaseConfig();
      setSupabaseUrl(cfg.url);
      setSupabaseAnonKey(cfg.anonKey);

      // Check server Supabase status
      fetch('/api/supabase/status')
        .then(r => r.json())
        .then(d => {
          if (d?.status) {
            setSupabaseStatus({
              isConnected: d.status.isConnected,
              tablesReady: d.status.tablesReady,
              pingLatencyMs: d.status.pingLatencyMs,
              error: d.status.error
            });
          }
        })
        .catch(() => {});

      // Check Telegram webhook info
      fetch('/api/telegram/webhook-info')
        .then(r => r.json())
        .then(d => {
          if (d?.info?.result) {
            setWebhookInfo(d.info.result);
            if (d.info.result.url) {
              setWebhookUrl(d.info.result.url);
            }
          }
        })
        .catch(() => {});

      // Load tokens overview
      loadTokensOverview();

      // Default webhook URL from origin if empty
      if (typeof window !== 'undefined' && !webhookUrl) {
        setWebhookUrl(`${window.location.origin}/api/telegram/webhook`);
      }
    }
  }, [isOwner]);

  const handleVerifyOwner = (e: React.FormEvent) => {
    e.preventDefault();
    setOwnerAuthError('');
    const clean = ownerInputId.trim();
    if (clean === CHIEF_OWNER_TG_ID) {
      setChiefOwnerAuthenticated(clean);
      setIsOwner(true);
      onOwnerStatusChange?.(true);
    } else {
      setOwnerAuthError(`Неверный ID. Доступ разрешен только главному владельцу (ID: ${CHIEF_OWNER_TG_ID})`);
    }
  };

  const handleQuickUnlock = () => {
    setChiefOwnerAuthenticated(CHIEF_OWNER_TG_ID);
    setIsOwner(true);
    onOwnerStatusChange?.(true);
  };

  const handleLogoutOwner = () => {
    revokeChiefOwner();
    setIsOwner(false);
    onOwnerStatusChange?.(false);
  };

  const loadTokensOverview = () => {
    setLoadingTokens(true);
    fetch('/api/cloud/tokens/overview')
      .then(r => r.json())
      .then(d => {
        if (d?.tokens) {
          setTokensList(d.tokens);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingTokens(false));
  };

  const handleTestSupabase = async () => {
    setIsTestingSupabase(true);
    setSyncMessage(null);
    try {
      const res = await testSupabaseConnection(supabaseUrl, supabaseAnonKey);
      setSupabaseStatus({
        isConnected: res.success,
        tablesReady: res.tables ? true : undefined,
        pingLatencyMs: res.latencyMs,
        message: res.message,
        error: !res.success ? res.message : null
      });

      if (res.success) {
        saveSupabaseConfig(supabaseUrl, supabaseAnonKey);
        await fetch('/api/supabase/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url: supabaseUrl,
            anonKey: supabaseAnonKey,
            serviceRoleKey: supabaseServiceRoleKey
          })
        });
      }
    } catch (e: any) {
      setSupabaseStatus({ isConnected: false, error: e.message });
    } finally {
      setIsTestingSupabase(false);
    }
  };

  const handleSyncAllTokensToSupabase = async () => {
    setIsSyncingTokens(true);
    setSyncMessage(null);
    try {
      const res = await fetch('/api/supabase/sync-all-tokens', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSyncMessage('Все локальные токены успешно выгружены в Supabase!');
        loadTokensOverview();
      } else {
        setSyncMessage(`Ошибка синхронизации: ${data.error}`);
      }
    } catch (e: any) {
      setSyncMessage(`Ошибка: ${e.message}`);
    } finally {
      setIsSyncingTokens(false);
    }
  };

  const handleLoadTokensFromSupabase = async () => {
    setIsSyncingTokens(true);
    setSyncMessage(null);
    try {
      const res = await fetch('/api/supabase/load-tokens');
      const data = await res.json();
      if (data.success) {
        setSyncMessage('Токены успешно загружены из Supabase в сервер!');
        loadTokensOverview();
      } else {
        setSyncMessage(`Ошибка: ${data.error}`);
      }
    } catch (e: any) {
      setSyncMessage(`Ошибка: ${e.message}`);
    } finally {
      setIsSyncingTokens(false);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleTestBot = async () => {
    setIsTestingBot(true);
    setBotStatusMessage(null);
    try {
      const res = await fetch('/api/telegram/bot-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ botToken })
      });
      const data = await res.json();
      if (data.valid && data.bot) {
        setBotInfo(data.bot);
        setBotStatusMessage(`Бот авторизован: @${data.bot.username} (${data.bot.firstName})`);
        loadTokensOverview();
      } else {
        setBotStatusMessage(`Ошибка авторизации бота: ${data.error}`);
      }
    } catch (e: any) {
      setBotStatusMessage(`Ошибка: ${e.message}`);
    } finally {
      setIsTestingBot(false);
    }
  };

  const handleSetWebhook = async () => {
    setBotStatusMessage('Установка вебхука в Telegram...');
    try {
      const res = await fetch('/api/telegram/set-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ botToken, webhookUrl })
      });
      const data = await res.json();
      if (data.success && data.result?.ok) {
        setBotStatusMessage(`Вебхук успешно установлен на: ${data.webhookUrl}`);
        const infoRes = await fetch('/api/telegram/webhook-info');
        const infoData = await infoRes.json();
        if (infoData?.info?.result) setWebhookInfo(infoData.info.result);
      } else {
        setBotStatusMessage(`Не удалось установить вебхук: ${data.error || data.result?.description}`);
      }
    } catch (e: any) {
      setBotStatusMessage(`Ошибка: ${e.message}`);
    }
  };

  const handleSaveToken = async (provider: string) => {
    if (!editTokenValue) return;
    try {
      const res = await fetch('/api/cloud/tokens/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          token: editTokenValue
        })
      });
      const data = await res.json();
      if (data.success) {
        setEditingProvider(null);
        setEditTokenValue('');
        loadTokensOverview();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleTestWaveCloud = async () => {
    setTestingWave(true);
    try {
      const res = await fetch('/api/cloud/wave/next?station=user:onyourwave');
      const data = await res.json();
      if (data.success && data.tracks?.length > 0) {
        setTestWaveData(data.tracks[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTestingWave(false);
    }
  };

  const handleSearchCloud = async () => {
    if (!testSearchQuery.trim()) return;
    setSearchingCloud(true);
    try {
      const res = await fetch(`/api/cloud/search?q=${encodeURIComponent(testSearchQuery)}`);
      const data = await res.json();
      if (data.success && data.tracks) {
        setTestSearchResults(data.tracks);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSearchingCloud(false);
    }
  };

  const botCommandsText = `wave - Запустить поток «Моя волна»
search - Поиск музыки по каталогам
tokens - Проверить статус подключения токенов
help - Инструкция и команды`;

  const handleCopyCommands = () => {
    navigator.clipboard.writeText(botCommandsText);
    setCopiedCommands(true);
    setTimeout(() => setCopiedCommands(false), 2500);
  };

  // =========================================================================
  // OWNER SECURITY GATE (Telegram Bot 2FA - Strict Owner Access: 8981404137)
  if (!isOwner) {
    return (
      <div className="w-full max-w-xl mx-auto p-6 sm:p-10 my-8">
        <div className="bg-[#121318] border-2 border-amber-500/50 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border-2 border-amber-500/40 shadow-[0_0_25px_rgba(245,158,11,0.25)]">
            <Lock className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5" />
              <span>Главный владелец</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Доступ строго ограничен
            </h2>
            <p className="text-zinc-200 text-sm leading-relaxed max-w-md mx-auto font-medium">
              Конфигурация <b>Supabase</b>, <b>Telegram-бота</b> и <b>токенов</b> скрыта и защищена двухфакторной аутентификацией. Доступ имеет только главный владелец с верифицированным Telegram ID <span className="font-mono text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">{CHIEF_OWNER_TG_ID}</span>.
            </p>
          </div>

          <div className="space-y-3 max-w-sm mx-auto pt-2">
            <button
              onClick={() => setShowOwnerAuthModal(true)}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-sm transition-all shadow-xl shadow-amber-900/30 active:scale-95 cursor-pointer flex items-center justify-center gap-2.5 border-2 border-amber-300"
            >
              <Send className="w-4 h-4" />
              <span>Войти через Telegram-бота (2FA)</span>
            </button>
            <p className="text-[11px] text-zinc-400 leading-normal">
              Безопасная аутентификация: генерация одноразового токена → подтверждение в боте → 6-значный OTP на почту. Никаких ручных обходов.
            </p>
          </div>

          <OwnerAuthModal
            isOpen={showOwnerAuthModal}
            onClose={() => setShowOwnerAuthModal(false)}
            onAuthenticated={() => {
              setChiefOwnerAuthenticated(CHIEF_OWNER_TG_ID);
              setIsOwner(true);
              setShowOwnerAuthModal(false);
              onOwnerStatusChange?.(true);
            }}
            t={t}
          />
        </div>
      </div>
    );
  }

  // =========================================================================
  // MAIN HUB VIEW (High contrast, crystal clear readability)
  // =========================================================================
  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 text-white space-y-6 font-sans">
      {/* Top Owner Status Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-zinc-900 border-2 border-emerald-500/40 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Crown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-sm sm:text-base">Главный Владелец Активен</span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-mono font-bold border border-emerald-500/30">
                ID: {CHIEF_OWNER_TG_ID}
              </span>
            </div>
            <p className="text-zinc-300 text-xs mt-0.5">
              Вам предоставлен эксклюзивный доступ к конфигурации Supabase, Telegram-боту и токенам
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
          <button
            onClick={() => setShowNetlifyModal(true)}
            className="px-3.5 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-bold border-2 border-teal-500/40 transition-all flex items-center gap-2 cursor-pointer shadow-md hover:border-teal-400"
          >
            <Globe className="w-3.5 h-3.5 text-teal-400" />
            <span>Деплой Netlify & Домен</span>
          </button>
          <button
            onClick={() => setShowOwnerAuthModal(true)}
            className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 hover:text-amber-200 text-xs font-bold border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Сессии 2FA</span>
          </button>
          <button
            onClick={handleLogoutOwner}
            className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-bold border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-zinc-400" />
            <span>Заблокировать панель</span>
          </button>
        </div>
      </div>

      {/* Main Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-zinc-900 border-2 border-zinc-700 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-extrabold border border-emerald-500/40">
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>Глобальный онлайн-масштаб & Серверная синхронизация</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Облако, Supabase & Telegram Bot
            </h1>
            <p className="text-zinc-200 text-sm max-w-2xl leading-relaxed">
              Центр управления для масштабирования в интернет: подключение Supabase PostgreSQL, 
              Telegram-бота и Mini App, единое хранилище токенов (Яндекс, VK, OK.ru) и публичный API «Моей волны».
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <div className="p-3.5 rounded-2xl bg-black border-2 border-zinc-700 flex items-center gap-3">
              <div className={`w-3.5 h-3.5 rounded-full ${supabaseStatus.isConnected ? 'bg-emerald-400 animate-pulse shadow-[0_0_10px_#34d399]' : 'bg-amber-400'}`} />
              <div className="text-left text-xs">
                <p className="font-extrabold text-white">{supabaseStatus.isConnected ? 'Supabase Подключен' : 'Supabase Не подключен'}</p>
                <p className="text-zinc-300 font-mono">{supabaseStatus.pingLatencyMs ? `${supabaseStatus.pingLatencyMs} мс задержка` : 'Локальный режим'}</p>
              </div>
            </div>

            <button
              onClick={handleSyncAllTokensToSupabase}
              disabled={isSyncingTokens}
              className="px-5 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm transition-all shadow-lg shadow-emerald-900/40 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSyncingTokens ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              <span>Синхронизировать токены</span>
            </button>
          </div>
        </div>

        {syncMessage && (
          <div className="mt-4 p-3.5 rounded-xl bg-emerald-950/80 border-2 border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{syncMessage}</span>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs (High contrast buttons) */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2 border-b-2 border-zinc-700">
        <button
          onClick={() => setActiveSubTab('supabase')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === 'supabase'
              ? 'bg-emerald-400 text-black shadow-lg shadow-emerald-900/50 scale-102 border-2 border-emerald-200 ring-2 ring-emerald-400/40'
              : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-100 hover:text-white border-2 border-zinc-700 hover:border-zinc-500'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-400" />
          <span>1. Supabase (База & Облако)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('telegram')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === 'telegram'
              ? 'bg-blue-500 text-white shadow-lg shadow-blue-900/50 scale-102 border-2 border-blue-300 ring-2 ring-blue-400/40'
              : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-100 hover:text-white border-2 border-zinc-700 hover:border-zinc-500'
          }`}
        >
          <Send className="w-4 h-4 text-blue-400" />
          <span>2. Telegram Bot & Webhook</span>
        </button>

        <button
          onClick={() => setActiveSubTab('tokens')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === 'tokens'
              ? 'bg-amber-400 text-black shadow-lg shadow-amber-900/50 scale-102 border-2 border-amber-200 ring-2 ring-amber-400/40'
              : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-100 hover:text-white border-2 border-zinc-700 hover:border-zinc-500'
          }`}
        >
          <Key className="w-4 h-4 text-amber-400" />
          <span>3. Токены (Яндекс, VK, OK.ru)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('cloud_api')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === 'cloud_api'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-900/50 scale-102 border-2 border-purple-300 ring-2 ring-purple-400/40'
              : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-100 hover:text-white border-2 border-zinc-700 hover:border-zinc-500'
          }`}
        >
          <Radio className="w-4 h-4 text-purple-400" />
          <span>4. Онлайн API: Волна & Поиск</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. SUPABASE INTEGRATION TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'supabase' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border-2 border-emerald-500/30">
                    <Database className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-white">Параметры Supabase</h3>
                    <p className="text-zinc-300 text-xs">Подключение облачной базы данных PostgreSQL</p>
                  </div>
                </div>

                <div className={`px-3 py-1.5 rounded-full text-xs font-extrabold flex items-center gap-1.5 ${
                  supabaseStatus.isConnected ? 'bg-emerald-500/20 text-emerald-300 border-2 border-emerald-500/40' : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                }`}>
                  <span className={`w-2.5 h-2.5 rounded-full ${supabaseStatus.isConnected ? 'bg-emerald-400' : 'bg-zinc-500'}`} />
                  <span>{supabaseStatus.isConnected ? 'Подключено' : 'Ожидание ключей'}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1.5">
                    Project URL (Адрес проекта в Supabase)
                  </label>
                  <input
                    type="text"
                    value={supabaseUrl}
                    onChange={(e) => setSupabaseUrl(e.target.value)}
                    placeholder="https://your-project.supabase.co"
                    className="w-full px-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-sm font-mono focus:border-emerald-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1.5">
                    Anon / Public API Key
                  </label>
                  <input
                    type="password"
                    value={supabaseAnonKey}
                    onChange={(e) => setSupabaseAnonKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="w-full px-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-sm font-mono focus:border-emerald-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1.5 flex items-center justify-between">
                    <span>Service Role Key (Опционально)</span>
                    <span className="text-[11px] text-zinc-400">Для выполнения административных запросов</span>
                  </label>
                  <input
                    type="password"
                    value={supabaseServiceRoleKey}
                    onChange={(e) => setSupabaseServiceRoleKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (Service Key)"
                    className="w-full px-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-sm font-mono focus:border-emerald-400 focus:outline-none"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={handleTestSupabase}
                    disabled={isTestingSupabase || !supabaseUrl || !supabaseAnonKey}
                    className="px-5 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs sm:text-sm transition-all shadow-lg shadow-emerald-900/40 active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-40"
                  >
                    {isTestingSupabase ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                    <span>Проверить и сохранить</span>
                  </button>

                  <button
                    onClick={() => {
                      clearSupabaseConfig();
                      setSupabaseUrl('');
                      setSupabaseAnonKey('');
                      setSupabaseStatus({ isConnected: false });
                    }}
                    className="px-4 py-3.5 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold border border-zinc-700 transition-colors"
                  >
                    Сбросить ключи
                  </button>
                </div>

                {supabaseStatus.message && (
                  <div className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-3 ${
                    supabaseStatus.isConnected ? 'bg-emerald-950/80 border-2 border-emerald-500/40 text-emerald-200' : 'bg-rose-950/80 border-2 border-rose-500/40 text-rose-200'
                  }`}>
                    {supabaseStatus.isConnected ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
                    <span>{supabaseStatus.message}</span>
                  </div>
                )}
              </div>
            </div>

            {/* SQL Migration Script Box */}
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border-2 border-purple-500/30">
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base text-white">Готовая схема SQL (1-клик миграция)</h4>
                    <p className="text-zinc-300 text-xs">Таблицы для токенов, Моей волны, профилей и Telegram</p>
                  </div>
                </div>

                <button
                  onClick={handleCopySql}
                  className={`px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer ${
                    copiedSql ? 'bg-emerald-500 text-black' : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                  }`}
                >
                  {copiedSql ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedSql ? 'Скопировано!' : 'Скопировать SQL'}</span>
                </button>
              </div>

              <div className="bg-black rounded-2xl p-4 border border-zinc-800 font-mono text-xs text-emerald-300 max-h-52 overflow-y-auto leading-relaxed select-all">
                {SUPABASE_SQL_SCHEMA.substring(0, 800)}...
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-semibold text-zinc-300 pt-1">
                <span>Откройте Supabase &rarr; SQL Editor &rarr; Вставьте и нажмите RUN</span>
                <a
                  href="https://supabase.com/dashboard"
                  target="_blank"
                  rel="noreferrer"
                  className="text-purple-400 hover:text-purple-300 flex items-center gap-1 underline font-bold"
                >
                  <span>Supabase Dashboard</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Side Info */}
          <div className="space-y-6">
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 space-y-4 shadow-xl">
              <h4 className="font-extrabold text-base text-white flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                <span>Облачный статус</span>
              </h4>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">База данных</span>
                  <span className="font-extrabold text-emerald-400">PostgreSQL (Supabase)</span>
                </div>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">Задержка пинга</span>
                  <span className="font-mono font-extrabold text-white">{supabaseStatus.pingLatencyMs ? `${supabaseStatus.pingLatencyMs} мс` : '—'}</span>
                </div>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">Синхронизация токенов</span>
                  <span className="font-extrabold text-purple-300">Двусторонняя</span>
                </div>
              </div>

              <div className="pt-2 space-y-2.5">
                <button
                  onClick={handleSyncAllTokensToSupabase}
                  disabled={isSyncingTokens || !supabaseStatus.isConnected}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold border border-zinc-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-purple-400" />
                  <span>Выгрузить токены в Supabase</span>
                </button>
                <button
                  onClick={handleLoadTokensFromSupabase}
                  disabled={isSyncingTokens || !supabaseStatus.isConnected}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold border border-zinc-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span>Загрузить токены из Supabase</span>
                </button>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-zinc-900 border-2 border-emerald-500/30 text-xs space-y-2.5">
              <p className="font-black text-emerald-300 text-sm">🚀 Зачем нужен Supabase?</p>
              <p className="text-zinc-200 leading-relaxed font-medium">
                Supabase хранит токены Яндекс Музыки, VK и OK.ru в централизованной защищенной базе. 
                Когда вы перезапускаете контейнер, подключаете Telegram-бота или открываете приложение на кастомном домене, 
                все сервисы мгновенно получают актуальные токены без повторного ввода!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TELEGRAM BOT & MINI APP TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'telegram' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center border-2 border-blue-500/30">
                    <Send className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-white">Telegram-Бот & Webhook</h3>
                    <p className="text-zinc-300 text-xs">Привязка бота к серверу для обработки команд /wave, /search и Mini App</p>
                  </div>
                </div>

                {botInfo?.username && (
                  <a
                    href={`https://t.me/${botInfo.username}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-1.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-xs font-extrabold flex items-center gap-1.5 hover:bg-blue-500/30"
                  >
                    <span>@{botInfo.username}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1.5 flex items-center justify-between">
                    <span>Telegram Bot Token (от @BotFather)</span>
                    <a href="https://t.me/BotFather" target="_blank" rel="noreferrer" className="text-blue-400 hover:underline flex items-center gap-1 font-bold">
                      <span>Создать бота в @BotFather</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </label>
                  <input
                    type="password"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    placeholder="1234567890:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                    className="w-full px-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-sm font-mono focus:border-blue-400 focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleTestBot}
                    disabled={isTestingBot || !botToken}
                    className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-40"
                  >
                    {isTestingBot ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                    <span>Проверить токен бота</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1.5 flex items-center justify-between">
                    <span>Public Webhook URL (Адрес вашего сервера или домена)</span>
                    <span className="text-[11px] text-zinc-400">Обязательно HTTPS</span>
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={webhookUrl}
                      onChange={(e) => setWebhookUrl(e.target.value)}
                      placeholder="https://your-domain.com/api/telegram/webhook"
                      className="flex-1 px-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-xs font-mono focus:border-blue-400 focus:outline-none"
                    />
                    <button
                      onClick={handleSetWebhook}
                      disabled={!botToken || !webhookUrl}
                      className="px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition-all shadow-lg active:scale-95 shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      Установить Webhook
                    </button>
                  </div>
                </div>

                {botStatusMessage && (
                  <div className="p-4 rounded-2xl bg-blue-950/80 border-2 border-blue-500/40 text-blue-200 text-xs font-bold flex items-center gap-3">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-blue-400" />
                    <span>{botStatusMessage}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Telegram Commands Helper */}
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-base text-white">Команды для @BotFather (/setcommands)</h4>
                  <p className="text-zinc-300 text-xs">Скопируйте этот список и отправьте боту @BotFather для настройки меню</p>
                </div>
                <button
                  onClick={handleCopyCommands}
                  className={`px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer ${
                    copiedCommands ? 'bg-emerald-500 text-black' : 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700'
                  }`}
                >
                  {copiedCommands ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedCommands ? 'Скопировано!' : 'Скопировать'}</span>
                </button>
              </div>

              <div className="bg-black rounded-2xl p-4 border border-zinc-800 font-mono text-xs text-zinc-200 space-y-1.5 font-bold">
                <p>wave - Запустить поток «Моя волна»</p>
                <p>search - Поиск музыки по каталогам</p>
                <p>tokens - Проверить статус подключения токенов</p>
                <p>help - Инструкция и команды</p>
              </div>
            </div>
          </div>

          {/* Webhook Status Info */}
          <div className="space-y-6">
            <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 space-y-4 shadow-xl">
              <h4 className="font-extrabold text-base text-white flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-400" />
                <span>Статус Webhook</span>
              </h4>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">Текущий URL</span>
                  <span className="font-mono text-blue-300 font-bold truncate max-w-[150px]">{webhookInfo?.url || 'Не установлен'}</span>
                </div>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">Очередь сообщений</span>
                  <span className="font-extrabold text-white">{webhookInfo?.pending_update_count ?? 0}</span>
                </div>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black border border-zinc-800">
                  <span className="text-zinc-300 font-bold">Последняя ошибка</span>
                  <span className="font-bold text-rose-400 truncate max-w-[150px]">{webhookInfo?.last_error_message || 'Нет'}</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-zinc-900 border-2 border-blue-500/30 text-xs space-y-2.5">
              <p className="font-black text-blue-300 text-sm">📱 Telegram Mini App (TMA)</p>
              <p className="text-zinc-200 leading-relaxed font-medium">
                Вы можете привязать это веб-приложение прямо внутрь бота как Telegram Mini App! 
                Для этого в @BotFather выберите бота &rarr; <b>Bot Settings</b> &rarr; <b>Menu Button</b> &rarr; 
                введите URL вашего сервера. Пользователи смогут слушать музыку прямо в Telegram!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. UNIVERSAL TOKENS HUB (ОТ А ДО Я) */}
      {/* ========================================================================= */}
      {activeSubTab === 'tokens' && (
        <div className="space-y-6">
          <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="font-black text-xl text-white flex items-center gap-2.5">
                  <Key className="w-6 h-6 text-amber-400" />
                  <span>Универсальное хранилище токенов «От А до Я»</span>
                </h3>
                <p className="text-zinc-300 text-xs mt-1">
                  Подключение токенов Яндекс Музыки, VK Музыки, OK.ru и Telegram для бесперебойного стриминга онлайн
                </p>
              </div>

              <button
                onClick={loadTokensOverview}
                disabled={loadingTokens}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold border border-zinc-700 transition-colors flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingTokens ? 'animate-spin' : ''}`} />
                <span>Обновить статус</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tokensList.map((item) => {
                const platformMap: Record<string, string> = {
                  yandex: 'yandex',
                  vk: 'vk',
                  ok_ru: 'okru',
                  telegram_bot: 'telegram',
                  spotify: 'spotify',
                };
                const mappedPlatform = platformMap[item.provider] || item.provider;

                return (
                <div
                  key={item.provider}
                  className="bg-black border-2 border-zinc-800 hover:border-zinc-700 rounded-3xl p-5 sm:p-6 flex flex-col justify-between gap-5 transition-all shadow-lg"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3.5">
                      <div className="shrink-0">
                        <PlatformBrandIcon platformId={mappedPlatform} size="lg" />
                      </div>
                      <div>
                        <h4 className="font-black text-base text-white">{item.name}</h4>
                        <p className="text-xs text-zinc-300 font-medium mt-0.5">
                          {item.accountName ? `Аккаунт: ${item.accountName}` : (item.hasToken ? 'Токен сохранен и валиден' : 'Токен не настроен')}
                        </p>
                      </div>
                    </div>

                    <div className={`px-3 py-1 rounded-full text-xs font-black flex items-center gap-1.5 shrink-0 ${
                      item.isValid ? 'bg-emerald-500/20 text-emerald-300 border-2 border-emerald-500/40' :
                      item.hasToken ? 'bg-amber-500/20 text-amber-300 border-2 border-amber-500/40' :
                      'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}>
                      <span className={`w-2 h-2 rounded-full ${item.isValid ? 'bg-emerald-400 animate-pulse' : item.hasToken ? 'bg-amber-400' : 'bg-zinc-500'}`} />
                      <span>{item.isValid ? 'Активен' : item.hasToken ? 'Проверка' : 'Не подключен'}</span>
                    </div>
                  </div>

                  {/* Token protected server-side indicator (no raw extraction) */}
                  {item.hasToken && (
                    <div className="bg-zinc-950 rounded-2xl p-3 px-4 border-2 border-zinc-800 flex items-center justify-between gap-3 text-xs text-zinc-100">
                      <div className="flex items-center gap-2 font-mono">
                        <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="tracking-widest text-emerald-400 font-bold">••••••••••••••••</span>
                      </div>
                      <span className="text-[11px] font-semibold text-zinc-400 bg-zinc-900 px-2.5 py-1 rounded-lg border border-zinc-800 shrink-0 flex items-center gap-1.5">
                        <Shield className="w-3 h-3 text-emerald-400" />
                        <span>Защищен сервером</span>
                      </span>
                    </div>
                  )}

                  {editingProvider === item.provider ? (
                    <div className="space-y-2 pt-1">
                      <input
                        type="password"
                        value={editTokenValue}
                        onChange={(e) => setEditTokenValue(e.target.value)}
                        placeholder={`Введите токен ${item.name}`}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-950 border-2 border-zinc-700 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none focus:border-amber-400"
                      />
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSaveToken(item.provider)}
                          className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs transition-colors cursor-pointer"
                        >
                          Сохранить токен
                        </button>
                        <button
                          onClick={() => {
                            setEditingProvider(null);
                            setEditTokenValue('');
                          }}
                          className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
                        >
                          Отмена
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between pt-1">
                      <button
                        onClick={() => {
                          setEditingProvider(item.provider);
                          setEditTokenValue('');
                        }}
                        className="text-xs text-purple-400 hover:text-purple-300 font-extrabold transition-colors cursor-pointer"
                      >
                        {item.hasToken ? 'Заменить токен' : '+ Добавить токен'}
                      </button>

                      {item.error && (
                        <span className="text-xs text-rose-400 truncate max-w-[200px] font-bold" title={item.error}>
                          {item.error}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      <OwnerAuthModal
        isOpen={showOwnerAuthModal}
        onClose={() => setShowOwnerAuthModal(false)}
        onAuthenticated={() => {
          setIsOwner(true);
          setShowOwnerAuthModal(false);
          onOwnerStatusChange?.(true);
        }}
        t={t}
      />

      {/* 4. CLOUD API: ВОЛНА & ПОИСК ТЕСТЕР */}
      {/* ========================================================================= */}
      {activeSubTab === 'cloud_api' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Cloud Rotor / My Wave Tester */}
          <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center border-2 border-yellow-500/30">
                  <Radio className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">API «Моя волна» (Online Stream)</h3>
                  <p className="text-zinc-300 text-xs">Эндпоинт для Telegram ботов и внешних клиентов</p>
                </div>
              </div>

              <button
                onClick={handleTestWaveCloud}
                disabled={testingWave}
                className="px-4 py-2.5 rounded-xl bg-yellow-500 hover:bg-yellow-400 text-black font-black text-xs transition-all shadow-md active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                {testingWave ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
                <span>Запросить трек</span>
              </button>
            </div>

            <div className="p-3.5 bg-black rounded-2xl border border-zinc-800 font-mono text-xs text-emerald-300 font-bold">
              <code>GET /api/cloud/wave/next?station=user:onyourwave</code>
            </div>

            {testWaveData ? (
              <div className="p-4 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {testWaveData.coverUri && (
                    <img
                      src={`https://${testWaveData.coverUri.replace('%%', '200x200')}`}
                      alt=""
                      className="w-12 h-12 rounded-xl object-cover shrink-0 border border-zinc-700"
                    />
                  )}
                  <div className="min-w-0">
                    <p className="font-extrabold text-sm text-white truncate">{testWaveData.title}</p>
                    <p className="text-zinc-300 text-xs truncate">{testWaveData.artists}</p>
                  </div>
                </div>

                {onPlayTrack && (
                  <button
                    onClick={() => onPlayTrack(testWaveData)}
                    className="p-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white shrink-0 shadow-md cursor-pointer"
                    title="Воспроизвести в плеере"
                  >
                    <Play className="w-4 h-4 fill-white" />
                  </button>
                )}
              </div>
            ) : (
              <p className="text-zinc-400 text-xs py-4 text-center font-medium">
                Нажмите «Запросить трек», чтобы протестировать стриминговую выдачу Моей волны через облачный API
              </p>
            )}
          </div>

          {/* Cloud Search API Tester */}
          <div className="bg-zinc-900 border-2 border-zinc-700 rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border-2 border-indigo-500/30">
                <Search className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-white">API Поиска Музыки (Cross-Search)</h3>
                <p className="text-zinc-300 text-xs">Универсальный поиск треков через Яндекс, VK и OK.ru</p>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={testSearchQuery}
                onChange={(e) => setTestSearchQuery(e.target.value)}
                placeholder="Поисковый запрос..."
                className="flex-1 px-4 py-3 rounded-xl bg-black border-2 border-zinc-700 text-white text-xs font-mono focus:border-indigo-400 focus:outline-none"
              />
              <button
                onClick={handleSearchCloud}
                disabled={searchingCloud}
                className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs transition-all shadow-md active:scale-95 shrink-0 flex items-center gap-1.5 cursor-pointer"
              >
                {searchingCloud ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                <span>Найти</span>
              </button>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {testSearchResults.length > 0 ? (
                testSearchResults.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 rounded-xl bg-black border border-zinc-800 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-bold text-white truncate">{t.title}</p>
                      <p className="text-zinc-300 text-[11px] truncate">{t.artists}</p>
                    </div>
                    {onPlayTrack && (
                      <button
                        onClick={() => onPlayTrack(t)}
                        className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white shrink-0 cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                      </button>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-zinc-400 text-xs py-4 text-center font-medium">
                  Введите запрос для проверки онлайн-поиска
                </p>
              )}
            </div>
          </div>
        </div>
      )}
      {/* Netlify Deployment & Custom Domain Modal */}
      <NetlifyDeploymentModal
        isOpen={showNetlifyModal}
        onClose={() => setShowNetlifyModal(false)}
        t={t}
      />
    </div>
  );
}
