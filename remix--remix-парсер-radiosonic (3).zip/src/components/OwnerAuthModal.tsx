import React, { useState, useEffect, useRef } from 'react';
import { 
  Crown, ShieldCheck, Send, Mail, CheckCircle2, 
  AlertCircle, Loader2, ArrowRight, X, ExternalLink, 
  RefreshCw, LogOut, Laptop, Smartphone, Clock, Lock, Edit2
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onAuthenticated: () => void;
  t?: (en: string, ru: string) => string;
}

export function OwnerAuthModal({ isOpen, onClose, onAuthenticated, t }: Props) {
  const [step, setStep] = useState<'initial' | 'waiting_telegram' | 'awaiting_email' | 'email_otp' | 'success'>('initial');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // User's custom email state
  const [userEmail, setUserEmail] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_user_email') || '';
    }
    return '';
  });
  const [maskedEmail, setMaskedEmail] = useState<string>('');

  // Request state
  const [requestId, setRequestId] = useState<string>('');
  const [botDeepLink, setBotDeepLink] = useState<string>('');
  const [countdown, setCountdown] = useState<number>(300); // 5 mins in seconds

  // OTP state
  const [otpCode, setOtpCode] = useState<string>('');
  const [otpCountdown, setOtpCountdown] = useState<number>(300);
  const [resendCooldown, setResendCooldown] = useState<number>(0);

  // Active sessions management
  const [showSessions, setShowSessions] = useState(false);
  const [sessionsList, setSessionsList] = useState<any[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(false);

  const pollIntervalRef = useRef<any>(null);

  // Reset states on open
  useEffect(() => {
    if (isOpen) {
      setError(null);
      checkExistingSession();
    } else {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    }
    return () => {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [isOpen]);

  // Timers
  useEffect(() => {
    let timer: any = null;
    if (step === 'waiting_telegram' && countdown > 0) {
      timer = setInterval(() => setCountdown(c => (c > 0 ? c - 1 : 0)), 1000);
    } else if (step === 'email_otp' && otpCountdown > 0) {
      timer = setInterval(() => setOtpCountdown(c => (c > 0 ? c - 1 : 0)), 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [step, countdown, otpCountdown]);

  // Resend cooldown timer
  useEffect(() => {
    let timer: any = null;
    if (resendCooldown > 0) {
      timer = setInterval(() => setResendCooldown(c => (c > 0 ? c - 1 : 0)), 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [resendCooldown]);

  const checkExistingSession = async () => {
    try {
      const res = await fetch('/api/owner/session');
      const data = await res.json();
      if (data?.isAuthenticated) {
        setStep('success');
        if (data.maskedEmail) setMaskedEmail(data.maskedEmail);
        onAuthenticated();
      } else {
        setStep('initial');
      }
    } catch (e) {
      setStep('initial');
    }
  };

  const handleStartAuth = async () => {
    setLoading(true);
    setError(null);

    const cleanEmail = userEmail.trim().toLowerCase();
    if (cleanEmail && (!cleanEmail.includes('@') || !cleanEmail.includes('.'))) {
      setError('Пожалуйста, введите корректный адрес электронной почты');
      setLoading(false);
      return;
    }

    try {
      if (cleanEmail) {
        localStorage.setItem('auth_user_email', cleanEmail);
      }

      const res = await fetch('/api/owner/auth/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail || undefined })
      });
      const data = await res.json();

      if (!data.success || !data.requestId) {
        setError(data.error || 'Не удалось запустить авторизацию. Попробуйте позже.');
        return;
      }

      setRequestId(data.requestId);
      setBotDeepLink(data.botDeepLink || '');
      if (data.maskedEmail) setMaskedEmail(data.maskedEmail);
      setCountdown(300);
      setStep('waiting_telegram');

      // Automatically open Telegram bot in new tab if deep link available
      if (data.botDeepLink) {
        window.open(data.botDeepLink, '_blank');
      }

      // Start polling backend status
      startPolling(data.requestId);
    } catch (err: any) {
      setError(err.message || 'Ошибка сети при запуске авторизации');
    } finally {
      setLoading(false);
    }
  };

  const startPolling = (reqId: string) => {
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);

    pollIntervalRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/owner/auth/status?requestId=${encodeURIComponent(reqId)}`);
        const statusData = await res.json();

        if (statusData.status === 'awaiting_email') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setStep('awaiting_email');
        } else if (statusData.status === 'awaiting_email_otp') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          if (statusData.maskedEmail) setMaskedEmail(statusData.maskedEmail);
          setStep('email_otp');
          setOtpCountdown(300);
          setResendCooldown(45);
        } else if (statusData.status === 'completed') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          if (statusData.maskedEmail) setMaskedEmail(statusData.maskedEmail);
          setStep('success');
          onAuthenticated();
        } else if (statusData.status === 'cancelled') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setError('Вход был отклонен в Telegram-боте.');
          setStep('initial');
        } else if (statusData.status === 'expired') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setError('Срок действия запроса истек. Начните заново.');
          setStep('initial');
        }
      } catch (e) {}
    }, 2000);
  };

  const handleSendEmailOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanEmail = userEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('Введите действительный адрес электронной почты для получения кода');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      localStorage.setItem('auth_user_email', cleanEmail);
      const res = await fetch('/api/owner/auth/send-email-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId,
          email: cleanEmail
        })
      });
      const data = await res.json();

      if (data.success) {
        if (data.maskedEmail) setMaskedEmail(data.maskedEmail);
        setStep('email_otp');
        setOtpCountdown(300);
        setResendCooldown(45);
      } else {
        setError(data.error || 'Не удалось отправить код на указанный email.');
      }
    } catch (err: any) {
      setError('Сетевая ошибка при отправке кода на почту.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = otpCode.trim().replace(/\s+/g, '');
    if (cleanCode.length < 6) {
      setError('Введите полный 6-значный код подтверждения');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/owner/auth/verify-email-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId,
          otpCode: cleanCode
        })
      });
      const data = await res.json();

      if (data.success) {
        if (data.session?.maskedEmail) setMaskedEmail(data.session.maskedEmail);
        setStep('success');
        onAuthenticated();
      } else {
        setError(data.error || 'Не удалось подтвердить вход. Проверьте код.');
      }
    } catch (err: any) {
      setError('Сетевая ошибка при проверке кода.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/owner/auth/resend-email-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      });
      const data = await res.json();
      if (data.success) {
        setResendCooldown(45);
        setOtpCountdown(300);
        if (data.maskedEmail) setMaskedEmail(data.maskedEmail);
      } else {
        setError(data.error || 'Не удалось повторно отправить код.');
      }
    } catch (err: any) {
      setError('Ошибка при повторной отправке кода.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoadSessions = async () => {
    setLoadingSessions(true);
    try {
      const res = await fetch('/api/owner/sessions');
      const data = await res.json();
      if (data?.sessions) {
        setSessionsList(data.sessions);
      }
    } catch (e) {} finally {
      setLoadingSessions(false);
    }
  };

  const handleRevokeSession = async (sessionId: string) => {
    try {
      await fetch('/api/owner/revoke-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      });
      handleLoadSessions();
    } catch (e) {}
  };

  const handleRevokeAllSessions = async () => {
    try {
      await fetch('/api/owner/revoke-all-sessions', { method: 'POST' });
      handleLoadSessions();
    } catch (e) {}
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/owner/logout', { method: 'POST' });
    } catch (e) {}
    setStep('initial');
    onClose();
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#0e1117] border-2 border-emerald-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl text-center space-y-6 relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-32 bg-emerald-500/20 blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* ========================================================================= */}
        {/* STEP 1: INITIAL SCREEN */}
        {/* ========================================================================= */}
        {step === 'initial' && (
          <div className="space-y-5">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border-2 border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(245,158,11,0.25)]">
              <Crown className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-black uppercase tracking-wider">
                <Crown className="w-3.5 h-3.5" />
                <span>Двухфакторная защита (2FA)</span>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight">
                Вход с подтверждением
              </h2>
              <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed max-w-md mx-auto font-medium">
                Подтверждение через <b>Telegram-бота</b> и одноразовый 6-значный код на <b>ваш Email</b>.
              </p>
            </div>

            {/* Email Input Field */}
            <div className="space-y-1.5 text-left">
              <label className="block text-xs font-bold text-zinc-200">
                Ваша электронная почта для получения кода:
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => {
                    setUserEmail(e.target.value);
                    setError(null);
                  }}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black border-2 border-zinc-700 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-emerald-400 font-medium transition-colors"
                />
              </div>
              <p className="text-[11px] text-zinc-400">
                Код подтверждения придёт именно на этот адрес почты.
              </p>
            </div>

            {error && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border-2 border-rose-500/50 text-rose-200 text-xs font-bold flex items-center gap-2.5 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <div className="pt-1">
              <button
                onClick={handleStartAuth}
                disabled={loading}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-sm sm:text-base transition-all shadow-xl shadow-emerald-950/60 active:scale-95 cursor-pointer flex items-center justify-center gap-2.5 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                <span>Войти через Telegram</span>
              </button>
            </div>

            {/* Visual Security Pipeline */}
            <div className="border-t border-zinc-800 pt-4 space-y-2 text-xs text-zinc-300">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="font-bold flex items-center gap-2">
                  <Send className="w-3.5 h-3.5 text-blue-400" />
                  <span>1. Telegram-бот:</span>
                </span>
                <span className="text-amber-400 font-extrabold">Подтверждение в боте</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="font-bold flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-purple-400" />
                  <span>2. Код на почту:</span>
                </span>
                <span className="text-zinc-400 font-bold truncate max-w-[180px]">
                  {userEmail ? userEmail : 'На ваш введённый email'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-2 text-zinc-400 text-xs font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Защищённый 2FA вход • Ваши персональные данные в безопасности</span>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2: WAITING FOR TELEGRAM BOT CONFIRMATION */}
        {/* ========================================================================= */}
        {step === 'waiting_telegram' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-3xl bg-blue-500/10 border-2 border-blue-500/40 text-blue-400 flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(59,130,246,0.25)]">
              <Send className="w-8 h-8 animate-bounce" />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-black">
                <Clock className="w-3.5 h-3.5" />
                <span>Шаг 1 из 2</span>
              </div>
              <h3 className="text-xl font-black text-white">
                Подтвердите вход в Telegram-боте
              </h3>
              <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed max-w-sm mx-auto font-medium">
                Откройте бота в Telegram и нажмите кнопку <b>«✅ Подтвердить вход»</b>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-900 border-2 border-zinc-700 flex items-center justify-between">
              <span className="text-zinc-300 text-xs font-bold">Запрос действует:</span>
              <span className="font-mono text-amber-400 font-black text-base">{formatSeconds(countdown)}</span>
            </div>

            {error && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border-2 border-rose-500/50 text-rose-200 text-xs font-bold flex items-center gap-2.5 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex flex-col gap-2.5">
              {botDeepLink && (
                <a
                  href={botDeepLink}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3.5 px-6 rounded-2xl bg-blue-500 hover:bg-blue-400 text-white font-black text-sm transition-all shadow-lg shadow-blue-950/60 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Открыть Telegram-бота</span>
                </a>
              )}

              <button
                onClick={() => setStep('initial')}
                className="w-full py-3 px-4 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Отмена
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 text-zinc-400 text-xs">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
              <span>Ожидание нажатия кнопки в боте...</span>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2.5: AWAITING EMAIL (If user hasn't provided email yet) */}
        {/* ========================================================================= */}
        {step === 'awaiting_email' && (
          <form onSubmit={handleSendEmailOtp} className="space-y-6 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-3xl bg-purple-500/10 border-2 border-purple-500/40 text-purple-400 flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(168,85,247,0.25)]">
              <Mail className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-black">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Telegram подтверждён • Шаг 2 из 2</span>
              </div>
              <h3 className="text-xl font-black text-white">
                Куда отправить код?
              </h3>
              <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed max-w-sm mx-auto font-medium">
                Введите ваш адрес электронной почты, на который отправить 6-значный код подтверждения:
              </p>
            </div>

            <div className="space-y-2 text-left">
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => {
                    setUserEmail(e.target.value);
                    setError(null);
                  }}
                  placeholder="name@example.com"
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-black border-2 border-purple-500/50 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-purple-400 font-medium"
                  autoFocus
                />
              </div>
            </div>

            {error && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border-2 border-rose-500/50 text-rose-200 text-xs font-bold flex items-center gap-2.5 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setStep('initial')}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                type="submit"
                disabled={loading || !userEmail.includes('@')}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs sm:text-sm shadow-lg shadow-purple-950/50 cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-40"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                <span>Отправить код</span>
              </button>
            </div>
          </form>
        )}

        {/* ========================================================================= */}
        {/* STEP 3: EMAIL 2FA OTP */}
        {/* ========================================================================= */}
        {step === 'email_otp' && (
          <form onSubmit={handleVerifyOtp} className="space-y-6 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-3xl bg-purple-500/10 border-2 border-purple-500/40 text-purple-400 flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(168,85,247,0.25)]">
              <Mail className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-black">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Telegram подтверждён • Шаг 2 из 2</span>
              </div>
              <h3 className="text-xl font-black text-white">
                Введите код подтверждения
              </h3>
              <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed max-w-sm mx-auto font-medium">
                Код отправлен на адрес:<br />
                <span className="inline-flex items-center gap-1.5 mt-1 font-mono text-purple-300 font-bold text-sm bg-purple-500/10 px-2.5 py-1 rounded-xl border border-purple-500/30">
                  <span>{maskedEmail || userEmail}</span>
                  <button
                    type="button"
                    onClick={() => setStep('awaiting_email')}
                    className="p-1 hover:text-white text-zinc-400 cursor-pointer"
                    title="Изменить адрес почты"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </span>
              </p>
            </div>

            <div className="space-y-2">
              <input
                type="text"
                maxLength={6}
                value={otpCode}
                onChange={(e) => {
                  setOtpCode(e.target.value.replace(/\D/g, ''));
                  setError(null);
                }}
                placeholder="••••••"
                className="w-full py-4 px-4 rounded-2xl bg-black border-2 border-purple-500/50 text-white font-mono text-2xl tracking-[0.4em] font-black text-center focus:outline-none focus:border-purple-400 shadow-inner"
                autoFocus
              />
              <div className="flex items-center justify-between text-xs text-zinc-400 px-1 font-bold">
                <span>Код действует: {formatSeconds(otpCountdown)}</span>
                <button
                  type="button"
                  onClick={handleResendOtp}
                  disabled={resendCooldown > 0 || loading}
                  className="text-purple-400 hover:text-purple-300 disabled:text-zinc-600 cursor-pointer font-bold"
                >
                  {resendCooldown > 0 ? `Повторить (${resendCooldown}с)` : 'Отправить повторно'}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border-2 border-rose-500/50 text-rose-200 text-xs font-bold flex items-center gap-2.5 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setStep('initial')}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                type="submit"
                disabled={loading || otpCode.length < 6}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs sm:text-sm shadow-lg shadow-emerald-950/50 cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-40"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                <span>Подтвердить вход</span>
              </button>
            </div>
          </form>
        )}

        {/* ========================================================================= */}
        {/* STEP 4: AUTHENTICATED / ACTIVE SESSIONS MANAGEMENT */}
        {/* ========================================================================= */}
        {step === 'success' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border-2 border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.3)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-black">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>Главный владелец активен</span>
              </div>
              <h3 className="text-xl font-black text-white">
                Сессия владельца подтверждена
              </h3>
              <p className="text-zinc-300 text-xs font-medium">
                Telegram: ✅ Подтверждён • Email: ✅ {maskedEmail || userEmail || 'Подтверждён'}
              </p>
            </div>

            {/* Active Sessions Drawer */}
            <div className="border border-zinc-800 rounded-2xl p-4 bg-zinc-950 text-left space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-white text-xs flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-emerald-400" />
                  <span>Управление активными сеансами</span>
                </span>
                <button
                  onClick={() => {
                    setShowSessions(!showSessions);
                    if (!showSessions) handleLoadSessions();
                  }}
                  className="text-xs text-emerald-400 hover:underline font-bold cursor-pointer"
                >
                  {showSessions ? 'Скрыть' : 'Показать'}
                </button>
              </div>

              {showSessions && (
                <div className="space-y-2 pt-2 border-t border-zinc-800">
                  {loadingSessions ? (
                    <div className="py-4 text-center text-zinc-400 text-xs flex items-center justify-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Загрузка сессий...</span>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                        {sessionsList.map((s) => (
                          <div
                            key={s.id}
                            className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between text-xs"
                          >
                            <div>
                              <p className="font-bold text-white flex items-center gap-1.5">
                                <span>{s.deviceLabel}</span>
                                {s.isCurrent && (
                                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                                    Текущий
                                  </span>
                                )}
                              </p>
                              <p className="text-[11px] text-zinc-400 font-mono">
                                IP: {s.ip} • Активность: {new Date(s.lastActive).toLocaleTimeString()}
                              </p>
                              {s.email && (
                                <p className="text-[10px] text-purple-400 font-mono">
                                  Email: {s.maskedEmail || s.email}
                                </p>
                              )}
                            </div>
                            {!s.isCurrent && (
                              <button
                                onClick={() => handleRevokeSession(s.id)}
                                className="px-2.5 py-1 rounded bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-[11px] font-bold cursor-pointer"
                              >
                                Завершить
                              </button>
                            )}
                          </div>
                        ))}
                      </div>

                      <button
                        onClick={handleRevokeAllSessions}
                        className="w-full py-2 px-3 rounded-xl bg-rose-950/80 hover:bg-rose-900/80 border border-rose-500/40 text-rose-200 text-xs font-bold transition-colors cursor-pointer text-center"
                      >
                        Завершить все остальные сеансы
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={handleLogout}
                className="flex-1 py-3 px-4 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Выйти из панели</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer"
              >
                Перейти в панель
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
