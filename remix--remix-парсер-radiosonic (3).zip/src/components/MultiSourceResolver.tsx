import React from 'react';
import { Shield, Music, Disc3, Clock, Calendar, CheckCircle2, AlertTriangle, HelpCircle } from 'lucide-react';

export default function MultiSourceResolver({ result }: { result: any }) {
  if (!result) return null;

  const { identity, recording, release, rights, label, distributors, sources, conflicts } = result;

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'confirmed': return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'conflict': return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'unknown':
      default: return <HelpCircle className="w-4 h-4 text-zinc-500" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white/5 dark:bg-zinc-900/50 p-6 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-2"><Music className="w-4 h-4" /> TRACK IDENTITY</h3>
          <div className="grid grid-cols-2 gap-y-4">
             <div>
                <p className="text-xs text-zinc-400">ARTIST</p>
                <p className="font-medium text-black dark:text-white">{identity.artist || 'Unknown'}</p>
             </div>
             <div>
                <p className="text-xs text-zinc-400">TITLE</p>
                <p className="font-medium text-black dark:text-white">{identity.title || 'Unknown'}</p>
             </div>
             <div>
                <p className="text-xs text-zinc-400">VERSION</p>
                <p className="font-medium text-black dark:text-white">{identity.version || 'Original'}</p>
             </div>
             <div>
                <p className="text-xs text-zinc-400">ALBUM</p>
                <p className="font-medium text-black dark:text-white">{identity.album || 'Unknown'}</p>
             </div>
             <div>
                <p className="text-xs text-zinc-400 flex items-center gap-1"><Calendar className="w-3 h-3" /> RELEASE DATE</p>
                <p className="font-medium text-black dark:text-white">{identity.releaseDate || 'Unknown'}</p>
             </div>
             <div>
                <p className="text-xs text-zinc-400 flex items-center gap-1"><Clock className="w-3 h-3" /> DURATION</p>
                <p className="font-medium text-black dark:text-white">{identity.duration ? `\${Math.floor(identity.duration / 60)}:\${(identity.duration % 60).toString().padStart(2, '0')}` : 'Unknown'}</p>
             </div>
          </div>
        </div>

        <div className="bg-white/5 dark:bg-zinc-900/50 p-6 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-2"><Disc3 className="w-4 h-4" /> IDENTIFIERS</h3>
          <div className="space-y-4">
             <div>
                <p className="text-xs text-zinc-400 mb-1">ISRC</p>
                <div className="flex items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10">
                   <span className="font-mono text-black dark:text-white">{recording.isrc.value || 'Not found'}</span>
                   <div className="flex items-center gap-2">
                     <span className="text-xs text-zinc-500 uppercase">{recording.isrc.status}</span>
                     {getStatusIcon(recording.isrc.status)}
                   </div>
                </div>
                {recording.isrc.sources && recording.isrc.sources.length > 0 && (
                   <p className="text-xs text-zinc-500 mt-1">Sources: {recording.isrc.sources.join(', ')}</p>
                )}
             </div>
             <div>
                <p className="text-xs text-zinc-400 mb-1">UPC / EAN</p>
                <div className="flex items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10">
                   <span className="font-mono text-black dark:text-white">{release.upc.value || 'Not found'}</span>
                   <div className="flex items-center gap-2">
                     <span className="text-xs text-zinc-500 uppercase">{release.upc.status}</span>
                     {getStatusIcon(release.upc.status)}
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>

      <div className="bg-white/5 dark:bg-zinc-900/50 p-6 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-2"><Shield className="w-4 h-4" /> RIGHTS & DISTRIBUTION</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="space-y-4">
              <div>
                 <p className="text-xs text-zinc-400 mb-1">℗ PHONOGRAM COPYRIGHT</p>
                 {rights.copyright.filter((c:any) => c.raw.includes('℗')).map((c:any, i:number) => (
                    <div key={i} className="bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10 mb-2">
                       <p className="text-sm font-medium text-black dark:text-white">{c.raw}</p>
                       <p className="text-xs text-zinc-500 mt-1">Detected Entity: {c.entity} (Source: {c.source})</p>
                    </div>
                 ))}
                 {rights.copyright.filter((c:any) => c.raw.includes('℗')).length === 0 && <p className="text-sm text-zinc-500">Not found</p>}
              </div>
              <div>
                 <p className="text-xs text-zinc-400 mb-1">© COPYRIGHT</p>
                 {rights.copyright.filter((c:any) => !c.raw.includes('℗')).map((c:any, i:number) => (
                    <div key={i} className="bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10 mb-2">
                       <p className="text-sm font-medium text-black dark:text-white">{c.raw}</p>
                       <p className="text-xs text-zinc-500 mt-1">Detected Entity: {c.entity} (Source: {c.source})</p>
                    </div>
                 ))}
                 {rights.copyright.filter((c:any) => !c.raw.includes('℗')).length === 0 && <p className="text-sm text-zinc-500">Not found</p>}
              </div>
           </div>
           
           <div className="space-y-4">
              <div>
                 <p className="text-xs text-zinc-400 mb-1">LABEL</p>
                 <div className="bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10">
                   <p className="text-sm font-medium text-black dark:text-white">{label || 'Not found'}</p>
                 </div>
              </div>
              <div>
                 <p className="text-xs text-zinc-400 mb-1">DISTRIBUTOR / AGGREGATOR</p>
                 <div className="bg-black/5 dark:bg-white/5 p-3 rounded-lg border border-black/10 dark:border-white/10">
                   {rights.copyright.filter((c:any) => c.raw.includes('℗') && c.source === 'ok.ru').map((c:any, i:number) => (
                      <div key={i}>
                         <p className="text-sm font-medium text-black dark:text-white">{c.entity}</p>
                         <p className="text-xs text-amber-500 mt-1">PROBABLE — inferred from OK.ru copyright</p>
                      </div>
                   ))}
                   {rights.copyright.filter((c:any) => c.raw.includes('℗') && c.source === 'ok.ru').length === 0 && <p className="text-sm text-zinc-500">Unknown</p>}
                 </div>
              </div>
           </div>
        </div>
      </div>

      <div className="bg-white/5 dark:bg-zinc-900/50 p-6 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-wider">SOURCES STATUS</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
           {['ok.ru', 'yandex', 'spotify', 'apple', 'deezer', 'musicbrainz', 'vk', 'zvuk'].map(provider => {
              const res = sources[provider];
              return (
                 <div key={provider} className={`p-3 rounded-lg border ${res?.status === 'confirmed' ? 'border-green-500/30 bg-green-500/5' : 'border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5'} flex flex-col gap-1`}>
                    <p className="text-xs font-bold uppercase text-black dark:text-white">{provider}</p>
                    <p className="text-[10px] text-zinc-500 uppercase">{res?.status || 'pending'}</p>
                 </div>
              );
           })}
        </div>
      </div>
    </div>
  );
}
