import React, { useEffect, useRef, useState } from 'react';
import {
  audioEqualizer,
  EQUALIZER_PRESETS,
  FREQUENCY_LABELS,
  FineTuningSettings,
} from '../utils/audioEqualizer';
import {
  Sliders,
  Volume2,
  Zap,
  RotateCcw,
  Sparkles,
  Layers,
  Radio,
  X,
  Check,
  Disc3,
  Waves,
} from 'lucide-react';

interface EqualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EqualizerModal({ isOpen, onClose }: EqualizerModalProps) {
  const [settings, setSettings] = useState<FineTuningSettings>(audioEqualizer.getSettings());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    return audioEqualizer.subscribe((newSettings) => {
      setSettings(newSettings);
    });
  }, []);

  // Real-time canvas audio spectrum visualizer
  useEffect(() => {
    if (!isOpen) {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const analyser = audioEqualizer.getAnalyser();

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Background subtle grid
      ctx.fillStyle = 'rgba(24, 24, 27, 0.4)';
      ctx.fillRect(0, 0, width, height);

      let dataArray = new Uint8Array(64);
      if (analyser && settings.enabled) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        // Subtle resting wave
        const time = Date.now() / 300;
        dataArray = new Uint8Array(
          Array.from({ length: 64 }, (_, i) => Math.sin(i * 0.2 + time) * 15 + 20)
        );
      }

      const barCount = 32;
      const barWidth = (width / barCount) - 3;

      for (let i = 0; i < barCount; i++) {
        const value = dataArray[Math.floor((i / barCount) * dataArray.length)] || 0;
        const percent = Math.min(1, value / 255);
        const barHeight = Math.max(4, percent * (height - 12));

        const x = i * (barWidth + 3) + 2;
        const y = height - barHeight - 4;

        // Gradient for bars
        const grad = ctx.createLinearGradient(0, y, 0, height);
        if (settings.enabled) {
          grad.addColorStop(0, '#a855f7'); // Purple
          grad.addColorStop(0.5, '#3b82f6'); // Blue
          grad.addColorStop(1, '#06b6d4'); // Cyan
        } else {
          grad.addColorStop(0, '#52525b');
          grad.addColorStop(1, '#27272a');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 1, 1]);
        ctx.fill();

        // Top glow dot
        if (settings.enabled && percent > 0.15) {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(x + barWidth / 2, y - 2, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isOpen, settings.enabled]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10005] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                10-полосный Эквалайзер и Звук
                {settings.enabled && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    DSP Активен
                  </span>
                )}
              </h2>
              <p className="text-xs text-zinc-400">
                Тонкая настройка частот, усиление баса, 3D стереобаза и пресеты
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => audioEqualizer.setEnabled(!settings.enabled)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                settings.enabled
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/25'
                  : 'bg-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              {settings.enabled ? 'Включен' : 'Выключен'}
            </button>

            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Live Audio Spectrum Visualizer */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-4 relative overflow-hidden">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-zinc-400 flex items-center gap-1.5">
                <Waves className="w-3.5 h-3.5 text-purple-400" />
                Спектральный анализатор в реальном времени
              </span>
              <span className="text-[11px] text-zinc-500 font-mono">
                {settings.enabled ? '20 Гц — 20 кГц' : 'Bypassed'}
              </span>
            </div>
            <canvas
              ref={canvasRef}
              width={700}
              height={90}
              className="w-full h-20 rounded-xl bg-zinc-950/80 border border-zinc-800/50"
            />
          </div>

          {/* Presets Bar */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Звуковые пресеты
              </span>
              <button
                onClick={() => audioEqualizer.resetAll()}
                className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                Сбросить в ноль
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {EQUALIZER_PRESETS.map((preset) => {
                const isActive = settings.presetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => audioEqualizer.setPreset(preset.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold shadow-md shadow-purple-600/20 scale-[1.02]'
                        : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {preset.nameRu}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 10-Band Graphic Equalizer */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                10-полосная регулировка (-12 дБ … +12 дБ)
              </span>
              <span className="text-xs text-zinc-500">
                Двойной клик на регулятор сбрасывает в 0 дБ
              </span>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 sm:gap-4 items-end justify-items-center py-2">
              {FREQUENCY_LABELS.map((label, index) => {
                const gain = settings.bands[index] || 0;
                return (
                  <div key={label} className="flex flex-col items-center gap-2 w-full">
                    {/* Gain dB Value */}
                    <span
                      className={`text-[11px] font-mono font-semibold ${
                        gain > 0
                          ? 'text-purple-400'
                          : gain < 0
                          ? 'text-blue-400'
                          : 'text-zinc-500'
                      }`}
                    >
                      {gain > 0 ? `+${gain}` : gain}
                    </span>

                    {/* Vertical Slider */}
                    <div className="h-36 flex items-center justify-center py-2 relative">
                      <input
                        type="range"
                        min="-12"
                        max="12"
                        step="0.5"
                        value={gain}
                        onDoubleClick={() => audioEqualizer.setBandGain(index, 0)}
                        onChange={(e) =>
                          audioEqualizer.setBandGain(index, parseFloat(e.target.value))
                        }
                        className="h-32 w-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-purple-500 [writing-mode:bt-lr] [-webkit-appearance:slider-vertical]"
                      />
                    </div>

                    {/* Zero center indicator line */}
                    <span className="text-[11px] font-medium text-zinc-400 truncate w-full text-center">
                      {label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Fine Tuning & Audio Enhancements (Тонкая настройка) */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              Тонкая настройка и пространственные эффекты
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
              {/* Bass Boost */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium flex items-center gap-1">
                    <Disc3 className="w-3.5 h-3.5 text-purple-400" />
                    Усиление баса (Bass Boost)
                  </span>
                  <span className="font-mono text-purple-400 font-semibold">
                    {settings.bassBoost}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.bassBoost}
                  onChange={(e) => audioEqualizer.setBassBoost(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                />
              </div>

              {/* 3D Surround Spatializer */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium flex items-center gap-1">
                    <Radio className="w-3.5 h-3.5 text-blue-400" />
                    3D Пространственный звук (Surround)
                  </span>
                  <span className="font-mono text-blue-400 font-semibold">
                    {settings.surround}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.surround}
                  onChange={(e) => audioEqualizer.setSurround(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              {/* Vocal Clarity */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    Четкость вокала и речи
                  </span>
                  <span className="font-mono text-amber-400 font-semibold">
                    {settings.vocalClarity}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.vocalClarity}
                  onChange={(e) => audioEqualizer.setVocalClarity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Pre-Amp Gain */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium flex items-center gap-1">
                    <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                    Предусилитель (Pre-Amp)
                  </span>
                  <span className="font-mono text-emerald-400 font-semibold">
                    {settings.preAmp > 0 ? `+${settings.preAmp}` : settings.preAmp} дБ
                  </span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.5"
                  value={settings.preAmp}
                  onChange={(e) => audioEqualizer.setPreAmp(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              {/* Balance */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium">Баланс каналов (L / R)</span>
                  <span className="font-mono text-zinc-400">
                    {settings.balance === 0
                      ? 'Центр'
                      : settings.balance < 0
                      ? `L ${Math.abs(Math.round(settings.balance * 100))}%`
                      : `R ${Math.round(settings.balance * 100)}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-1"
                  max="1"
                  step="0.05"
                  value={settings.balance}
                  onDoubleClick={() => audioEqualizer.setBalance(0)}
                  onChange={(e) => audioEqualizer.setBalance(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-zinc-300"
                />
              </div>

              {/* Playback Speed */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-300 font-medium">Скорость воспроизведения</span>
                  <span className="font-mono text-cyan-400 font-semibold">
                    {settings.playbackRate}x
                  </span>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {[0.75, 0.9, 1.0, 1.1, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => audioEqualizer.setPlaybackRate(rate)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-colors ${
                        settings.playbackRate === rate
                          ? 'bg-cyan-600 text-white font-bold'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-zinc-800/80 flex items-center justify-between bg-zinc-900/30">
          <span className="text-xs text-zinc-500">
            Настройки автоматически сохраняются и применяются ко всем трекам
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-white text-black font-bold rounded-xl text-sm hover:bg-zinc-200 transition-colors shadow-lg"
          >
            Готово
          </button>
        </div>
      </div>
    </div>
  );
}
