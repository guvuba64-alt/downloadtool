import React, { useState, useEffect } from 'react';
import { 
  X, Key, Info, Check, Copy, LogOut, RefreshCw, ExternalLink, 
  User, Crown, Activity, Globe, MapPin, Wifi, ShieldCheck, AlertCircle 
} from 'lucide-react';

export const TokenSettingsModal = ({ 
  isTokenModalOpen, 
  setIsTokenModalOpen, 
  status, 
  code, 
  setCode, 
  isSubmitting, 
  error, 
  onSubmitAuth, 
  handleRefresh,
  handleDisconnect,
  copiedAccess,
  copiedRefresh,
  handleCopy,
  AUTH_URL,
  t 
}: any) => {
  const [showReplaceInput, setShowReplaceInput] = useState(false);
  const [pingData, setPingData] = useState<{
    latencyMs?: number;
    status?: number;
    authorized?: boolean;
    endpoint?: string;
    loading?: boolean;
    error?: string;
  } | null>(null);

  const [geoData, setGeoData] = useState<{
    ip?: string;
    country?: string;
    countryCode?: string;
    countryFlag?: string;
    city?: string;
    region?: string;
    isp?: string;
    latencyMs?: number;
    isProxy?: boolean;
    loading?: boolean;
    error?: string;
  } | null>(null);

  // Ping Yandex API
  const testYandexPing = async () => {
    setPingData(prev => ({ ...prev, loading: true, error: undefined }));
    const startTime = Date.now();
    try {
      const res = await fetch("/api/music/ping");
      const data = await res.json();
      if (res.ok && data.success) {
        setPingData({
          latencyMs: data.latencyMs,
          status: data.status,
          authorized: data.authorized,
          endpoint: data.endpoint,
          loading: false,
        });
      } else {
        setPingData({
          latencyMs: Date.now() - startTime,
          status: data.status || 500,
          authorized: false,
          endpoint: "api.music.yandex.net",
          loading: false,
          error: data.error || "Ошибка соединения",
        });
      }
    } catch (e: any) {
      setPingData({
        latencyMs: Date.now() - startTime,
        status: 0,
        authorized: false,
        loading: false,
        error: e.message || "Не удалось отправить запрос",
      });
    }
  };

  // Fetch Geo & Proxy status
  const fetchGeoInfo = async () => {
    setGeoData(prev => ({ ...prev, loading: true, error: undefined }));
    try {
      const res = await fetch("/api/proxy/geo");
      const data = await res.json();
      if (res.ok && data.success) {
        setGeoData({
          ip: data.ip,
          country: data.country,
          countryCode: data.countryCode,
          countryFlag: data.countryFlag,
          city: data.city,
          region: data.region,
          isp: data.isp,
          latencyMs: data.latencyMs,
          isProxy: data.isProxy,
          loading: false,
        });
      } else {
        setGeoData({
          loading: false,
          error: data.message || "Не удалось получить геолокацию",
        });
      }
    } catch (e: any) {
      setGeoData({
        loading: false,
        error: e.message || "Ошибка запроса геолокации",
      });
    }
  };

  useEffect(() => {
    if (isTokenModalOpen) {
      testYandexPing();
      fetchGeoInfo();
      try {
        const saved = localStorage.getItem("yandex_music_token");
        if (saved && !code && !status?.connected) {
          setCode(saved);
        }
      } catch (e) {}
    }
  }, [isTokenModalOpen]);

  if (!isTokenModalOpen) return null;

  const user = status?.user;
  const token = status?.token || status;
  const accessToken = token?.accessToken || token?.access_token || status?.access_token;
  const refreshToken = token?.refreshToken || token?.refresh_token || status?.refresh_token;
  const isValid = status?.valid !== false;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#18181b] w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden border border-zinc-200/80 dark:border-white/10 flex flex-col animate-in zoom-in-95 duration-200 max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-100 dark:border-white/5 flex justify-between items-center shrink-0">
          <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-50 flex items-center gap-2.5">
            <Key className="w-5 h-5 text-blue-500" /> {t("Yandex Music Token & Network Diagnostics", "Токен Яндекс Музыки и Сеть")}
          </h3>
          <button 
            onClick={() => setIsTokenModalOpen(false)} 
            className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors p-1.5 rounded-full hover:bg-zinc-100 dark:hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 flex-1 overflow-y-auto space-y-4">
          
          {/* Quick Notice about Yandex API Status */}
          <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/70 dark:border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${status?.connected && isValid ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-400'}`} />
              <div className="min-w-0">
                <div className="text-xs font-bold text-zinc-800 dark:text-zinc-200">
                  {status?.connected && isValid ? t("Yandex Music API: Connected", "API Яндекс Музыки: Подключено") : t("Yandex Music API: Inactive / Disconnected", "API Яндекс Музыки: Отключено")}
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                  {status?.connected && isValid ? t("Using authorized access token", "Используется авторизованный токен") : t("API calls disabled or using public fallback", "Запросы отключены или без токена")}
                </div>
              </div>
            </div>

            <div className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 shrink-0">
              {status?.connected && isValid ? t("Authorized", "Авторизован") : t("Disconnected", "Отключен")}
            </div>
          </div>

          {/* Diagnostic Stats Cards: Ping & Proxy Geolocation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* 1. Yandex API Ping */}
            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/70 dark:border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-blue-500" /> {t("Yandex API Ping", "Пинг к API Яндекса")}
                </span>
                <button
                  onClick={testYandexPing}
                  disabled={pingData?.loading}
                  title={t("Test ping again", "Перепроверить пинг")}
                  className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-white transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${pingData?.loading ? 'animate-spin text-blue-500' : ''}`} />
                </button>
              </div>

              <div className="flex items-baseline gap-2">
                {pingData?.loading ? (
                  <span className="text-sm font-semibold text-zinc-400 animate-pulse">{t("Measuring...", "Измерение...")}</span>
                ) : pingData?.latencyMs !== undefined ? (
                  <>
                    <span className={`text-2xl font-black tracking-tight ${
                      pingData.latencyMs < 120 
                        ? 'text-emerald-500' 
                        : pingData.latencyMs < 300 
                          ? 'text-amber-500' 
                          : 'text-rose-500'
                    }`}>
                      {pingData.latencyMs} <span className="text-xs font-bold uppercase">мс</span>
                    </span>
                    <span className="text-[11px] font-semibold text-zinc-500 dark:text-zinc-400">
                      ({pingData.status === 200 ? '200 OK' : `HTTP ${pingData.status}`})
                    </span>
                  </>
                ) : (
                  <span className="text-xs text-zinc-400">{t("Not checked", "Не проверено")}</span>
                )}
              </div>

              <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate mt-1">
                {pingData?.endpoint || "api.music.yandex.net"}
              </div>
            </div>

            {/* 2. Proxy & Geolocation */}
            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/70 dark:border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-purple-500" /> {t("Geolocation & IP", "Геолокация и IP")}
                </span>
                <button
                  onClick={fetchGeoInfo}
                  disabled={geoData?.loading}
                  title={t("Refresh location", "Обновить геолокацию")}
                  className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-white transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${geoData?.loading ? 'animate-spin text-purple-500' : ''}`} />
                </button>
              </div>

              <div>
                {geoData?.loading ? (
                  <span className="text-sm font-semibold text-zinc-400 animate-pulse">{t("Detecting...", "Определение...")}</span>
                ) : geoData?.ip ? (
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 text-sm font-bold text-zinc-800 dark:text-zinc-200 truncate">
                      <span className="text-base leading-none">{geoData.countryFlag || '🌐'}</span>
                      <span>{geoData.city ? `${geoData.city}, ` : ''}{geoData.country || geoData.countryCode || 'Unknown'}</span>
                    </div>
                    <div className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 truncate">
                      IP: {geoData.ip} {geoData.isp ? `• ${geoData.isp}` : ''}
                    </div>
                  </div>
                ) : (
                  <span className="text-xs text-rose-500 font-medium">{geoData?.error || t("Unable to determine IP", "Не удалось определить IP")}</span>
                )}
              </div>

              <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 flex items-center justify-between">
                <span className="flex items-center gap-1 truncate">
                  <MapPin className="w-3 h-3 text-purple-400 shrink-0" />
                  <span className="truncate">{geoData?.region || geoData?.country || "Сервер приложений"}</span>
                </span>
                {geoData?.latencyMs !== undefined && (
                  <span className="text-[10px] font-semibold text-zinc-400 shrink-0 ml-1">
                    {geoData.isProxy ? "Proxy" : "Direct"} • {geoData.latencyMs} мс
                  </span>
                )}
              </div>
            </div>

          </div>

          {status?.connected ? (
            <div className="space-y-4">
              {/* Account / Profile Card */}
              {user ? (
                <div className="p-4 bg-gradient-to-r from-zinc-50 to-zinc-100 dark:from-white/5 dark:to-white/[0.02] rounded-2xl border border-zinc-200/60 dark:border-white/10 flex items-center gap-3.5">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.displayName}
                      className="w-12 h-12 rounded-full object-cover border border-zinc-200 dark:border-white/10 shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                      <User className="w-6 h-6" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-zinc-900 dark:text-zinc-100 truncate text-base">
                        {user.displayName}
                      </h4>
                      {user.hasPlus && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                          <Crown className="w-3 h-3" /> Плюс
                        </span>
                      )}
                    </div>
                    {user.login && (
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                        @{user.login}
                      </p>
                    )}
                  </div>
                </div>
              ) : null}

              {/* Status block */}
              <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
                isValid
                  ? "bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20"
                  : "bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20"
              }`}>
                <div className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                  isValid ? "bg-green-500 animate-pulse" : "bg-amber-500"
                }`}></div>
                <div className="flex-1">
                  <h4 className={`font-semibold text-sm mb-0.5 ${
                    isValid ? "text-green-900 dark:text-green-400" : "text-amber-900 dark:text-amber-400"
                  }`}>
                    {isValid ? t("Connected & Active", "Подключено и активно") : t("Token check warning", "Токен требует проверки")}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400">
                    {isValid
                      ? t("API requests are authorized and operational.", "Запросы к Яндекс Музыке авторизованы.")
                      : (status.verificationError || t("Token expired or missing permissions.", "Токен устарел или не имеет доступа к музыке."))}
                  </p>

                  <div className="flex flex-wrap gap-2 mt-3.5">
                    <button 
                      onClick={handleRefresh}
                      disabled={isSubmitting}
                      className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-white/10 dark:hover:bg-white/20 text-zinc-800 dark:text-zinc-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isSubmitting ? 'animate-spin' : ''}`} />
                      {t("Verify / Refresh", "Проверить / Обновить")}
                    </button>

                    <button 
                      onClick={() => setShowReplaceInput(!showReplaceInput)}
                      className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-500/10 dark:hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <Key className="w-3.5 h-3.5" />
                      {showReplaceInput ? t("Hide", "Скрыть ввод") : t("Change token", "Заменить токен")}
                    </button>
                    
                    <button 
                      onClick={handleDisconnect}
                      disabled={isSubmitting}
                      className="px-3 py-1.5 bg-red-50 hover:bg-red-100 dark:bg-red-500/10 dark:hover:bg-red-500/20 text-red-600 dark:text-red-400 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      {t("Disconnect", "Отключить")}
                    </button>
                  </div>
                </div>
              </div>

              {/* Replace token inline form */}
              {showReplaceInput && (
                <div className="p-4 bg-zinc-50 dark:bg-black/30 rounded-2xl border border-zinc-200 dark:border-white/10 space-y-3">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                    {t("Enter New Token or URL", "Введите новый токен или ссылку")}
                  </label>
                  <input 
                    type="text" 
                    value={code}
                    onChange={e => setCode(e.target.value)}
                    placeholder={t("Paste y0_... or OAuth link", "Вставьте y0_... или ссылку")}
                    className="w-full px-3.5 py-2.5 bg-white dark:bg-black/50 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-xs font-mono"
                  />
                  {error && <p className="text-red-500 text-xs font-medium">{error}</p>}
                  <button 
                    onClick={async (e) => {
                      await onSubmitAuth(e);
                      setShowReplaceInput(false);
                    }}
                    disabled={isSubmitting || !code}
                    className="w-full py-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5"
                  >
                    {isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    {t("Save New Token", "Сохранить новый токен")}
                  </button>
                </div>
              )}
              
              {/* Token strings display */}
              <div className="space-y-2 pt-1">
                {accessToken && (
                  <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-3 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Access Token</span>
                      <button onClick={() => handleCopy(accessToken, 'access')} className="text-blue-500 hover:text-blue-600 p-1">
                        {copiedAccess ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="font-mono text-xs text-zinc-600 dark:text-zinc-400 truncate">
                      {token?.maskedToken || accessToken}
                    </div>
                  </div>
                )}
                
                {refreshToken && (
                  <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-3 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Refresh Token</span>
                      <button onClick={() => handleCopy(refreshToken, 'refresh')} className="text-blue-500 hover:text-blue-600 p-1">
                        {copiedRefresh ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="font-mono text-xs text-zinc-600 dark:text-zinc-400 truncate">
                      {refreshToken}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-500/10 rounded-2xl border border-blue-200 dark:border-blue-500/20 mb-2">
                <h4 className="font-semibold text-blue-900 dark:text-blue-400 flex items-center gap-2 mb-1.5 text-sm">
                  <Info className="w-4 h-4" /> {t("How to get your token", "Как получить токен")}
                </h4>
                <p className="text-xs text-blue-800 dark:text-blue-300 mb-3 leading-relaxed">
                  {t("Click the button below to authorize via Yandex. You can paste the whole callback URL or just the y0_... token string.", "Нажмите кнопку ниже, чтобы авторизоваться через Яндекс. Вы можете вставить как полную ссылку со страницы авторизации, так и сам токен формата y0_...")}
                </p>
                <a href={AUTH_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white text-xs font-semibold rounded-xl transition-colors shadow-sm">
                  {t("Get Yandex API Token", "Получить токен Яндекс")} <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300">
                  {t("Access Token or URL", "Токен или ссылка авторизации")}
                </label>
                <input 
                  type="text" 
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  placeholder={t("Paste token (y0_...) or URL here...", "Вставьте токен (y0_...) или ссылку...")}
                  className="w-full px-4 py-3 bg-zinc-100 dark:bg-black/50 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono text-sm"
                />
                {error && <p className="text-red-500 text-xs font-medium">{error}</p>}
              </div>

              <button 
                onClick={onSubmitAuth}
                disabled={isSubmitting || !code}
                className="w-full mt-3 py-3 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 text-sm shadow-sm"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                {isSubmitting ? t("Connecting...", "Проверка и подключение...") : t("Connect", "Подключить")}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
