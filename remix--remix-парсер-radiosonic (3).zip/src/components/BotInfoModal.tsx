import React, { useEffect, useState } from 'react';
import { X, ExternalLink, Bot, Sparkles } from 'lucide-react';
import { TelegramIcon } from './Icons';

export const BotInfoModal = ({ isBotInfoOpen, setIsBotInfoOpen, botName, botUsername, botId, botStatus, t }: any) => {
  const [aiConfig, setAiConfig] = useState<{ enabled: boolean; model: string; provider: string } | null>(null);

  useEffect(() => {
    if (isBotInfoOpen) {
      fetch('/api/tg/ai/config')
        .then((r) => r.json())
        .then((data) => setAiConfig(data))
        .catch(() => {});
    }
  }, [isBotInfoOpen]);

  if (!isBotInfoOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl border border-zinc-200 dark:border-zinc-800 animate-in zoom-in-95 duration-200">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <TelegramIcon className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-zinc-900 dark:text-white leading-tight">{t("Bot Info", "Информация о боте")}</h3>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className="relative flex h-2 w-2">
                    {botStatus === 'online' && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
                    <span className={"relative inline-flex rounded-full h-2 w-2 " + (botStatus === 'online' ? "bg-emerald-500" : botStatus === 'checking' ? "bg-zinc-400" : "bg-red-500")}></span>
                  </span>
                  <span className="text-xs text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">{botStatus}</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsBotInfoOpen(false)} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-3.5">
            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-3.5 border border-zinc-100 dark:border-zinc-800">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-0.5">{t("Name", "Имя")}</div>
              <div className="font-medium text-zinc-900 dark:text-zinc-100">{botName || "—"}</div>
            </div>
            
            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-3.5 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
              <div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-0.5">{t("Username", "Юзернейм")}</div>
                <div className="font-medium text-zinc-900 dark:text-zinc-100">{botUsername ? "@" + botUsername : "—"}</div>
              </div>
              {botUsername && (
                <a href={"https://t.me/" + botUsername} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-sm font-medium rounded-lg transition-colors">
                  <ExternalLink className="w-4 h-4" />
                  {t("Open", "Открыть")}
                </a>
              )}
            </div>

            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-3.5 border border-zinc-100 dark:border-zinc-800">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-0.5">ID</div>
              <div className="font-mono text-xs text-zinc-900 dark:text-zinc-100">{botId || "—"}</div>
            </div>

            {/* AI Assistant Mode Badge */}
            <div className="bg-indigo-50/70 dark:bg-indigo-950/30 rounded-xl p-3.5 border border-indigo-200 dark:border-indigo-900/40">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400 font-bold text-xs">
                  <Bot className="w-4 h-4" />
                  {t("AI Assistant Mode", "ИИ-Ассистент")}
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  aiConfig?.enabled 
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800'
                    : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}>
                  {aiConfig?.enabled ? t("Active", "Включен") : t("Disabled", "Выключен")}
                </span>
              </div>
              {aiConfig?.enabled && (
                <div className="mt-1.5 text-xs text-zinc-600 dark:text-zinc-300 flex items-center justify-between">
                  <span className="text-[11px] text-zinc-400">{t("Model:", "Модель:")}</span>
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{aiConfig.model}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
