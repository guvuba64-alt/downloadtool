import React, { useState, useEffect } from "react";
import { ProxyImage } from "./ProxyImage";
import { 
  Search, Music, Disc, User, Loader2, Settings, 
  Sparkles, Flame, Play, X, ChevronRight, Film
} from "lucide-react";
import { VideoSnapshotModal } from "./VideoSnapshotModal";

interface SearchTabProps {
  onPlayTrack: (track: any, playlist: any[]) => void;
  onSelectArtist: (artistId: string, provider?: string) => void;
  onSelectAlbum: (albumOrId: any) => void;
  onOpenSpotifySettings?: () => void;
  t: (en: string, ru: string) => string;
}

export function SearchTab({ 
  onPlayTrack, 
  onSelectArtist, 
  onSelectAlbum, 
  onOpenSpotifySettings, 
  t 
}: SearchTabProps) {
  const [query, setQuery] = useState("");
  const [provider, setProvider] = useState("yandex");
  
  const providers = [
    { id: "yandex", label: "Яндекс Музыка" },
    { id: "spotify", label: "Spotify" },
    { id: "deezer", label: "Deezer" }
  ];

  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [videoSnapshotTrack, setVideoSnapshotTrack] = useState<any>(null);
  const [isVideoSnapshotOpen, setIsVideoSnapshotOpen] = useState(false);

  // Discover state for browsing without entering names
  const [discoverData, setDiscoverData] = useState<{
    releases: any[];
    artists: any[];
    genres: string[];
  }>({ releases: [], artists: [], genres: [] });
  const [loadingDiscover, setLoadingDiscover] = useState(false);

  useEffect(() => {
    fetchDiscover(provider);
  }, [provider]);

  const fetchDiscover = async (prov: string) => {
    setLoadingDiscover(true);
    try {
      const res = await fetch(`/api/music/discover?provider=${prov}`);
      const data = await res.json();
      if (data?.data) {
        setDiscoverData(data.data);
      }
    } catch (_) {
    } finally {
      setLoadingDiscover(false);
    }
  };

  const executeSearch = async (searchQuery: string, targetProvider = provider) => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    try {
      const spotifyClientId = localStorage.getItem("spotify_client_id") || "";
      const spotifyClientSecret = localStorage.getItem("spotify_client_secret") || "";
      
      const res = await fetch(`/api/music/search`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          query: searchQuery.trim(), 
          provider: targetProvider,
          spotifyClientId,
          spotifyClientSecret
        })
      });
      const data = await res.json();
      if (data?.data) {
        setResults(data.data);
      }
    } catch (_) {
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(query);
  };

  const handleTagClick = (tag: string) => {
    const cleanTag = tag.replace(/^[🔥⚡️✨]\s*/, "");
    setQuery(cleanTag);
    executeSearch(cleanTag);
  };

  return (
    <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden min-h-[600px] flex flex-col">
      {/* Header & Search Bar */}
      <div className="p-6 md:p-8 border-b border-zinc-100 dark:border-white/5 bg-gradient-to-b from-zinc-50/50 dark:from-white/[0.02] to-transparent">
        <div className="flex items-center justify-between gap-4 mb-4">
          <h3 className="font-bold text-xl md:text-2xl tracking-tight text-zinc-900 dark:text-zinc-50 flex items-center gap-2.5">
            <Search className="w-6 h-6 text-zinc-800 dark:text-zinc-200" />
            <span>{t("Search & Catalog", "Поиск и каталог релизов")}</span>
          </h3>

          {provider === "spotify" && onOpenSpotifySettings && (
            <button
              type="button"
              onClick={onOpenSpotifySettings}
              className="px-3.5 py-1.5 rounded-full text-xs font-semibold text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white bg-zinc-100 dark:bg-white/5 hover:bg-zinc-200 dark:hover:bg-white/10 transition-colors flex items-center gap-1.5"
              title={t("Spotify Settings", "Настройки Spotify")}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Spotify Keys</span>
            </button>
          )}
        </div>

        {/* Providers Tabs */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 flex-wrap">
            {providers.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setProvider(p.id);
                  if (query.trim()) {
                    executeSearch(query, p.id);
                  } else {
                    setResults(null);
                  }
                }}
                className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all ${
                  provider === p.id
                    ? p.id === "spotify"
                      ? "bg-emerald-600 text-white shadow-sm"
                      : p.id === "deezer"
                      ? "bg-purple-600 text-white shadow-sm"
                      : "bg-black text-white dark:bg-white dark:text-black shadow-sm"
                    : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-white/5 dark:text-zinc-400 dark:hover:bg-white/10"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <form onSubmit={handleSearch} className="flex items-center gap-3 relative">
            <Search className="w-5 h-5 absolute left-4 text-zinc-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("Search tracks, albums, or artists...", "Треки, альбомы, артисты...")}
              className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#141415] rounded-2xl pl-12 pr-10 py-3.5 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-all shadow-inner"
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  setResults(null);
                }}
                className="absolute right-36 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="bg-black dark:bg-white hover:opacity-85 text-white dark:text-black shadow-sm font-semibold py-3.5 px-6 rounded-2xl transition-all disabled:opacity-40 shrink-0 text-sm flex items-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : t("Search", "Найти")}
            </button>
          </form>

          {/* Genre / Style Quick Tags */}
          {discoverData.genres?.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              <span className="text-xs font-semibold text-zinc-400 shrink-0 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {t("Quick search:", "Быстрый поиск:")}
              </span>
              {discoverData.genres.map((g, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleTagClick(g)}
                  className="px-3 py-1 rounded-full text-xs font-medium bg-zinc-100 dark:bg-white/5 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-white/10 whitespace-nowrap transition-colors shrink-0"
                >
                  {g}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-6 md:p-8 flex-1">
        {/* If Active Search Results exist, display them */}
        {results ? (
          <div className="flex flex-col gap-8">
            {/* Artists Result */}
            {!!results?.artists?.results?.length && (
              <div>
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-zinc-900 dark:text-zinc-100">
                  <User className="w-5 h-5 text-zinc-700 dark:text-zinc-300" />
                  <span>{t("Artists", "Исполнители")}</span>
                </h4>
                <div className="flex flex-col gap-2">
                  {results.artists.results.map((artist: any) => {
                    const cover = artist.cover?.uri
                      ? (artist.cover.uri.startsWith("http")
                          ? artist.cover.uri.replace("%%", "200x200")
                          : `https://${artist.cover.uri.replace("%%", "200x200")}`)
                      : undefined;
                    return (
                      <div
                        key={artist.id}
                        className="flex items-center justify-between p-3 sm:p-4 rounded-2xl bg-zinc-100/80 dark:bg-[#18181b] hover:bg-zinc-200/70 dark:hover:bg-[#242427] transition-all cursor-pointer group border border-zinc-200/50 dark:border-white/5 shadow-sm active:scale-[0.99]"
                        onClick={() => onSelectArtist(artist.id, provider)}
                      >
                        <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full overflow-hidden shrink-0 shadow-md border border-zinc-300 dark:border-white/10 bg-zinc-200 dark:bg-zinc-800">
                            {cover ? (
                              <ProxyImage src={cover} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <User className="w-6 h-6 text-zinc-400" />
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="font-bold text-base sm:text-lg text-zinc-900 dark:text-white truncate group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
                              {artist.name}
                            </span>
                            <span className="text-xs text-zinc-500 dark:text-zinc-400">
                              {t("Artist", "Исполнитель")}{artist.genres?.length ? ` • ${artist.genres[0]}` : ""}
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-zinc-400 group-hover:text-zinc-900 dark:group-hover:text-white transition-colors shrink-0 mr-1" />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tracks Result */}
            {!!results?.tracks?.results?.length && (
              <div>
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-zinc-900 dark:text-zinc-100">
                  <Music className="w-5 h-5 text-zinc-700 dark:text-zinc-300" />
                  <span>{t("Tracks", "Треки")}</span>
                </h4>
                <div className="flex flex-col gap-2">
                  {results.tracks.results.map((track: any) => {
                    const cover = track.coverUri
                      ? (track.coverUri.startsWith("http")
                          ? track.coverUri.replace("%%", "100x100")
                          : `https://${track.coverUri.replace("%%", "100x100")}`)
                      : undefined;
                    return (
                      <div
                        key={track.id}
                        className="flex items-center gap-4 p-3 hover:bg-zinc-50 dark:hover:bg-white/5 rounded-2xl transition-colors group cursor-pointer border border-transparent hover:border-zinc-200/50 dark:hover:border-white/10"
                        onClick={() => onPlayTrack(track, results?.tracks?.results || [])}
                      >
                        <div className="relative w-12 h-12 rounded-xl overflow-hidden shadow-sm shrink-0 bg-zinc-100 dark:bg-zinc-800">
                          <ProxyImage src={cover} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <Play className="w-5 h-5 text-white fill-white" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-zinc-900 dark:text-zinc-50 truncate text-sm">
                              {track.title}
                            </span>
                            {track.backgroundVideoUri && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                                <Film className="w-3 h-3 text-emerald-400" />
                                <span>Шот</span>
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-zinc-500 truncate mt-0.5">
                            {track.artists?.map((a: any) => a.name).join(", ")}
                          </div>
                        </div>

                        {/* Video Snapshot Action Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setVideoSnapshotTrack(track);
                            setIsVideoSnapshotOpen(true);
                          }}
                          className={`p-2 rounded-xl border transition-all cursor-pointer ${
                            track.backgroundVideoUri
                              ? 'bg-purple-500/20 hover:bg-purple-500/30 border-purple-500/30 text-purple-400'
                              : 'opacity-0 group-hover:opacity-100 bg-white/5 hover:bg-white/10 border-white/5 text-zinc-400 hover:text-white'
                          }`}
                          title={track.backgroundVideoUri ? "Дистрибьютор добавил видео-снапшот на этот трек" : "Проверить видео-снапшот и клип"}
                        >
                          <Film className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Albums Result */}
            {!!results?.albums?.results?.length && (
              <div>
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-zinc-900 dark:text-zinc-100">
                  <Disc className="w-5 h-5 text-zinc-700 dark:text-zinc-300" />
                  <span>{t("Albums & Releases", "Альбомы и релизы")}</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {results.albums.results.map((album: any, aIdx: number) => {
                    const cover = album.coverUri
                      ? (album.coverUri.startsWith("http")
                          ? album.coverUri.replace("%%", "400x400")
                          : `https://${album.coverUri.replace("%%", "400x400")}`)
                      : undefined;
                    return (
                      <div
                        key={`search-alb-${album.id || "alb"}-${aIdx}`}
                        className="flex flex-col gap-2 group cursor-pointer p-2 rounded-2xl hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors"
                        onClick={() =>
                          onSelectAlbum({
                            id: album.id,
                            provider: provider,
                            title: album.title,
                            coverUri: cover,
                            artist: album.artists?.map((a: any) => a.name).join(", ")
                          })
                        }
                      >
                        <div className="relative rounded-2xl overflow-hidden aspect-square shadow-sm bg-zinc-100 dark:bg-zinc-800">
                          <ProxyImage
                            src={cover}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center shadow-lg">
                              <Play className="w-4 h-4 ml-0.5 fill-black" />
                            </div>
                          </div>
                        </div>
                        <div>
                          <div className="font-bold text-zinc-900 dark:text-zinc-50 truncate text-sm">
                            {album.title}
                          </div>
                          <div className="text-xs text-zinc-500 truncate">
                            {album.artists?.map((a: any) => a.name).join(", ")}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* When there is NO active search query, show DISCOVERY FEED */
          <div className="flex flex-col gap-8">
            {loadingDiscover ? (
              <div className="flex flex-col items-center justify-center py-20 gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-zinc-400" />
                <p className="text-xs font-semibold text-zinc-400">
                  {t("Loading catalog releases & charts...", "Загрузка каталога и чартов...")}
                </p>
              </div>
            ) : (
              <>
                {/* 1. Featured Artists */}
                {discoverData.artists?.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-lg md:text-xl flex items-center gap-2 text-zinc-900 dark:text-zinc-100">
                        <Flame className="w-5 h-5 text-amber-500" />
                        <span>{t("Popular Artists", "Популярные исполнители")}</span>
                      </h4>
                      <span className="text-xs text-zinc-400 font-medium">
                        {t("Click to view full discography", "Нажмите для открытия всех релизов")}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 sm:gap-4">
                      {discoverData.artists.slice(0, 8).map((art: any) => {
                        const cover = art.cover?.uri
                          ? (art.cover.uri.startsWith("http")
                              ? art.cover.uri.replace("%%", "200x200")
                              : `https://${art.cover.uri.replace("%%", "200x200")}`)
                          : undefined;
                        return (
                          <div
                            key={art.id}
                            className="flex flex-col items-center gap-2 p-2 rounded-2xl group cursor-pointer hover:bg-zinc-50 dark:hover:bg-white/5 transition-all text-center"
                            onClick={() => onSelectArtist(art.id, provider)}
                          >
                            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden shadow-md group-hover:scale-105 transition-transform duration-300 border-2 border-zinc-200 dark:border-white/10 bg-zinc-100 dark:bg-zinc-800">
                              {cover ? (
                                <ProxyImage src={cover} className="w-full h-full object-cover" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <User className="w-6 h-6 text-zinc-400" />
                                </div>
                              )}
                            </div>
                            <div className="font-bold text-zinc-900 dark:text-zinc-50 truncate w-full text-xs">
                              {art.name}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 2. All Releases & Hot Albums */}
                {discoverData.releases?.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-lg md:text-xl flex items-center gap-2 text-zinc-900 dark:text-zinc-100">
                        <Disc className="w-5 h-5 text-indigo-500" />
                        <span>{t("All Releases & Albums", "Все альбомы и релизы")}</span>
                      </h4>
                      <span className="text-xs text-zinc-400 font-medium">
                        {provider === "spotify"
                          ? "Spotify Catalog"
                          : provider === "deezer"
                          ? "Deezer Top Chart"
                          : "Яндекс Новинки и Чарты"}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {discoverData.releases.map((rel: any, rIdx: number) => {
                        const cover = rel.coverUri
                          ? (rel.coverUri.startsWith("http")
                              ? rel.coverUri.replace("%%", "400x400")
                              : `https://${rel.coverUri.replace("%%", "400x400")}`)
                          : undefined;

                        return (
                          <div
                            key={`discover-rel-${rel.id || "rel"}-${rIdx}`}
                            className="flex flex-col gap-2 group cursor-pointer p-2.5 rounded-2xl hover:bg-zinc-50 dark:hover:bg-white/5 border border-transparent hover:border-zinc-200/50 dark:hover:border-white/10 transition-all"
                            onClick={() =>
                              onSelectAlbum({
                                id: rel.id,
                                provider: rel.provider || provider,
                                title: rel.title,
                                coverUri: cover,
                                artist: rel.artist,
                                year: rel.year
                              })
                            }
                          >
                            <div className="relative rounded-2xl overflow-hidden aspect-square shadow-sm bg-zinc-100 dark:bg-zinc-800">
                              <ProxyImage
                                src={cover}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />

                              <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md text-[10px] font-bold bg-black/60 backdrop-blur-md text-white capitalize">
                                {rel.type === "single" ? t("Single", "Сингл") : t("Album", "Альбом")}
                              </div>

                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                                  <Play className="w-5 h-5 ml-0.5 fill-black" />
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col min-w-0">
                              <div className="font-bold text-zinc-900 dark:text-zinc-50 truncate text-sm">
                                {rel.title}
                              </div>
                              <div className="text-xs text-zinc-500 truncate mt-0.5">
                                {rel.artist}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Video Snapshot Modal */}
      <VideoSnapshotModal
        track={videoSnapshotTrack}
        isOpen={isVideoSnapshotOpen}
        onClose={() => setIsVideoSnapshotOpen(false)}
        onPlayTrack={(t) => onPlayTrack(t, [t])}
        onOpenStudio={(trackInfo) => window.dispatchEvent(new CustomEvent('openVideoShotStudio', { detail: trackInfo }))}
      />
    </div>
  );
}
