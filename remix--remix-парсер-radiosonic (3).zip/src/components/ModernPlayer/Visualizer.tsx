import { ProxyImage } from '../ProxyImage';
import React, { useEffect, useRef } from 'react';
import { usePlayerStore } from './store';
import { motion, AnimatePresence } from 'motion/react';
import { Disc3 } from 'lucide-react';

export const Visualizer = ({ analyser, albumCover, onCoverClick }: { analyser: AnalyserNode | null, albumCover?: string, onCoverClick?: () => void }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { state, isPlaying, coverVariant } = usePlayerStore();
  const animationRef = useRef<number | null>(null);
  const particlesRef = useRef<any[]>([]);

  useEffect(() => {
    // Initialize ambient particles for vinyl reactive mode
    const particles = [];
    for (let i = 0; i < 120; i++) {
      particles.push({
        angle: Math.random() * Math.PI * 2,
        radius: Math.random() * 50 + 90,
        speed: Math.random() * 0.015 + 0.005,
        size: Math.random() * 2.5 + 1,
        alpha: Math.random() * 0.6 + 0.2
      });
    }
    particlesRef.current = particles;
  }, []);

  useEffect(() => {
    if (coverVariant !== 'vinyl') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;
    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : new Uint8Array(128);

    const draw = () => {
      time += 0.015;
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        animationRef.current = requestAnimationFrame(draw);
        return;
      }
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);

      const width = rect.width;
      const height = rect.height;
      const centerX = width / 2;
      const centerY = height / 2;

      ctx.clearRect(0, 0, width, height);

      let averageAmplitude = 0;
      let bassAmplitude = 0;
      if (analyser && isPlaying && state === 'playing') {
        analyser.getByteFrequencyData(dataArray);
        const sum = dataArray.reduce((a, b) => a + b, 0);
        averageAmplitude = sum / dataArray.length;
        
        // Bass frequencies (first ~16 bins)
        const bassSum = dataArray.slice(0, 16).reduce((a, b) => a + b, 0);
        bassAmplitude = bassSum / 16;
      }

      // Base radius of dynamic glow ring
      const baseRadius = (Math.min(width, height) * 0.38) + (bassAmplitude / 255) * 22;

      // 1. Draw outer audio-reactive equalizer glow ring
      ctx.shadowBlur = 25;
      ctx.shadowColor = `rgba(168, 85, 247, ${0.4 + (averageAmplitude / 255) * 0.5})`;

      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius + 12, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(168, 85, 247, ${0.15 + (averageAmplitude / 255) * 0.35})`;
      ctx.lineWidth = 6 + (bassAmplitude / 255) * 8;
      ctx.stroke();

      // 2. Frequency spectrum arcs
      if (analyser && isPlaying && state === 'playing') {
        const numBars = 64;
        const step = (Math.PI * 2) / numBars;
        for (let i = 0; i < numBars; i++) {
          const freqVal = dataArray[i * 2] || 0;
          const barHeight = (freqVal / 255) * 26;
          const angle = i * step + time * 0.2;
          
          const x1 = centerX + Math.cos(angle) * (baseRadius + 6);
          const y1 = centerY + Math.sin(angle) * (baseRadius + 6);
          const x2 = centerX + Math.cos(angle) * (baseRadius + 6 + barHeight);
          const y2 = centerY + Math.sin(angle) * (baseRadius + 6 + barHeight);

          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.strokeStyle = `rgba(192, 132, 252, ${0.3 + (freqVal / 255) * 0.7})`;
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }

      ctx.shadowBlur = 0; // reset

      // 3. Audio reactive orbiting particles
      particlesRef.current.forEach((p, i) => {
        p.angle += p.speed * (isPlaying ? 1.5 : 0.5);

        let r = baseRadius + 20 + Math.sin(p.angle * 4 + time) * 12;
        if (analyser && isPlaying && state === 'playing') {
          const freqIdx = Math.floor((i / particlesRef.current.length) * (dataArray.length / 2));
          r += (dataArray[freqIdx] / 255) * 28;
        }

        const x = centerX + Math.cos(p.angle) * r;
        const y = centerY + Math.sin(p.angle) * r;

        ctx.beginPath();
        ctx.arc(x, y, p.size + (averageAmplitude / 255) * 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(216, 180, 254, ${p.alpha * (isPlaying ? 1 : 0.5)})`;
        ctx.fill();
      });

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [analyser, isPlaying, state, coverVariant]);

  // Clean cover URL for high resolution
  const highResCover = albumCover 
    ? (albumCover.startsWith("http") ? albumCover.replace("%%", "600x600") : "https://" + albumCover.replace("%%", "600x600"))
    : undefined;

  return (
    <div className="relative w-full aspect-square max-w-[340px] sm:max-w-[400px] md:max-w-[440px] mx-auto flex items-center justify-center select-none">
      
      {/* VARIANT 1: NORMAL CLASSIC COVER */}
      {coverVariant === 'normal' && (
        <motion.div 
          key="cover-normal"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3 }}
          className="relative w-full h-full p-4 sm:p-6 flex items-center justify-center"
        >
          {/* Ambient colored backlight glow */}
          {highResCover && (
            <div 
              className="absolute inset-4 rounded-3xl bg-cover bg-center blur-3xl opacity-40 -z-10 transition-all duration-700 pointer-events-none"
              style={{ backgroundImage: `url(${highResCover})` }}
            />
          )}

          {/* Album artwork container */}
          <div 
            onClick={onCoverClick}
            className={`relative w-full h-full rounded-2xl sm:rounded-3xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/10 bg-zinc-900 group ${onCoverClick ? 'cursor-pointer' : ''}`}
            title={onCoverClick ? "Нажмите, чтобы открыть альбом" : undefined}
          >
            {highResCover ? (
              <ProxyImage 
                src={highResCover} 
                alt="Album Cover" 
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105" 
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-800 text-white/40">
                <Disc3 className="w-16 h-16 mb-2 opacity-50" />
                <span className="text-sm font-medium">Нет обложки</span>
              </div>
            )}
            
            {/* Subtle gloss overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-black/40 via-transparent to-white/10 pointer-events-none" />
          </div>
        </motion.div>
      )}

      {/* VARIANT 2: SOUND-REACTIVE VINYL RECORD */}
      {coverVariant === 'vinyl' && (
        <motion.div 
          key="cover-vinyl"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3 }}
          className="relative w-full h-full flex items-center justify-center"
        >
          {/* Canvas for sound-reactive waves & particles */}
          <canvas 
            ref={canvasRef} 
            className="absolute inset-0 w-full h-full pointer-events-none" 
            style={{ filter: 'drop-shadow(0 0 25px rgba(168, 85, 247, 0.4))' }} 
          />

          {/* Vinyl Disc Container */}
          <div 
            onClick={onCoverClick}
            className={`relative w-[78%] h-[78%] sm:w-[82%] sm:h-[82%] rounded-full shadow-[0_0_60px_rgba(0,0,0,0.9)] flex items-center justify-center ${onCoverClick ? 'cursor-pointer hover:scale-105 transition-transform' : ''}`}
            title={onCoverClick ? "Нажмите, чтобы открыть альбом" : undefined}
          >
            
            {/* Vinyl Body with concentric grooves and rotating sheen */}
            <div 
              className={`w-full h-full rounded-full bg-[#111113] relative overflow-hidden flex items-center justify-center shadow-inner ${isPlaying && state === 'playing' ? 'animate-[spin_18s_linear_infinite]' : ''}`}
              style={{
                background: 'radial-gradient(circle, #1a1a1e 0%, #0d0d0f 50%, #050507 100%)',
                border: '2px solid rgba(255, 255, 255, 0.08)'
              }}
            >
              {/* Concentric Vinyl Grooves (rings) */}
              <div className="absolute inset-[6%] rounded-full border border-white/[0.04] pointer-events-none" />
              <div className="absolute inset-[12%] rounded-full border border-white/[0.05] pointer-events-none" />
              <div className="absolute inset-[18%] rounded-full border border-white/[0.04] pointer-events-none" />
              <div className="absolute inset-[24%] rounded-full border border-white/[0.05] pointer-events-none" />
              <div className="absolute inset-[30%] rounded-full border border-white/[0.03] pointer-events-none" />
              <div className="absolute inset-[35%] rounded-full border border-white/[0.06] pointer-events-none" />

              {/* Realistic vinyl light sheen reflection */}
              <div 
                className="absolute inset-0 rounded-full pointer-events-none opacity-40"
                style={{
                  background: 'conic-gradient(from 45deg, transparent 0deg, rgba(255,255,255,0.12) 60deg, transparent 120deg, transparent 180deg, rgba(255,255,255,0.12) 240deg, transparent 300deg)'
                }}
              />

              {/* Center Vinyl Label (Album Artwork) */}
              <div className="relative w-[44%] h-[44%] rounded-full overflow-hidden border-[3px] border-[#222228] shadow-[0_0_15px_rgba(0,0,0,0.8)] flex items-center justify-center bg-zinc-900">
                {highResCover ? (
                  <ProxyImage 
                    src={highResCover} 
                    alt="Center Label" 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full bg-zinc-800 flex items-center justify-center text-white/30">
                    <Disc3 className="w-8 h-8" />
                  </div>
                )}
                
                {/* Spindle hole in the very center */}
                <div className="absolute w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-[#0a0a0c] border-2 border-zinc-400/60 shadow-inner flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Buffering/Loading Overlay Indicator */}
      <AnimatePresence>
        {state === 'loading' && (
          <motion.div 
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none z-30"
          >
            <div className="px-4 py-2 rounded-full bg-black/60 backdrop-blur-md border border-purple-500/30 text-purple-200 text-xs font-semibold tracking-wider uppercase">
              Загрузка трека...
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
