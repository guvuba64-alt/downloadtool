import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, Pause, Download, Volume2, VolumeX, Maximize2, 
  Sparkles, CheckCircle2, AlertCircle, Film, Loader2, 
  ExternalLink, Layers, Check
} from 'lucide-react';
import { ProxyImage } from '../ProxyImage';

export interface VideoSnapshotViewProps {
  track: any;
  albumCover?: string;
  albumArtists?: string;
  isPlaying: boolean;
  snapshotData: {
    hasVideoSnapshot: boolean;
    hasClips?: boolean;
    distributorUploaded: boolean;
    statusText: string;
    videoSnapshot?: {
      url: string;
      streamUrl: string;
      downloadUrl: string;
      id?: string;
      type?: string;
    } | null;
    clips?: Array<{
      clipId: string | number;
      title: string;
      duration?: number;
      previewUrl?: string;
      streamUrl?: string;
      downloadUrl?: string;
      thumbnail?: string;
    }>;
  } | null;
  isLoading: boolean;
  onSwitchVariant: (variant: 'normal' | 'vinyl') => void;
}

export function VideoSnapshotView({
  track,
  albumCover,
  albumArtists,
  isPlaying,
  snapshotData,
  isLoading,
  onSwitchVariant,
}: VideoSnapshotViewProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [activeTab, setActiveTab] = useState<'snapshot' | 'clip'>('snapshot');
  const [selectedClipIndex, setSelectedClipIndex] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const hasSnapshot = Boolean(snapshotData?.hasVideoSnapshot && snapshotData.videoSnapshot?.streamUrl);
  const clips = snapshotData?.clips || [];
  const hasClips = clips.length > 0;

  // Decide current active video source
  const currentVideoUrl = (activeTab === 'snapshot' && hasSnapshot)
    ? snapshotData!.videoSnapshot!.streamUrl
    : (hasClips && clips[selectedClipIndex]?.streamUrl ? clips[selectedClipIndex].streamUrl : null);

  // Sync video play/pause with player audio state
  useEffect(() => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.play().then(() => setIsVideoPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsVideoPlaying(false);
    }
  }, [isPlaying, currentVideoUrl]);

  const toggleVideoPlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsVideoPlaying(true);
    } else {
      videoRef.current.pause();
      setIsVideoPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const handleDownload = async () => {
    const downloadUrl = (activeTab === 'snapshot' && snapshotData?.videoSnapshot?.downloadUrl)
      ? snapshotData.videoSnapshot.downloadUrl
      : (hasClips && clips[selectedClipIndex]?.downloadUrl ? clips[selectedClipIndex].downloadUrl : null);

    if (!downloadUrl) return;

    setIsDownloading(true);
    try {
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 2500);
    } catch (err) {
      console.error('Download failed', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const formattedCover = albumCover 
    ? (albumCover.startsWith('http') ? albumCover.replace('%%', '600x600') : `https://${albumCover.replace('%%', '600x600')}`) 
    : null;

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center mx-auto py-2">
      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center gap-3 py-12 text-white/70">
          <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
          <p className="text-sm font-medium">Загрузка видеошота...</p>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Main Video or Fallback Container - Full vertical 9:16 ratio without square constraints */}
          <div className="relative w-full h-full max-w-[420px] aspect-[9/16] max-h-[85vh] rounded-[28px] overflow-hidden shadow-2xl border border-white/15 bg-black/60 flex items-center justify-center group">
            {/* Ambient Blurred Background (matches video colors or cover) */}
            <div className="absolute inset-0 -z-10 scale-125 blur-3xl opacity-30 pointer-events-none overflow-hidden">
              {currentVideoUrl ? (
                <video 
                  src={currentVideoUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : formattedCover ? (
                <img src={formattedCover} alt="" className="w-full h-full object-cover" />
              ) : null}
            </div>

            {currentVideoUrl ? (
              <>
                <video
                  ref={videoRef}
                  src={currentVideoUrl}
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  className="w-full h-full object-cover cursor-pointer"
                  onClick={toggleVideoPlay}
                />

                {/* Video Overlay Top Badge: Distributor Status */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-20 pointer-events-auto">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white/90 text-[11px] font-semibold shadow-lg">
                    <Film className="w-3.5 h-3.5 shrink-0 text-purple-400" />
                    <span className="truncate">
                      {activeTab === 'snapshot' ? 'Видеошот' : 'Официальный клип'}
                    </span>
                  </div>

                  {/* Audio Mute & Fullscreen quick actions */}
                  <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md border border-white/10 rounded-full p-1 shadow-lg">
                    <button
                      onClick={toggleMute}
                      className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
                      title={isMuted ? 'Включить звук видео' : 'Отключить звук видео (играет плеер)'}
                    >
                      {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-purple-400" />}
                    </button>
                    <button
                      onClick={handleFullscreen}
                      className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
                      title="На весь экран"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Floating Play/Pause Center Indicator */}
                {!isVideoPlaying && (
                  <button
                    onClick={toggleVideoPlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px] z-10"
                  >
                    <div className="w-14 h-14 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white shadow-xl transition-transform hover:scale-105">
                      <Play className="w-6 h-6 fill-white ml-1" />
                    </div>
                  </button>
                )}

                {/* Bottom Overlay Info & Quick Download Bar */}
                <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-between gap-3 z-20">
                  <div className="min-w-0 flex-1">
                    <p className="text-white font-bold text-sm truncate">{track.title}</p>
                    <p className="text-white/60 text-xs truncate">{albumArtists || track.artists}</p>
                  </div>

                  <button
                    onClick={handleDownload}
                    disabled={isDownloading}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs transition-all shadow-lg active:scale-95 ${
                      downloadSuccess 
                        ? 'bg-emerald-500 text-white'
                        : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-900/40'
                    }`}
                    title="Скачать этот видео-клип/снапшот на устройство"
                  >
                    {isDownloading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : downloadSuccess ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Скачано</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" />
                        <span>Скачать MP4</span>
                      </>
                    )}
                  </button>
                </div>
              </>
            ) : (
              /* Fallback when distributor did NOT upload a video snapshot */
              <div className="flex flex-col items-center justify-center p-6 text-center max-w-xs z-10">
                <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 mb-4 shadow-inner">
                  <Film className="w-8 h-8 text-white/30" />
                </div>

                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white/70 text-xs font-medium mb-3">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Видео-снапшот отсутствует</span>
                </div>

                <h4 className="text-white font-bold text-base mb-1">
                  Видеошот отсутствует
                </h4>
                <p className="text-white/50 text-xs leading-relaxed mb-5">
                  Для данного трека видеошот пока не добавлен в Яндекс Музыке.
                </p>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSwitchVariant('normal')}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg shadow-purple-900/30 transition-all active:scale-95"
                  >
                    Показать обложку
                  </button>
                  <button
                    onClick={() => onSwitchVariant('vinyl')}
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 hover:text-white text-xs font-semibold border border-white/10 transition-all active:scale-95"
                  >
                    Винил
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Sub-bar: If clips are also available, let user toggle between Video Shot (9:16) and Clips */}
          {hasClips && (
            <div className="flex items-center justify-center gap-2 mt-3 w-full">
              {hasSnapshot && (
                <button
                  onClick={() => setActiveTab('snapshot')}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                    activeTab === 'snapshot'
                      ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(147,51,234,0.5)]'
                      : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  Видеошот (9:16)
                </button>
              )}

              {clips.map((clip, idx) => (
                <button
                  key={clip.clipId || idx}
                  onClick={() => {
                    setActiveTab('clip');
                    setSelectedClipIndex(idx);
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                    activeTab === 'clip' && selectedClipIndex === idx
                      ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(147,51,234,0.5)]'
                      : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  Клип #{idx + 1}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
