import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';

export interface WaveformVisualizerProps {
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  analyser?: AnalyserNode | null;
  trackId?: string | number;
  trackTitle?: string;
  onSeek?: (time: number) => void;
  className?: string;
  height?: number;
  barCount?: number;
  interactive?: boolean;
  variant?: 'full' | 'compact' | 'mini';
}

function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// Generate realistic musical peaks based on seed
function generateTrackPeaks(seedKey: string, count: number): number[] {
  let hash = 0;
  for (let i = 0; i < seedKey.length; i++) {
    hash = (hash << 5) - hash + seedKey.charCodeAt(i);
    hash |= 0;
  }

  // Simple deterministic LCG random generator
  let seed = Math.abs(hash) || 4242;
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  const peaks: number[] = [];
  const introEnd = Math.floor(count * 0.12);
  const outroStart = Math.floor(count * 0.88);
  const chorus1Start = Math.floor(count * 0.28);
  const chorus1End = Math.floor(count * 0.45);
  const chorus2Start = Math.floor(count * 0.62);
  const chorus2End = Math.floor(count * 0.82);

  // Generate multi-octave pseudo-waveform
  for (let i = 0; i < count; i++) {
    const progress = i / count;
    let base = 0.35 + rand() * 0.45;

    // Structure envelope: Intro
    if (i < introEnd) {
      const introFactor = (i + 1) / introEnd;
      base *= 0.3 + introFactor * 0.7;
    } 
    // Outro fade
    else if (i > outroStart) {
      const outroFactor = (count - i) / (count - outroStart);
      base *= 0.3 + outroFactor * 0.7;
    }

    // Chorus / Drop dynamic boost
    if ((i >= chorus1Start && i <= chorus1End) || (i >= chorus2Start && i <= chorus2End)) {
      base = Math.min(1.0, base * 1.35 + 0.1);
    }

    // Add rhythmic micro-harmonics
    const rhythm = Math.sin(progress * Math.PI * 18) * 0.12 + Math.cos(progress * Math.PI * 40) * 0.08;
    const finalVal = Math.max(0.12, Math.min(0.98, base + rhythm));
    peaks.push(finalVal);
  }

  return peaks;
}

export function WaveformVisualizer({
  currentTime,
  duration,
  isPlaying,
  analyser,
  trackId = 'default',
  trackTitle = '',
  onSeek,
  className = '',
  height = 52,
  barCount = 64,
  interactive = true,
  variant = 'full'
}: WaveformVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [hoverPosition, setHoverPosition] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Smoothed dynamic frequency amplitudes for each bar
  const dynamicAmplitudesRef = useRef<Float32Array>(new Float32Array(barCount));
  const rawDataArrayRef = useRef<Uint8Array | null>(null);

  // Cache base track waveform peaks
  const basePeaks = useMemo(() => {
    const key = `${trackId}-${trackTitle}`;
    return generateTrackPeaks(key, barCount);
  }, [trackId, trackTitle, barCount]);

  // Keep progress in ref for high-framerate 60 FPS animation loop
  const progressRef = useRef(0);
  useEffect(() => {
    progressRef.current = duration > 0 ? Math.min(1, Math.max(0, currentTime / duration)) : 0;
  }, [currentTime, duration]);

  const isPlayingRef = useRef(isPlaying);
  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  // Handle seeking interaction
  const handleSeekFromClientX = useCallback((clientX: number) => {
    if (!containerRef.current || !onSeek || duration <= 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    onSeek(ratio * duration);
  }, [duration, onSeek]);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (!interactive) return;
    setIsDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    handleSeekFromClientX(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!interactive || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setHoverPosition(ratio);

    if (isDragging) {
      handleSeekFromClientX(e.clientX);
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!interactive) return;
    setIsDragging(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch (_) {}
  };

  const handlePointerLeave = () => {
    if (!isDragging) {
      setHoverPosition(null);
    }
  };

  // Main high-performance Canvas Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;

    const render = () => {
      time += 0.035;

      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const h = rect.height;

      if (width === 0 || h === 0) {
        animationFrameRef.current = requestAnimationFrame(render);
        return;
      }

      // Handle retina resolution
      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(h * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(h * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, h);

      // Check audio analyser frequency data
      let hasRealAnalyserData = false;
      if (analyser && isPlayingRef.current) {
        if (!rawDataArrayRef.current || rawDataArrayRef.current.length !== analyser.frequencyBinCount) {
          rawDataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);
        }
        analyser.getByteFrequencyData(rawDataArrayRef.current);
        // Verify non-zero energy
        let sum = 0;
        for (let i = 0; i < 32; i++) {
          sum += rawDataArrayRef.current[i] || 0;
        }
        if (sum > 10) {
          hasRealAnalyserData = true;
        }
      }

      const currentProgress = progressRef.current;
      const dynamicAmps = dynamicAmplitudesRef.current;
      const count = basePeaks.length;
      const playheadBarIndex = currentProgress * count;

      // Calculate bar layout dimensions
      const totalSpacingRatio = 0.35; // 35% gap, 65% bar width
      const barWidth = Math.max(1.8, (width / count) * (1 - totalSpacingRatio));
      const barGap = (width - barWidth * count) / (count - 1);
      const centerY = h / 2;

      // Draw background ambient glow underneath played section
      if (currentProgress > 0) {
        const playedWidth = currentProgress * width;
        const glowGrad = ctx.createLinearGradient(0, centerY, playedWidth, centerY);
        glowGrad.addColorStop(0, 'rgba(168, 85, 247, 0.08)');
        glowGrad.addColorStop(1, 'rgba(236, 72, 153, 0.16)');
        ctx.fillStyle = glowGrad;
        ctx.fillRect(0, centerY - h * 0.45, playedWidth, h * 0.9);
      }

      // Render each waveform bar
      for (let i = 0; i < count; i++) {
        const barProgress = i / (count - 1);
        const isPlayed = barProgress <= currentProgress;
        const isHovered = hoverPosition !== null && barProgress <= hoverPosition;
        const distFromPlayhead = Math.abs(i - playheadBarIndex);

        // Calculate dynamic real-time audio modulation
        let targetModulation = 0;
        if (isPlayingRef.current) {
          if (hasRealAnalyserData && rawDataArrayRef.current) {
            // Map bar index to frequency spectrum
            const binIndex = Math.min(
              rawDataArrayRef.current.length - 1,
              Math.floor((i / count) * (rawDataArrayRef.current.length * 0.6))
            );
            const freqVal = (rawDataArrayRef.current[binIndex] || 0) / 255;
            targetModulation = freqVal * 0.55;
          } else {
            // Harmonic fallback synced with audio playback
            const harmonic1 = Math.sin(time * 3 + i * 0.28) * 0.18;
            const harmonic2 = Math.cos(time * 5 + i * 0.52) * 0.12;
            const playheadWave = distFromPlayhead < 6 ? (1 - distFromPlayhead / 6) * (Math.sin(time * 8) * 0.25 + 0.25) : 0;
            targetModulation = Math.max(0, harmonic1 + harmonic2 + playheadWave);
          }
        }

        // Smooth spring interpolation
        dynamicAmps[i] += (targetModulation - dynamicAmps[i]) * 0.25;

        // Final calculated height of this bar
        const basePeak = basePeaks[i] || 0.4;
        let animatedHeight = basePeak * (1 + dynamicAmps[i] * 0.65);
        animatedHeight = Math.max(0.1, Math.min(1.0, animatedHeight));

        const barPixelHeight = Math.max(4, animatedHeight * (h * 0.85));
        const x = i * (barWidth + barGap);
        const yTop = centerY - barPixelHeight / 2;

        // Bar colors & style
        ctx.beginPath();
        const radius = Math.min(barWidth / 2, 2.5);

        if (isPlayed) {
          // Energetic played gradient
          const grad = ctx.createLinearGradient(x, yTop, x, yTop + barPixelHeight);
          if (distFromPlayhead < 2) {
            // Right at playhead: bright cyan / magenta peak
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.5, '#c084fc');
            grad.addColorStop(1, '#a855f7');
          } else {
            // Played segment
            grad.addColorStop(0, '#e879f9');
            grad.addColorStop(0.5, '#a855f7');
            grad.addColorStop(1, '#7e22ce');
          }
          ctx.fillStyle = grad;

          // Subtle glow for active bars near playhead
          if (distFromPlayhead < 4) {
            ctx.shadowColor = 'rgba(232, 121, 249, 0.7)';
            ctx.shadowBlur = 6;
          } else {
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
          }
        } else if (isHovered) {
          // Hover preview scrub segment
          ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        } else {
          // Unplayed future segment
          ctx.fillStyle = 'rgba(255, 255, 255, 0.16)';
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        }

        // Draw rounded rectangle for bar
        ctx.roundRect
          ? ctx.roundRect(x, yTop, barWidth, barPixelHeight, radius)
          : ctx.rect(x, yTop, barWidth, barPixelHeight);
        ctx.fill();
      }

      // Draw Playhead Indicator Needle & Glowing Beacon
      const playheadX = currentProgress * width;
      ctx.shadowBlur = 10;
      ctx.shadowColor = 'rgba(192, 132, 252, 0.9)';

      // Vertical laser needle
      ctx.beginPath();
      ctx.moveTo(playheadX, 0);
      ctx.lineTo(playheadX, h);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Top and bottom playhead luminous beads
      ctx.beginPath();
      ctx.arc(playheadX, centerY, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      // Playhead energetic pulse ring if audio is playing
      if (isPlayingRef.current) {
        const pulseSize = 4 + Math.sin(time * 6) * 2.5;
        ctx.beginPath();
        ctx.arc(playheadX, centerY, pulseSize, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(232, 121, 249, ${0.5 - (pulseSize - 4) * 0.15})`;
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }

      // Draw Hover Indicator Line
      if (hoverPosition !== null) {
        const hoverX = hoverPosition * width;
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.setLineDash([3, 3]);
        ctx.moveTo(hoverX, 0);
        ctx.lineTo(hoverX, h);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.setLineDash([]);
      }

      ctx.restore();
      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [basePeaks, hoverPosition]);

  const hoverTime = hoverPosition !== null && duration > 0 ? hoverPosition * duration : null;

  // Mini variant for compact bars
  if (variant === 'mini') {
    return (
      <div 
        ref={containerRef}
        onClick={(e) => {
          if (!interactive) return;
          handleSeekFromClientX(e.clientX);
        }}
        className={`relative w-full h-[20px] cursor-pointer select-none overflow-hidden ${className}`}
      >
        <canvas 
          ref={canvasRef}
          className="w-full h-full block"
        />
      </div>
    );
  }

  return (
    <div className={`space-y-1.5 select-none ${className}`}>
      {/* Waveform Canvas Container */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerLeave}
        className="relative w-full group cursor-pointer touch-none py-1"
        style={{ height: `${height}px` }}
        title="Перемотка трека по визуальной звуковой дорожке"
      >
        <canvas
          ref={canvasRef}
          className="w-full h-full block rounded-xl transition-opacity"
        />

        {/* Floating Hover Time Badge */}
        {hoverTime !== null && (
          <div
            className="absolute top-0 -translate-y-full -translate-x-1/2 pointer-events-none z-20 pb-1.5 transition-all"
            style={{ left: `${(hoverPosition ?? 0) * 100}%` }}
          >
            <div className="bg-zinc-900/90 text-white font-mono text-[11px] font-semibold px-2 py-0.5 rounded-md shadow-lg border border-purple-500/40 backdrop-blur-md whitespace-nowrap">
              {formatTime(hoverTime)}
            </div>
          </div>
        )}
      </div>

      {/* Timestamps */}
      <div className="flex justify-between text-xs font-mono font-medium text-white/50 px-1">
        <span className="flex items-center gap-1.5 text-purple-300">
          <span className={`w-1.5 h-1.5 rounded-full ${isPlaying ? 'bg-purple-400 animate-pulse' : 'bg-white/30'}`} />
          {formatTime(currentTime)}
        </span>
        <span className="text-white/40">
          {formatTime(duration)}
        </span>
      </div>
    </div>
  );
}
