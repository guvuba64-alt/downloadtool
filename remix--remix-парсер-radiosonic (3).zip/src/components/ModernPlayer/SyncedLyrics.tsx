import React, { useEffect, useRef, useMemo, useState } from 'react';
import { usePlayerStore } from './store';
import { Maximize2, Minimize2, Music2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LyricLine {
  id: number;
  time: number;
  text: string;
  nextTime?: number;
}

export const SyncedLyrics = ({ 
  lyrics, 
  currentTime, 
  isExpanded, 
  onToggleExpand,
  onSeek
}: { 
  lyrics: any; 
  currentTime: number; 
  isExpanded?: boolean; 
  onToggleExpand?: () => void;
  onSeek?: (time: number) => void;
}) => {
  const { state } = usePlayerStore();
  const containerRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);
  const [userIsScrolling, setUserIsScrolling] = useState(false);
  const scrollTimeoutRef = useRef<any>(null);

  // Parse raw lyrics into structured array with timestamps
  const { isSynced, parsedLines } = useMemo(() => {
    let rawText = "";
    if (typeof lyrics === 'string') rawText = lyrics;
    else if (lyrics?.fullLyrics) rawText = lyrics.fullLyrics;
    else if (lyrics?.text) rawText = lyrics.text;
    else rawText = "";

    if (!rawText.trim()) {
      return { isSynced: false, parsedLines: [] };
    }

    const lines = rawText.split('\n');
    const parsed: LyricLine[] = [];
    let idCounter = 0;

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      const timeMatches = [...line.matchAll(/\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\]/g)];
      
      if (timeMatches.length > 0) {
        const text = line.replace(/\[\d{2}:\d{2}(?:\.\d{2,3})?\]/g, '').trim();
        for (const match of timeMatches) {
          const minutes = parseInt(match[1], 10);
          const seconds = parseInt(match[2], 10);
          const ms = match[3] ? parseInt(match[3].padEnd(3, '0'), 10) : 0;
          const time = minutes * 60 + seconds + ms / 1000;
          parsed.push({ id: idCounter++, time, text });
        }
      } else {
        parsed.push({ id: idCounter++, time: -1, text: line });
      }
    }

    // Sort synced lines chronologically
    const hasSync = parsed.some(l => l.time !== -1);
    if (hasSync) {
      parsed.sort((a, b) => a.time - b.time);
      for (let i = 0; i < parsed.length; i++) {
        let nextTime = Infinity;
        for (let j = i + 1; j < parsed.length; j++) {
          if (parsed[j].time !== -1) {
            nextTime = parsed[j].time;
            break;
          }
        }
        parsed[i].nextTime = nextTime;
      }
    }

    return { isSynced: hasSync, parsedLines: parsed };
  }, [lyrics]);

  // Find active line index
  const activeIndex = useMemo(() => {
    if (!isSynced || parsedLines.length === 0) return -1;
    
    // Find the latest line whose time <= currentTime
    let activeIdx = -1;
    for (let i = 0; i < parsedLines.length; i++) {
      if (parsedLines[i].time !== -1 && currentTime >= parsedLines[i].time) {
        activeIdx = i;
      } else if (parsedLines[i].time > currentTime) {
        break;
      }
    }
    return activeIdx;
  }, [parsedLines, currentTime, isSynced]);

  // Countdown calculations for Yandex/Apple Music 3-2-1 lead-in right before vocal begins
  const countdownState = useMemo(() => {
    if (!isSynced || parsedLines.length === 0) return null;

    // 1. Check intro lead-in before the very first vocal line
    const firstLine = parsedLines.find((l) => l.time > 0);
    if (firstLine && firstLine.time >= 2.0 && currentTime < firstLine.time) {
      const diff = firstLine.time - currentTime;
      if (diff <= 3.2 && diff > 0.05) {
        const step = diff > 2.0 ? 3 : diff > 1.0 ? 2 : 1;
        return { targetLineIndex: 0, step, diff };
      }
    }

    // 2. Check long instrumental gaps before upcoming vocal lines
    if (activeIndex >= 0 && activeIndex < parsedLines.length - 1) {
      const currentLine = parsedLines[activeIndex];
      const nextLine = parsedLines[activeIndex + 1];
      const gap = nextLine.time - (currentLine.time || 0);
      
      // If gap is significant (>= 5.5s) and we are within 3.2s before next vocal line
      if (gap >= 5.5) {
        const diff = nextLine.time - currentTime;
        if (diff <= 3.2 && diff > 0.05) {
          const step = diff > 2.0 ? 3 : diff > 1.0 ? 2 : 1;
          return { targetLineIndex: activeIndex + 1, step, diff };
        }
      }
    }

    return null;
  }, [parsedLines, currentTime, activeIndex, isSynced]);

  // Smooth scroll to active line
  useEffect(() => {
    if (userIsScrolling) return;
    if (activeLineRef.current && containerRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [activeIndex, userIsScrolling]);

  // Detect user manual scroll to avoid fighting auto-scroll
  const handleScroll = () => {
    setUserIsScrolling(true);
    if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
    scrollTimeoutRef.current = setTimeout(() => {
      setUserIsScrolling(false);
    }, 2500);
  };

  return (
    <div 
      ref={containerRef} 
      onScroll={handleScroll}
      className={`absolute inset-0 z-20 overflow-y-auto scrollbar-hide select-none transition-all duration-300 ${
        isExpanded 
          ? 'bg-[#0b0414]/90 backdrop-blur-2xl px-6 sm:px-16 pt-16 pb-32' 
          : 'bg-black/60 backdrop-blur-xl rounded-3xl p-6 sm:p-10'
      } text-center`}
      style={{
        maskImage: 'linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%)'
      }}
    >
      {/* Fullscreen / Minimize Toggle */}
      {onToggleExpand && (
        <button 
          onClick={(e) => { e.stopPropagation(); onToggleExpand(); }}
          className={`absolute ${isExpanded ? 'top-6 right-6' : 'top-4 right-4'} p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all z-50`}
          title={isExpanded ? "Свернуть" : "Развернуть на весь экран"}
        >
          {isExpanded ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      )}

      {parsedLines.length > 0 ? (
        <div className="py-[35vh] space-y-6 sm:space-y-8 flex flex-col items-center">
          
          {/* Apple / Yandex Music 3-2-1 Countdown Indicator Banner */}
          <AnimatePresence>
            {countdownState && (
              <motion.div
                key="karaoke-countdown"
                initial={{ opacity: 0, scale: 0.8, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: -10 }}
                className="flex items-center gap-3 px-5 py-2.5 rounded-full bg-purple-500/20 border border-purple-400/40 backdrop-blur-md shadow-[0_0_20px_rgba(168,85,247,0.4)] my-2"
              >
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full transition-all duration-300 ${countdownState.step <= 3 ? 'bg-purple-300 shadow-[0_0_10px_#d8b4fe] scale-125' : 'bg-white/20'}`} />
                  <div className={`w-3 h-3 rounded-full transition-all duration-300 ${countdownState.step <= 2 ? 'bg-purple-300 shadow-[0_0_10px_#d8b4fe] scale-125' : 'bg-white/20'}`} />
                  <div className={`w-3 h-3 rounded-full transition-all duration-300 ${countdownState.step <= 1 ? 'bg-white shadow-[0_0_15px_#ffffff] scale-150' : 'bg-white/20'}`} />
                </div>
                <span className="text-sm font-bold text-purple-200 tracking-wider">
                  {countdownState.step === 3 ? '3..' : countdownState.step === 2 ? '2..' : '1..'}
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Render Lines */}
          {parsedLines.map((line, i) => {
            const isActive = i === activeIndex;
            const isPassed = isSynced && i < activeIndex;
            const isUpcoming = isSynced && i > activeIndex;

            return (
              <div 
                key={line.id} 
                ref={isActive ? activeLineRef : null}
                onClick={() => {
                  if (line.time !== -1 && onSeek) {
                    onSeek(line.time);
                  }
                }}
                className={`group transition-all duration-300 ease-out cursor-pointer max-w-2xl px-4 py-1.5 rounded-xl ${
                  !isSynced 
                    ? 'text-white/80 text-xl sm:text-2xl font-semibold' 
                    : isActive 
                      ? 'text-white text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight scale-105 drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]' 
                      : isPassed 
                        ? 'text-white/30 text-lg sm:text-xl md:text-2xl font-medium hover:text-white/50' 
                        : 'text-white/45 text-lg sm:text-xl md:text-2xl font-medium hover:text-white/70 hover:scale-102'
                }`}
              >
                <span className={isActive ? 'bg-clip-text text-transparent bg-gradient-to-r from-white via-purple-100 to-white' : ''}>
                  {line.text}
                </span>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-white/40 gap-3">
          <Music2 className="w-10 h-10 opacity-30 animate-pulse" />
          <p className="text-lg font-medium">Текст песни отсутствует</p>
          <span className="text-xs text-white/30">Слова для этого трека пока не добавлены</span>
        </div>
      )}
    </div>
  );
};
