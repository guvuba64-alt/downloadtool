import { ProxyImage } from '../ProxyImage';
import React, { useState, useEffect, useRef } from 'react';
import { usePlayerStore, CoverVariant } from './store';
import { Visualizer } from './Visualizer';
import { SyncedLyrics } from './SyncedLyrics';
import { Equalizer } from './Equalizer';
import { WaveformVisualizer } from './WaveformVisualizer';
import { downloadWavTrack, subscribeDownloadState } from '../../utils/audioDownloader';
import { audioEqualizer } from '../../utils/audioEqualizer';
import { extractTrackDetails } from '../../utils/trackMetadata';
import { 
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, 
  ChevronDown, Download, Heart, MoreVertical, Maximize2, 
  ListMusic, Volume2, VolumeX, X, Mic2, AlertCircle, ChevronRight, 
  Info, Image as ImageIcon, Disc3, Sparkles, Check, Loader2, Sliders,
  Copy, Film, CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AlbumModal } from '../AlbumModal';
import { VideoSnapshotView } from './VideoSnapshotView';

export function ModernPlayer({ src, track, albumCover, albumArtists, artistAvatarUri, onNext, onPlayTrack, onArtistClick }: any) {
  const { 
    state, setState, 
    countdown, setCountdown, 
    progress, setProgress,
    currentTime, setCurrentTime,
    duration, setDuration,
    volume, setVolume,
    isPlaying, setIsPlaying,
    isExpanded, setIsExpanded,
    coverVariant, setCoverVariant
  } = usePlayerStore();
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(() => audioEqualizer.getAnalyser());
  
  const [hasStartedCountdown, setHasStartedCountdown] = useState(false);
  const [menuState, setMenuState] = useState<'none' | 'main' | 'info'>('none');
  const [isAlbumModalOpen, setIsAlbumModalOpen] = useState(false);
  const [showLyrics, setShowLyrics] = useState(false);
  const [isLyricsExpanded, setIsLyricsExpanded] = useState(false);
  const [showEqualizer, setShowEqualizer] = useState(false);
  const [lyricsData, setLyricsData] = useState<any>(null);
  const [trackDetails, setTrackDetails] = useState<any>(() => extractTrackDetails(track, albumArtists, albumCover));
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [okRuCheckStatus, setOkRuCheckStatus] = useState<{
    status: 'idle' | 'checking' | 'found' | 'not_found';
    foundOnOkRu?: boolean;
    source?: string | null;
    copyright?: string | null;
    label?: string | null;
    copyrightOwnerName?: string | null;
    copyrightOwnerId?: number | string | null;
    trackName?: string | null;
    trackArtist?: string | null;
    message?: string | null;
  }>({ status: 'idle' });
  const [isDownloadingCover, setIsDownloadingCover] = useState(false);
  const [coverDownloadSuccess, setCoverDownloadSuccess] = useState(false);
  const [playbackWarning, setPlaybackWarning] = useState<string | null>(null);

  // Video Snapshot (Видео-снапшот из Яндекс Музыки)
  const [snapshotData, setSnapshotData] = useState<any>(null);
  const [loadingSnapshot, setLoadingSnapshot] = useState(false);
  const [isDownloadingSnapshot, setIsDownloadingSnapshot] = useState(false);
  const [snapshotDownloadSuccess, setSnapshotDownloadSuccess] = useState(false);
  const fullscreenVideoRef = useRef<HTMLVideoElement | null>(null);
  const [isVideoMuted, setIsVideoMuted] = useState(true);

  // A valid, playable video snapshot requires BOTH hasVideoSnapshot flag and an active stream URL (not audio/mp3)
  const hasActiveVideo = Boolean(
    snapshotData?.hasVideoSnapshot && 
    snapshotData?.videoSnapshot?.streamUrl &&
    !String(snapshotData.videoSnapshot.streamUrl).toLowerCase().includes('.mp3')
  );

  // Sync fullscreen video snapshot playback with audio player state
  useEffect(() => {
    if (!fullscreenVideoRef.current) return;
    if (isPlaying && coverVariant === 'video' && hasActiveVideo) {
      fullscreenVideoRef.current.play().catch(() => {});
    } else {
      fullscreenVideoRef.current.pause();
    }
  }, [isPlaying, coverVariant, hasActiveVideo]);

  useEffect(() => {
    const cleanId = String(track?.id || '').replace(/^(ya_|track_|t_)/, '');
    if (!cleanId) {
      setSnapshotData(null);
      if (coverVariant === 'video') setCoverVariant('normal');
      return;
    }

    if (track?.backgroundVideoUri && String(track.backgroundVideoUri).startsWith('http')) {
      const bgUri = track.backgroundVideoUri;
      const title = track.title || '';
      const artist = Array.isArray(track.artists)
        ? track.artists.map((a: any) => (typeof a === 'string' ? a : a.name)).join(', ')
        : (typeof track.artists === 'string' ? track.artists : '');
      setSnapshotData({
        hasVideoSnapshot: true,
        distributorUploaded: true,
        statusText: "Видеошот активен (Яндекс Музыка)",
        videoSnapshot: {
          url: bgUri,
          streamUrl: `/api/music/video-stream?url=${encodeURIComponent(bgUri)}`,
          downloadUrl: `/api/music/video-download?url=${encodeURIComponent(bgUri)}&title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}&type=snapshot`,
          id: track.backgroundVideoId || null,
          type: "snapshot_9_16"
        },
        clips: [],
        videos: []
      });
      // Do NOT force coverVariant to 'video' automatically — allow user to enjoy normal album cover/visualizer
      return;
    }

    // Reset previous snapshot while fetching
    setSnapshotData(null);
    if (coverVariant === 'video') {
      setCoverVariant('normal');
    }

    setLoadingSnapshot(true);
    const rawId = String(track?.id || '');
    const reqPlatform = track?.platform || (rawId.startsWith('sp_') ? 'spotify' : (rawId.startsWith('dz_') ? 'deezer' : 'yandex'));
    const reqIsrc = track?.isrc || '';
    const reqTitle = track?.title || trackDetails?.title || '';
    const reqArtist = Array.isArray(track?.artists) 
      ? track.artists.map((a: any) => (typeof a === 'string' ? a : a.name)).join(', ')
      : (typeof track?.artists === 'string' ? track.artists : (trackDetails?.artist || ''));
    fetch(`/api/music/track/${encodeURIComponent(cleanId)}/video-snapshot?platform=${encodeURIComponent(reqPlatform)}&isrc=${encodeURIComponent(reqIsrc)}&title=${encodeURIComponent(reqTitle)}&artist=${encodeURIComponent(reqArtist)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data && data.success && data.hasVideoSnapshot && data.videoSnapshot?.streamUrl) {
          setSnapshotData(data);
        } else {
          setSnapshotData(null);
          if (coverVariant === 'video') {
            setCoverVariant('normal');
          }
        }
      })
      .catch(() => {
        setSnapshotData(null);
        if (coverVariant === 'video') {
          setCoverVariant('normal');
        }
      })
      .finally(() => setLoadingSnapshot(false));
  }, [track?.id, track?.backgroundVideoUri]);

  const handleDownloadSnapshotMp4 = () => {
    const downloadUrl = snapshotData?.videoSnapshot?.downloadUrl;
    if (!downloadUrl) return;

    setIsDownloadingSnapshot(true);
    try {
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setSnapshotDownloadSuccess(true);
      setTimeout(() => setSnapshotDownloadSuccess(false), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloadingSnapshot(false);
    }
  };

  // Attach Web Audio API Equalizer DSP to HTML Audio element
  useEffect(() => {
    if (audioRef.current) {
      audioEqualizer.attach(audioRef.current);
      setAnalyser(audioEqualizer.getAnalyser());
    }
  }, [src]);

  const isPlaceholderCopyright = (val?: string | null): boolean => {
    if (!val) return true;
    const s = val.trim().toLowerCase();
    return (
      s === '' ||
      s === 'no copyright' ||
      s === 'copyright не найден' ||
      s === 'не найден' ||
      s === 'не указан' ||
      s === 'copyright не указан' ||
      s === 'unknown' ||
      s === '—' ||
      s === '-' ||
      s === 'нет данных' ||
      s === 'not found' ||
      s === 'ok.ru og metadata' ||
      s === 'правообладатель' ||
      s === 'copyright'
    );
  };

  const verifyOkRuCopyright = async (customArtist?: string, customTitle?: string) => {
    const artistName = customArtist || trackDetails?.performer || albumArtists || trackDetails?.artists || (typeof track?.artists === 'string' ? track.artists : track?.artists?.map((a: any) => a.name).join(', ')) || '';
    const trackName = customTitle || trackDetails?.title || track?.title || '';
    const trackId = track?.id || trackDetails?.id;
    
    if (!trackName && !trackId) return;

    setOkRuCheckStatus(prev => ({ ...prev, status: 'checking', message: 'Проверка лейбла и релизов на ok.ru...' }));

    try {
      const storedCookies = localStorage.getItem("okru_cookies") || undefined;
      const res = await fetch("/api/music/verify-track-copyright", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId,
          title: trackName,
          artist: artistName,
          isrc: trackDetails?.isrc || track?.isrc,
          upc: trackDetails?.upc || track?.upc,
          okCookies: storedCookies
        }),
      });
      
      const data = await res.json().catch(() => null);

      if (data && data.success && data.verified && (data.copyright || data.copyrightOwnerName || data.label)) {
        const finalCopyright = data.copyright || (data.copyrightOwnerName ? `℗ ${new Date().getFullYear()} ${data.copyrightOwnerName}` : null) || data.label;
        const finalLabel = data.label || data.copyrightOwnerName || null;
        const finalDistributor = data.distributor || data.copyrightOwnerName || null;

        setOkRuCheckStatus({
          status: 'found',
          foundOnOkRu: true,
          source: 'OK.RU',
          copyright: finalCopyright,
          label: finalLabel,
          copyrightOwnerName: data.copyrightOwnerName || null,
          copyrightOwnerId: data.copyrightOwnerId || null,
          trackName,
          trackArtist: artistName,
          message: 'найден на ok.ru'
        });

        setTrackDetails((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            copyright: finalCopyright || prev.copyright,
            label: finalLabel || prev.label,
            distributor: finalDistributor || prev.distributor,
            isrc: data.isrc || prev.isrc,
            upc: data.upc || prev.upc,
            authorsMusic: data.authorsMusic || prev.authorsMusic,
            authorsText: data.authorsText || prev.authorsText
          };
        });
      } else {
        setOkRuCheckStatus({
          status: 'not_found',
          foundOnOkRu: false,
          source: null,
          message: data?.message || 'не найден на ok.ru'
        });
      }
    } catch (e) {
      setOkRuCheckStatus({
        status: 'not_found',
        foundOnOkRu: false,
        source: null,
        message: 'не найден на ok.ru'
      });
    }
  };
  
  useEffect(() => {
    if (track?.id) {
      // 1. INSTANT: Immediately extract and set full metadata from track & album objects (0 ms delay)
      const instantDetails = extractTrackDetails(track, albumArtists, albumCover);
      if (instantDetails) {
        setTrackDetails(instantDetails);
      }
      setOkRuCheckStatus({ status: 'idle' });
      
      // 2. Fetch synced lyrics in background
      const artistName = track.artists?.[0]?.name || (typeof track.artists === 'string' ? track.artists : '') || '';
      const queryParams = new URLSearchParams({
        title: track.title || '',
        artist: artistName,
        duration: String(track.duration || (track.durationMs ? Math.round(track.durationMs / 1000) : ''))
      });
      fetch(`/api/music/lyrics/${encodeURIComponent(track.id)}?${queryParams.toString()}`)
        .then(r => r.json())
        .then(d => {
          if (d.success && d.lyrics) setLyricsData(d.lyrics);
          else setLyricsData(null);
        }).catch(() => setLyricsData(null));

      // 3. FAST: Fetch deep credits & supplement from dedicated fast endpoint to seamlessly enrich fields
      const fastParams = new URLSearchParams({
        title: track.title || '',
        artist: artistName,
        isrc: track.isrc || '',
        upc: track.upc || ''
      });
      fetch(`/api/music/tracks/${encodeURIComponent(track.id)}/fast-details?${fastParams.toString()}`)
        .then(r => r.json())
        .then(d => {
          if (d?.success && d.data) {
            setTrackDetails((prev: any) => ({
              ...(prev || {}),
              ...d.data,
              // Retain non-empty fallback strings if needed
              title: d.data.title || prev?.title || track.title,
              artists: d.data.artists || prev?.artists,
              performer: d.data.performer || prev?.performer,
              label: (d.data.label && d.data.label !== 'Не указан') ? d.data.label : (prev?.label || 'Не указан'),
              phonogramSource: (d.data.phonogramSource && d.data.phonogramSource !== 'Не указан') ? d.data.phonogramSource : (prev?.phonogramSource || 'Не указан'),
              copyright: (d.data.copyright && d.data.copyright !== 'Не указан') ? d.data.copyright : (prev?.copyright || 'Не указан'),
              isrc: d.data.isrc || prev?.isrc || track.isrc,
              upc: d.data.upc || prev?.upc || track.upc,
              authorsMusic: d.data.authorsMusic || prev?.authorsMusic,
              authorsText: d.data.authorsText || prev?.authorsText,
            }));
          }
        })
        .catch(() => {});
    }
  }, [track?.id, albumArtists, albumCover]);

  const [isDownloadingWav, setIsDownloadingWav] = useState(false);

  useEffect(() => {
    return subscribeDownloadState((state) => {
      if (state.isDownloading && state.trackId === String(track?.id)) {
        setIsDownloadingWav(true);
      } else {
        setIsDownloadingWav(false);
      }
    });
  }, [track?.id]);

  // Audio Download in WAV format
  const handleDownloadWav = () => {
    if (track?.id) {
      const artists = albumArtists || (typeof track.artists === 'string' ? track.artists : track.artists?.map((a: any) => a.name).join(', '));
      downloadWavTrack({
        trackId: String(track.id),
        title: track.title,
        artists: artists || '',
        coverUri: albumCover || track.coverUri,
      });
    }
  };

  // Convert and Download Cover in 3000x3000px resolution
  const handleDownloadCover3000x3000 = async () => {
    const rawCover = albumCover || track?.coverUri;
    if (!rawCover) return;

    try {
      setIsDownloadingCover(true);
      setCoverDownloadSuccess(false);

      // Get high quality original source URL
      const highResUrl = rawCover.startsWith('http') 
        ? rawCover.replace(/\/(%%|\d+x\d+)/, '/orig') 
        : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, '/orig')}`;

      const proxyUrl = `/api/music/proxy-image?url=${encodeURIComponent(highResUrl)}`;

      // Load image into HTML5 Image element
      const img = new Image();
      img.crossOrigin = 'anonymous';

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => {
          // Fallback to 1000x1000 if orig fails
          const fallbackUrl = rawCover.startsWith('http') 
            ? rawCover.replace(/\/(%%|\d+x\d+)/, '/1000x1000') 
            : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, '/1000x1000')}`;
          img.src = `/api/music/proxy-image?url=${encodeURIComponent(fallbackUrl)}`;
          img.onload = () => resolve();
          img.onerror = (err) => reject(err);
        };
        img.src = proxyUrl;
      });

      // Draw onto 3000x3000 Canvas with high quality bicubic interpolation
      const canvas = document.createElement('canvas');
      canvas.width = 3000;
      canvas.height = 3000;
      const ctx = canvas.getContext('2d');

      if (!ctx) throw new Error('Could not get 2d context');

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, 3000, 3000);

      // Export as high quality JPEG blob
      canvas.toBlob((blob) => {
        if (!blob) {
          setIsDownloadingCover(false);
          return;
        }

        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const cleanName = `${albumArtists || track.artists || 'Artist'} - ${track.title || 'Track'}`.replace(/[/\\?%*:|"<>]/g, '-').trim();
        a.href = blobUrl;
        a.download = `Cover_${cleanName}_3000x3000.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);

        setIsDownloadingCover(false);
        setCoverDownloadSuccess(true);
        setTimeout(() => setCoverDownloadSuccess(false), 3000);
      }, 'image/jpeg', 0.95);

    } catch (e: any) {
      console.error('Error rendering 3000x3000 cover:', e);
      setIsDownloadingCover(false);
    }
  };

  const handleCopyField = (text: string | null | undefined, fieldKey: string) => {
    if (!text || text === 'Не указан') return;
    navigator.clipboard.writeText(String(text));
    setCopiedField(fieldKey);
    setTimeout(() => {
      setCopiedField(prev => (prev === fieldKey ? null : prev));
    }, 1800);
  };

  const handleCopyAllInfo = () => {
    const titleVal = trackDetails?.title || track?.title || '';
    const artistVal = trackDetails?.performer || albumArtists || trackDetails?.artists || (typeof track?.artists === 'string' ? track.artists : track?.artists?.map((a: any) => a.name).join(', ')) || track?.artists || '';
    const distVal = trackDetails?.distributor || (track as any)?.distributor;
    const labelVal = distVal || (trackDetails?.label && trackDetails.label !== "No label" ? trackDetails.label : (trackDetails?.hiddenLabel || ''));
    const phonoVal = trackDetails?.phonogramSource && trackDetails.phonogramSource !== "No phonogram source" ? trackDetails.phonogramSource : (trackDetails?.label && trackDetails.label !== "No label" ? trackDetails.label : '');
    const copyrightVal = trackDetails?.copyright && trackDetails.copyright !== "No copyright" && trackDetails.copyright !== "Copyright не найден"
      ? trackDetails.copyright
      : (okRuCheckStatus.copyright || '');

    const lines: string[] = [];
    if (titleVal) lines.push(`Трек: ${titleVal}`);
    if (artistVal) lines.push(`Исполнитель: ${artistVal}`);
    if (labelVal && labelVal !== 'Не указан') lines.push(`Лейбл (дистрибьютор): ${labelVal} [в переработке]`);
    if (phonoVal && phonoVal !== 'Не указан' && phonoVal !== labelVal) lines.push(`Источник фонограммы: ${phonoVal}`);
    if (trackDetails?.authorsMusic) lines.push(`Авторы музыки: ${trackDetails.authorsMusic}`);
    if (trackDetails?.authorsText) lines.push(`Авторы текста: ${trackDetails.authorsText}`);
    if (trackDetails?.upc) lines.push(`UPC: ${trackDetails.upc}`);
    if (trackDetails?.isrc) lines.push(`ISRC: ${trackDetails.isrc}`);
    if (trackDetails?.releaseDate) lines.push(`Дата выхода: ${new Date(trackDetails.releaseDate).toLocaleDateString('ru-RU')}`);
    if (copyrightVal && copyrightVal !== 'Не указан') lines.push(`Копирайт (правообладатель): ${copyrightVal} [в переработке]`);

    const textToCopy = lines.join('\n');
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopiedField('all');
    setTimeout(() => {
      setCopiedField(prev => (prev === 'all' ? null : prev));
    }, 1800);
  };

  useEffect(() => {
    if (track && src) {
      setState('loading');
      setHasStartedCountdown(false);
      setProgress(0);
      setCurrentTime(0);
      setPlaybackWarning(null);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = src;
        audioRef.current.load();
        initAudio();
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
              setState('playing');
            })
            .catch((err: any) => {
              if (err.name !== 'AbortError') {
                console.warn('Autoplay handled:', err?.message);
                setIsPlaying(false);
                setState('paused');
              }
            });
        }
      }
    }
  }, [track?.id, src, setState, setProgress, setCurrentTime, setIsPlaying]);

  const initAudio = () => {
    if (audioRef.current) {
      audioEqualizer.attach(audioRef.current);
      audioEqualizer.resumeAudioContext();
      setAnalyser(audioEqualizer.getAnalyser());
    }
  };

  const handlePlayAction = async () => {
    if (isPlaying || state === 'playing') {
      audioRef.current?.pause();
      setIsPlaying(false);
      setState('paused');
      return;
    }

    if (!audioRef.current || !src) return;

    initAudio();
    setState('loading');
    
    if (!audioRef.current.src || (!audioRef.current.src.includes('/api/music/download') && !audioRef.current.src.startsWith('http'))) {
      audioRef.current.src = src;
      audioRef.current.load();
    }

    try {
      const playPromise = audioRef.current.play();
      if (playPromise !== undefined) {
        await playPromise;
        setIsPlaying(true);
        setState('playing');
      }
    } catch (e: any) {
      if (e.name !== 'AbortError') {
        if (e.name === 'NotSupportedError' || e.name === 'NotAllowedError') {
          console.warn('Play unsupported or blocked:', e?.message || String(e));
        } else {
          console.warn('Play handled error:', e?.message || String(e));
        }
        setIsPlaying(false);
        setState('paused');
      }
    }
  };

  const playTick = () => {
    const ctx = audioEqualizer.getAudioContext();
    if (ctx) {
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.05);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      } catch(e) {}
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const min = Math.floor(time / 60);
    const sec = Math.floor(time % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  useEffect(() => {
    const handleToggle = () => {
      handlePlayAction();
    };
    window.addEventListener('togglePlayAudio', handleToggle);
    return () => window.removeEventListener('togglePlayAudio', handleToggle);
  }, [isPlaying, state, currentTime, hasStartedCountdown]);

  if (!track) return null;

  return (
    <>
      <audio 
        ref={audioRef}
        onTimeUpdate={() => {
          if (audioRef.current) {
            setCurrentTime(audioRef.current.currentTime);
            if (duration > 0) {
              setProgress((audioRef.current.currentTime / duration) * 100);
            }
          }
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            setDuration(audioRef.current.duration);
          }
        }}
        onEnded={() => {
          setIsPlaying(false);
          setState('paused');
          if (onNext) onNext();
        }}
        onWaiting={() => setState('buffering')}
        onError={(e) => {
          const mediaError = (e.currentTarget as HTMLAudioElement)?.error;
          const isFormatOrNetwork = mediaError && (mediaError.code === 4 || mediaError.code === 2);
          const warnText = isFormatOrNetwork 
            ? "Трек недоступен для прямого воспроизведения (ограничение правообладателя / no-rights)"
            : "Ошибка воспроизведения аудио";
          setPlaybackWarning(warnText);
          setTimeout(() => setPlaybackWarning(null), 6000);
          setIsPlaying(false);
          setState('paused');
          if (onNext) {
            setTimeout(onNext, 2500);
          }
        }}
        onPlaying={() => setState('playing')}
      />

      {/* Mini Player */}
      {!isExpanded && (
        <div className="fixed bottom-0 left-0 right-0 z-[80] animate-in slide-in-from-bottom-5 p-2 pb-4 pointer-events-auto">
          {playbackWarning && (
            <div className="mx-auto max-w-lg mb-2 bg-amber-500/90 backdrop-blur-md text-black px-4 py-2 rounded-2xl text-xs font-semibold flex items-center gap-2 shadow-lg animate-in fade-in slide-in-from-bottom-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-black" />
              <span className="truncate">{playbackWarning}</span>
            </div>
          )}
          <div 
            onClick={() => setIsExpanded(true)}
            className="mx-auto max-w-lg bg-[#12091F]/95 backdrop-blur-2xl border border-white/10 rounded-[28px] p-2 pr-4 flex items-center gap-3 cursor-pointer shadow-[0_10px_35px_rgba(0,0,0,0.8)] hover:bg-[#1A0D2A]/95 transition-all active:scale-[0.98] relative overflow-hidden"
          >
            <div className="w-14 h-14 rounded-[20px] overflow-hidden bg-zinc-800 flex-shrink-0 relative">
               <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent z-10" />
               <ProxyImage src={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "400x400") : "https://" + albumCover.replace("%%", "400x400")) : undefined} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0 flex flex-col justify-center">
              <p className="text-yellow-400 text-[10px] font-bold tracking-wider uppercase mb-0.5">СЕЙЧАС ИГРАЕТ</p>
              <h4 className="text-white font-semibold text-sm truncate">{track.title}</h4>
              <p className="text-zinc-400 text-xs truncate">{albumArtists || track.artists}</p>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={(e) => { e.stopPropagation(); handlePlayAction(); }}
                className="w-12 h-12 bg-white/10 hover:bg-white/20 text-white rounded-full flex items-center justify-center transition-colors relative z-10"
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
              </button>
            </div>

            {/* Dynamic Mini Waveform synced with playback position */}
            <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-80 pointer-events-none overflow-hidden">
              <WaveformVisualizer
                currentTime={currentTime}
                duration={duration}
                isPlaying={isPlaying}
                analyser={analyser}
                trackId={track.id}
                trackTitle={track.title}
                height={6}
                barCount={52}
                interactive={false}
                variant="mini"
              />
            </div>
          </div>
        </div>
      )}

      {/* Full Screen Player */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed inset-0 z-[95] bg-[#090611] flex flex-col h-[100dvh] overflow-hidden font-sans"
          >
            {/* Fullscreen Video Snapshot Background (Как в Яндекс Музыке - заполняет весь экран полностью, без квадратов) */}
            {coverVariant === 'video' && hasActiveVideo && (
              <div className="absolute inset-0 z-0 overflow-hidden select-none bg-black flex items-center justify-center">
                {/* 1. Ambient blurred background video filling 100% of player viewport */}
                <video
                  src={snapshotData?.videoSnapshot?.streamUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  poster={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "600x600") : "https://" + albumCover.replace("%%", "600x600")) : undefined}
                  onError={() => {
                    setCoverVariant('normal');
                  }}
                  className="absolute inset-0 w-full h-full object-cover blur-3xl scale-125 opacity-40 pointer-events-none"
                />

                {/* 2. Main High-Definition Video Shot (100% full screen / full player view, edge-to-edge) */}
                <video
                  ref={fullscreenVideoRef}
                  src={snapshotData?.videoSnapshot?.streamUrl}
                  autoPlay
                  loop
                  muted={isVideoMuted}
                  playsInline
                  poster={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "600x600") : "https://" + albumCover.replace("%%", "600x600")) : undefined}
                  onError={() => {
                    setCoverVariant('normal');
                  }}
                  onLoadedMetadata={(e) => {
                    if (e.currentTarget.videoWidth === 0) {
                      setCoverVariant('normal');
                    }
                  }}
                  className="w-full h-full object-cover"
                />

                {/* 3. Dark Vignettes at top & bottom so controls are 100% readable just like Yandex Music */}
                <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-transparent to-black/95 pointer-events-none" />
                <div className="absolute inset-0 bg-black/15 pointer-events-none" />
              </div>
            )}

            {/* Header */}
            <div className={`flex items-center justify-between px-6 py-4 pt-6 relative z-50 transition-opacity ${isLyricsExpanded ? "opacity-0 pointer-events-none" : ""}`}>
              <button onClick={() => setIsExpanded(false)} className="text-white/60 hover:text-white transition-colors p-2 -ml-2 rounded-full hover:bg-white/10">
                <ChevronDown className="w-6 h-6" />
              </button>
              
              {/* Cover Variant Toggle Switch (Обычная / Винил / Видеошот) */}
              <div className="flex items-center bg-white/10 p-1 rounded-full border border-white/10 shadow-inner">
                <button
                  onClick={() => setCoverVariant('normal')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    coverVariant === 'normal'
                      ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.6)]'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Обычная</span>
                </button>
                <button
                  onClick={() => setCoverVariant('vinyl')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    coverVariant === 'vinyl'
                      ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.6)]'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Disc3 className="w-3.5 h-3.5" />
                  <span>Винил</span>
                </button>
                <button
                  onClick={() => setCoverVariant('video')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all relative ${
                    coverVariant === 'video'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.7)]'
                      : 'text-white/60 hover:text-white'
                  }`}
                  title="Видеошот"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>Видеошот</span>
                  {hasActiveVideo && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#34d399]" />
                  )}
                </button>
              </div>

              {/* Balanced spacer */}
              <div className="w-10" />
            </div>

            {/* Visualizer Area */}
            <div className={`flex-1 flex flex-col items-center justify-center px-4 relative min-h-0 py-2 ${isLyricsExpanded ? 'hidden' : ''}`}>
              <AnimatePresence>
                {showLyrics && lyricsData && !isLyricsExpanded && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute inset-0 z-30"
                  >
                    <SyncedLyrics 
                      lyrics={lyricsData} 
                      currentTime={currentTime} 
                      isExpanded={false} 
                      onToggleExpand={() => setIsLyricsExpanded(true)}
                      onSeek={(time) => {
                        if (audioRef.current) {
                          audioRef.current.currentTime = time;
                          setCurrentTime(time);
                        }
                      }}
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              {coverVariant === 'video' ? (
                hasActiveVideo ? (
                  /* Open Center Area - the video fills the full screen background */
                  <div 
                    className="flex-1 w-full flex flex-col items-center justify-between py-4 cursor-pointer relative z-10 select-none"
                    onClick={handlePlayAction}
                  >
                    {/* Top spacer */}
                    <div />

                    {/* Floating Center Pause Indicator when paused */}
                    {!isPlaying && (
                      <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-2xl transition-transform hover:scale-110">
                        <Play className="w-7 h-7 fill-white ml-1" />
                      </div>
                    )}

                    {/* Audio Mute toggle button */}
                    <div className="self-end mr-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (fullscreenVideoRef.current) {
                            fullscreenVideoRef.current.muted = !fullscreenVideoRef.current.muted;
                            setIsVideoMuted(fullscreenVideoRef.current.muted);
                          }
                        }}
                        className="p-2 rounded-full bg-black/50 backdrop-blur-md border border-white/10 text-white/80 hover:text-white transition-colors"
                        title={isVideoMuted ? "Включить звук видео" : "Отключить звук видео (играет музыка трека)"}
                      >
                        {isVideoMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-purple-400" />}
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Fallback if distributor did not upload a video snapshot */
                  <div className="flex-1 w-full flex flex-col items-center justify-center p-6 text-center max-w-sm z-10">
                    <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 mb-4 shadow-inner">
                      <Film className="w-8 h-8 text-white/30" />
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white/70 text-xs font-medium mb-3">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Видео-снапшот отсутствует</span>
                    </div>
                    <h4 className="text-white font-bold text-base mb-1">
                      Видеошот не добавлен
                    </h4>
                    <p className="text-white/50 text-xs leading-relaxed mb-5">
                      Для этого трека в сервисе Яндекс Музыка видеошот пока не опубликован.
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setCoverVariant('normal')}
                        className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg shadow-purple-900/30 transition-all active:scale-95"
                      >
                        Обычная обложка
                      </button>
                      <button
                        onClick={() => setCoverVariant('vinyl')}
                        className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 hover:text-white text-xs font-semibold border border-white/10 transition-all active:scale-95"
                      >
                        Винил
                      </button>
                    </div>
                    <button
                      onClick={() => window.dispatchEvent(new CustomEvent('openVideoShotStudio', { 
                        detail: { 
                          title: track?.title || trackDetails?.title || '', 
                          artist: trackDetails?.artist || (Array.isArray(track?.artists) ? track.artists.map((a: any) => a.name).join(', ') : ''), 
                          coverUrl: albumCover 
                        } 
                      }))}
                      className="mt-3 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-black font-black text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 fill-black" />
                      <span>Создать видеошот (404×720)</span>
                    </button>
                  </div>
                )
              ) : (
                <div className={`w-full max-w-[340px] sm:max-w-[400px] md:max-w-[440px] aspect-square relative rounded-full bg-transparent overflow-visible flex items-center justify-center transition-all duration-500 ${showLyrics ? 'scale-75 opacity-20 blur-xl' : ''}`}>
                   <Visualizer 
                     analyser={analyser || audioEqualizer.getAnalyser()} 
                     albumCover={albumCover ? (albumCover.startsWith("http") ? albumCover.replace("%%", "600x600") : "https://" + albumCover.replace("%%", "600x600")) : undefined} 
                     onCoverClick={() => setIsAlbumModalOpen(true)}
                   />
                   {/* Quick floating pill if video snapshot is available on this track */}
                   {hasActiveVideo && !showLyrics && (
                     <button
                       onClick={() => setCoverVariant('video')}
                       className="absolute -bottom-3 px-3.5 py-1.5 rounded-full bg-black/85 hover:bg-black border border-purple-500/40 text-purple-200 hover:text-white text-xs font-semibold shadow-xl backdrop-blur-md flex items-center gap-1.5 transition-all transform hover:scale-105 active:scale-95 group z-20 cursor-pointer"
                       title="Смотреть полноэкранный видеошот"
                     >
                       <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                       <Film className="w-3.5 h-3.5 text-purple-400 group-hover:text-purple-300" />
                       <span>Смотреть видеошот</span>
                     </button>
                   )}
                </div>
              )}
            </div>

            {/* Fullscreen Lyrics Area */}
            <AnimatePresence>
              {isLyricsExpanded && lyricsData && (
                <motion.div 
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 50 }}
                  className="absolute inset-0 z-40 flex flex-col pb-[120px]"
                  style={{ backgroundImage: 'radial-gradient(circle at 50% 0%, #1A0D2A 0%, #090611 70%)' }}
                >
                  <SyncedLyrics 
                    lyrics={lyricsData} 
                    currentTime={currentTime} 
                    isExpanded={true} 
                    onToggleExpand={() => setIsLyricsExpanded(false)}
                    onSeek={(time) => {
                      if (audioRef.current) {
                        audioRef.current.currentTime = time;
                        setCurrentTime(time);
                      }
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>
            
            {/* Track Info & Controls Area */}
            <div className={`px-4 flex flex-col flex-shrink-0 relative z-50 ${isLyricsExpanded ? "pb-6 pt-4 bg-black/40 backdrop-blur-3xl" : "pb-8 pt-2"}`}>
              
              {!isLyricsExpanded ? (
                <>
                  {/* Info & Menu */}
                  <div className="flex items-center justify-between mb-3 sm:mb-6">
                    <div className="flex items-center gap-3.5 min-w-0 pr-2">
                      {coverVariant === 'video' && albumCover && (
                        <div 
                          onClick={() => setIsAlbumModalOpen(true)}
                          className="w-12 h-12 rounded-full overflow-hidden border-2 border-white/25 shadow-2xl shrink-0 cursor-pointer bg-black/40 hover:scale-105 transition-transform"
                          title="Нажмите, чтобы открыть альбом"
                        >
                          <ProxyImage 
                            src={albumCover.startsWith("http") ? albumCover.replace("%%", "200x200") : "https://" + albumCover.replace("%%", "200x200")} 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <h2 
                          onClick={() => setIsAlbumModalOpen(true)}
                          className="text-[24px] sm:text-[28px] leading-tight font-bold text-white mb-0.5 truncate cursor-pointer hover:text-purple-300 transition-colors drop-shadow-md"
                          title="Нажмите, чтобы открыть альбом"
                        >
                          {track.title}
                        </h2>
                        <button
                          onClick={() => {
                            const art = albumArtists || (typeof track.artists === 'string' ? track.artists : track.artists?.map((a: any) => a.name).join(', '));
                            if (onArtistClick && art) onArtistClick(art);
                            else setIsAlbumModalOpen(true);
                          }}
                          className="text-zinc-300 hover:text-purple-300 transition-colors text-[15px] sm:text-[16px] truncate text-left cursor-pointer flex items-center gap-1.5 drop-shadow"
                        >
                          <span>{albumArtists || track.artists}</span>
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {coverVariant === 'video' && hasActiveVideo && (
                        <button
                          onClick={handleDownloadSnapshotMp4}
                          disabled={isDownloadingSnapshot}
                          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                          title="Скачать видео-снапшот (MP4)"
                        >
                          {isDownloadingSnapshot ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
                        </button>
                      )}
                      <button onClick={() => setMenuState('main')} className="text-white/70 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10" title="Меню">
                        <MoreVertical className="w-6 h-6" />
                      </button>
                    </div>
                  </div>

                  {/* Dynamic Visual Waveform Animation & Audio Scrubber */}
                  <div className="mb-3 sm:mb-6">
                    <WaveformVisualizer
                      currentTime={currentTime}
                      duration={duration}
                      isPlaying={isPlaying}
                      analyser={analyser}
                      trackId={track.id}
                      trackTitle={track.title}
                      onSeek={(newTime) => {
                        if (audioRef.current) {
                          audioRef.current.currentTime = newTime;
                          setCurrentTime(newTime);
                          if (duration > 0) {
                            setProgress((newTime / duration) * 100);
                          }
                        }
                      }}
                      height={48}
                      barCount={64}
                      interactive={true}
                      variant="full"
                    />
                  </div>

                  {/* Main Playback Controls */}
                  <div className="flex items-center justify-between max-w-sm mx-auto w-full mb-3 sm:mb-6 gap-2">
                    <button className="text-white/40 hover:text-white transition-colors">
                      <Shuffle className="w-5 h-5" />
                    </button>
                    <button className="text-white hover:text-purple-400 transition-colors">
                      <SkipBack className="w-9 h-9 fill-current" />
                    </button>
                    <button 
                      onClick={handlePlayAction}
                      className={`w-16 h-16 sm:w-[80px] sm:h-[80px] rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all ${
                        coverVariant === 'video'
                          ? 'bg-[#FFE100] text-black shadow-[0_0_35px_rgba(255,225,0,0.45)]'
                          : 'bg-purple-600 hover:bg-purple-500 text-white shadow-[0_0_30px_rgba(147,51,234,0.4)]'
                      }`}
                    >
                      {isPlaying ? (
                        <Pause className={`w-8 h-8 sm:w-10 sm:h-10 ${coverVariant === 'video' ? 'fill-black' : 'fill-white'}`} />
                      ) : (
                        <Play className={`w-8 h-8 sm:w-10 sm:h-10 ml-1.5 ${coverVariant === 'video' ? 'fill-black' : 'fill-white'}`} />
                      )}
                    </button>
                    <button onClick={onNext} className="text-white hover:text-purple-400 transition-colors">
                      <SkipForward className="w-9 h-9 fill-current" />
                    </button>
                    <button className="text-white/40 hover:text-white transition-colors">
                      <Repeat className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Secondary Controls */}
                  <div className={`flex justify-between items-center max-w-sm mx-auto w-full px-4 text-white/40 transition-all ${isLyricsExpanded ? "hidden" : "mt-0"}`}>
                    <button 
                      onClick={() => setCoverVariant(coverVariant === 'normal' ? 'vinyl' : 'normal')} 
                      className="hover:text-white transition-colors bg-white/5 p-3 rounded-2xl flex items-center justify-center" 
                      title="Сменить вид обложки"
                    >
                      {coverVariant === 'normal' ? <Disc3 className="w-5 h-5 text-purple-400" /> : <ImageIcon className="w-5 h-5 text-purple-400" />}
                    </button>

                    <button 
                      onClick={() => setCoverVariant(coverVariant === 'video' ? 'normal' : 'video')} 
                      className={`transition-all p-3 rounded-2xl relative ${coverVariant === 'video' ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_15px_rgba(147,51,234,0.6)]" : "hover:text-white bg-white/5"}`} 
                      title="Видеошот"
                    >
                      <Film className="w-5 h-5 text-purple-400" />
                      {hasActiveVideo && coverVariant !== 'video' && (
                        <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#34d399]" />
                      )}
                    </button>

                    <button 
                      onClick={() => setShowLyrics(!showLyrics)} 
                      className={`transition-all p-3 rounded-2xl ${showLyrics ? "bg-purple-600 text-white shadow-[0_0_15px_rgba(147,51,234,0.5)]" : "hover:text-white bg-white/5"}`} 
                      title="Караоке текст песни"
                    >
                      <Mic2 className="w-5 h-5" />
                    </button>

                    <button 
                      onClick={() => setShowEqualizer(!showEqualizer)} 
                      className={`transition-all p-3 rounded-2xl ${showEqualizer ? "bg-purple-600 text-white shadow-[0_0_15px_rgba(147,51,234,0.5)]" : "hover:text-white bg-white/5"}`} 
                      title="Эквалайзер и тонкая настройка"
                    >
                      <Sliders className="w-5 h-5 text-purple-400" />
                    </button>

                    <button 
                      onClick={handleDownloadWav} 
                      disabled={isDownloadingWav}
                      className={`transition-colors p-3 rounded-2xl ${isDownloadingWav ? "bg-purple-600/30 text-purple-400 cursor-wait" : "hover:text-white bg-white/5"}`} 
                      title="Скачать трек в формате WAV"
                    >
                      {isDownloadingWav ? (
                        <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
                      ) : (
                        <Download className="w-5 h-5" />
                      )}
                    </button>

                    <button 
                      onClick={() => setMenuState('main')} 
                      className="hover:text-white transition-colors bg-white/5 p-3 rounded-2xl" 
                      title="Опции и скачивание обложки"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Equalizer Under Player Controls */}
                  <AnimatePresence>
                    {showEqualizer && (
                      <motion.div
                        initial={{ opacity: 0, height: 0, scale: 0.95 }}
                        animate={{ opacity: 1, height: 'auto', scale: 1 }}
                        exit={{ opacity: 0, height: 0, scale: 0.95 }}
                        transition={{ duration: 0.25 }}
                        className="w-full max-w-lg mx-auto mt-4 overflow-hidden"
                      >
                        <Equalizer onClose={() => setShowEqualizer(false)} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </>
              ) : (
                /* Mini Player for Fullscreen Lyrics */
                <div className="w-full flex flex-col gap-2">
                  <div className="w-full">
                    <WaveformVisualizer
                      currentTime={currentTime}
                      duration={duration}
                      isPlaying={isPlaying}
                      analyser={analyser}
                      trackId={track.id}
                      trackTitle={track.title}
                      onSeek={(newTime) => {
                        if (audioRef.current) {
                          audioRef.current.currentTime = newTime;
                          setCurrentTime(newTime);
                          if (duration > 0) {
                            setProgress((newTime / duration) * 100);
                          }
                        }
                      }}
                      height={32}
                      barCount={52}
                      interactive={true}
                      variant="full"
                    />
                  </div>
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-3 overflow-hidden pr-4 flex-1">
                    {albumCover && (
                       <ProxyImage 
                         src={albumCover.startsWith("http") ? albumCover.replace("%%", "100x100") : "https://" + albumCover.replace("%%", "100x100")}
                         alt="Cover"
                         className="w-12 h-12 rounded-lg object-cover flex-shrink-0 shadow-lg"
                       />
                    )}
                    <div className="min-w-0 flex flex-col justify-center">
                      <h3 className="text-white font-bold text-base truncate mb-0.5">{track.title}</h3>
                      <p className="text-white/50 text-xs truncate">{albumArtists || track.artists}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0">
                    <button className="text-white/60 hover:text-white transition-colors">
                      <Heart className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handlePlayAction(); }}
                      className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
                    >
                      {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-1" />}
                    </button>
                  </div>
                </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* 3 DOTS MODAL MENU */}
      <AnimatePresence>
        {menuState !== 'none' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm flex items-end justify-center sm:items-center sm:p-6"
            onClick={() => setMenuState('none')}
          >
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full sm:max-w-md bg-[#140b22] border border-white/10 rounded-t-[28px] sm:rounded-[28px] overflow-hidden relative flex flex-col max-h-[90vh] shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
               {menuState === 'main' ? (
                 <div className="flex flex-col p-6">
                   {/* Header Row: Cover + Title + Duration */}
                   <div className="flex items-center gap-4 mb-6">
                     <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-white/5 border border-white/10">
                        {albumCover && <ProxyImage src={albumCover.startsWith("http") ? albumCover.replace("%%", "200x200") : "https://" + albumCover.replace("%%", "200x200")} className="w-full h-full object-cover" />}
                     </div>
                     <div className="flex-1 min-w-0 flex flex-col justify-center">
                        <div className="flex items-center gap-2">
                           <h3 className="text-xl font-bold text-white truncate">{track.title}</h3>
                           {track.explicit && <div className="w-4 h-4 rounded-sm bg-white/20 text-[9px] flex items-center justify-center font-bold text-white">E</div>}
                        </div>
                        <p className="text-white/60 text-sm truncate mt-0.5">{albumArtists || track.artists}</p>
                     </div>
                     <button onClick={() => setMenuState('none')} className="text-white/40 hover:text-white p-2">
                       <X className="w-5 h-5" />
                     </button>
                   </div>
                   
                   {/* Cover display mode selector in menu */}
                   <div className="bg-white/5 rounded-2xl p-3 mb-4 border border-white/5">
                     <span className="text-xs font-semibold text-white/50 uppercase tracking-wider block mb-2 px-1">Вид плеера</span>
                     <div className="grid grid-cols-3 gap-2">
                       <button
                         onClick={() => setCoverVariant('normal')}
                         className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-semibold transition-all ${
                           coverVariant === 'normal'
                             ? 'bg-purple-600 text-white shadow-md'
                             : 'bg-white/5 text-white/70 hover:bg-white/10'
                         }`}
                       >
                         <ImageIcon className="w-3.5 h-3.5" />
                         <span>Обычная</span>
                       </button>
                       <button
                         onClick={() => setCoverVariant('vinyl')}
                         className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-semibold transition-all ${
                           coverVariant === 'vinyl'
                             ? 'bg-purple-600 text-white shadow-md'
                             : 'bg-white/5 text-white/70 hover:bg-white/10'
                         }`}
                       >
                         <Disc3 className="w-3.5 h-3.5" />
                         <span>Винил</span>
                       </button>
                       <button
                         onClick={() => setCoverVariant('video')}
                         className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-semibold transition-all relative ${
                           coverVariant === 'video'
                             ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                             : 'bg-white/5 text-white/70 hover:bg-white/10'
                         }`}
                       >
                         <Film className="w-3.5 h-3.5" />
                         <span>Видеошот</span>
                         {snapshotData?.hasVideoSnapshot && (
                           <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                         )}
                       </button>
                     </div>
                   </div>

                   {/* Quick Equalizer Button in Menu */}
                   <button 
                     onClick={() => {
                       setShowEqualizer(true);
                       setMenuState('none');
                     }}
                     className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-purple-600/10 hover:bg-purple-600/20 text-white transition-all border border-purple-500/20 mb-4 group"
                   >
                     <div className="flex items-center gap-3.5">
                       <div className="w-10 h-10 rounded-xl bg-purple-600/30 text-purple-300 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                         <Sliders className="w-5 h-5" />
                       </div>
                       <div className="text-left">
                         <p className="font-semibold text-sm">Эквалайзер и тонкая настройка</p>
                         <p className="text-xs text-white/40">Rock, Pop, Jazz, Bass Boost & 10 полос</p>
                       </div>
                     </div>
                     <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white transition-colors" />
                   </button>

                   <div className="h-px bg-white/10 w-full mb-4" />
                   
                   {/* Action Buttons: WAV Download & 3000x3000px Cover Download */}
                   <div className="space-y-2.5 mb-4">
                     
                     {/* 1. Download WAV */}
                     <button 
                       onClick={handleDownloadWav}
                       className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 group"
                     >
                       <div className="flex items-center gap-3.5">
                         <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                           <Download className="w-5 h-5" />
                         </div>
                         <div className="text-left">
                           <p className="font-semibold text-sm">Скачать аудио (WAV)</p>
                           <p className="text-xs text-white/40">Lossless 16-bit 44.1kHz</p>
                         </div>
                       </div>
                       <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white transition-colors" />
                     </button>

                     {/* 2. Download Cover 3000x3000 */}
                     <button 
                       onClick={handleDownloadCover3000x3000}
                       disabled={isDownloadingCover}
                       className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 group disabled:opacity-50"
                     >
                       <div className="flex items-center gap-3.5">
                         <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                           {isDownloadingCover ? (
                             <Loader2 className="w-5 h-5 animate-spin" />
                           ) : coverDownloadSuccess ? (
                             <Check className="w-5 h-5 text-green-400" />
                           ) : (
                             <ImageIcon className="w-5 h-5" />
                           )}
                         </div>
                         <div className="text-left">
                           <p className="font-semibold text-sm">Скачать обложку (3000×3000 HQ)</p>
                           <p className="text-xs text-white/40">
                             {isDownloadingCover ? 'Конвертация в 3000×3000...' : coverDownloadSuccess ? 'Скачано успешно!' : 'Ультра-качество JPEG'}
                           </p>
                         </div>
                       </div>
                       <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white transition-colors" />
                     </button>

                     {/* 3. Download Video Snapshot MP4 */}
                     <button 
                       onClick={handleDownloadSnapshotMp4}
                       disabled={!snapshotData?.hasVideoSnapshot || isDownloadingSnapshot}
                       className={`w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-all border border-white/5 group ${
                         !snapshotData?.hasVideoSnapshot ? 'opacity-45 cursor-not-allowed' : ''
                       }`}
                     >
                       <div className="flex items-center gap-3.5">
                         <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                           {isDownloadingSnapshot ? (
                             <Loader2 className="w-5 h-5 animate-spin" />
                           ) : snapshotDownloadSuccess ? (
                             <Check className="w-5 h-5 text-green-400" />
                           ) : (
                             <Film className="w-5 h-5" />
                           )}
                         </div>
                         <div className="text-left">
                           <div className="flex items-center gap-2">
                             <p className="font-semibold text-sm">Скачать видео-снапшот (MP4)</p>
                             {snapshotData?.hasVideoSnapshot && (
                               <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                 ДИСТРИБЬЮТОР
                               </span>
                             )}
                           </div>
                           <p className="text-xs text-white/40">
                             {snapshotData?.hasVideoSnapshot 
                               ? (snapshotDownloadSuccess ? 'Скачано успешно!' : isDownloadingSnapshot ? 'Загрузка видео...' : 'Оригинал 9:16 из Яндекс Музыки')
                               : 'Дистрибьютор не загрузил видео на этот трек'}
                           </p>
                         </div>
                       </div>
                       <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white transition-colors" />
                     </button>
                   </div>
                   
                   <div className="h-px bg-white/10 w-full mb-2" />
                   
                   <button onClick={() => setMenuState('info')} className="flex items-center gap-3 p-3.5 text-white hover:bg-white/5 rounded-2xl transition-colors">
                     <Info className="w-5 h-5 text-white/50" />
                     <span className="font-medium text-sm">Информация о треке и авторах</span>
                   </button>
                   
                 </div>
               ) : (
                  <div className="flex flex-col p-5 sm:p-6 h-full overflow-y-auto overflow-x-hidden">
                    {/* Info State Header */}
                    <div className="flex items-center justify-between gap-3 mb-5 pb-3 border-b border-white/10">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30 shrink-0">
                          <Info className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-base sm:text-lg font-bold text-white leading-tight truncate">О треке</h3>
                          <p className="text-[11px] text-white/40 truncate">Метаданные, авторы и коды</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={handleCopyAllInfo}
                          className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white text-xs font-medium flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                          title="Скопировать все метаданные трека в буфер"
                        >
                          {copiedField === 'all' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400 font-semibold">Скопировано!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-purple-400" />
                              <span className="hidden xs:inline">Копировать всё</span>
                              <span className="xs:hidden">Всё</span>
                            </>
                          )}
                        </button>
                        <button 
                          onClick={() => setMenuState('main')} 
                          className="px-2.5 py-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/5 text-xs font-medium transition-colors cursor-pointer"
                        >
                          Назад
                        </button>
                      </div>
                    </div>
                    
                    {/* Cards with Data and Copy Squares */}
                    <div className="space-y-2.5 pb-2">
                      {/* Track title */}
                      <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                        <div className="min-w-0 flex-1">
                          <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Трек</p>
                          <p className="text-white font-medium text-sm select-all break-words">{trackDetails?.title || track.title || 'Не указан'}</p>
                        </div>
                        <button
                          onClick={() => handleCopyField(trackDetails?.title || track.title, 'title')}
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                            copiedField === 'title'
                              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                              : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                          }`}
                          title="Скопировать название трека"
                        >
                          {copiedField === 'title' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {/* Performer / Artists */}
                      {(() => {
                        const performerVal = trackDetails?.performer || albumArtists || trackDetails?.artists || (typeof track?.artists === 'string' ? track.artists : track?.artists?.map((a: any) => a.name).join(', ')) || track.artists || 'Не указан';
                        return (
                          <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                            <div className="min-w-0 flex-1">
                              <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Исполнитель (Псевдоним)</p>
                              <p className="text-white font-medium text-sm select-all break-words">{performerVal}</p>
                            </div>
                            <button
                              onClick={() => handleCopyField(performerVal, 'performer')}
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                copiedField === 'performer'
                                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                  : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                              }`}
                              title="Скопировать исполнителя"
                            >
                              {copiedField === 'performer' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        );
                      })()}

                      {/* Label / Distributor */}
                      {(() => {
                        const distVal = trackDetails?.distributor || (track as any)?.distributor;
                        const labelVal = distVal || (trackDetails?.label && trackDetails.label !== "No label" ? trackDetails.label : (trackDetails?.hiddenLabel || ''));
                        return (
                          <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-amber-500/25 rounded-xl p-3 flex items-center justify-between gap-3 transition-all relative overflow-hidden">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                                <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">Лейбл / Дистрибьютор</p>
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40">
                                  В переработке
                                </span>
                              </div>
                              <div className="text-white font-medium text-sm select-all break-words">
                                {distVal ? (
                                  <span><span className="text-white/50 text-xs font-normal">Дистрибьютор:</span> {distVal}</span>
                                ) : labelVal && labelVal !== 'Не указан' ? (
                                  <span><span className="text-white/50 text-xs font-normal">Дистрибьютор / Лейбл:</span> {labelVal}</span>
                                ) : (
                                  <span className="text-amber-300/80 italic text-xs">В переработке (поиск дистрибьютора)</span>
                                )}
                              </div>
                            </div>
                            {labelVal && (
                              <button
                                onClick={() => handleCopyField(distVal || labelVal, 'label')}
                                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                  copiedField === 'label'
                                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                    : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                                }`}
                                title="Скопировать дистрибьютор"
                              >
                                {copiedField === 'label' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            )}
                          </div>
                        );
                      })()}

                      {/* Phonogram source */}
                      {(() => {
                        const phonoVal = trackDetails?.phonogramSource && trackDetails.phonogramSource !== "No phonogram source" ? trackDetails.phonogramSource : (trackDetails?.label && trackDetails.label !== "No label" ? trackDetails.label : 'Не указан');
                        return (
                          <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                            <div className="min-w-0 flex-1">
                              <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Источник фонограммы</p>
                              <p className="text-white font-medium text-sm select-all break-words">{phonoVal}</p>
                            </div>
                            <button
                              onClick={() => handleCopyField(phonoVal, 'phonogramSource')}
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                copiedField === 'phonogramSource'
                                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                  : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                              }`}
                              title="Скопировать источник фонограммы"
                            >
                              {copiedField === 'phonogramSource' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        );
                      })()}

                      {/* Authors Music (if present) */}
                      {trackDetails?.authorsMusic && (
                        <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                          <div className="min-w-0 flex-1">
                            <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Авторы музыки трека</p>
                            <p className="text-white font-medium text-sm select-all break-words">{trackDetails.authorsMusic}</p>
                          </div>
                          <button
                            onClick={() => handleCopyField(trackDetails.authorsMusic, 'authorsMusic')}
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                              copiedField === 'authorsMusic'
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                              }`}
                            title="Скопировать авторов музыки"
                          >
                            {copiedField === 'authorsMusic' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      )}

                      {/* Authors Text (if present) */}
                      {trackDetails?.authorsText && (
                        <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                          <div className="min-w-0 flex-1">
                            <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Авторы текста</p>
                            <p className="text-white font-medium text-sm select-all break-words">{trackDetails.authorsText}</p>
                          </div>
                          <button
                            onClick={() => handleCopyField(trackDetails.authorsText, 'authorsText')}
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                              copiedField === 'authorsText'
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                            }`}
                            title="Скопировать авторов текста"
                          >
                            {copiedField === 'authorsText' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      )}

                      {/* UPC */}
                      {(() => {
                        const upcVal = trackDetails?.upc || 'Не указан';
                        const hasUpc = Boolean(trackDetails?.upc && trackDetails.upc !== 'Не указан');
                        return (
                          <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                            <div className="min-w-0 flex-1">
                              <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">UPC</p>
                              <p className={`text-sm tracking-wide select-all break-all ${hasUpc ? 'text-white font-mono font-medium' : 'text-white/40 italic'}`}>
                                {upcVal}
                              </p>
                            </div>
                            {hasUpc && (
                              <button
                                onClick={() => handleCopyField(trackDetails.upc!, 'upc')}
                                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                  copiedField === 'upc'
                                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                    : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                                }`}
                                title="Скопировать UPC"
                              >
                                {copiedField === 'upc' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            )}
                          </div>
                        );
                      })()}

                      {/* ISRC */}
                      {(() => {
                        const isrcVal = trackDetails?.isrc || 'Не указан';
                        const hasIsrc = Boolean(trackDetails?.isrc && trackDetails.isrc !== 'Не указан');
                        return (
                          <div className={`group border rounded-xl p-3 flex items-center justify-between gap-3 transition-all ${
                            hasIsrc 
                              ? 'bg-purple-500/5 hover:bg-purple-500/10 border-purple-500/20' 
                              : 'bg-white/[0.04] hover:bg-white/[0.07] border-white/[0.08]'
                          }`}>
                            <div className="min-w-0 flex-1">
                              <p className={`text-[10px] font-bold uppercase tracking-wider mb-0.5 ${hasIsrc ? 'text-purple-400/80' : 'text-white/40'}`}>ISRC</p>
                              <p className={`text-sm tracking-wider select-all break-all ${hasIsrc ? 'text-purple-200 font-mono font-semibold' : 'text-white/40 italic'}`}>
                                {isrcVal}
                              </p>
                            </div>
                            {hasIsrc && (
                              <button
                                onClick={() => handleCopyField(trackDetails.isrc!, 'isrc')}
                                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                  copiedField === 'isrc'
                                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                    : 'bg-purple-500/10 hover:bg-purple-500/25 border-purple-500/30 text-purple-300 hover:text-white active:scale-95'
                                }`}
                                title="Скопировать ISRC"
                              >
                                {copiedField === 'isrc' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            )}
                          </div>
                        );
                      })()}

                      {/* Release Date (if present) */}
                      {trackDetails?.releaseDate && (
                        <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between gap-3 transition-all">
                          <div className="min-w-0 flex-1">
                            <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">Дата выхода</p>
                            <p className="text-white font-medium text-sm select-all">{new Date(trackDetails.releaseDate).toLocaleDateString('ru-RU')}</p>
                          </div>
                          <button
                            onClick={() => handleCopyField(new Date(trackDetails.releaseDate).toLocaleDateString('ru-RU'), 'releaseDate')}
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                              copiedField === 'releaseDate'
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                            }`}
                            title="Скопировать дату выхода"
                          >
                            {copiedField === 'releaseDate' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      )}

                      {/* Copyright */}
                      {(() => {
                        const hasRealCopyright = trackDetails?.copyright && !isPlaceholderCopyright(trackDetails.copyright);
                        const hasOkCopyright = okRuCheckStatus.copyright && !isPlaceholderCopyright(okRuCheckStatus.copyright);
                        const copyrightVal = hasOkCopyright
                          ? okRuCheckStatus.copyright
                          : (hasRealCopyright ? trackDetails.copyright : 'Не указан');
                        return (
                          <div className="group bg-white/[0.04] hover:bg-white/[0.07] border border-amber-500/25 rounded-xl p-3 flex flex-col gap-2 transition-all relative overflow-hidden">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">Копирайт / Правообладатель</p>
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40">
                                  В переработке
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] font-sans text-amber-400/80 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                                  функция прикрыта (в переработке)
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between gap-3">
                              <div className="min-w-0 flex-1">
                                <div className="text-white/90 font-mono text-xs select-all break-all">
                                  {copyrightVal && copyrightVal !== 'Не указан' ? (
                                    <span><span className="text-white/50 font-sans text-xs font-normal">Правообладатель:</span> {copyrightVal}</span>
                                  ) : (
                                    <span className="text-amber-300/80 italic font-sans text-xs">В переработке (поиск правообладателя)</span>
                                  )}
                                </div>
                              </div>
                              {copyrightVal && copyrightVal !== 'Не указан' && (
                                <button
                                  onClick={() => handleCopyField(copyrightVal, 'copyright')}
                                  className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                                    copiedField === 'copyright'
                                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                      : 'bg-white/5 hover:bg-white/15 border-white/10 text-white/60 hover:text-white active:scale-95'
                                  }`}
                                  title="Скопировать копирайт"
                                >
                                  {copiedField === 'copyright' ? <Check className="w-4 h-4" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}
                
                <div className="absolute top-2 w-full flex justify-center">
                 <div className="w-12 h-1 bg-white/20 rounded-full mt-2" />
               </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full Album Modal */}
      <AlbumModal
        isOpen={isAlbumModalOpen}
        onClose={() => setIsAlbumModalOpen(false)}
        album={{
          id: trackDetails?.albumId || track?.albumId || (Array.isArray(track?.albums) && track.albums[0]?.id) || track?.id,
          title: trackDetails?.albumTitle || track?.albumTitle || (Array.isArray(track?.albums) && track.albums[0]?.title) || trackDetails?.title || track?.title || 'Альбом',
          artist: albumArtists || trackDetails?.artists || (typeof track?.artists === 'string' ? track.artists : track?.artists?.map((a: any) => a.name).join(', ')) || '',
          artistAvatarUri: artistAvatarUri,
          coverUri: albumCover || trackDetails?.coverUri || track?.coverUri,
          year: trackDetails?.year || (trackDetails?.releaseDate ? new Date(trackDetails.releaseDate).getFullYear() : undefined),
          releaseDate: trackDetails?.releaseDate,
          label: trackDetails?.label,
          copyright: trackDetails?.copyright || okRuCheckStatus.copyright || undefined,
          upc: trackDetails?.upc,
          isrc: trackDetails?.isrc,
          authorsMusic: trackDetails?.authorsMusic,
          authorsText: trackDetails?.authorsText,
          phonogramSource: trackDetails?.phonogramSource,
          performer: trackDetails?.performer,
        }}
        activeTrackId={track?.id}
        isPlaying={isPlaying}
        onPlayTrack={(clickedTrack) => {
          if (onPlayTrack) {
            onPlayTrack(clickedTrack);
          } else if (String(clickedTrack.id) === String(track?.id)) {
            handlePlayAction();
          }
        }}
        onArtistClick={onArtistClick}
      />
    </>
  );
}
