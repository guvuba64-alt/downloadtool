import React, { useState, useEffect } from 'react';
import { 
  Sliders, 
  Sparkles, 
  Volume2, 
  RotateCcw, 
  Zap, 
  Radio, 
  Mic2, 
  Flame, 
  TrendingUp, 
  Check, 
  ChevronDown, 
  ChevronUp,
  Activity,
  Layers
} from 'lucide-react';
import { 
  audioEqualizer, 
  FREQUENCY_LABELS, 
  FREQUENCIES, 
  EQUALIZER_PRESETS, 
  FineTuningSettings 
} from '../../utils/audioEqualizer';

interface EqualizerProps {
  className?: string;
  isCompact?: boolean;
  defaultExpanded?: boolean;
  onClose?: () => void;
}

export function Equalizer({ className = '', isCompact = false, defaultExpanded = true, onClose }: EqualizerProps) {
  const [settings, setSettings] = useState<FineTuningSettings>(audioEqualizer.getSettings());
  const [activeTab, setActiveTab] = useState<'templates' | 'manual' | 'effects'>('templates');
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  // Subscribe to audioEqualizer changes
  useEffect(() => {
    return audioEqualizer.subscribe((newSettings) => {
      setSettings(newSettings);
    });
  }, []);

  // Quick Tuning Templates
  const applyTemplate = (templateType: 'bass' | 'treble' | 'lows' | 'vocal') => {
    switch (templateType) {
      case 'bass':
        // Усилитель баса (Bass Boost)
        audioEqualizer.updateSettings({
          enabled: true,
          presetId: 'custom_bass_boost',
          bands: [9, 8, 6, 3, 1, 0, 0, 1, 2, 2],
          bassBoost: 85,
          surround: 25,
          vocalClarity: 15,
        });
        break;

      case 'treble':
        // Верхние частоты (Treble)
        audioEqualizer.updateSettings({
          enabled: true,
          presetId: 'custom_treble',
          bands: [-1, -1, 0, 0, 1, 3, 5, 8, 9, 10],
          bassBoost: 10,
          surround: 30,
          vocalClarity: 50,
        });
        break;

      case 'lows':
        // Нижние частоты (Sub-bass & Lows)
        audioEqualizer.updateSettings({
          enabled: true,
          presetId: 'custom_lows',
          bands: [11, 10, 8, 4, 1, -1, -1, 0, 1, 1],
          bassBoost: 95,
          surround: 15,
          vocalClarity: 0,
        });
        break;

      case 'vocal':
        // Вокал (Vocal Clarity)
        audioEqualizer.updateSettings({
          enabled: true,
          presetId: 'custom_vocal',
          bands: [-3, -2, -1, 2, 6, 7, 5, 3, 1, 0],
          bassBoost: 15,
          surround: 20,
          vocalClarity: 90,
        });
        break;
    }
  };

  const handleBandChange = (index: number, gain: number) => {
    audioEqualizer.setBandGain(index, gain);
  };

  const handlePresetSelect = (presetId: string) => {
    audioEqualizer.applyPreset(presetId);
  };

  const handleReset = () => {
    audioEqualizer.applyPreset('flat');
  };

  // Main 4 required presets for fast access + more
  const primaryPresets = [
    { id: 'rock', name: 'Rock', icon: Flame, color: 'from-red-500 to-amber-500' },
    { id: 'pop', name: 'Pop', icon: Sparkles, color: 'from-pink-500 to-purple-500' },
    { id: 'jazz', name: 'Jazz', icon: Radio, color: 'from-amber-500 to-yellow-600' },
    { id: 'bass_boost', name: 'Bass Boost', icon: Zap, color: 'from-purple-600 to-indigo-600' },
  ];

  return (
    <div className={`bg-[#120a1f]/90 border border-purple-500/20 rounded-3xl p-4 sm:p-5 shadow-2xl backdrop-blur-xl transition-all ${className}`}>
      {/* Header Bar */}
      <div className="flex items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-purple-600/30 border border-purple-500/40 text-purple-400 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.3)]">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white font-bold text-base leading-none">Эквалайзер</h3>
              {settings.enabled ? (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-semibold">
                  ВКЛ
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-zinc-700/40 text-zinc-400 text-[10px] font-semibold">
                  ВЫКЛ
                </span>
              )}
            </div>
            <p className="text-white/40 text-xs mt-0.5">10 полос & тонкая настройка звука</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Master Enable/Disable Toggle */}
          <button
            onClick={() => audioEqualizer.setEnabled(!settings.enabled)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              settings.enabled
                ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.5)]'
                : 'bg-white/10 text-white/60 hover:text-white'
            }`}
          >
            {settings.enabled ? 'Активен' : 'Включить'}
          </button>

          <button
            onClick={handleReset}
            title="Сбросить в Flat"
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-colors"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          {/* Navigation Tabs */}
          <div className="flex p-1 bg-white/5 rounded-2xl border border-white/5 gap-1">
            <button
              onClick={() => setActiveTab('templates')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'templates'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Шаблоны и Пресеты</span>
            </button>

            <button
              onClick={() => setActiveTab('manual')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'manual'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>10 Полос</span>
            </button>

            <button
              onClick={() => setActiveTab('effects')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'effects'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Бас & Вокал</span>
            </button>
          </div>

          {/* TAB 1: QUICK TUNING TEMPLATES & PRESETS */}
          {activeTab === 'templates' && (
            <div className="space-y-4">
              {/* Required Templates Section */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-purple-400" />
                    Шаблоны быстрой настройки
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {/* 1. Усилитель баса */}
                  <button
                    onClick={() => applyTemplate('bass')}
                    className="p-3 bg-white/5 hover:bg-purple-600/20 border border-purple-500/20 hover:border-purple-500/50 rounded-2xl flex flex-col items-start gap-1.5 text-left transition-all group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-purple-300 transition-colors">
                        Усилитель баса
                      </div>
                      <div className="text-[10px] text-white/50">Громкий мощный панч</div>
                    </div>
                  </button>

                  {/* 2. Верхние частоты */}
                  <button
                    onClick={() => applyTemplate('treble')}
                    className="p-3 bg-white/5 hover:bg-cyan-600/20 border border-cyan-500/20 hover:border-cyan-500/50 rounded-2xl flex flex-col items-start gap-1.5 text-left transition-all group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                        Верхние частоты
                      </div>
                      <div className="text-[10px] text-white/50">Прозрачный Air-звук</div>
                    </div>
                  </button>

                  {/* 3. Нижние частоты */}
                  <button
                    onClick={() => applyTemplate('lows')}
                    className="p-3 bg-white/5 hover:bg-indigo-600/20 border border-indigo-500/20 hover:border-indigo-500/50 rounded-2xl flex flex-col items-start gap-1.5 text-left transition-all group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Layers className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors">
                        Нижние частоты
                      </div>
                      <div className="text-[10px] text-white/50">Глубокий суб-бас</div>
                    </div>
                  </button>

                  {/* 4. Вокал */}
                  <button
                    onClick={() => applyTemplate('vocal')}
                    className="p-3 bg-white/5 hover:bg-emerald-600/20 border border-emerald-500/20 hover:border-emerald-500/50 rounded-2xl flex flex-col items-start gap-1.5 text-left transition-all group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mic2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                        Вокал
                      </div>
                      <div className="text-[10px] text-white/50">Четкая речь и голос</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Main Presets: Rock, Pop, Jazz, Bass Boost */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white/50 uppercase tracking-wider">
                    Жанровые предустановки (Rock, Pop, Jazz, Bass Boost)
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {primaryPresets.map((p) => {
                    const Icon = p.icon;
                    const isSelected = settings.presetId === p.id;
                    return (
                      <button
                        key={p.id}
                        onClick={() => handlePresetSelect(p.id)}
                        className={`p-3 rounded-2xl flex items-center gap-2.5 transition-all text-left border ${
                          isSelected
                            ? 'bg-purple-600/40 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)]'
                            : 'bg-white/5 border-white/5 hover:bg-white/10 text-white/80'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${p.color} flex items-center justify-center text-white shadow-md shrink-0`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold truncate">{p.name}</div>
                          <div className="text-[10px] text-white/40 truncate">
                            {isSelected ? 'Активен' : 'Применить'}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Additional Presets Chips */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {EQUALIZER_PRESETS.filter(p => !['rock', 'pop', 'jazz', 'bass_boost'].includes(p.id)).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => handlePresetSelect(p.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                        settings.presetId === p.id
                          ? 'bg-purple-600 text-white font-semibold shadow-sm'
                          : 'bg-white/5 hover:bg-white/10 text-white/60 hover:text-white border border-white/5'
                      }`}
                    >
                      {p.nameRu || p.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 10-BAND MANUAL ADJUSTMENT */}
          {activeTab === 'manual' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white/50 uppercase tracking-wider">
                  Ручная регулировка 10 частотных полос (-12dB .. +12dB)
                </span>
                <span className="text-xs text-purple-400 font-mono">
                  {settings.bands.every(b => b === 0) ? '0 dB (Flat)' : 'Пользовательская кривая'}
                </span>
              </div>

              {/* Sliders Container */}
              <div className="grid grid-cols-10 gap-1 sm:gap-2 p-3 bg-white/5 rounded-2xl border border-white/5 items-end h-48">
                {FREQUENCIES.map((freq, idx) => {
                  const gain = settings.bands[idx] || 0;
                  return (
                    <div key={freq} className="flex flex-col items-center h-full justify-between gap-1 group">
                      {/* Gain Value Label */}
                      <span className={`text-[10px] font-mono font-bold leading-none ${
                        gain > 0 ? 'text-emerald-400' : gain < 0 ? 'text-rose-400' : 'text-white/40'
                      }`}>
                        {gain > 0 ? `+${gain}` : gain}
                      </span>

                      {/* Vertical Slider Track */}
                      <div className="relative w-full flex-1 flex items-center justify-center my-1">
                        <input
                          type="range"
                          min="-12"
                          max="12"
                          step="1"
                          value={gain}
                          onChange={(e) => handleBandChange(idx, parseFloat(e.target.value))}
                          className="slider-vertical cursor-pointer w-full h-full opacity-80 hover:opacity-100 transition-opacity"
                          style={{
                            writingMode: 'vertical-lr',
                            direction: 'rtl',
                            appearance: 'slider-vertical',
                          }}
                        />
                      </div>

                      {/* Frequency Label */}
                      <span className="text-[9px] font-semibold text-white/60 truncate max-w-full text-center group-hover:text-purple-300">
                        {FREQUENCY_LABELS[idx].replace(' Гц', '').replace(' кГц', 'k')}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Zero reset button */}
              <div className="flex justify-end">
                <button
                  onClick={() => audioEqualizer.updateSettings({ bands: [0,0,0,0,0,0,0,0,0,0], presetId: 'flat' })}
                  className="px-3 py-1 rounded-xl bg-white/5 hover:bg-white/10 text-white/50 hover:text-white text-xs transition-colors flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Выровнять все в 0 dB
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: FINE-TUNING EFFECTS & ENHANCEMENTS */}
          {activeTab === 'effects' && (
            <div className="space-y-4">
              {/* Pre-Amp */}
              <div className="p-3 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                    Предусилитель (Pre-Amp)
                  </span>
                  <span className="font-mono text-purple-400 font-bold">
                    {settings.preAmp > 0 ? `+${settings.preAmp} dB` : `${settings.preAmp} dB`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.5"
                  value={settings.preAmp}
                  onChange={(e) => audioEqualizer.setPreAmp(parseFloat(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>

              {/* Bass Boost */}
              <div className="p-3 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-purple-400" />
                    Усилитель баса (Bass Boost 60Hz)
                  </span>
                  <span className="font-mono text-purple-400 font-bold">{settings.bassBoost}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.bassBoost}
                  onChange={(e) => audioEqualizer.setBassBoost(parseInt(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>

              {/* Vocal Clarity */}
              <div className="p-3 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <Mic2 className="w-3.5 h-3.5 text-emerald-400" />
                    Четкость вокала (3kHz Presence)
                  </span>
                  <span className="font-mono text-emerald-400 font-bold">{settings.vocalClarity}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.vocalClarity}
                  onChange={(e) => audioEqualizer.setVocalClarity(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>

              {/* 3D Surround */}
              <div className="p-3 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    3D Пространственный объем (Surround)
                  </span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.surround}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.surround}
                  onChange={(e) => audioEqualizer.setSurround(parseInt(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
}
