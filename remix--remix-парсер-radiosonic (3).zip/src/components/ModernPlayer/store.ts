import { create } from 'zustand';

export type PlayerState = 'loading' | 'countdown' | 'playing' | 'paused' | 'buffering' | 'error';
export type VisualMode = 'orbital' | 'galaxy' | 'liquid' | 'spectrum' | 'minimal' | 'cyber';
export type CoverStyle = 'classic' | 'floating' | 'depth' | 'ambient' | 'full-bleed' | 'morph' | 'reactive';
export type CoverVariant = 'normal' | 'vinyl' | 'video';
export type LyricsMode = 'standard' | 'cinematic' | 'minimal' | 'dynamic' | 'floating' | 'full-screen';

interface PlayerStore {
  state: PlayerState;
  countdown: number;
  progress: number;
  currentTime: number;
  duration: number;
  volume: number;
  isPlaying: boolean;
  isExpanded: boolean;
  
  // Visual & Cover variants
  coverVariant: CoverVariant;
  visualMode: VisualMode;
  coverStyle: CoverStyle;
  lyricsMode: LyricsMode;
  glitchIntensity: number;
  particlesAmount: number;
  glowIntensity: number;
  colorPalette: [string, string, string] | null;
  showLyrics: boolean;
  visualMixerOpen: boolean;

  setState: (state: PlayerState) => void;
  setCountdown: (val: number) => void;
  setProgress: (val: number) => void;
  setCurrentTime: (val: number) => void;
  setDuration: (val: number) => void;
  setVolume: (val: number) => void;
  setIsPlaying: (val: boolean) => void;
  setIsExpanded: (val: boolean) => void;
  
  setCoverVariant: (val: CoverVariant) => void;
  setVisualMode: (val: VisualMode) => void;
  setCoverStyle: (val: CoverStyle) => void;
  setLyricsMode: (val: LyricsMode) => void;
  setGlitchIntensity: (val: number) => void;
  setParticlesAmount: (val: number) => void;
  setGlowIntensity: (val: number) => void;
  setColorPalette: (val: [string, string, string] | null) => void;
  setShowLyrics: (val: boolean) => void;
  setVisualMixerOpen: (val: boolean) => void;
}

const savedCoverVariant = (typeof window !== 'undefined' && (localStorage.getItem('player_cover_variant') as CoverVariant)) || 'vinyl';

export const usePlayerStore = create<PlayerStore>((set) => ({
  state: 'paused',
  countdown: 0,
  progress: 0,
  currentTime: 0,
  duration: 0,
  volume: 1,
  isPlaying: false,
  isExpanded: false,
  
  coverVariant: savedCoverVariant,
  visualMode: 'orbital',
  coverStyle: 'reactive',
  lyricsMode: 'cinematic',
  glitchIntensity: 0.1,
  particlesAmount: 150,
  glowIntensity: 0.5,
  colorPalette: null,
  showLyrics: false,
  visualMixerOpen: false,

  setState: (state) => set({ state }),
  setCountdown: (countdown) => set({ countdown }),
  setProgress: (progress) => set({ progress }),
  setCurrentTime: (currentTime) => set({ currentTime }),
  setDuration: (duration) => set({ duration }),
  setVolume: (volume) => set({ volume }),
  setIsPlaying: (isPlaying) => set({ isPlaying }),
  setIsExpanded: (isExpanded) => set({ isExpanded }),
  
  setCoverVariant: (coverVariant) => {
    try { localStorage.setItem('player_cover_variant', coverVariant); } catch(e) {}
    set({ coverVariant });
  },
  setVisualMode: (visualMode) => set({ visualMode }),
  setCoverStyle: (coverStyle) => set({ coverStyle }),
  setLyricsMode: (lyricsMode) => set({ lyricsMode }),
  setGlitchIntensity: (glitchIntensity) => set({ glitchIntensity }),
  setParticlesAmount: (particlesAmount) => set({ particlesAmount }),
  setGlowIntensity: (glowIntensity) => set({ glowIntensity }),
  setColorPalette: (colorPalette) => set({ colorPalette }),
  setShowLyrics: (showLyrics) => set({ showLyrics }),
  setVisualMixerOpen: (visualMixerOpen) => set({ visualMixerOpen }),
}));
