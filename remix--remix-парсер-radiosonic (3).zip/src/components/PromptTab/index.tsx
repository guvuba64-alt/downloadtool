import React, { useState } from 'react';
import { Copy, Check, Sparkles, RefreshCw, Wand2, Mic2, Disc3 } from 'lucide-react';

interface PromptTabProps {
  t: (en: string, ru: string) => string;
}

export function PromptTab({ t }: PromptTabProps) {
  const [copied, setCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [generationType, setGenerationType] = useState<'artist' | 'label'>('artist');
  const [error, setError] = useState('');

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError('');
    setResult(null);
    try {
      // Provide a generic input so the AI model has something to work with
      const defaultInputs = "сгенерируй уникальные и актуальные названия, используй свою лучшую экспертизу брендинга без привязки к конкретному жанру.";
      const response = await fetch('/api/generate-naming', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ type: generationType, inputs: defaultInputs })
      });
      
      let data;
      const text = await response.text();
      try {
        data = JSON.parse(text);
      } catch (e) {
        throw new Error("Ошибка сервера. Ответ: " + text.substring(0, 100));
      }
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate');
      }
      
      setResult(data.result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto my-8 space-y-6">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <h2 className="text-2xl font-bold text-zinc-900 dark:text-zinc-50">
            {t("Pseudonyms & Labels", "Генерация псевдонимов и лейблов")}
          </h2>
        </div>
      </div>

      <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/50 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="p-8 border-b border-zinc-100 dark:border-white/5 flex flex-col items-center justify-center">
          
          <div className="bg-zinc-100 dark:bg-white/5 p-1.5 rounded-2xl flex items-center mb-8 w-full max-w-md">
            <button
              onClick={() => setGenerationType('artist')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold transition-all duration-300 ${
                generationType === 'artist' 
                  ? 'bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-white shadow-sm' 
                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
              }`}
            >
              <Mic2 className="w-4 h-4" />
              {t("Artist Pseudonym", "Псевдоним артиста")}
            </button>
            <button
              onClick={() => setGenerationType('label')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold transition-all duration-300 ${
                generationType === 'label' 
                  ? 'bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-white shadow-sm' 
                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
              }`}
            >
              <Disc3 className="w-4 h-4" />
              {t("Label Name", "Название лейбла")}
            </button>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full max-w-md flex items-center justify-center gap-3 bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black py-4 px-8 rounded-2xl font-bold text-lg transition-colors disabled:opacity-50 disabled:scale-95 active:scale-95 shadow-md"
          >
            {isGenerating ? <RefreshCw className="w-6 h-6 animate-spin" /> : <Wand2 className="w-6 h-6" />}
            {isGenerating ? t("Generating...", "Генерация...") : t("Generate Name", "Сгенерировать")}
          </button>

          {error && <p className="text-red-500 text-sm mt-4 text-center">{error}</p>}
        </div>

        {result && (
          <div className="p-8 bg-zinc-50/50 dark:bg-black/20">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-500" />
                {t("Result", "Результаты")}
              </h3>
              <button
                onClick={() => handleCopy(result)}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-xl transition-colors font-medium text-sm"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span className="text-emerald-600 dark:text-emerald-400">Скопировано</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Копировать</span>
                  </>
                )}
              </button>
            </div>
            <pre className="text-sm text-zinc-800 dark:text-zinc-300 font-mono whitespace-pre-wrap overflow-x-auto max-h-[600px] custom-scrollbar p-6 bg-white dark:bg-[#121212] rounded-2xl border border-zinc-200 dark:border-zinc-800 leading-relaxed shadow-inner">
              {result}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
