import React, { useState, useEffect } from 'react';
import {
  Bot,
  Sparkles,
  Zap,
  Key,
  Globe,
  Sliders,
  Play,
  Save,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Clock,
  Eye,
  EyeOff,
  RefreshCw,
  Users,
  Shield,
  MessageSquare,
  Copy,
  Check,
  ChevronRight,
  Send,
  HelpCircle,
  Crown,
  Lock,
  UserCheck,
  Activity,
  Gauge,
  Server,
  Radio,
  Cpu,
} from 'lucide-react';
import { TelegramIcon } from './Icons';

interface TelegramAiConfig {
  enabled: boolean;
  provider: 'custom' | 'openai' | 'gemini' | 'anthropic' | 'deepseek' | 'groq' | 'ollama';
  apiUrl: string;
  apiKey: string;
  apiKeyMasked?: string;
  model: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  accessMode: 'owner_only' | 'contacts_only' | 'all';
  historyLimit: number;
  ownerChatId?: string;
  unauthorizedResponse?: 'silent' | 'reject_message';
  autoFallback?: boolean;
}

export interface ModelScanStatus {
  id: string;
  available: boolean;
  status: number;
  latencyMs: number;
  error?: string;
  isFree: boolean;
  testedAt?: number;
}

const PROVIDER_OPTIONS = [
  {
    id: 'custom',
    name: 'Кастомный API',
    desc: 'Любой OpenAI-совместимый эндпоинт, прокси или локальный сервер',
    defaultUrl: 'https://api.openai.com/v1/chat/completions',
    defaultModel: 'gpt-4o-mini',
    badge: 'Custom URL',
    icon: Globe,
    color: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    desc: 'Официальный Gemini 3.1 Flash-Lite / 3.8 Flash (быстрый и умный)',
    defaultUrl: '',
    defaultModel: 'gemini-3.1-flash-lite',
    badge: 'Рекомендуется',
    icon: Sparkles,
    color: 'text-blue-500 bg-blue-500/10 border-blue-500/20',
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    desc: 'DeepSeek V3 / R1 (высочайший интеллект, доступная цена)',
    defaultUrl: 'https://api.deepseek.com/v1/chat/completions',
    defaultModel: 'deepseek-chat',
    badge: 'Популярно',
    icon: Bot,
    color: 'text-indigo-500 bg-indigo-500/10 border-indigo-500/20',
  },
  {
    id: 'openai',
    name: 'OpenAI ChatGPT',
    desc: 'Оригинальные модели GPT-4o, GPT-4o-mini, o3-mini',
    defaultUrl: 'https://api.openai.com/v1/chat/completions',
    defaultModel: 'gpt-4o-mini',
    badge: 'GPT-4o',
    icon: Zap,
    color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
  },
  {
    id: 'groq',
    name: 'Groq Cloud',
    desc: 'Сверхбыстрый LPU вывод моделей LLaMA 3.3 (500+ токенов/сек)',
    defaultUrl: 'https://api.groq.com/openai/v1/chat/completions',
    defaultModel: 'llama-3.3-70b-versatile',
    badge: 'Ультра-быстро',
    icon: Zap,
    color: 'text-orange-500 bg-orange-500/10 border-orange-500/20',
  },
  {
    id: 'anthropic',
    name: 'Anthropic Claude',
    desc: 'Claude 3.5 Sonnet / Haiku (лучший для сложных текстов)',
    defaultUrl: 'https://api.anthropic.com/v1/messages',
    defaultModel: 'claude-3-5-sonnet-20241022',
    badge: 'Claude 3.5',
    icon: Bot,
    color: 'text-purple-500 bg-purple-500/10 border-purple-500/20',
  },
  {
    id: 'ollama',
    name: 'Ollama / Local',
    desc: 'Локальная или серверная модель без цензуры (localhost:11434)',
    defaultUrl: 'http://localhost:11434/v1/chat/completions',
    defaultModel: 'llama3',
    badge: 'Self-hosted',
    icon: Globe,
    color: 'text-zinc-500 bg-zinc-500/10 border-zinc-500/20',
  },
];

const PROMPT_PRESETS = [
  {
    id: 'music_label',
    title: 'Музыкальный лейбл',
    icon: '🎵',
    prompt:
      'Ты профессиональный персональный ИИ-ассистент музыкального лейбла в Telegram. Отвечай вежливо, емко и по делу. Помогай артистам и менеджерам с релизами, дистрибуцией на Spotify/Apple/Яндекс/VK, промо-материалами, текстами песен, питчингом, ISRC/UPC и любыми творческими вопросами.',
  },
  {
    id: 'general_gpt',
    title: 'Универсальный GPT',
    icon: '🤖',
    prompt:
      'Ты умный, тактичный и эрудированный персональный ассистент в Telegram. Отвечай подробно, структурированно и грамотно на любые вопросы пользователя. При необходимости используй форматирование со списками.',
  },
  {
    id: 'support_care',
    title: 'Поддержка и сервис',
    icon: '🎧',
    prompt:
      'Ты заботливый менеджер поддержки музыкального сервиса отчётов и аналитики. Твоя цель: доброжелательно помогать артистам разбираться с выгрузками, отчётами по прослушиваниям, роялти и техническими вопросами платформы.',
  },
  {
    id: 'creative_copy',
    title: 'Креативный копирайтер',
    icon: '✍️',
    prompt:
      'Ты талантливый креативный копирайтер и контент-мейкер. Помогай писать яркие анонсы релизов, сниппеты для соцсетей, пресс-релизы для СМИ, концепции обложек и цепляющие посты для Telegram-каналов.',
  },
];

const MODEL_PRESETS: Record<string, string[]> = {
  custom: [
    'free/gemini-3.8-flash',
    'free/deepseek-v4.1-flash',
    'free/gpt-5.6-luna',
    'free/glm-5.3-flash',
    'gpt-4o-mini',
    'deepseek-chat',
    'mistral-large',
  ],
  gemini: ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-flash-latest'],
  deepseek: ['deepseek-chat', 'deepseek-reasoner'],
  openai: ['gpt-4o-mini', 'gpt-4o', 'o3-mini', 'gpt-4-turbo'],
  groq: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'],
  anthropic: ['claude-3-5-sonnet-20241022', 'claude-3-5-haiku-20241022'],
  ollama: ['llama3', 'mistral', 'deepseek-r1', 'qwen2.5'],
};

export const TelegramAiBotConfig = ({
  t,
  onViewTelegramLogs,
}: {
  t: (en: string, ru: string) => string;
  onViewTelegramLogs?: () => void;
}) => {
  const [config, setConfig] = useState<TelegramAiConfig>({
    enabled: true,
    provider: 'gemini',
    apiUrl: '',
    apiKey: '',
    model: 'gemini-3.1-flash-lite',
    systemPrompt: PROMPT_PRESETS[0].prompt,
    temperature: 0.7,
    maxTokens: 1500,
    accessMode: 'owner_only',
    historyLimit: 8,
    ownerChatId: '8160231965',
    unauthorizedResponse: 'silent',
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);

  // Test Runner state
  const [testPrompt, setTestPrompt] = useState('Привет! Кто ты и чем можешь помочь нашему музыкальному лейблу?');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    reply?: string;
    durationMs?: number;
    model?: string;
    provider?: string;
    error?: string;
  } | null>(null);

  // Stats state
  const [stats, setStats] = useState<{ activeChats: number; totalMessages: number } | null>(null);
  const [isClearingMemory, setIsClearingMemory] = useState(false);
  const [memoryCleared, setMemoryCleared] = useState(false);
  const [isWipingOthers, setIsWipingOthers] = useState(false);
  const [othersWiped, setOthersWiped] = useState(false);

  // Models fetched & scanned from server
  const [fetchedModels, setFetchedModels] = useState<string[]>([]);
  const [isFetchingModels, setIsFetchingModels] = useState(false);
  const [fetchModelsError, setFetchModelsError] = useState<string | null>(null);

  // Model Availability Scanner state
  const [scanResults, setScanResults] = useState<ModelScanStatus[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [scanFilter, setScanFilter] = useState<'all' | 'working' | 'free' | 'errors'>('working');
  const [lastScannedAt, setLastScannedAt] = useState<number | null>(null);

  // 24/7 Server & Gateway Health state
  const [serverHealth, setServerHealth] = useState<{
    serverMode: string;
    uptimeSeconds: number;
    activeBots: number;
    tokensConfigured: number;
    totalUpdatesProcessed: number;
    totalPollsExecuted: number;
    aiConfig?: {
      enabled: boolean;
      provider: string;
      model: string;
      autoFallback: boolean;
      geminiFallbackReady: boolean;
    };
  } | null>(null);
  const [isRestartingGateway, setIsRestartingGateway] = useState(false);
  const [restartMessage, setRestartMessage] = useState<string | null>(null);

  // Load config on mount
  useEffect(() => {
    fetchConfig();
    fetchStats();
    fetchCachedScan();
    fetchServerHealth();

    const interval = setInterval(() => {
      fetchServerHealth();
      fetchStats();
    }, 20000);
    return () => clearInterval(interval);
  }, []);

  const fetchServerHealth = async () => {
    try {
      const res = await fetch('/api/tg/server-health');
      if (res.ok) {
        const data = await res.json();
        setServerHealth(data);
      }
    } catch {}
  };

  const handleRestartGateway = async () => {
    setIsRestartingGateway(true);
    setRestartMessage(null);
    try {
      const res = await fetch('/api/tg/restart-polling', { method: 'POST' });
      if (res.ok) {
        setRestartMessage('Шлюз Telegram успешно перезапущен в режиме 24/7');
        await fetchServerHealth();
        setTimeout(() => setRestartMessage(null), 4000);
      }
    } catch (e: any) {
      setRestartMessage('Ошибка перезапуска: ' + (e?.message || e));
    } finally {
      setIsRestartingGateway(false);
    }
  };

  const fetchCachedScan = async () => {
    try {
      const res = await fetch('/api/tg/ai/scan-models');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.results) && data.results.length > 0) {
          setScanResults(data.results);
          setLastScannedAt(data.timestamp || null);
          setFetchedModels(data.results.map((r: ModelScanStatus) => r.id));
        }
      }
    } catch {}
  };

  const fetchConfig = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/tg/ai/config');
      if (res.ok) {
        const data = await res.json();
        setConfig(data);
      }
    } catch (e) {
      console.error('Failed to load TG AI config:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/tg/ai/stats');
      if (res.ok) {
        const data = await res.json();
        setStats({ activeChats: data.activeChats || 0, totalMessages: data.totalMessages || 0 });
      }
    } catch (e) {}
  };

  const handleProviderChange = (newProvider: any) => {
    const pInfo = PROVIDER_OPTIONS.find((p) => p.id === newProvider);
    setConfig((prev) => ({
      ...prev,
      provider: newProvider,
      apiUrl: pInfo?.defaultUrl || '',
      model: pInfo?.defaultModel || prev.model,
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      const res = await fetch('/api/tg/ai/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.config) setConfig((prev) => ({ ...prev, ...data.config }));
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } else {
        const err = await res.json();
        alert(err.error || 'Ошибка при сохранении конфигурации');
      }
    } catch (e: any) {
      alert('Сбой сети при сохранении: ' + e.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleRunTest = async () => {
    if (!testPrompt.trim()) return;
    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/tg/ai/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: testPrompt,
          config,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setTestResult({
          success: true,
          reply: data.reply,
          durationMs: data.durationMs,
          model: data.model,
          provider: data.provider,
        });
      } else {
        setTestResult({
          success: false,
          error: data.error || 'Ошибка при запросе к модели',
        });
      }
    } catch (e: any) {
      setTestResult({
        success: false,
        error: e.message || 'Сетевая ошибка при проверке API',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleClearMemory = async () => {
    if (!window.confirm(t('Clear all conversation memory for all Telegram chats?', 'Очистить историю всех диалогов в Telegram?'))) {
      return;
    }
    setIsClearingMemory(true);
    try {
      const res = await fetch('/api/tg/ai/history', { method: 'DELETE' });
      if (res.ok) {
        setMemoryCleared(true);
        fetchStats();
        setTimeout(() => setMemoryCleared(false), 2500);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsClearingMemory(false);
    }
  };

  const handleWipeOthers = async () => {
    if (!window.confirm(t('Wipe conversation history of all other users while preserving your owner dialogue?', 'Очистить историю всех сторонних пользователей, оставив ваш диалог владельца в целости?'))) {
      return;
    }
    setIsWipingOthers(true);
    try {
      const res = await fetch('/api/tg/ai/wipe-others', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerChatId: config.ownerChatId || '8160231965' }),
      });
      if (res.ok) {
        setOthersWiped(true);
        fetchStats();
        setTimeout(() => setOthersWiped(false), 2500);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsWipingOthers(false);
    }
  };

  const handleFetchModels = async () => {
    setIsFetchingModels(true);
    setFetchModelsError(null);
    try {
      const res = await fetch('/api/tg/ai/models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiUrl: config.apiUrl,
          apiKey: config.apiKey,
          provider: config.provider,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success && Array.isArray(data.models) && data.models.length > 0) {
        setFetchedModels(data.models);
      } else {
        setFetchModelsError(
          data.error ||
            t(
              'Could not load models list automatically. Check URL and Key.',
              'Не удалось автоматически загрузить список моделей. Проверьте URL и ключ.'
            )
        );
      }
    } catch (e: any) {
      setFetchModelsError(e.message || 'Ошибка сети при получении моделей');
    } finally {
      setIsFetchingModels(false);
    }
  };

  const handleScanModels = async () => {
    setIsScanning(true);
    setScanError(null);
    try {
      const res = await fetch('/api/tg/ai/scan-models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiUrl: config.apiUrl,
          apiKey: config.apiKey,
          provider: config.provider,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success && Array.isArray(data.results)) {
        setScanResults(data.results);
        setLastScannedAt(data.timestamp || Date.now());
        // Also update fetchedModels with all discovered IDs
        const ids = data.results.map((r: ModelScanStatus) => r.id);
        if (ids.length > 0) {
          setFetchedModels(ids);
        }
      } else {
        setScanError(data.error || t('Failed to scan models', 'Не удалось просканировать модели'));
      }
    } catch (e: any) {
      setScanError(e.message || 'Ошибка сети при сканировании');
    } finally {
      setIsScanning(false);
    }
  };

  const handleSelectFastest = () => {
    const working = scanResults.filter((r) => r.available);
    if (working.length > 0) {
      // First working item is best (free + lowest latency)
      setConfig((prev) => ({ ...prev, model: working[0].id }));
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-zinc-500 gap-3">
        <RefreshCw className="w-8 h-8 animate-spin text-indigo-500" />
        <span className="text-sm">{t('Loading AI Bot configuration...', 'Загрузка настроек ИИ-Бота...')}</span>
      </div>
    );
  }

  const selectedProviderInfo = PROVIDER_OPTIONS.find((p) => p.id === config.provider);

  return (
    <div className="flex flex-col gap-4 sm:gap-6 animate-in fade-in duration-300">
      {/* 1. HERO MASTER CARD: STATUS & TOGGLE */}
      <div className="bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent dark:from-indigo-950/40 dark:via-purple-950/20 dark:to-transparent p-4 sm:p-7 rounded-2xl sm:rounded-3xl border border-indigo-200/70 dark:border-indigo-800/40 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-6 relative z-10">
          <div className="flex items-start sm:items-center gap-3 sm:gap-4">
            <div
              className={`w-11 h-11 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl flex items-center justify-center shadow-md transition-all shrink-0 ${
                config.enabled
                  ? 'bg-gradient-to-tr from-indigo-600 to-purple-600 text-white ring-4 ring-indigo-500/20'
                  : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-400'
              }`}
            >
              <Bot className="w-6 h-6 sm:w-7 sm:h-7" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg sm:text-2xl font-black text-zinc-900 dark:text-white tracking-tight">
                  {t('Telegram AI Bot & Custom API', 'Telegram ИИ-Бот и Кастомный API')}
                </h3>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider ${
                    config.enabled
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800'
                      : 'bg-zinc-200 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400'
                  }`}
                >
                  {config.enabled ? t('Active', 'Включен') : t('Disabled', 'Выключен')}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-300 mt-1 max-w-xl leading-relaxed">
                {t(
                  'Transform your Telegram bot into an intelligent AI assistant. Connect any custom OpenAI-compatible endpoint, Gemini, DeepSeek, Claude, or local model.',
                  'Превратите вашего Telegram-бота в умного ИИ-ассистента. Подключите любой кастомный API-эндпоинт, Gemini, DeepSeek, ChatGPT или локальную нейросеть.'
                )}
              </p>
            </div>
          </div>

          {/* Big ON/OFF Switch */}
          <div className="flex items-center gap-3 shrink-0 self-start sm:self-center">
            <button
              type="button"
              onClick={() => setConfig((p) => ({ ...p, enabled: !p.enabled }))}
              className={`relative inline-flex h-8 w-16 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                config.enabled ? 'bg-indigo-600' : 'bg-zinc-300 dark:bg-zinc-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-7 w-7 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  config.enabled ? 'translate-x-8' : 'translate-x-0'
                }`}
              />
            </button>
            <span className="text-xs sm:text-sm font-bold text-zinc-700 dark:text-zinc-200">
              {config.enabled ? t('AI Responses ON', 'Ответы ИИ включены') : t('AI OFF', 'ИИ выключен')}
            </span>
          </div>
        </div>

        {/* Live Bot Meta Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-200/50 dark:border-white/10">
          <div className="bg-white/70 dark:bg-zinc-900/70 backdrop-blur-md px-4 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/5">
            <div className="text-[11px] text-zinc-400 font-medium">{t('Active Provider', 'Провайдер')}</div>
            <div className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate">
              {selectedProviderInfo?.name || config.provider}
            </div>
          </div>
          <div className="bg-white/70 dark:bg-zinc-900/70 backdrop-blur-md px-4 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/5">
            <div className="text-[11px] text-zinc-400 font-medium">{t('Model', 'Модель')}</div>
            <div className="text-xs sm:text-sm font-bold text-indigo-600 dark:text-indigo-400 font-mono truncate">
              {config.model || 'не указана'}
            </div>
          </div>
          <div className="bg-white/70 dark:bg-zinc-900/70 backdrop-blur-md px-4 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/5">
            <div className="text-[11px] text-zinc-400 font-medium">{t('Access Mode', 'Доступ в Telegram')}</div>
            <div className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate">
              {config.accessMode === 'all' ? t('Public (All Users)', 'Все пользователи') : t('Contacts Only', 'Только контакты')}
            </div>
          </div>
          <div className="bg-white/70 dark:bg-zinc-900/70 backdrop-blur-md px-4 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/5 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-zinc-400 font-medium">{t('Active Chats', 'Диалогов в памяти')}</div>
              <div className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white">
                {stats?.activeChats || 0}
              </div>
            </div>
            {onViewTelegramLogs && (
              <button
                onClick={onViewTelegramLogs}
                title={t('View Telegram Logs', 'Смотреть логи Telegram')}
                className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:scale-105 transition-transform"
              >
                <TelegramIcon className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 24/7 AUTONOMOUS SERVER & FAILOVER BANNER */}
      <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-indigo-500/10 dark:from-emerald-950/40 dark:via-zinc-900/40 dark:to-indigo-950/30 p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-emerald-300/50 dark:border-emerald-800/40 shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 sm:gap-5 relative z-10">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
              <div className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 shrink-0">
                <Server className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <h4 className="text-sm sm:text-lg font-black text-zinc-900 dark:text-white tracking-tight flex items-center gap-2">
                {t('24/7 Autonomous Server & AI Gateway', '24/7 Автономный Сервер и Шлюз ИИ')}
              </h4>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-400/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                {t('Online 24/7 (Long-Polling)', 'В сети 24/7 (Long-Polling)')}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
              {t(
                'The Telegram bot and AI run continuously in the background on the server. You can close your browser tab or app completely — the bot continues to receive messages and generate instant AI replies 24/7.',
                'Telegram-бот и ИИ работают непрерывно в фоне на сервере. Вы можете полностью закрыть вкладку браузера или выключить приложение — бот продолжает принимать сообщения и мгновенно отвечать в Telegram круглосуточно.'
              )}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2 w-full lg:w-auto shrink-0">
            <button
              type="button"
              onClick={handleRestartGateway}
              disabled={isRestartingGateway}
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-white/10 text-xs font-bold transition-all shadow-xs disabled:opacity-60 min-h-[40px]"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 ${isRestartingGateway ? 'animate-spin' : ''}`} />
              {isRestartingGateway
                ? t('Restarting...', 'Перезапуск...')
                : t('Restart Telegram Gateway', 'Перезапустить шлюз')}
            </button>
            <button
              type="button"
              onClick={handleScanModels}
              disabled={isScanning}
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm shadow-emerald-600/20 disabled:opacity-60 min-h-[40px]"
            >
              <Activity className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              {isScanning ? t('Scanning...', 'Сканирование...') : t('Check AI Health', 'Проверить доступность ИИ')}
            </button>
          </div>
        </div>

        {restartMessage && (
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            {restartMessage}
          </div>
        )}

        {/* Live 24/7 Diagnostics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5 mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-emerald-200/40 dark:border-white/5">
          <div className="bg-white/60 dark:bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-200/50 dark:border-white/5">
            <div className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">{t('Server Uptime', 'Аптайм сервера')}</div>
            <div className="text-xs font-bold text-zinc-800 dark:text-zinc-200 font-mono mt-0.5 truncate">
              {serverHealth?.uptimeSeconds
                ? `${Math.floor(serverHealth.uptimeSeconds / 3600)}ч ${Math.floor((serverHealth.uptimeSeconds % 3600) / 60)}м ${serverHealth.uptimeSeconds % 60}с`
                : t('Continuous', 'Непрерывно')}
            </div>
          </div>

          <div className="bg-white/60 dark:bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-200/50 dark:border-white/5">
            <div className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">{t('Failover Protection', 'Резерв ответов ИИ')}</div>
            <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{t('Active (6 Models + Gemini)', 'Активен (6 моделей)')}</span>
            </div>
          </div>

          <div className="bg-white/60 dark:bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-200/50 dark:border-white/5">
            <div className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">{t('Telegram Polls Executed', 'Опросов Telegram')}</div>
            <div className="text-xs font-bold text-zinc-800 dark:text-zinc-200 font-mono mt-0.5 truncate">
              {serverHealth?.totalPollsExecuted ?? 'Активен'}
            </div>
          </div>

          <div className="bg-white/60 dark:bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-200/50 dark:border-white/5">
            <div className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">{t('Watchdog Monitor', 'Watchdog')}</div>
            <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400 mt-0.5 flex items-center gap-1">
              <Radio className="w-3.5 h-3.5 shrink-0 animate-pulse" />
              <span className="truncate">{t('Every 15s', 'Каждые 15с')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. PROVIDER SELECTOR GRID */}
      <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-500" />
            {t('Select AI Engine / Provider', 'Выберите провайдера ИИ')}
          </label>
          <span className="text-xs text-zinc-400">
            {t('Supports any OpenAI-compatible API', 'Поддерживает любой OpenAI-совместимый API')}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {PROVIDER_OPTIONS.map((p) => {
            const Icon = p.icon;
            const isSelected = config.provider === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => handleProviderChange(p.id)}
                className={`flex flex-col text-left p-3.5 rounded-2xl border transition-all relative ${
                  isSelected
                    ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 shadow-sm ring-1 ring-indigo-500/20'
                    : 'bg-zinc-50/50 dark:bg-zinc-900/40 border-zinc-200/80 dark:border-white/5 hover:border-zinc-300 dark:hover:border-white/15'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <div className={`p-2 rounded-xl border ${p.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-zinc-200/60 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
                    {p.badge}
                  </span>
                </div>
                <span className="text-sm font-bold text-zinc-900 dark:text-white leading-tight">{p.name}</span>
                <span className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 line-clamp-2 leading-snug">
                  {p.desc}
                </span>
                {isSelected && (
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. API & CONNECTION CONFIGURATION */}
      <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-6 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm space-y-5">
        <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
          <Key className="w-4 h-4 text-purple-500" />
          {t('API Credentials & Endpoint', 'Параметры подключения и Ключи API')}
        </h4>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Custom API URL */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-zinc-400" />
                {t('API Endpoint URL', 'Эндпоинт API (URL)')}
              </label>
              {config.provider !== 'custom' && (
                <span className="text-[11px] text-zinc-400">
                  {config.provider === 'gemini' ? 'Встроенный Google SDK' : 'Предустановленный URL'}
                </span>
              )}
            </div>
            <input
              type="text"
              value={config.apiUrl}
              onChange={(e) => setConfig({ ...config, apiUrl: e.target.value })}
              placeholder={
                config.provider === 'gemini'
                  ? t('Direct Gemini API integration (no URL needed)', 'Прямая интеграция с Gemini (URL не требуется)')
                  : 'https://api.openai.com/v1/chat/completions'
              }
              disabled={config.provider === 'gemini'}
              className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none disabled:opacity-50 transition-all"
            />
            <div className="flex flex-col gap-1 text-[11px] text-zinc-400 leading-tight">
              <span>
                {t(
                  'Base or completions URL (e.g. https://api.apinex.bond/v1). Automatically appended with /chat/completions.',
                  'Базовый URL или эндпоинт (например, https://api.apinex.bond/v1). Сервер автоматически дополнит его до /chat/completions.'
                )}
              </span>
              {config.apiUrl && !config.apiUrl.endsWith('/chat/completions') && config.provider !== 'gemini' && (
                <span className="text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {t('Auto-normalized to /chat/completions on request', 'Автоматически преобразуется в .../chat/completions')}
                </span>
              )}
            </div>
          </div>

          {/* API Key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-zinc-400" />
                {t('API Key (Secret)', 'API Ключ (Bearer / Secret)')}
              </label>
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="text-[11px] text-indigo-500 hover:text-indigo-600 flex items-center gap-1 font-medium"
              >
                {showApiKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                {showApiKey ? t('Hide', 'Скрыть') : t('Show', 'Показать')}
              </button>
            </div>
            <div className="relative">
              <input
                type={showApiKey ? 'text' : 'password'}
                value={config.apiKey}
                onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                placeholder={
                  config.provider === 'gemini'
                    ? t('Optional: Leave blank to use server GEMINI_API_KEY', 'Опционально: Оставьте пустым для серверного ключа')
                    : 'sk-...'
                }
                className="w-full px-3.5 py-2.5 pr-10 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              />
            </div>
            <p className="text-[11px] text-zinc-400 leading-tight">
              {config.provider === 'gemini'
                ? t('If empty, the server automatically uses the existing GEMINI_API_KEY from environment.', 'Если не заполнен, используется системный GEMINI_API_KEY.')
                : t('Passed as Bearer authorization header to your API endpoint.', 'Передается как заголовок Bearer Authorization в ваш API.')}
            </p>
          </div>
        </div>

        {/* Model Selection & Custom Name */}
        <div className="space-y-2 pt-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-zinc-400" />
              {t('Model Name / Identifier', 'Имя модели (Model Identifier)')}
            </label>
            
            <div className="flex flex-wrap items-center gap-2">
              {config.provider !== 'gemini' && config.provider !== 'anthropic' && (
                <>
                  <button
                    type="button"
                    onClick={handleScanModels}
                    disabled={isScanning}
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all flex items-center gap-1.5 disabled:opacity-50"
                  >
                    {isScanning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Activity className="w-3.5 h-3.5" />}
                    {isScanning ? t('Scanning models...', 'Сканирование моделей...') : t('Scan Model Availability', '🔍 Сканировать доступность моделей')}
                  </button>

                  <button
                    type="button"
                    onClick={handleFetchModels}
                    disabled={isFetchingModels}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-medium bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 transition-all flex items-center gap-1.5"
                  >
                    {isFetchingModels ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                    {t('Refresh List', 'Обновить список')}
                  </button>
                </>
              )}
              <span className="text-[11px] text-zinc-400">{t('Quick Presets:', 'Быстрый выбор:')}</span>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap gap-1.5 mb-2">
            {(MODEL_PRESETS[config.provider] || MODEL_PRESETS.custom).map((mName) => (
              <button
                key={mName}
                type="button"
                onClick={() => setConfig({ ...config, model: mName })}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1 ${
                  config.model === mName
                    ? 'bg-indigo-600 text-white shadow-xs font-bold ring-2 ring-indigo-500/30'
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                }`}
              >
                {mName.startsWith('free/') && (
                  <span className="px-1 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                    FREE
                  </span>
                )}
                <span>{mName}</span>
              </button>
            ))}
          </div>

          {/* MODEL AVAILABILITY SCANNER CARD */}
          {config.provider !== 'gemini' && config.provider !== 'anthropic' && (
            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/80 border border-zinc-200 dark:border-zinc-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-zinc-200/70 dark:border-zinc-800">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-500">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                      {t('API Model Health Scanner', 'Сканер Доступности Моделей')}
                      {lastScannedAt && (
                        <span className="text-[10px] font-normal text-zinc-400 font-mono">
                          • {new Date(lastScannedAt).toLocaleTimeString()}
                        </span>
                      )}
                    </h5>
                    <p className="text-[11px] text-zinc-400">
                      {t('Automatically probes each model to detect 200 OK vs 402/404 errors', 'Автоматически пингует каждую модель и проверяет статус ответа API')}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {scanResults.some((r) => r.available) && (
                    <button
                      type="button"
                      onClick={handleSelectFastest}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50 transition-all flex items-center gap-1 shadow-xs"
                    >
                      <Zap className="w-3 h-3 text-amber-500" />
                      {t('Select Fastest Free', 'Выбрать быстрейшую FREE')}
                    </button>
                  )}
                </div>
              </div>

              {/* Scanning status banner */}
              {isScanning && (
                <div className="p-3 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/50 flex items-center gap-3 animate-pulse">
                  <RefreshCw className="w-4 h-4 text-indigo-600 animate-spin shrink-0" />
                  <div className="text-xs text-indigo-700 dark:text-indigo-300">
                    <p className="font-semibold">{t('Probing model endpoints...', 'Идет тестирование моделей и замер отклика...')}</p>
                    <p className="text-[10px] opacity-80">{t('Sending lightweight ping requests to identify active and free models', 'Отправка микрозапросов для выявления работающих и бесплатных моделей')}</p>
                  </div>
                </div>
              )}

              {/* Scan Metrics Pills */}
              {scanResults.length > 0 && (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="p-2 rounded-xl bg-white dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700/80">
                      <span className="text-[10px] text-zinc-400 uppercase font-medium">{t('Working', 'Работают')}</span>
                      <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 mt-0.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        {scanResults.filter((r) => r.available).length}
                      </p>
                    </div>

                    <div className="p-2 rounded-xl bg-white dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700/80">
                      <span className="text-[10px] text-zinc-400 uppercase font-medium">{t('Free Available', 'Бесплатные')}</span>
                      <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mt-0.5">
                        <span className="px-1 py-0.2 rounded text-[9px] font-bold bg-indigo-500 text-white">FREE</span>
                        {scanResults.filter((r) => r.available && r.isFree).length}
                      </p>
                    </div>

                    <div className="p-2 rounded-xl bg-white dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700/80">
                      <span className="text-[10px] text-zinc-400 uppercase font-medium">{t('Errors / Unreachable', 'Недоступны')}</span>
                      <p className="text-sm font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1.5 mt-0.5">
                        <span className="w-2 h-2 rounded-full bg-rose-500" />
                        {scanResults.filter((r) => !r.available).length}
                      </p>
                    </div>

                    <div className="p-2 rounded-xl bg-white dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700/80">
                      <span className="text-[10px] text-zinc-400 uppercase font-medium">{t('Fastest Ping', 'Мин. отклик')}</span>
                      <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1 mt-0.5 font-mono">
                        <Gauge className="w-3.5 h-3.5 text-amber-500" />
                        {scanResults.filter((r) => r.available).length > 0
                          ? `${Math.min(...scanResults.filter((r) => r.available).map((r) => r.latencyMs))} мс`
                          : '—'}
                      </p>
                    </div>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex items-center gap-1.5 pt-1 overflow-x-auto">
                    {[
                      { id: 'working', label: t('🟢 Working', '🟢 Доступные'), count: scanResults.filter((r) => r.available).length },
                      { id: 'free', label: t('🎁 Free Only', '🎁 Бесплатные'), count: scanResults.filter((r) => r.available && r.isFree).length },
                      { id: 'errors', label: t('🔴 Unavailable', '🔴 Недоступные'), count: scanResults.filter((r) => !r.available).length },
                      { id: 'all', label: t('All Models', 'Все модели'), count: scanResults.length },
                    ].map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setScanFilter(f.id as any)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                          scanFilter === f.id
                            ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 shadow-xs'
                            : 'bg-zinc-200/60 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200'
                        }`}
                      >
                        {f.label} ({f.count})
                      </button>
                    ))}
                  </div>

                  {/* Scanned Models List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                    {scanResults
                      .filter((r) => {
                        if (scanFilter === 'working') return r.available;
                        if (scanFilter === 'free') return r.available && r.isFree;
                        if (scanFilter === 'errors') return !r.available;
                        return true;
                      })
                      .map((r) => {
                        const isSelected = config.model === r.id;
                        return (
                          <div
                            key={r.id}
                            onClick={() => setConfig({ ...config, model: r.id })}
                            className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all flex flex-col justify-between gap-1.5 ${
                              isSelected
                                ? 'bg-indigo-50/90 dark:bg-indigo-950/60 border-indigo-500 ring-2 ring-indigo-500/20 shadow-xs'
                                : r.available
                                ? 'bg-white dark:bg-zinc-800/90 border-zinc-200 dark:border-zinc-700/80 hover:border-indigo-300 dark:hover:border-indigo-700'
                                : 'bg-zinc-100/60 dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800/80 opacity-70 hover:opacity-100'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-mono font-semibold text-zinc-900 dark:text-zinc-100 text-[11px]">
                                  {r.id}
                                </span>
                                {r.isFree && (
                                  <span className="px-1 py-0.2 rounded text-[9px] font-bold bg-emerald-500 text-white">
                                    FREE
                                  </span>
                                )}
                              </div>
                              {isSelected ? (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-600 text-white flex items-center gap-0.5 shrink-0">
                                  <Check className="w-3 h-3" /> {t('Active', 'Активна')}
                                </span>
                              ) : r.available ? (
                                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline shrink-0 font-medium">
                                  {t('Select', 'Выбрать')}
                                </span>
                              ) : null}
                            </div>

                            <div className="flex items-center justify-between text-[11px] pt-1 border-t border-zinc-100 dark:border-zinc-800">
                              {r.available ? (
                                <span className="text-emerald-600 dark:text-emerald-400 font-mono font-medium flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                  200 OK • {r.latencyMs} мс
                                </span>
                              ) : (
                                <span className="text-rose-600 dark:text-rose-400 truncate max-w-[240px]" title={r.error}>
                                  {r.error || `HTTP ${r.status}`}
                                </span>
                              )}
                              <span className="text-[10px] text-zinc-400">
                                {r.available ? t('Online', 'Работает') : t('Unavailable', 'Недоступна')}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </>
              )}

              {scanError && (
                <div className="text-xs text-red-500 dark:text-red-400 flex items-center gap-1.5 p-2 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{scanError}</span>
                </div>
              )}
            </div>
          )}

          {/* AUTO-FALLBACK FAILOVER PROTECTION */}
          {config.provider !== 'gemini' && config.provider !== 'anthropic' && (
            <div className="p-3.5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/80 dark:border-indigo-800/40 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div className="p-1.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 mt-0.5">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                    {t('Smart Auto-Failover to Free Model', 'Авто-переключение на резервную модель при сбое')}
                  </h5>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed mt-0.5">
                    {t(
                      'If the chosen model returns HTTP 402 (insufficient balance), 404 or connection timeout, the bot automatically falls back to an available free model so Telegram users always receive a response without interruption.',
                      'Если выбранная модель выдаст ошибку 402 (недостаточно средств), 404 или таймаут, бот автоматически ответит через доступную бесплатную модель (напр. free/gemini-3.8-flash). Пользователь в Telegram не увидит ошибку.'
                    )}
                  </p>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                <input
                  type="checkbox"
                  checked={config.autoFallback !== false}
                  onChange={(e) => setConfig({ ...config, autoFallback: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-zinc-600 peer-checked:bg-indigo-600"></div>
              </label>
            </div>
          )}

          {/* Fetched Models Container */}
          {fetchedModels.length > 0 && (
            <div className="p-3 rounded-2xl bg-zinc-50/80 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-zinc-600 dark:text-zinc-400 font-semibold">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  {t('Models available on your provider:', 'Доступно моделей на вашем сервере:')} ({fetchedModels.length})
                </span>
                <span className="text-[10px] text-zinc-400">{t('Click to select', 'Нажмите для выбора')}</span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
                {fetchedModels.map((m) => {
                  const isFree = m.startsWith('free/');
                  const isSelected = config.model === m;
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setConfig({ ...config, model: m })}
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1 ${
                        isSelected
                          ? 'bg-indigo-600 text-white font-bold shadow-xs'
                          : isFree
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-800/40 hover:bg-emerald-100'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:border-zinc-400'
                      }`}
                    >
                      {isFree && (
                        <span className="px-1 py-0.2 rounded text-[9px] font-bold bg-emerald-500 text-white">
                          FREE
                        </span>
                      )}
                      <span>{m}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {fetchModelsError && (
            <div className="text-xs text-red-500 dark:text-red-400 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{fetchModelsError}</span>
            </div>
          )}

          <input
            type="text"
            value={config.model}
            onChange={(e) => setConfig({ ...config, model: e.target.value })}
            placeholder="e.g. free/gemini-3.8-flash, free/deepseek-v4.1-flash, gpt-4o-mini..."
            className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
          />
        </div>
      </div>

      {/* 4. SYSTEM PROMPT & PERSONA */}
      <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-6 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-500" />
              {t('System Instruction (Persona & Behavior)', 'Системный промпт (Роль и характер бота)')}
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              {t('Defines how the bot behaves when answering queries in Telegram.', 'Определяет, как бот общается с пользователями в Telegram.')}
            </p>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {PROMPT_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => setConfig({ ...config, systemPrompt: preset.prompt })}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-zinc-700 dark:text-zinc-300 hover:text-indigo-600 dark:hover:text-indigo-400 border border-zinc-200/60 dark:border-white/5 transition-all flex items-center gap-1.5"
              >
                <span>{preset.icon}</span>
                <span>{preset.title}</span>
              </button>
            ))}
          </div>
        </div>

        <textarea
          rows={4}
          value={config.systemPrompt}
          onChange={(e) => setConfig({ ...config, systemPrompt: e.target.value })}
          placeholder={t('Enter system instruction for AI...', 'Введите инструкции для ИИ...')}
          className="w-full p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all resize-y"
        />
      </div>

      {/* 5. GENERATION PARAMETERS & ACCESS CONTROL */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Sliders Box */}
        <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-6 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm space-y-4">
          <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            {t('Generation Tuning', 'Тонкая настройка')}
          </h4>

          {/* Temperature */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">{t('Temperature (Creativity)', 'Креативность (Temperature)')}</span>
              <span className="font-mono font-bold text-indigo-500">{config.temperature}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1.5"
              step="0.1"
              value={config.temperature}
              onChange={(e) => setConfig({ ...config, temperature: parseFloat(e.target.value) })}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-zinc-400">
              <span>0.0 (Точный / Строгий)</span>
              <span>0.7 (Оптимальный)</span>
              <span>1.5 (Творческий)</span>
            </div>
          </div>

          {/* Max Tokens */}
          <div className="space-y-1.5 pt-2">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">{t('Max Output Tokens', 'Лимит длины ответа (Токены)')}</span>
              <span className="font-mono font-bold text-indigo-500">{config.maxTokens}</span>
            </div>
            <input
              type="range"
              min="300"
              max="4000"
              step="100"
              value={config.maxTokens}
              onChange={(e) => setConfig({ ...config, maxTokens: parseInt(e.target.value) })}
              className="w-full accent-indigo-600 cursor-pointer"
            />
          </div>

          {/* Memory limit */}
          <div className="space-y-1.5 pt-2">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">{t('Dialogue Context Memory', 'Глубина памяти диалога')}</span>
              <span className="font-mono font-bold text-indigo-500">{config.historyLimit} {t('turns', 'сообщений')}</span>
            </div>
            <input
              type="range"
              min="2"
              max="20"
              step="2"
              value={config.historyLimit}
              onChange={(e) => setConfig({ ...config, historyLimit: parseInt(e.target.value) })}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <p className="text-[11px] text-zinc-400">
              {t('How many recent messages per chat to send to AI for contextual continuity.', 'Сколько последних реплик пользователя помнить для связного разговора.')}
            </p>
          </div>
        </div>

        {/* Access Control & Actions */}
        <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-6 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-500" />
                {t('Access Control & VIP Owner Priority', 'Контроль доступа и VIP-приоритет')}
              </h4>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center gap-1">
                <Crown className="w-3 h-3" /> VIP
              </span>
            </div>

            {/* Owner Telegram ID Section */}
            <div className="p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-800/30 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <Crown className="w-3.5 h-3.5 text-amber-500" />
                  {t('Your Telegram ID (VIP Priority)', 'Ваш Telegram ID (VIP-Приоритет)')}
                </label>
                <span className="text-[10px] font-mono text-amber-700 dark:text-amber-400 font-semibold">
                  {t('Absolute Priority', 'Наивысший приоритет')}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={config.ownerChatId || '8160231965'}
                  onChange={(e) => setConfig({ ...config, ownerChatId: e.target.value.trim() })}
                  placeholder="8160231965"
                  className="flex-1 px-3 py-1.5 rounded-xl border border-amber-300/70 dark:border-amber-700/50 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setConfig({ ...config, ownerChatId: '8160231965' })}
                  className="px-2.5 py-1.5 rounded-xl text-xs font-medium bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/50 dark:hover:bg-amber-800/60 text-amber-800 dark:text-amber-200 transition-colors shrink-0"
                >
                  8160231965
                </button>
              </div>

              <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80 leading-relaxed">
                {t(
                  'Messages from this ID bypass all limits, have doubled memory depth, priority queueing, and admin commands (/admin, /setmodel, /wipe_others).',
                  'Сообщения с этого ID обрабатываются вне очереди, имеют удвоенный контекст памяти и доступ к командам управления (/admin, /setmodel, /wipe_others).'
                )}
              </p>
            </div>

            {/* Access Mode Selector */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                {t('Bot Access Policy:', 'Политика доступа к боту:')}
              </span>

              {/* Mode 1: Owner Only */}
              <button
                type="button"
                onClick={() => setConfig({ ...config, accessMode: 'owner_only' })}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                  config.accessMode === 'owner_only'
                    ? 'bg-amber-50/70 dark:bg-amber-950/40 border-amber-500 ring-1 ring-amber-500/20'
                    : 'bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-900 dark:text-white flex items-center gap-1.5">
                      <span>{t('Only Owner (Private Mode)', 'Только Владелец (Строго Приватный)')}</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500 text-white">VIP</span>
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-snug">
                      {t('Bot only answers you. All other users are blocked and cannot use AI.', 'Бот отвечает только вам. Никто другой не сможет использовать вашего ИИ-бота.')}
                    </div>
                  </div>
                </div>
                {config.accessMode === 'owner_only' && <CheckCircle2 className="w-5 h-5 text-amber-600 shrink-0" />}
              </button>

              {/* Mode 2: Contacts Only */}
              <button
                type="button"
                onClick={() => setConfig({ ...config, accessMode: 'contacts_only' })}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                  config.accessMode === 'contacts_only'
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/20'
                    : 'bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-900 dark:text-white">
                      {t('Owner + Trusted Contacts', 'Владелец + Доверенные контакты')}
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-snug">
                      {t('Only you and contacts from your label list', 'Только вы и проверенные артисты из списка рассылки')}
                    </div>
                  </div>
                </div>
                {config.accessMode === 'contacts_only' && <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0" />}
              </button>

              {/* Mode 3: All Users */}
              <button
                type="button"
                onClick={() => setConfig({ ...config, accessMode: 'all' })}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                  config.accessMode === 'all'
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/20'
                    : 'bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center shrink-0">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-900 dark:text-white">
                      {t('All Telegram Users', 'Открыт для всех (с VIP-приоритетом)')}
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-snug">
                      {t('Anyone can chat, but your queries take top precedence', 'Любой может писать, но ваши запросы идут вне очереди')}
                    </div>
                  </div>
                </div>
                {config.accessMode === 'all' && <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0" />}
              </button>
            </div>

            {/* Unauthorized response behavior */}
            <div className="pt-2">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  {t('Action for unauthorized users:', 'Реакция на сторонних пользователей:')}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setConfig({ ...config, unauthorizedResponse: 'silent' })}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    (config.unauthorizedResponse || 'silent') === 'silent'
                      ? 'bg-zinc-800 text-white border-zinc-700 dark:bg-white dark:text-zinc-900 font-bold'
                      : 'bg-zinc-50 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800'
                  }`}
                >
                  🤫 {t('Silent (Ignore)', 'Молчаливый игнор')}
                  <div className="text-[10px] font-normal opacity-80 mt-0.5">
                    {t('0 tokens spent, bot stays quiet', '0 расхода токенов, не выдает ИИ')}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setConfig({ ...config, unauthorizedResponse: 'reject_message' })}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    config.unauthorizedResponse === 'reject_message'
                      ? 'bg-zinc-800 text-white border-zinc-700 dark:bg-white dark:text-zinc-900 font-bold'
                      : 'bg-zinc-50 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800'
                  }`}
                >
                  🔒 {t('Send Refusal Notice', 'Сообщение об отказе')}
                  <div className="text-[10px] font-normal opacity-80 mt-0.5">
                    {t('Polite notice about private mode', 'Вежливое уведомление о доступе')}
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Memory Management */}
          <div className="pt-3 border-t border-zinc-200/60 dark:border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                {t('Chat History Storage', 'Хранилище диалогов')}
              </div>
              <div className="text-[11px] text-zinc-400">
                {stats?.totalMessages || 0} {t('stored messages', 'сообщений в базе')} • {stats?.activeChats || 0} {t('dialogues', 'диалогов')}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleWipeOthers}
                disabled={isWipingOthers}
                title={t('Wipe all other users history while keeping your own', 'Удалить диалоги всех посторонних пользователей')}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-900/50 transition-all flex items-center gap-1.5"
              >
                {isWipingOthers ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <UserCheck className="w-3.5 h-3.5" />}
                {othersWiped ? t('Wiped others!', 'Чужие стерты!') : t('Wipe Others', 'Стереть чужие')}
              </button>

              <button
                type="button"
                onClick={handleClearMemory}
                disabled={isClearingMemory}
                title={t('Clear all conversation memory', 'Очистить всю базу диалогов')}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/50 transition-all flex items-center gap-1.5"
              >
                {isClearingMemory ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                {memoryCleared ? t('Cleared!', 'Очищено!') : t('Clear All', 'Сброс всех')}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 6. SAVE ACTION BUTTON */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-5 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm">
        <div className="text-xs text-zinc-500 dark:text-zinc-400">
          {t(
            'Changes take effect instantly for all incoming Telegram messages.',
            'Все изменения сохраняются в базе данных и применяются на лету.'
          )}
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {saveSuccess && (
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
              <Check className="w-4 h-4" />
              {t('Configuration saved successfully!', 'Настройки успешно сохранены!')}
            </span>
          )}

          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
          >
            {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isSaving ? t('Saving...', 'Сохранение...') : t('Save AI Bot Settings', 'Сохранить настройки ИИ')}
          </button>
        </div>
      </div>

      {/* 7. INTERACTIVE IN-PANEL API TESTER */}
      <div className="bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-xl p-6 rounded-3xl border border-zinc-200/60 dark:border-white/10 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-2">
              <Play className="w-4 h-4 text-emerald-500 fill-emerald-500" />
              {t('Live API Test Sandbox', 'Тестирование API и Промпта прямо в панели')}
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              {t(
                'Verify your custom API URL, key, model, and prompt without needing to open Telegram.',
                'Проверьте правильность URL, ключа, модели и качество ответов без перехода в Telegram.'
              )}
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <input
            type="text"
            value={testPrompt}
            onChange={(e) => setTestPrompt(e.target.value)}
            placeholder={t('Enter a test message for AI...', 'Введите проверочное сообщение для ИИ...')}
            className="flex-1 px-4 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !isTesting) handleRunTest();
            }}
          />
          <button
            type="button"
            onClick={handleRunTest}
            disabled={isTesting || !testPrompt.trim()}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 shrink-0 active:scale-95"
          >
            {isTesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            {isTesting ? t('Testing...', 'Проверка...') : t('Run API Test', 'Отправить запрос')}
          </button>
        </div>

        {/* Test Result Display */}
        {testResult && (
          <div
            className={`p-4 rounded-2xl border text-xs transition-all animate-in fade-in duration-200 ${
              testResult.success
                ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
                : 'bg-red-50/70 dark:bg-red-950/30 border-red-300 dark:border-red-800'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span
                className={`font-bold flex items-center gap-1.5 ${
                  testResult.success ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'
                }`}
              >
                {testResult.success ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                {testResult.success
                  ? t('API Responded Successfully!', 'API успешно ответил!')
                  : t('API Request Failed', 'Ошибка запроса к API')}
              </span>

              {testResult.durationMs && (
                <span className="text-[11px] font-mono text-zinc-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {testResult.durationMs} ms ({testResult.model})
                </span>
              )}
            </div>

            {testResult.success ? (
              <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl border border-emerald-200 dark:border-emerald-900/50 text-zinc-900 dark:text-zinc-100 whitespace-pre-wrap leading-relaxed shadow-xs">
                {testResult.reply}
              </div>
            ) : (
              <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 font-mono text-[11px] leading-relaxed">
                {testResult.error}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
