import React, { useState } from 'react';

export function ProxyImage({ 
  src, 
  className, 
  alt, 
  style 
}: { 
  src?: string; 
  className?: string; 
  alt?: string; 
  style?: React.CSSProperties 
}) {
  const [hasDirectError, setHasDirectError] = useState(false);

  if (!src) return null;

  let finalUrl = src;

  if (finalUrl.includes('%%')) {
    finalUrl = finalUrl.replace('%%', '600x600');
  }

  if (!finalUrl.startsWith('http') && !finalUrl.startsWith('/api') && !finalUrl.startsWith('/')) {
    finalUrl = 'https://' + finalUrl;
  }

  // Use proxy directly for avatars.yandex.net or fallback
  const proxyUrl = finalUrl.startsWith('/api') 
    ? finalUrl 
    : `/api/music/proxy-image?url=${encodeURIComponent(finalUrl)}`;

  // For fastest rendering, use proxyUrl directly with caching headers from server
  return (
    <img
      src={proxyUrl}
      className={className}
      alt={alt || ""}
      style={style}
      loading="eager"
      decoding="async"
      referrerPolicy="no-referrer"
    />
  );
}
