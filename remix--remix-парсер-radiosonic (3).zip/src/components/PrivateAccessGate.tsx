import React, { useState } from "react";
import { 
  Lock, KeyRound, ShieldCheck, Sparkles, Send, CheckCircle2, 
  AlertCircle, Loader2, ArrowRight, ExternalLink, HelpCircle,
  Eye, EyeOff, Radio, Cpu, Layers, Disc
} from "lucide-react";
import { TelegramIcon } from "./Icons";

interface Props {
  t: (en: string, ru: string) => string;
  onAccessGranted: (key: string) => void;
}

export function PrivateAccessGate({ t, onAccessGranted }: Props) {
  const [inviteKey, setInviteKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Request invite modal state
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestContact, setRequestContact] = useState("");
  const [requestGoal, setRequestGoal] = useState("");
  const [requestLoading, setRequestLoading] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(false);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanKey = inviteKey.trim().toUpperCase();
    if (!cleanKey) {
      setError(t("Please enter your invite key", "Пожалуйста, введите инвайт-код или ключ доступа"));
      return;
    }

    setLoading(true);
    setError("");

    try {
      // Server validation check
      const res = await fetch("/api/auth/private-access/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inviteKey: cleanKey })
      });
      const data = await res.json();

      if (data.success) {
        setSuccess(true);
        // Persist both in localStorage and long-lived cookies (365 days)
        try {
          localStorage.setItem("private_circle_auth", "true");
          localStorage.setItem("private_circle_key", cleanKey);
          if (cleanKey === "8981404137") {
            localStorage.setItem('owner_tg_id', "8981404137");
            localStorage.setItem('adminTgId', "8981404137");
          }
          document.cookie = `private_circle_auth=true; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
          document.cookie = `private_circle_key=${encodeURIComponent(cleanKey)}; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
          if (data?.sessionId) {
            document.cookie = `private_circle_session=${encodeURIComponent(data.sessionId)}; path=/; max-age=${365 * 24 * 3600}; SameSite=Lax`;
          }
        } catch (e) {}

        setTimeout(() => {
          onAccessGranted(cleanKey);
        }, 500);
      } else {
        setError(data.error || t("Invalid or expired invite key. Contact administrator for access.", "Неверный или недействительный инвайт-код. Свяжитесь с администратором для получения доступа."));
      }
    } catch (e) {
      setError(t("Failed to verify key. Please try again.", "Не удалось проверить ключ. Пожалуйста, попробуйте снова."));
    } finally {
      setLoading(false);
    }
  };

  const handleSendInviteRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestContact.trim()) return;

    setRequestLoading(true);
    try {
      await fetch("/api/auth/private-access/request-invite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contact: requestContact.trim(),
          goal: requestGoal.trim(),
          note: requestGoal.trim()
        })
      });
      setRequestSuccess(true);
    } catch (err) {
      // Even if offline/network fails, show success confirmation
      setRequestSuccess(true);
    } finally {
      setRequestLoading(false);
    }
  };

  return (
    <div className="relative min-h-[640px] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-gradient-to-tr from-amber-500/10 via-orange-500/10 to-indigo-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="w-full max-w-xl bg-white/95 dark:bg-[#131316]/95 border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl transition-all">
        {/* Top Header Badge */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-zinc-100 dark:border-white/5">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
            <span className="text-xs font-bold tracking-wider uppercase text-amber-600 dark:text-amber-400">
              {t("Private Access • Closed Circle", "Закрытый доступ • Ограниченный круг")}
            </span>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-white/5 text-zinc-500">
            v3.8-CORE
          </span>
        </div>

        {/* Lock Icon */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/15 to-orange-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500 dark:text-amber-400 mb-6 shadow-inner mx-auto">
          <Lock className="w-8 h-8" />
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-center text-zinc-900 dark:text-white tracking-tight mb-3">
          {t("Private Access • Closed Circle", "Вход в закрытый круг")}
        </h2>

        <p className="text-sm text-center text-zinc-600 dark:text-zinc-400 leading-relaxed mb-6 max-w-md mx-auto">
          {t(
            "Access to the parser and all tools is restricted and available only to our private circle of sound producers, labels, and verified partners.",
            "Функционал парсера и всех инструментов закрыт для публичного доступа и используется исключительно для закрытых кругов общения, саунд-продюсеров и закрытых лейблов."
          )}
        </p>

        {/* 9 Modules Protected List */}
        <div className="mb-6 p-3 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-200/60 dark:border-white/5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-2 px-1 flex items-center justify-between">
            <span>{t("Protected modules (9 tools)", "Защищённые модули (9 инструментов)")}:</span>
            <span className="text-amber-500 font-mono">ALL LOCKED</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 text-xs text-zinc-700 dark:text-zinc-300">
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Парсер OK.RU (CDP)
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Моя Волна
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Поиск
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Отчёт
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Логи
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> История
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Создатель
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Нейминг
            </span>
            <span className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/70 dark:bg-white/5 border border-zinc-200/50 dark:border-white/5">
              <Lock className="w-3 h-3 text-amber-500 shrink-0" /> Конвертер (WAV)
            </span>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 rounded-2xl flex items-start gap-3 text-sm animate-shake">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center gap-3 text-sm animate-pulse">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{t("Access granted! Opening core parser...", "Доступ подтверждён! Открываем ядро парсера...")}</span>
          </div>
        )}

        {/* Input Invite Form */}
        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-2">
              {t("Private Invite Code or Key", "Инвайт-код или ключ доступа")}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <KeyRound className="w-5 h-5" />
              </div>
              <input
                type={showKey ? "text" : "password"}
                required
                value={inviteKey}
                onChange={(e) => {
                  setInviteKey(e.target.value);
                  setError("");
                }}
                placeholder="Введите инвайт-код или ключ доступа"
                className="w-full pl-11 pr-11 py-3.5 bg-zinc-50 dark:bg-black/40 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-zinc-900 dark:text-white placeholder-zinc-400 font-mono text-base tracking-wider focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all uppercase"
                autoComplete="off"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-500 mt-1.5 flex items-center gap-1">
              <span>Поддерживаются инвайты закрытого круга и персональные ключи доступа</span>
            </p>
          </div>

          <button
            type="submit"
            disabled={loading || !inviteKey.trim()}
            className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 active:scale-[0.98] text-white rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <ShieldCheck className="w-5 h-5" />
                <span>{t("Activate Access & Enter", "Активировать доступ и войти")}</span>
              </>
            )}
          </button>
        </form>

        {/* Closed Circle Features Teaser */}
        <div className="mt-8 pt-6 border-t border-zinc-100 dark:border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/50 dark:border-white/5">
            <div className="flex items-center gap-2 mb-1">
              <Disc className="w-4 h-4 text-amber-500" />
              <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">ISRC & OK.RU Copyright</span>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              Глубокое извлечение закрытых метаданных, владельцев прав и дистрибьюторов.
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/50 dark:border-white/5">
            <div className="flex items-center gap-2 mb-1">
              <Layers className="w-4 h-4 text-amber-500" />
              <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">3000x3000px & WAV</span>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              Оригинальные студийные обложки без сжатия и прямой lossless-поток.
            </p>
          </div>
        </div>

        {/* Telegram Request CTA */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-500 dark:text-zinc-400 bg-amber-500/5 border border-amber-500/15 p-4 rounded-2xl">
          <div className="flex items-center gap-2.5 text-left">
            <TelegramIcon className="w-5 h-5 text-[#2AABEE] shrink-0" />
            <span>
              {t("Don't have an invite key?", "Нет ключа или хотите попасть в закрытый круг?")}
            </span>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href="https://t.me/Tester_V3?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%A5%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0%B8%D0%BD%D0%B2%D0%B0%D0%B9%D1%82-%D0%BA%D0%BE%D0%B4%20%D0%B4%D0%BB%D1%8F%20%D0%B2%D1%85%D0%BE%D0%B4%D0%B0%20%D0%B2%20%D0%B7%D0%B0%D0%BA%D1%80%D1%8B%D1%82%D1%8B%D0%B9%20%D0%BF%D0%B0%D1%80%D1%81%D0%B5%D1%80%20%D1%80%D0%B5%D0%BB%D0%B8%D0%B7%D0%BE%D0%B2."
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-4 py-2 bg-[#2AABEE] hover:bg-[#229ED9] text-white rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
            >
              <span>Запросить у @Tester_V3</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setShowRequestModal(true)}
              className="px-3 py-2 bg-zinc-200/80 dark:bg-white/10 hover:bg-zinc-300 dark:hover:bg-white/20 text-zinc-700 dark:text-zinc-200 rounded-xl font-medium transition-all text-center"
              title="Отправить заявку"
            >
              Заявка
            </button>
          </div>
        </div>
      </div>

      {/* Quick Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#1c1c1e] rounded-3xl p-6 border border-zinc-200 dark:border-white/10 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => {
                setShowRequestModal(false);
                setRequestSuccess(false);
              }}
              className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-1"
            >
              ✕
            </button>

            <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2">
              Заявка на доступ в закрытый круг
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-6 leading-relaxed">
              Укажите контакт для связи (Telegram, ник или почту) и цель использования. Заявка поступит администратору.
            </p>

            {requestSuccess ? (
              <div className="p-5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-9 h-9 mx-auto text-emerald-500" />
                <p className="font-semibold text-base">Заявка успешно отправлена!</p>
                <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  Уведомление отправлено администратору в Telegram-бот с пометкой <span className="font-mono font-bold text-zinc-800 dark:text-zinc-200">«Заявка или доступ в систему»</span>. Мы свяжемся с вами в ближайшее время!
                </p>
                <div className="pt-2">
                  <a
                    href="https://t.me/Tester_V3"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs text-[#2AABEE] hover:underline font-semibold"
                  >
                    <span>Или напишите напрямую: @Tester_V3</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <button
                  onClick={() => {
                    setShowRequestModal(false);
                    setRequestSuccess(false);
                  }}
                  className="mt-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-all"
                >
                  Понятно
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendInviteRequest} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Контакт для связи (Telegram, ник или почту) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={requestContact}
                    onChange={(e) => setRequestContact(e.target.value)}
                    placeholder="@username, никнейм или почта"
                    className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-black/50 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all placeholder:text-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Цель использования <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={requestGoal}
                    onChange={(e) => setRequestGoal(e.target.value)}
                    placeholder="Опишите цель использования (например: артист, лейбл, работа с релизами, звукорежиссура)..."
                    className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-black/50 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all placeholder:text-zinc-400"
                  />
                </div>
                <div className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>После одобрения вход будет автоматически сохранён на этом устройстве</span>
                </div>
                <button
                  type="submit"
                  disabled={requestLoading || !requestContact.trim() || !requestGoal.trim()}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-500/20 disabled:opacity-50 active:scale-[0.99]"
                >
                  {requestLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Отправить заявку"}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
