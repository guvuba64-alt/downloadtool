import React, { useState, useEffect } from 'react';
import { X, Check, Copy, RefreshCw, AlertCircle, Globe, LogOut, Server, Save } from 'lucide-react';
import { OkRuIcon } from './Icons';
import { safeParseResponse } from '../utils/safeFetch';

interface OkRuAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  t: (en: string, ru: string) => string;
}

export const OkRuAuthModal: React.FC<OkRuAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  t,
}) => {
  const [loginMode, setLoginMode] = useState<'cookie' | 'password' | 'proxy'>('cookie');
  
  // Auth state
  const [okRuLogin, setOkRuLogin] = useState('');
  const [okRuPassword, setOkRuPassword] = useState('');
  const [okRuCookieString, setOkRuCookieString] = useState('');

  // Status & loading
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);

  // Proxy state
  const [okRuProxyUrl, setOkRuProxyUrl] = useState('');
  const [okRuProxyEnabled, setOkRuProxyEnabled] = useState(false);
  const [isTestingProxy, setIsTestingProxy] = useState(false);
  const [isSavingProxy, setIsSavingProxy] = useState(false);
  const [proxyTestResult, setProxyTestResult] = useState<{ success: boolean; message: string; ip?: string; latencyMs?: number; country?: string; okAccess?: boolean } | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkStatus();
      loadProxySettings();
      setErrorMessage(null);
      setSuccessMessage(null);
      try {
        const saved = localStorage.getItem('okru_cookies');
        if (saved && !okRuCookieString) {
          setOkRuCookieString(saved);
        }
      } catch (e) {}
    }
  }, [isOpen]);

  const checkStatus = async () => {
    try {
      const res = await fetch('/api/okru/status');
      const data = await safeParseResponse(res);
      if (data && data.hasSession) {
        setIsConnected(true);
        const name = typeof data.user === 'string' ? data.user : (data.user?.name || 'Пользователь OK.ru');
        setUserName(name);
      } else {
        setIsConnected(false);
        setUserName(null);
      }
    } catch (e) {
      // Don't disconnect on transient network glitch
    }
  };

  const loadProxySettings = async () => {
    try {
      const res = await fetch('/api/okru/proxy');
      const data = await safeParseResponse(res);
      if (data) {
        setOkRuProxyEnabled(Boolean(data.enabled));
        setOkRuProxyUrl(data.proxyUrl || '');
      }
    } catch (e) {}
  };

  const copyConsoleScript = () => {
    const script = `(() => {
  const code = (document.cookie.match(/AUTHCODE=([^;]+)/) || [])[1] || '';
  if (code) {
    copy(code);
    alert('✅ AUTHCODE скопирован в буфер обмена: ' + code);
  } else {
    prompt('Скопируйте куки или значение AUTHCODE из вкладки Application -> Cookies:', document.cookie || 'AUTHCODE');
  }
})();`;
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 3000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const payload: any = loginMode === 'cookie'
        ? { cookieString: okRuCookieString.trim() }
        : { login: okRuLogin.trim(), password: okRuPassword };

      const res = await fetch('/api/okru/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await safeParseResponse(res);
      if (res.ok && (data.success || data.valid)) {
        setIsConnected(true);
        const name = typeof data.user === 'string' ? data.user : (data.user?.name || 'Пользователь OK.ru');
        setUserName(name);
        if (loginMode === 'cookie' && okRuCookieString.trim()) {
          try { localStorage.setItem('okru_cookies', okRuCookieString.trim()); } catch(e) {}
        }
        setSuccessMessage(t('Successfully authorized in OK.ru! Cookies saved persistently.', 'Успешная авторизация в OK.ru! Сессия сохранена.'));
        if (onSuccess) onSuccess();
      } else {
        setErrorMessage(data.error || t('Authorization failed', 'Ошибка авторизации в OK.ru'));
      }
    } catch (err: any) {
      setErrorMessage(err.message || t('Connection error', 'Ошибка соединения с сервером'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      const res = await fetch('/api/okru/disconnect', { method: 'POST' });
      await safeParseResponse(res).catch(() => {});
      try { localStorage.removeItem('okru_cookies'); } catch(e) {}
      setIsConnected(false);
      setUserName(null);
      setSuccessMessage(t('Disconnected from OK.ru', 'Вы вышли из аккаунта OK.ru'));
      if (onSuccess) onSuccess();
    } catch (e: any) {
      setErrorMessage(e.message);
    }
  };

  const handleTestProxy = async () => {
    if (!okRuProxyUrl.trim()) return;
    setIsTestingProxy(true);
    setProxyTestResult(null);
    try {
      const res = await fetch('/api/okru/proxy/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxyUrl: okRuProxyUrl.trim() }),
      });
      const data = await safeParseResponse(res);
      setProxyTestResult(data);
    } catch (e: any) {
      setProxyTestResult({ success: false, message: e.message });
    } finally {
      setIsTestingProxy(false);
    }
  };

  const handleSaveProxy = async () => {
    setIsSavingProxy(true);
    try {
      const res = await fetch('/api/okru/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: okRuProxyEnabled, proxyUrl: okRuProxyUrl.trim() }),
      });
      const data = await safeParseResponse(res);
      if (data.success) {
        setSuccessMessage(t('Proxy settings saved', 'Настройки прокси сохранены'));
      }
    } catch (e: any) {
      setErrorMessage(e.message);
    } finally {
      setIsSavingProxy(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white dark:bg-[#18181b] border border-zinc-200/80 dark:border-white/10 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-zinc-100 dark:border-white/5 flex items-center justify-between bg-zinc-50/50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#EE8208] text-white flex items-center justify-center shadow-md shadow-[#EE8208]/25">
              <OkRuIcon className="w-6 h-6 fill-current" />
            </div>
            <div>
              <h3 className="font-bold text-base text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
                <span>{t('OK.ru Authorization', 'Авторизация OK.ru (Одноклассники)')}</span>
                {isConnected && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    {t('Active', 'Активна')}
                  </span>
                )}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {t('Connect account to access OK.ru music & metadata', 'Подключение для поиска музыки и проверки правообладателей')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-white/5 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Alerts */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 rounded-2xl text-xs text-rose-600 dark:text-rose-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-2xl text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
              <Check className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Active User Card if connected */}
          {isConnected && (
            <div className="p-4 bg-orange-50/70 dark:bg-[#EE8208]/10 border border-[#EE8208]/20 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#EE8208] text-white flex items-center justify-center font-bold text-lg shadow-sm">
                  <OkRuIcon className="w-6 h-6 fill-current" />
                </div>
                <div>
                  <div className="font-bold text-sm text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
                    <span>{userName || 'OK.ru Session'}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#EE8208]/15 text-[#EE8208] dark:text-orange-300">
                      AUTHCODE
                    </span>
                  </div>
                  <div className="text-xs text-zinc-500 dark:text-zinc-400">
                    {t('Authorized and operational', 'Сессия активна и готова к поиску')}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDisconnect}
                className="p-2 text-zinc-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-colors"
                title={t('Disconnect account', 'Выйти из аккаунта')}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Tabs */}
          <div className="flex bg-zinc-100 dark:bg-zinc-800/70 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => setLoginMode('cookie')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all ${
                loginMode === 'cookie'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {t('Cookie / Session', 'Cookie / Сессия')}
            </button>
            <button
              type="button"
              onClick={() => setLoginMode('password')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all ${
                loginMode === 'password'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {t('Login & Password', 'Логин / Пароль')}
            </button>
            <button
              type="button"
              onClick={() => setLoginMode('proxy')}
              className={`flex-1 text-xs font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1 ${
                loginMode === 'proxy'
                  ? 'bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100 font-bold'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              <Globe className="w-3 h-3" />
              {t('Proxy', 'Прокси')}
              {okRuProxyEnabled && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
            </button>
          </div>

          {/* TAB 1: COOKIE */}
          {loginMode === 'cookie' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-4 bg-orange-50/80 dark:bg-orange-500/10 border border-orange-200 dark:border-orange-500/20 rounded-2xl text-xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-orange-950 dark:text-orange-200 flex items-center gap-1.5">
                    ⚡ {t('1-Click Express Bypass (ok.ru):', '⚡ Быстрый вход через куки (в 1 клик):')}
                  </span>
                  <button
                    type="button"
                    onClick={copyConsoleScript}
                    className="px-2.5 py-1 bg-[#EE8208] hover:bg-[#d87405] text-white rounded-lg font-bold text-[11px] transition-all flex items-center gap-1 shadow-sm"
                  >
                    {copiedScript ? (
                      <>
                        <Check className="w-3 h-3 text-white" />
                        {t('Copied!', 'Скопировано!')}
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        {t('Copy Script', 'Скопировать скрипт')}
                      </>
                    )}
                  </button>
                </div>
                <div className="text-[11px] text-orange-900/90 dark:text-orange-300 leading-relaxed space-y-1">
                  <div><strong>1. В 1 клик (DevTools Network):</strong> Нажмите F12 на сайте ok.ru ➔ вкладка «Сеть» (Network) ➔ кликните по любому запросу ➔ скопируйте заголовок <code className="font-mono bg-orange-200/50 dark:bg-orange-950/50 px-1 py-0.5 rounded">Cookie</code> (или ПКМ ➔ Copy as cURL) и вставьте ниже.</div>
                  <div><strong>2. Токен AUTHCODE:</strong> F12 ➔ вкладка «Application» (Приложение) ➔ Cookies ➔ ok.ru ➔ скопируйте значение <code className="font-mono bg-orange-200/50 dark:bg-orange-950/50 px-1 py-0.5 rounded">AUTHCODE</code>.</div>
                  <div><strong>3. Через расширение:</strong> Экспорт JSON из Cookie-Editor или EditThisCookie.</div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 uppercase tracking-wider">
                  {t('Cookie string, JSON or AUTHCODE token', 'Строка Cookie, JSON или токен AUTHCODE')}
                </label>
                <textarea
                  rows={4}
                  value={okRuCookieString}
                  onChange={(e) => setOkRuCookieString(e.target.value)}
                  placeholder="AUTHCODE=...; or [ { name: 'AUTHCODE', ... } ]"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-3 text-xs focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || !okRuCookieString.trim()}
                className="w-full bg-[#EE8208] hover:bg-[#d87405] text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md shadow-[#EE8208]/25 flex items-center justify-center gap-2 text-xs disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <OkRuIcon className="w-4 h-4 fill-current" />}
                <span>{isLoading ? t('Verifying session...', 'Проверка куки OK.ru...') : t('Save and Authorize', 'Сохранить и войти')}</span>
              </button>
            </form>
          )}

          {/* TAB 2: PASSWORD */}
          {loginMode === 'password' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-3 bg-zinc-50 dark:bg-white/5 border border-zinc-200/60 dark:border-white/10 rounded-2xl text-xs text-zinc-600 dark:text-zinc-400">
                {t(
                  'Direct login uses automated mobile authorization. If OK.ru prompts for SMS/Captcha due to cloud server IP, please configure a proxy in the Proxy tab or use the 1-Click Cookie tab.',
                  'Прямой вход использует защищенную мобильную авторизацию. Если OK.ru блокирует серверный IP, настройте прокси во вкладке «Прокси» или используйте вкладку «Cookie».'
                )}
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                  {t('Phone, Email or Login', 'Телефон, Email или Логин')}
                </label>
                <input
                  type="text"
                  value={okRuLogin}
                  onChange={(e) => setOkRuLogin(e.target.value)}
                  placeholder="+79991234567"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                  {t('Password', 'Пароль')}
                </label>
                <input
                  type="password"
                  value={okRuPassword}
                  onChange={(e) => setOkRuPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-zinc-900 dark:text-zinc-50 bg-zinc-100/50 dark:bg-white/5 border border-zinc-200/50 dark:border-white/10 focus:bg-white dark:focus:bg-[#1c1c1e] rounded-2xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#EE8208] hover:bg-[#d87405] text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md shadow-[#EE8208]/25 flex items-center justify-center gap-2 text-xs disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <OkRuIcon className="w-4 h-4 fill-current" />}
                <span>{isLoading ? t('Signing in...', 'Вход в OK.ru...') : t('Sign In', 'Войти')}</span>
              </button>
            </form>
          )}

          {/* TAB 3: PROXY */}
          {loginMode === 'proxy' && (
            <div className="space-y-4">
              <div className="p-4 bg-zinc-50 dark:bg-white/5 border border-zinc-200/70 dark:border-white/10 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5 text-[#EE8208]" />
                      {t('Use Proxy for OK.ru', 'Использовать прокси для OK.ru')}
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      {t('Routes login, search & parsing via proxy IP', 'Маршрутизирует вход и поиск через прокси-сервер')}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOkRuProxyEnabled(!okRuProxyEnabled)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      okRuProxyEnabled ? 'bg-[#EE8208]' : 'bg-zinc-300 dark:bg-zinc-700'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        okRuProxyEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                    {t('Proxy Address (HTTP / SOCKS5)', 'Адрес прокси')}
                  </label>
                  <input
                    type="text"
                    value={okRuProxyUrl}
                    onChange={(e) => setOkRuProxyUrl(e.target.value)}
                    placeholder="http://login:pass@ip:port или ip:port"
                    className="w-full text-zinc-900 dark:text-zinc-50 bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-orange-500 outline-none font-mono"
                  />
                </div>

                {proxyTestResult && (
                  <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    proxyTestResult.success 
                      ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                      : 'bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20'
                  }`}>
                    {proxyTestResult.success ? <Check className="w-4 h-4 text-emerald-500" /> : <AlertCircle className="w-4 h-4 text-rose-500" />}
                    <span>{proxyTestResult.message || (proxyTestResult.success ? `Онлайн (${proxyTestResult.latencyMs}ms)` : 'Ошибка')}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={handleTestProxy}
                  disabled={isTestingProxy || !okRuProxyUrl.trim()}
                  className="flex-1 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingProxy ? 'animate-spin text-[#EE8208]' : ''}`} />
                  {isTestingProxy ? t('Testing...', 'Проверка...') : t('Test Connection', 'Проверить связь')}
                </button>
                <button
                  type="button"
                  onClick={handleSaveProxy}
                  disabled={isSavingProxy}
                  className="flex-1 bg-[#EE8208] hover:bg-[#d87405] text-white font-semibold py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs shadow-sm disabled:opacity-50"
                >
                  {isSavingProxy ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  {isSavingProxy ? t('Saving...', 'Сохранение...') : t('Save Proxy', 'Сохранить прокси')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
