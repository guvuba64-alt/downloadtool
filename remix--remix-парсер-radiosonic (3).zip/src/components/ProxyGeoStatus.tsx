import React, { useState, useEffect, useCallback } from 'react';
import { 
  Globe, MapPin, Wifi, RefreshCw, Copy, Check, ShieldCheck, 
  AlertCircle, Server, Activity, ArrowUpRight, Zap
} from 'lucide-react';

export interface ProxyGeoData {
  success?: boolean;
  isProxy?: boolean;
  ip?: string;
  country?: string;
  countryCode?: string;
  countryFlag?: string;
  city?: string;
  region?: string;
  isp?: string;
  latencyMs?: number;
  message?: string;
  okAccess?: boolean;
}

export interface ProxyGeoStatusProps {
  /** Optional pre-fetched or parent-controlled proxy test result */
  geoData?: ProxyGeoData | null;
  /** Optional custom proxy URL string to test */
  proxyUrl?: string;
  /** Whether the proxy is currently enabled */
  proxyEnabled?: boolean;
  /** Callback when health test finishes */
  onTestComplete?: (result: ProxyGeoData) => void;
  /** Translation function */
  t?: (en: string, ru: string) => string;
  /** Compact or full card layout */
  variant?: 'card' | 'compact' | 'badge';
  /** Optional custom CSS classes */
  className?: string;
  /** Auto-fetch on mount (default true if geoData not supplied) */
  autoFetch?: boolean;
}

export const ProxyGeoStatus: React.FC<ProxyGeoStatusProps> = ({
  geoData: initialGeoData,
  proxyUrl,
  proxyEnabled,
  onTestComplete,
  t = (en, ru) => ru || en,
  variant = 'card',
  className = '',
  autoFetch = true,
}) => {
  const [data, setData] = useState<ProxyGeoData | null>(initialGeoData || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(initialGeoData ? new Date() : null);

  // Synchronize when external geoData changes
  useEffect(() => {
    if (initialGeoData) {
      setData(initialGeoData);
      setLastChecked(new Date());
      setError(initialGeoData.success === false ? (initialGeoData.message || 'Ошибка проверки') : null);
    }
  }, [initialGeoData]);

  // Trigger health check & geolocation fetch
  const triggerHealthCheck = useCallback(async () => {
    setLoading(true);
    setError(null);
    const startTime = Date.now();

    try {
      let endpoint = '/api/proxy/geo';
      let options: RequestInit = { method: 'GET' };

      // If a specific proxy URL is supplied and we want to test that specific URL
      if (proxyUrl && proxyUrl.trim()) {
        endpoint = '/api/okru/proxy/test';
        options = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ proxyUrl: proxyUrl.trim() }),
        };
      }

      const res = await fetch(endpoint, options);
      const resData = await res.json();

      const result: ProxyGeoData = {
        success: resData.success !== false,
        isProxy: resData.isProxy ?? Boolean(proxyUrl || proxyEnabled),
        ip: resData.ip,
        country: resData.country,
        countryCode: resData.countryCode,
        countryFlag: resData.countryFlag || '🌐',
        city: resData.city,
        region: resData.region,
        isp: resData.isp,
        latencyMs: resData.latencyMs ?? (Date.now() - startTime),
        message: resData.message,
        okAccess: resData.okAccess,
      };

      if (resData.success === false && !resData.ip) {
        setError(resData.message || t('Proxy check failed', 'Не удалось проверить прокси'));
      } else {
        setData(result);
        setError(null);
      }

      setLastChecked(new Date());
      if (onTestComplete) {
        onTestComplete(result);
      }
    } catch (e: any) {
      const errMessage = e?.message || t('Network check error', 'Ошибка сетевой проверки');
      setError(errMessage);
      const failResult: ProxyGeoData = {
        success: false,
        isProxy: Boolean(proxyUrl || proxyEnabled),
        latencyMs: Date.now() - startTime,
        message: errMessage,
      };
      setData(failResult);
      if (onTestComplete) {
        onTestComplete(failResult);
      }
    } finally {
      setLoading(false);
    }
  }, [proxyUrl, proxyEnabled, onTestComplete, t]);

  // Initial trigger if autoFetch is on and no initial data
  useEffect(() => {
    if (autoFetch && !initialGeoData) {
      triggerHealthCheck();
    }
  }, [autoFetch, triggerHealthCheck]);

  const handleCopyIp = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!data?.ip) return;
    navigator.clipboard.writeText(data.ip);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getLatencyColor = (latency?: number) => {
    if (latency === undefined) return 'text-zinc-400';
    if (latency < 250) return 'text-emerald-500 dark:text-emerald-400';
    if (latency < 650) return 'text-amber-500 dark:text-amber-400';
    return 'text-rose-500 dark:text-rose-400';
  };

  const getLatencyBadgeBg = (latency?: number) => {
    if (latency === undefined) return 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400';
    if (latency < 250) return 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-200/80 dark:border-emerald-500/20';
    if (latency < 650) return 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-200/80 dark:border-amber-500/20';
    return 'bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-200/80 dark:border-rose-500/20';
  };

  // Badge layout (minimal inline)
  if (variant === 'badge') {
    return (
      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-xs ${className}`}>
        {loading ? (
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-500" />
        ) : data?.countryFlag ? (
          <span className="text-sm select-none">{data.countryFlag}</span>
        ) : (
          <Globe className="w-3.5 h-3.5 text-zinc-400" />
        )}
        <span className="font-semibold text-zinc-900 dark:text-zinc-100">
          {data?.city ? `${data.city}, ` : ''}{data?.country || data?.countryCode || t('Direct', 'Прямое')}
        </span>
        {data?.ip && (
          <span className="font-mono text-[10px] text-zinc-500 dark:text-zinc-400">({data.ip})</span>
        )}
        <button
          type="button"
          onClick={triggerHealthCheck}
          disabled={loading}
          className="ml-1 p-0.5 rounded hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-600 transition-colors"
          title={t('Re-check location', 'Перепроверить локацию')}
        >
          <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>
    );
  }

  // Compact layout
  if (variant === 'compact') {
    return (
      <div className={`p-3 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/80 dark:border-white/10 flex items-center justify-between gap-3 ${className}`}>
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200/60 dark:border-white/10 flex items-center justify-center text-lg shadow-sm shrink-0 select-none">
            {loading ? <RefreshCw className="w-4 h-4 animate-spin text-blue-500" /> : (data?.countryFlag || '🌐')}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate">
              <span>{data?.country || t('Determining location...', 'Определение локации...')}</span>
              {data?.countryCode && (
                <span className="px-1 py-0.2 rounded text-[10px] font-mono bg-zinc-200/80 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300">
                  {data.countryCode}
                </span>
              )}
            </div>
            <div className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 truncate flex items-center gap-1">
              <span>{data?.ip || '...'}</span>
              {data?.ip && (
                <button
                  type="button"
                  onClick={handleCopyIp}
                  className="hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors"
                  title={t('Copy IP', 'Скопировать IP')}
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3 opacity-60" />}
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {data?.latencyMs !== undefined && (
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getLatencyBadgeBg(data.latencyMs)}`}>
              {data.latencyMs} ms
            </span>
          )}
          <button
            type="button"
            onClick={triggerHealthCheck}
            disabled={loading}
            className="p-1.5 rounded-xl hover:bg-zinc-200/80 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
            title={t('Refresh proxy diagnostics', 'Обновить диагностику')}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>
    );
  }

  // Full Card layout (default)
  return (
    <div className={`p-4 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 shadow-sm space-y-3.5 transition-all ${className}`}>
      
      {/* Top Header Row */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-400 flex items-center justify-center shadow-inner shrink-0">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
              <span>{t('Outgoing IP & Geolocation', 'Исходящий IP и Геолокация')}</span>
              {data?.isProxy ? (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold uppercase bg-orange-100 dark:bg-orange-500/20 text-orange-700 dark:text-orange-300">
                  Proxy
                </span>
              ) : (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold uppercase bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                  Direct
                </span>
              )}
            </div>
            <div className="text-[10px] text-zinc-500 dark:text-zinc-400">
              {lastChecked 
                ? `${t('Last tested', 'Проверено')}: ${lastChecked.toLocaleTimeString()}`
                : t('Live proxy health status', 'Диагностика сетевого узла')}
            </div>
          </div>
        </div>

        {/* Trigger Button */}
        <button
          type="button"
          onClick={triggerHealthCheck}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-zinc-100 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-white/20 transition-all disabled:opacity-50 shadow-sm"
          title={t('Run health check now', 'Запустить проверку сети')}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-orange-500' : ''}`} />
          <span>{loading ? t('Checking...', 'Проверка...') : t('Check', 'Проверить')}</span>
        </button>
      </div>

      {/* Main Geolocation Display Card */}
      {error && !data?.ip ? (
        <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200/80 dark:border-rose-500/20 flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300">
          <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
          <div className="flex-1 leading-relaxed">
            <div className="font-semibold">{t('Proxy Health Check Failed', 'Ошибка проверки прокси')}</div>
            <div className="text-[11px] opacity-90">{error}</div>
          </div>
        </div>
      ) : (
        <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200/60 dark:border-white/5 space-y-3">
          
          {/* Flag + Country + City + IP */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200/80 dark:border-white/10 flex items-center justify-center text-2xl shadow-sm shrink-0 select-none">
                {loading ? (
                  <RefreshCw className="w-5 h-5 animate-spin text-orange-500" />
                ) : (
                  data?.countryFlag || '🌐'
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">
                    {data?.country || (loading ? t('Detecting country...', 'Определение страны...') : t('Unknown Location', 'Неизвестная локация'))}
                  </span>
                  {data?.countryCode && (
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-zinc-200/90 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                      {data.countryCode}
                    </span>
                  )}
                </div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400 truncate flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-orange-500 shrink-0" />
                  <span>
                    {[data?.city, data?.region].filter(Boolean).join(', ') || t('Region detected', 'Регион определен')}
                  </span>
                </div>
              </div>
            </div>

            {/* Outgoing IP Pill */}
            <div className="text-right shrink-0">
              <div className="text-[10px] uppercase font-semibold text-zinc-400 dark:text-zinc-500 tracking-wider">
                {t('Outgoing IP', 'Исходящий IP')}
              </div>
              <div className="inline-flex items-center gap-1.5 mt-0.5">
                <span className="font-mono font-bold text-xs text-zinc-900 dark:text-zinc-100">
                  {data?.ip || (loading ? '...' : '—')}
                </span>
                {data?.ip && (
                  <button
                    type="button"
                    onClick={handleCopyIp}
                    className="p-1 rounded-md hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
                    title={t('Copy IP address', 'Скопировать IP')}
                  >
                    {copied ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Details Row: ISP & Latency Gauge */}
          <div className="pt-2 border-t border-zinc-200/50 dark:border-white/5 flex flex-wrap items-center justify-between gap-2 text-xs">
            {data?.isp && (
              <div className="text-zinc-500 dark:text-zinc-400 text-[11px] truncate max-w-[200px]">
                <span className="font-medium text-zinc-700 dark:text-zinc-300">ISP:</span> {data.isp}
              </div>
            )}
            
            <div className="flex items-center gap-2 ml-auto">
              {data?.latencyMs !== undefined && (
                <div className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-bold ${getLatencyBadgeBg(data.latencyMs)}`}>
                  <Zap className="w-3 h-3" />
                  <span>{data.latencyMs} ms</span>
                </div>
              )}

              {data?.okAccess !== undefined && (
                <div className="flex items-center gap-1 text-[11px] font-medium text-zinc-600 dark:text-zinc-300">
                  <span className={`w-2 h-2 rounded-full ${data.okAccess ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  <span>{data.okAccess ? t('OK.ru Reachable', 'OK.ru доступен') : t('Web Connected', 'Интернет доступен')}</span>
                </div>
              )}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
