import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  FileAudio, 
  Settings, 
  Loader2, 
  ArrowRight, 
  Download, 
  Music, 
  AlertCircle, 
  ImageIcon, 
  Maximize2, 
  Sparkles, 
  Check, 
  RotateCcw,
  Sliders,
  Crop,
  Lock,
  Unlock,
  Layers,
  Film
} from 'lucide-react';

interface ConverterTabProps {
  t: (key: string, ru: string) => string;
}

type ConverterMode = 'audio' | 'image';
type SampleRateOption = '44.1' | '44.8' | '48' | '96' | 'custom';
type ImagePreset = '1000' | '3000' | '6000' | 'custom';
type FitMode = 'proportional' | 'blur' | 'contain' | 'cover';
type ImageFormat = 'jpg' | 'png' | 'webp';

export function ConverterTab({ t }: ConverterTabProps) {
  const [mode, setMode] = useState<ConverterMode>('audio');

  // --- AUDIO STATE ---
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [sampleRate, setSampleRate] = useState<SampleRateOption>('44.1');
  const [customSampleRate, setCustomSampleRate] = useState<string>('44100');
  const [bitDepth, setBitDepth] = useState<'16' | '24'>('16');
  const [channels, setChannels] = useState<'2' | '1'>('2');
  const [isAudioConverting, setIsAudioConverting] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [audioProgress, setAudioProgress] = useState(0);
  const audioInputRef = useRef<HTMLInputElement>(null);

  // --- IMAGE STATE ---
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const [origDimensions, setOrigDimensions] = useState<{ width: number; height: number } | null>(null);
  const [targetWidth, setTargetWidth] = useState<number>(3000);
  const [targetHeight, setTargetHeight] = useState<number>(3000);
  const [lockAspect, setLockAspect] = useState<boolean>(true);
  const [activePreset, setActivePreset] = useState<ImagePreset>('3000');
  const [fitMode, setFitMode] = useState<FitMode>('proportional');
  const [imageFormat, setImageFormat] = useState<ImageFormat>('jpg');
  const [imageQuality, setImageQuality] = useState<number>(95);
  const [isImageProcessing, setIsImageProcessing] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [imageSuccess, setImageSuccess] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Cleanup image preview URL on unmount
  useEffect(() => {
    return () => {
      if (imagePreviewUrl) {
        URL.revokeObjectURL(imagePreviewUrl);
      }
    };
  }, [imagePreviewUrl]);

  // Handle image selection
  const handleImageSelect = (file: File) => {
    if (!file.type.startsWith('image/') && !/\.(jpg|jpeg|png|webp|avif|gif|bmp|tiff|svg)$/i.test(file.name)) {
      setImageError(t("Please select a valid image file (JPG, PNG, WEBP, etc.)", "Пожалуйста, выберите файл изображения (JPG, PNG, WEBP и др.)"));
      return;
    }

    setImageError(null);
    setImageSuccess(false);
    setImageFile(file);

    if (imagePreviewUrl) {
      URL.revokeObjectURL(imagePreviewUrl);
    }
    const url = URL.createObjectURL(file);
    setImagePreviewUrl(url);

    const img = new Image();
    img.onload = () => {
      const nw = img.naturalWidth;
      const nh = img.naturalHeight;
      setOrigDimensions({ width: nw, height: nh });

      // Automatically scale to target size without any crop or distortion
      const baseDim = activePreset === '1000' ? 1000 : activePreset === '6000' ? 6000 : 3000;
      if (fitMode === 'proportional') {
        if (nw >= nh) {
          setTargetWidth(baseDim);
          setTargetHeight(Math.round(baseDim * (nh / nw)));
        } else {
          setTargetHeight(baseDim);
          setTargetWidth(Math.round(baseDim * (nw / nh)));
        }
      } else {
        setTargetWidth(baseDim);
        setTargetHeight(baseDim);
      }
    };
    img.src = url;
  };

  // Preset button click (e.g. 1000, 3000, 6000)
  const handleApplyPreset = (preset: ImagePreset) => {
    setActivePreset(preset);
    const size = preset === '1000' ? 1000 : preset === '6000' ? 6000 : 3000;

    if (fitMode === 'proportional' && origDimensions && origDimensions.width > 0 && origDimensions.height > 0) {
      if (origDimensions.width >= origDimensions.height) {
        setTargetWidth(size);
        setTargetHeight(Math.round(size * (origDimensions.height / origDimensions.width)));
      } else {
        setTargetHeight(size);
        setTargetWidth(Math.round(size * (origDimensions.width / origDimensions.height)));
      }
    } else {
      setTargetWidth(size);
      setTargetHeight(size);
    }
  };

  // Fit mode change handler
  const handleFitModeChange = (newFit: FitMode) => {
    setFitMode(newFit);
    const baseDim = activePreset === '1000' ? 1000 : activePreset === '6000' ? 6000 : 3000;
    if (newFit === 'proportional' && origDimensions && origDimensions.width > 0 && origDimensions.height > 0) {
      if (origDimensions.width >= origDimensions.height) {
        setTargetWidth(baseDim);
        setTargetHeight(Math.round(baseDim * (origDimensions.height / origDimensions.width)));
      } else {
        setTargetHeight(baseDim);
        setTargetWidth(Math.round(baseDim * (origDimensions.width / origDimensions.height)));
      }
    } else if (newFit === 'blur' || newFit === 'contain' || newFit === 'cover') {
      setTargetWidth(baseDim);
      setTargetHeight(baseDim);
    }
  };

  const handleWidthChange = (val: number) => {
    const w = Math.max(10, Math.min(8000, val || 0));
    setTargetWidth(w);
    setActivePreset('custom');
    if (lockAspect) {
      if (origDimensions && origDimensions.width > 0 && origDimensions.height > 0) {
        const ratio = origDimensions.height / origDimensions.width;
        setTargetHeight(Math.round(w * ratio));
      } else {
        setTargetHeight(w);
      }
    }
  };

  const handleHeightChange = (val: number) => {
    const h = Math.max(10, Math.min(8000, val || 0));
    setTargetHeight(h);
    setActivePreset('custom');
    if (lockAspect) {
      if (origDimensions && origDimensions.width > 0 && origDimensions.height > 0) {
        const ratio = origDimensions.width / origDimensions.height;
        setTargetWidth(Math.round(h * ratio));
      } else {
        setTargetWidth(h);
      }
    }
  };

  // Convert & download image (Server-side FFmpeg for ultra-high-res lanczos up to 6000x6000)
  const handleProcessImage = async () => {
    if (!imageFile) return;
    setIsImageProcessing(true);
    setImageError(null);
    setImageSuccess(false);

    try {
      const formData = new FormData();
      formData.append('image', imageFile);
      formData.append('width', String(targetWidth));
      formData.append('height', String(targetHeight));
      formData.append('fit', fitMode);
      formData.append('format', imageFormat);
      formData.append('quality', String(imageQuality));

      const response = await fetch('/api/convert/resize-image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        let msg = `Ошибка обработки (HTTP ${response.status})`;
        try {
          const text = await response.text();
          const json = JSON.parse(text);
          if (json.error) msg = json.error;
        } catch {}
        throw new Error(msg);
      }

      // Download file
      const blob = await response.blob();
      const baseName = imageFile.name.replace(/\.[^/.]+$/, "") || "cover";
      const filename = `${baseName}_${targetWidth}x${targetHeight}.${imageFormat === 'jpeg' ? 'jpg' : imageFormat}`;

      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        window.URL.revokeObjectURL(downloadUrl);
        a.remove();
      }, 150);

      setImageSuccess(true);
      setTimeout(() => setImageSuccess(false), 3500);
    } catch (err: any) {
      console.error("Image processing error:", err);
      setImageError(err.message || t("Image processing failed", "Ошибка обработки изображения"));
    } finally {
      setIsImageProcessing(false);
    }
  };

  // --- AUDIO LOGIC ---
  const isAudioFile = (f: File) => {
    return f.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|flac|wma|aiff|alac|opus|weba|webm|mp4)$/i.test(f.name);
  };

  const handleAudioFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      if (isAudioFile(selectedFile)) {
        setAudioFile(selectedFile);
        setAudioError(null);
      } else {
        setAudioError(t("Please select a valid audio file (MP3, WAV, M4A, FLAC, AAC, etc.).", "Пожалуйста, выберите аудиофайл (MP3, WAV, M4A, FLAC, AAC и др.)."));
        setAudioFile(null);
      }
    }
  };

  const handleAudioConvert = async () => {
    if (!audioFile) return;

    setIsAudioConverting(true);
    setAudioError(null);
    setAudioProgress(0);

    const progressInterval = setInterval(() => {
      setAudioProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 450);

    try {
      const formData = new FormData();
      formData.append('audio', audioFile);

      // Determine target sample rate
      let rateToSend = "44100";
      if (sampleRate === '44.8') rateToSend = "44800";
      else if (sampleRate === '48') rateToSend = "48000";
      else if (sampleRate === '96') rateToSend = "96000";
      else if (sampleRate === 'custom') rateToSend = customSampleRate.trim() || "44100";

      formData.append('sampleRate', rateToSend);
      formData.append('bitDepth', bitDepth);
      formData.append('channels', channels);

      const response = await fetch('/api/convert/audio-to-wav', {
        method: 'POST',
        body: formData,
      });

      clearInterval(progressInterval);
      setAudioProgress(100);

      if (!response.ok) {
        let errMsg = `Ошибка конвертации (HTTP ${response.status})`;
        try {
          const text = await response.text();
          if (text) {
            try {
              const errData = JSON.parse(text);
              errMsg = errData.error || errData.message || errMsg;
            } catch {
              errMsg = text.length < 200 ? text : errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = audioFile.name.replace(/\.[^/.]+$/, "") + `_${sampleRate === '44.8' ? '44.8k' : sampleRate === '48' ? '48k' : '44.1k'}.wav`;
      if (contentDisposition) {
        const utf8Match = contentDisposition.match(/filename\*=UTF-8''([^;]+)/i);
        if (utf8Match && utf8Match[1]) {
          try {
            filename = decodeURIComponent(utf8Match[1]);
          } catch {}
        } else {
          const filenameMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
          if (filenameMatch && filenameMatch[1]) {
            filename = filenameMatch[1];
          }
        }
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        a.remove();
      }, 100);

      setTimeout(() => {
        setAudioProgress(0);
        setIsAudioConverting(false);
      }, 1800);

    } catch (err: any) {
      clearInterval(progressInterval);
      setAudioError(err.message || t('Conversion failed. Please try again.', 'Конвертация не удалась. Пожалуйста, попробуйте еще раз.'));
      setIsAudioConverting(false);
      setAudioProgress(0);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Top Header Card */}
      <div className="p-6 sm:p-8 rounded-[2rem] border bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border-zinc-200/60 dark:border-white/10 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-zinc-50 flex items-center gap-3">
              <Layers className="w-8 h-8 text-blue-500" />
              {t("Media Studio Converter", "Медиа Конвертер")}
            </h2>
            <p className="text-sm sm:text-base text-zinc-500 dark:text-zinc-400 mt-1.5">
              {t(
                "Convert any audio into studio 16/24-bit WAV (44.1, 44.8, 48 kHz) and resize release covers to 1000, 3000, or 6000×6000 px.",
                "Конвертация любого аудио в студийный WAV (44.1, 44.8, 48 кГц) и масштабирование обложек релизов в 1000, 3000 или 6000×6000 px."
              )}
            </p>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex p-1.5 bg-zinc-100 dark:bg-zinc-800/80 rounded-2xl border border-zinc-200 dark:border-zinc-700/60 self-start md:self-auto">
            <button
              onClick={() => setMode('audio')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 ${
                mode === 'audio'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Music className="w-4 h-4" />
              {t("Audio to WAV", "Аудио в WAV")}
            </button>
            <button
              onClick={() => setMode('image')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 ${
                mode === 'image'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              {t("Cover Resizer", "Обложки и Фото")}
            </button>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('openVideoShotStudio'))}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-400/10 cursor-pointer"
              title="Создать вертикальный видеошот для Яндекс Музыки (404×720) и Canvas"
            >
              <Film className="w-4 h-4 text-yellow-500" />
              <span>Видеошот (404×720)</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* MODE 1: AUDIO TO WAV                                                      */}
        {/* ========================================================================= */}
        {mode === 'audio' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Audio settings bar */}
            <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/60 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                  <Settings className="w-4 h-4 text-blue-500" />
                  {t("Audio Parameters & Sample Rate", "Параметры звука и частота дискретизации")}
                </span>
                <span className="text-xs text-blue-600 dark:text-blue-400 font-medium px-2.5 py-1 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
                  PCM {bitDepth}-bit • {sampleRate === 'custom' ? `${customSampleRate} Hz` : `${sampleRate} kHz`} • {channels === '2' ? 'Stereo' : 'Mono'}
                </span>
              </div>

              {/* Sample rate pill options: 44.1, 44.8, 48, 96, custom */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                  {t("Sample Rate (kHz):", "Частота дискретизации:")}
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    { id: '44.1', label: '44.1 кГц', sub: 'CD / Стриминги (44100 Гц)' },
                    { id: '44.8', label: '44.8 кГц', sub: 'Спец. частота (44800 Гц)' },
                    { id: '48', label: '48.0 кГц', sub: 'Студия / Видео (48000 Гц)' },
                    { id: '96', label: '96.0 кГц', sub: 'Hi-Res (96000 Гц)' },
                    { id: 'custom', label: 'Вручную...', sub: 'Произвольная частота' }
                  ].map(opt => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSampleRate(opt.id as SampleRateOption)}
                      className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-200 border ${
                        sampleRate === opt.id
                          ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-blue-400'
                      }`}
                    >
                      <div className="font-semibold">{opt.label}</div>
                      <div className={`text-[10px] ${sampleRate === opt.id ? 'text-blue-100' : 'text-zinc-400'}`}>{opt.sub}</div>
                    </button>
                  ))}
                </div>

                {sampleRate === 'custom' && (
                  <div className="pt-2 flex items-center gap-3">
                    <input
                      type="number"
                      value={customSampleRate}
                      onChange={(e) => setCustomSampleRate(e.target.value)}
                      placeholder="e.g. 44100, 44800, 48000"
                      className="w-48 px-3.5 py-2 text-sm rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">
                      {t("Hz (between 8000 and 192000)", "Гц (от 8000 до 192000)")}
                    </span>
                  </div>
                )}
              </div>

              {/* Bit Depth and Channels */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-zinc-200/60 dark:border-zinc-700/60">
                <div>
                  <label className="text-xs font-medium text-zinc-500 dark:text-zinc-400 block mb-1.5">
                    {t("Bit Depth:", "Разрядность:")}
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setBitDepth('16')}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                        bitDepth === '16'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      16-bit PCM (Стандарт)
                    </button>
                    <button
                      type="button"
                      onClick={() => setBitDepth('24')}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                        bitDepth === '24'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      24-bit PCM (Мастеринг)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-zinc-500 dark:text-zinc-400 block mb-1.5">
                    {t("Audio Channels:", "Каналы:")}
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setChannels('2')}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                        channels === '2'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      Stereo (2.0)
                    </button>
                    <button
                      type="button"
                      onClick={() => setChannels('1')}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                        channels === '1'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      Mono (1.0)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Error Message */}
            {audioError && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-2xl text-red-600 dark:text-red-400 text-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <p>{audioError}</p>
              </div>
            )}

            {/* Drag & Drop Audio Upload Area */}
            <div
              onClick={() => !isAudioConverting && audioInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                  const sel = e.dataTransfer.files[0];
                  if (isAudioFile(sel)) {
                    setAudioFile(sel);
                    setAudioError(null);
                  } else {
                    setAudioError(t("Please select a valid audio file.", "Пожалуйста, выберите корректный аудиофайл."));
                  }
                }
              }}
              className={`relative border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all duration-300 ${
                isAudioConverting
                  ? 'opacity-50 cursor-not-allowed border-zinc-200 dark:border-zinc-800'
                  : audioFile
                  ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-900/10 cursor-pointer'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-blue-400 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 cursor-pointer'
              }`}
            >
              <input
                type="file"
                ref={audioInputRef}
                onChange={handleAudioFileChange}
                accept="audio/*,.mp3,.wav,.m4a,.aac,.flac,.ogg,.wma,.aiff,.alac,.opus,.weba,.webm"
                className="hidden"
              />

              <div className="flex flex-col items-center justify-center gap-4">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-transform ${
                    audioFile
                      ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 scale-105'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500'
                  }`}
                >
                  {audioFile ? <FileAudio className="w-8 h-8" /> : <Upload className="w-8 h-8" />}
                </div>

                <div>
                  {audioFile ? (
                    <>
                      <p className="text-base font-semibold text-zinc-900 dark:text-zinc-100 break-all max-w-md">
                        {audioFile.name}
                      </p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                        {(audioFile.size / (1024 * 1024)).toFixed(2)} MB • {audioFile.type || "audio"}
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-base font-medium text-zinc-900 dark:text-zinc-100">
                        {t("Click to upload audio or drag and drop", "Нажмите для загрузки аудио или перетащите файл")}
                      </p>
                      <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                        MP3, FLAC, M4A, AAC, OGG, WAV, AIFF, OPUS, WMA (до 200MB)
                      </p>
                    </>
                  )}
                </div>

                {audioFile && !isAudioConverting && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setAudioFile(null);
                    }}
                    className="text-xs text-red-500 hover:text-red-700 underline"
                  >
                    {t("Choose another audio", "Выбрать другое аудио")}
                  </button>
                )}
              </div>
            </div>

            {/* Convert Audio Button */}
            <div className="flex justify-center pt-2">
              <button
                onClick={handleAudioConvert}
                disabled={!audioFile || isAudioConverting}
                className={`relative overflow-hidden group flex items-center gap-3 px-8 py-4 rounded-2xl font-semibold text-base sm:text-lg transition-all duration-300 ${
                  !audioFile || isAudioConverting
                    ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl hover:shadow-blue-500/25 active:scale-95'
                }`}
              >
                {isAudioConverting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {audioProgress === 100
                      ? t("Downloading WAV...", "Скачивание WAV...")
                      : t("Encoding to WAV...", "Конвертация в WAV...")}
                    {audioProgress > 0 && audioProgress < 100 && (
                      <span className="ml-2">{audioProgress}%</span>
                    )}
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5" />
                    <span>
                      {t("Convert to WAV", "Конвертировать в WAV")}{' '}
                      <span className="text-xs opacity-80 font-normal">
                        ({sampleRate === 'custom' ? `${customSampleRate}Hz` : `${sampleRate}kHz`})
                      </span>
                    </span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </>
                )}

                {isAudioConverting && audioProgress > 0 && (
                  <div
                    className="absolute left-0 bottom-0 h-1 bg-blue-400 transition-all duration-300 ease-out"
                    style={{ width: `${audioProgress}%` }}
                  />
                )}
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODE 2: IMAGE / COVER ART RESIZER & CONVERTER                             */}
        {/* ========================================================================= */}
        {mode === 'image' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Image Error or Success notification */}
            {imageError && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-2xl text-red-600 dark:text-red-400 text-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <p>{imageError}</p>
              </div>
            )}

            {imageSuccess && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-emerald-600 dark:text-emerald-400 text-sm flex items-center gap-3">
                <Check className="w-5 h-5 flex-shrink-0" />
                <p>{t("Image resized and downloaded successfully!", "Изображение успешно обработано и скачано!")}</p>
              </div>
            )}

            {/* Drop / Upload Zone or Live Preview */}
            {!imageFile ? (
              <div
                onClick={() => imageInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    handleImageSelect(e.dataTransfer.files[0]);
                  }
                }}
                className="border-2 border-dashed rounded-3xl p-10 sm:p-14 text-center cursor-pointer transition-all duration-300 border-zinc-300 dark:border-zinc-700 hover:border-blue-500 hover:bg-blue-50/20 dark:hover:bg-blue-900/10"
              >
                <input
                  type="file"
                  ref={imageInputRef}
                  onChange={(e) => e.target.files && e.target.files[0] && handleImageSelect(e.target.files[0])}
                  accept="image/*,.jpg,.jpeg,.png,.webp,.avif,.bmp,.tiff,.svg"
                  className="hidden"
                />
                <div className="flex flex-col items-center justify-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-base sm:text-lg font-semibold text-zinc-900 dark:text-zinc-100">
                      {t("Upload Cover or Photo", "Загрузите обложку или фото")}
                    </p>
                    <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                      {t(
                        "Drag & drop image here or click to browse. Scale to 1000x1000, 3000x3000, or 6000x6000 px.",
                        "Перетащите изображение сюда. Корректировка в 1000x1000, 3000x3000 или 6000x6000 px."
                      )}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Left column: Preview & image metadata */}
                <div className="lg:col-span-5 p-5 rounded-3xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/60 flex flex-col items-center">
                  <div className="relative w-full aspect-square max-w-[290px] rounded-2xl overflow-hidden shadow-md border border-zinc-200 dark:border-zinc-700 bg-zinc-950/90 flex items-center justify-center p-2">
                    {imagePreviewUrl && fitMode === 'blur' && (
                      <img
                        src={imagePreviewUrl}
                        alt="Blurred backdrop"
                        className="absolute inset-0 w-full h-full object-cover blur-xl opacity-45 scale-125 pointer-events-none"
                      />
                    )}
                    {imagePreviewUrl && (
                      <img
                        src={imagePreviewUrl}
                        alt="Preview"
                        className="relative z-10 max-w-full max-h-full object-contain drop-shadow-md"
                      />
                    )}
                    <div className="absolute top-2.5 right-2.5 z-20 px-2.5 py-1 bg-black/80 backdrop-blur-md rounded-lg text-[11px] font-mono text-white border border-white/10 shadow">
                      {targetWidth} × {targetHeight}
                    </div>
                  </div>

                  <div className="w-full mt-4 space-y-1.5 text-center sm:text-left">
                    <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 truncate">
                      {imageFile.name}
                    </p>
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                      {origDimensions && (
                        <span>
                          {t("Original:", "Исходник:")} <strong className="text-zinc-800 dark:text-zinc-200 font-mono">{origDimensions.width} × {origDimensions.height} px</strong>
                        </span>
                      )}
                      <span>•</span>
                      <span>{(imageFile.size / (1024 * 1024)).toFixed(2)} MB</span>
                    </div>

                    <div className="pt-2">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        <Check className="w-3 h-3" />
                        {fitMode === 'proportional'
                          ? t("100% uncropped original frame", "100% исходного кадра без обрезки")
                          : fitMode === 'blur'
                          ? t("Square with Smart Blur background", "Квадрат со Smart Blur фоном")
                          : fitMode === 'contain'
                          ? t("Square with matte padding", "Квадрат с полями без обрезки")
                          : t("Crop mode enabled", "Режим обрезки")}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setImageFile(null);
                      if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
                      setImagePreviewUrl(null);
                      setOrigDimensions(null);
                    }}
                    className="mt-4 flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 underline"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    {t("Replace Image", "Выбрать другое изображение")}
                  </button>
                </div>

                {/* Right column: Target resolution presets & manual adjustments */}
                <div className="lg:col-span-7 space-y-5 p-5 rounded-3xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/60">
                  {/* Presets requested by user: 1000, 3000, 6000 */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider block">
                        {t("Resolution Presets", "Быстрые форматы обложек")}
                      </label>
                      <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        {t("Without crop or distortion", "Без обрезки и искажений")}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-2.5">
                      <button
                        type="button"
                        onClick={() => handleApplyPreset('1000')}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          activePreset === '1000'
                            ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                            : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-blue-400'
                        }`}
                      >
                        <div className="text-sm font-bold">1000 px</div>
                        <div className={`text-[11px] ${activePreset === '1000' ? 'text-blue-100' : 'text-zinc-400'}`}>
                          {t("Web / Preview", "Веб / Просмотр")}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyPreset('3000')}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          activePreset === '3000'
                            ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                            : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-blue-400'
                        }`}
                      >
                        <div className="text-sm font-bold">3000 px</div>
                        <div className={`text-[11px] ${activePreset === '3000' ? 'text-blue-100' : 'text-zinc-400'}`}>
                          {t("Streaming Standard", "Стандарт стримингов")}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyPreset('6000')}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          activePreset === '6000'
                            ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                            : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-blue-400'
                        }`}
                      >
                        <div className="text-sm font-bold">6000 px</div>
                        <div className={`text-[11px] ${activePreset === '6000' ? 'text-blue-100' : 'text-zinc-400'}`}>
                          {t("Ultra HD / Print", "Ultra HD / Печать")}
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Manual custom inputs: Width & Height */}
                  <div className="pt-2 border-t border-zinc-200/60 dark:border-zinc-700/60">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider">
                        {t("Manual Pixel Adjustment", "Ручная корректировка (px)")}
                      </label>
                      <button
                        type="button"
                        onClick={() => setLockAspect(!lockAspect)}
                        className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-lg transition-colors ${
                          lockAspect
                            ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300'
                            : 'bg-zinc-200 dark:bg-zinc-700 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        {lockAspect ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                        {lockAspect ? t("Proportions Locked", "Пропорции заблокированы") : t("Free Size", "Свободный размер")}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[11px] text-zinc-500 dark:text-zinc-400 block mb-1">
                          {t("Width (px):", "Ширина (px):")}
                        </span>
                        <input
                          type="number"
                          min={50}
                          max={8000}
                          value={targetWidth}
                          onChange={(e) => handleWidthChange(parseInt(e.target.value, 10))}
                          className="w-full px-3.5 py-2 rounded-xl text-sm font-mono border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <span className="text-[11px] text-zinc-500 dark:text-zinc-400 block mb-1">
                          {t("Height (px):", "Высота (px):")}
                        </span>
                        <input
                          type="number"
                          min={50}
                          max={8000}
                          value={targetHeight}
                          onChange={(e) => handleHeightChange(parseInt(e.target.value, 10))}
                          className="w-full px-3.5 py-2 rounded-xl text-sm font-mono border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Fit Mode & Format */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-zinc-200/60 dark:border-zinc-700/60">
                    <div>
                      <label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 block mb-1.5">
                        {t("Fit Mode:", "Режим подгонки:")}
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          {
                            id: 'proportional',
                            label: t('Original Ratio', 'Оригинал'),
                            desc: t('Preserves 100% of original image without crop or distortion', '100% исходника: без обрезки и искажений'),
                            badge: '100%'
                          },
                          {
                            id: 'blur',
                            label: t('Square (Smart Blur)', 'Smart Blur'),
                            desc: t('Full uncropped image in center with soft blurred artwork on edges', 'В квадрат 1:1 с мягким размытием по бокам'),
                            badge: '1:1'
                          },
                          {
                            id: 'contain',
                            label: t('Square (Letterbox)', 'С полями'),
                            desc: t('Full uncropped image in center with clean borders', 'В квадрат 1:1 с полями без обрезки'),
                            badge: '1:1'
                          },
                        ].map(f => (
                          <button
                            key={f.id}
                            type="button"
                            title={f.desc}
                            onClick={() => handleFitModeChange(f.id as FitMode)}
                            className={`flex flex-col items-center justify-center p-2 rounded-xl text-center border transition-all ${
                              fitMode === f.id
                                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-blue-400'
                            }`}
                          >
                            <span className="text-xs font-bold leading-tight">{f.label}</span>
                            <span className={`text-[10px] mt-0.5 ${fitMode === f.id ? 'text-blue-100' : 'text-zinc-400'}`}>
                              {f.badge}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 block mb-1.5">
                        {t("Format & Quality:", "Формат:")}
                      </label>
                      <div className="flex gap-1.5">
                        {(['jpg', 'png', 'webp'] as ImageFormat[]).map(fmt => (
                          <button
                            key={fmt}
                            type="button"
                            onClick={() => setImageFormat(fmt)}
                            className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold uppercase border transition-all ${
                              imageFormat === fmt
                                ? 'bg-blue-600 text-white border-blue-600'
                                : 'bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
                            }`}
                          >
                            {fmt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Quality slider for JPG / WEBP */}
                  {imageFormat !== 'png' && (
                    <div className="flex items-center justify-between gap-4 pt-1">
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">
                        {t("Image Quality:", "Качество сжатия:")} {imageQuality}%
                      </span>
                      <input
                        type="range"
                        min={70}
                        max={100}
                        value={imageQuality}
                        onChange={(e) => setImageQuality(parseInt(e.target.value, 10))}
                        className="w-48 h-2 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>
                  )}

                  {/* Process & Download Button */}
                  <div className="pt-3">
                    <button
                      type="button"
                      onClick={handleProcessImage}
                      disabled={isImageProcessing}
                      className={`w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-2xl font-bold text-sm sm:text-base text-white transition-all duration-200 shadow-md ${
                        isImageProcessing
                          ? 'bg-zinc-400 dark:bg-zinc-700 cursor-not-allowed'
                          : 'bg-blue-600 hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/25 active:scale-95'
                      }`}
                    >
                      {isImageProcessing ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>{t("Processing Lanczos Scale...", "Рендеринг Lanczos HQ...")}</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-5 h-5" />
                          <span>
                            {t("Download Resized Cover", "Скачать обложку")}{' '}
                            <span className="font-mono opacity-90 font-normal">
                              ({targetWidth} × {targetHeight} px)
                            </span>
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
