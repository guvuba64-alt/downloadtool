import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, Info, Copy, Check, Download, Play, Music, 
  Loader2, ImageIcon, Barcode, Disc, Calendar, Clock, Sparkles, FileCheck,
  Film, CheckCircle2, AlertCircle, Maximize2
} from "lucide-react";
import { extractTrackDetails, TrackMetadataDetails } from "../utils/trackMetadata";
import { downloadWavTrack } from "../utils/audioDownloader";
import { ProxyImage } from "./ProxyImage";
import { generateReleaseSheetPdf } from "../lib/pdfGenerator";
import { VideoSnapshotModal } from "./VideoSnapshotModal";

export interface TrackInfoModalProps {
  track: any | null;
  isOpen: boolean;
  onClose: () => void;
  onPlayTrack?: (track: any) => void;
  t?: (en: string, ru: string) => string;
}

export function TrackInfoModal({
  track,
  isOpen,
  onClose,
  onPlayTrack,
  t = (_en, ru) => ru
}: TrackInfoModalProps) {
  const [details, setDetails] = useState<TrackMetadataDetails | null>(null);
  const [loadingDeepData, setLoadingDeepData] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isDownloadingWav, setIsDownloadingWav] = useState(false);
  const [isDownloadingCover, setIsDownloadingCover] = useState(false);
  const [coverDownloadSuccess, setCoverDownloadSuccess] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [snapshotData, setSnapshotData] = useState<any>(null);
  const [loadingSnapshot, setLoadingSnapshot] = useState(false);
  const [isDownloadingSnapshot, setIsDownloadingSnapshot] = useState(false);
  const [snapshotDownloadSuccess, setSnapshotDownloadSuccess] = useState(false);
  const [isVideoSnapshotModalOpen, setIsVideoSnapshotModalOpen] = useState(false);

  // Initialize and synchronously extract instant metadata
  useEffect(() => {
    if (!isOpen || !track) {
      setDetails(null);
      setLoadingDeepData(false);
      return;
    }

    const instant = extractTrackDetails(track);
    setDetails(instant);

    // If UPC, ISRC or copyright are missing, perform deep async lookup
    const needsLookup = !instant?.upc || !instant?.isrc || !instant?.copyright || instant?.copyright === "Не указан";
    
    if (needsLookup) {
      setLoadingDeepData(true);
      const artistName = instant?.performer || instant?.artists || "";
      const trackTitle = instant?.title || track?.title || "";
      const trackId = track?.id || instant?.id;

      // First try: verify-track-copyright endpoint (scans OK.ru, Yandex credits, etc.)
      fetch("/api/music/verify-track-copyright", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId,
          title: trackTitle,
          artist: artistName,
          isrc: instant?.isrc || track?.isrc,
          upc: instant?.upc || track?.upc,
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data && data.success) {
            setDetails((prev) => {
              if (!prev) return prev;
              const finalDistributor = data.distributor || data.distributorName || data.detectedDistributor?.name;
              const finalCopyright = data.copyright || (data.copyrightOwnerName ? `℗ ${new Date().getFullYear()} ${data.copyrightOwnerName}` : null) || prev.copyright;
              const finalLabel = finalDistributor || data.label || data.copyrightOwnerName || prev.label;
              return {
                ...prev,
                upc: data.upc || prev.upc,
                isrc: data.isrc || prev.isrc,
                copyright: finalCopyright || prev.copyright,
                label: finalLabel || prev.label,
                distributor: finalDistributor || prev.distributor,
                authorsMusic: data.authorsMusic || prev.authorsMusic,
                authorsText: data.authorsText || prev.authorsText,
              };
            });
          }

          // If still no UPC and track has an album ID, fetch album metadata with tracks
          const albId = instant?.albumId || (Array.isArray(track?.albums) && track.albums[0]?.id) || track?.album?.id;
          if (!data?.upc && albId) {
            return fetch(`/api/music/albums/${albId}/with-tracks`)
              .then((r) => r.json())
              .then((albData) => {
                if (albData?.album) {
                  const alb = albData.album;
                  const albumUpc = alb.upc || alb.barcode || alb.ean;
                  const albumDistributor = alb.distributor || alb.distributorName || (Array.isArray(alb.distributors) && (alb.distributors[0]?.name || alb.distributors[0]));
                  const albumLabel = albumDistributor || alb.label || (Array.isArray(alb.labels) && (alb.labels[0]?.name || alb.labels[0]));
                  const albumCopyright = alb.copyright || alb.pLine || (Array.isArray(alb.copyrights) && alb.copyrights[0]);

                  setDetails((prev) => {
                    if (!prev) return prev;
                    return {
                      ...prev,
                      upc: prev.upc || albumUpc || null,
                      label: prev.label && prev.label !== "Не указан" ? prev.label : (albumLabel || prev.label),
                      copyright: prev.copyright && prev.copyright !== "Не указан" ? prev.copyright : (albumCopyright || prev.copyright),
                    };
                  });
                }
              });
          }
        })
        .catch(() => {})
        .finally(() => {
          setLoadingDeepData(false);
        });
    }

    // Video Snapshot Lookup (Яндекс Музыка)
    const cleanTrackId = String(track?.id || instant?.id || '').replace(/^(ya_|track_|t_)/, '');
    if (cleanTrackId) {
      setLoadingSnapshot(true);
      fetch(`/api/music/track/${cleanTrackId}/video-snapshot`)
        .then((r) => r.json())
        .then((data) => {
          if (data && data.success) {
            setSnapshotData(data);
          }
        })
        .catch(() => {})
        .finally(() => {
          setLoadingSnapshot(false);
        });
    } else {
      setSnapshotData(null);
    }
  }, [isOpen, track]);

  const handleDownloadSnapshot = (url?: string, type: 'snapshot' | 'clip' = 'snapshot') => {
    const downloadUrl = url || snapshotData?.videoSnapshot?.downloadUrl;
    if (!downloadUrl) return;

    setIsDownloadingSnapshot(true);
    try {
      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = "";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setSnapshotDownloadSuccess(true);
      setTimeout(() => setSnapshotDownloadSuccess(false), 2500);
    } catch (_) {
    } finally {
      setIsDownloadingSnapshot(false);
    }
  };

  if (!isOpen || !track) return null;

  const handleCopyField = (val: string | null | undefined, key: string) => {
    if (!val || val === "Не указан") return;
    navigator.clipboard.writeText(String(val));
    setCopiedField(key);
    setTimeout(() => {
      setCopiedField((prev) => (prev === key ? null : prev));
    }, 1800);
  };

  const handleCopyAll = () => {
    if (!details) return;
    const lines: string[] = [];
    if (details.title) lines.push(`Трек: ${details.title}`);
    if (details.artists) lines.push(`Исполнитель: ${details.artists}`);
    if (details.albumTitle) lines.push(`Альбом: ${details.albumTitle}${details.year ? ` (${details.year})` : ""}`);
    if (details.upc) lines.push(`UPC / EAN: ${details.upc}`);
    if (details.isrc) lines.push(`ISRC: ${details.isrc}`);
    if (details.label && details.label !== "Не указан") lines.push(`Лейбл (дистрибьютор): ${details.label} в переработке`);
    if (details.copyright && details.copyright !== "Не указан") lines.push(`Копирайт (правообладатель): ${details.copyright} в переработке`);
    if (details.authorsMusic) lines.push(`Авторы музыки: ${details.authorsMusic}`);
    if (details.authorsText) lines.push(`Авторы текста: ${details.authorsText}`);
    if (details.releaseDate) lines.push(`Дата выхода: ${new Date(details.releaseDate).toLocaleDateString("ru-RU")}`);

    navigator.clipboard.writeText(lines.join("\n"));
    setCopiedField("all");
    setTimeout(() => setCopiedField(null), 1800);
  };

  const handleDownloadWav = async () => {
    if (!details) return;
    setIsDownloadingWav(true);
    try {
      await downloadWavTrack({
        trackId: String(details.id || track.id),
        title: details.title,
        artists: details.artists,
        upc: details.upc || undefined,
        isrc: details.isrc || undefined,
        coverUri: details.coverUri || undefined,
        t,
      });
    } catch (_) {
    } finally {
      setIsDownloadingWav(false);
    }
  };

  const handleDownloadCover3000 = async () => {
    const rawCover = details?.coverUri || track?.coverUri || (Array.isArray(track?.albums) && track.albums[0]?.coverUri);
    if (!rawCover) return;

    setIsDownloadingCover(true);
    try {
      const highResUrl = rawCover.startsWith("http")
        ? rawCover.replace(/\/(%%|\d+x\d+)/, "/orig")
        : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, "/orig")}`;

      const proxyUrl = `/api/music/proxy-image?url=${encodeURIComponent(highResUrl)}`;
      const img = new Image();
      img.crossOrigin = "anonymous";

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => {
          const fallbackUrl = rawCover.startsWith("http")
            ? rawCover.replace(/\/(%%|\d+x\d+)/, "/1000x1000")
            : `https://${rawCover.replace(/\/(%%|\d+x\d+)/, "/1000x1000")}`;
          img.src = `/api/music/proxy-image?url=${encodeURIComponent(fallbackUrl)}`;
          img.onload = () => resolve();
          img.onerror = (err) => reject(err);
        };
        img.src = proxyUrl;
      });

      const canvas = document.createElement("canvas");
      canvas.width = 3000;
      canvas.height = 3000;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(img, 0, 0, 3000, 3000);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              const safeName = `${details?.artists || "Artist"} - ${details?.title || "Track"}`.replace(/[\\/:*?"<>|]/g, "_");
              a.download = `${safeName} [3000x3000 Cover].jpg`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
              setCoverDownloadSuccess(true);
              setTimeout(() => setCoverDownloadSuccess(false), 2500);
            }
          },
          "image/jpeg",
          0.98
        );
      }
    } catch (_) {
    } finally {
      setIsDownloadingCover(false);
    }
  };

  const handleExportPdf = async () => {
    if (!track && !details) return;
    setIsExportingPdf(true);
    try {
      const meta = {
        title: details?.title || track?.title,
        artists: details?.performer || details?.artists || track?.artists,
        albumTitle: details?.albumTitle || track?.albumTitle,
        year: details?.year || track?.year,
        releaseDate: details?.releaseDate || track?.releaseDate,
        isrc: details?.isrc || track?.isrc,
        upc: details?.upc || track?.upc,
        label: details?.distributor || details?.label || track?.label,
        distributor: details?.distributor || details?.label || track?.distributor,
        copyright: details?.copyright || track?.copyright,
        copyrightOwnerName: details?.copyrightOwnerName || track?.copyrightOwnerName,
        copyrightOwnerId: details?.copyrightOwnerId || track?.copyrightOwnerId,
        authorsMusic: details?.authorsMusic || track?.authorsMusic,
        authorsText: details?.authorsText || track?.authorsText,
        duration: details?.duration || track?.duration,
        durationMs: details?.durationMs || track?.durationMs,
        coverUri: details?.coverUri || track?.coverUri,
        cover3000: details?.cover3000 || track?.cover3000,
        platform: details?.platform || track?.platform || 'Yandex / Universal',
        entityType: 'single',
      };
      await generateReleaseSheetPdf(meta, { lang: 'ru' });
    } catch (err) {
      console.error('Failed to export PDF from TrackInfoModal:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const coverSrc = details?.coverUri || track?.coverUri || (Array.isArray(track?.albums) && track.albums[0]?.coverUri);
  const formattedDuration = track?.durationMs
    ? `${Math.floor(track.durationMs / 60000)}:${String(Math.floor((track.durationMs % 60000) / 1000)).padStart(2, "0")}`
    : track?.duration
    ? `${Math.floor(track.duration / 60)}:${String(Math.floor(track.duration % 60)).padStart(2, "0")}`
    : null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-[95] bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 text-white animate-in fade-in duration-200"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 50, opacity: 0 }}
          transition={{ type: "spring", damping: 26, stiffness: 240 }}
          className="w-full sm:max-w-xl bg-[#131922] border border-white/10 rounded-t-[28px] sm:rounded-[28px] shadow-2xl flex flex-col max-h-[88vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-white/10 bg-[#18212d] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3.5 min-w-0 pr-2">
              <div className="w-12 h-12 rounded-2xl overflow-hidden bg-white/5 border border-white/10 shrink-0 relative flex items-center justify-center">
                {coverSrc ? (
                  <ProxyImage src={coverSrc} className="w-full h-full object-cover" />
                ) : (
                  <Music className="w-6 h-6 text-white/40" />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base sm:text-lg text-white truncate">
                    {t("About Track", "О треке")}
                  </h3>
                  {loadingDeepData && (
                    <span className="flex items-center gap-1 text-[11px] text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full font-medium">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      {t("Checking...", "Поиск данных...")}
                    </span>
                  )}
                </div>
                <p className="text-xs text-white/50 truncate">
                  {details?.title || track.title} — {details?.artists || "Исполнитель"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleCopyAll}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border border-white/10"
                title={t("Copy all info", "Скопировать все данные")}
              >
                {copiedField === "all" ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-bold">{t("Copied!", "Скопировано!")}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-yellow-400" />
                    <span>{t("Copy all", "Копировать всё")}</span>
                  </>
                )}
              </button>

              <button
                onClick={onClose}
                className="p-2 text-white/40 hover:text-white rounded-xl hover:bg-white/10 active:scale-95 transition-colors cursor-pointer"
                title={t("Close", "Закрыть")}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body Cards */}
          <div className="p-4 sm:p-5 overflow-y-auto space-y-2.5 max-h-[calc(88vh-160px)]">
            
            {/* 1. Track Title */}
            <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                  {t("Track Title", "Название трека")}
                </p>
                <p className="text-white font-medium text-sm sm:text-base select-all break-words">
                  {details?.title || track.title || "Не указан"}
                </p>
              </div>
              <button
                onClick={() => handleCopyField(details?.title || track.title, "title")}
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                title={t("Copy title", "Скопировать название")}
              >
                {copiedField === "title" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* 2. Artist */}
            <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                  {t("Artist / Performer", "Исполнитель")}
                </p>
                <p className="text-white font-medium text-sm sm:text-base select-all break-words">
                  {details?.artists || "Не указан"}
                </p>
              </div>
              <button
                onClick={() => handleCopyField(details?.artists, "artist")}
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                title={t("Copy artist", "Скопировать исполнителя")}
              >
                {copiedField === "artist" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* 3. Album */}
            {details?.albumTitle && (
              <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <Disc className="w-3 h-3 text-purple-400" />
                    <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                      {t("Album / Release", "Альбом / Релиз")}
                    </p>
                  </div>
                  <p className="text-white font-medium text-sm select-all break-words">
                    {details.albumTitle} {details.year ? `(${details.year})` : ""}
                  </p>
                </div>
                <button
                  onClick={() => handleCopyField(details.albumTitle, "album")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                  title={t("Copy album", "Скопировать альбом")}
                >
                  {copiedField === "album" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            )}

            {/* 4. UPC / EAN (Barcode) - HIGHLIGHTED SECTION */}
            <div className="bg-gradient-to-r from-purple-950/20 via-white/[0.04] to-blue-950/20 border border-purple-500/20 rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Barcode className="w-4 h-4 text-purple-400" />
                  <p className="text-purple-300 text-[10px] font-bold uppercase tracking-wider">
                    {t("UPC / EAN Barcode Code", "UPC / EAN Код")}
                  </p>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                    GS1 Universal
                  </span>
                </div>

                {details?.upc ? (
                  <p className="text-white font-mono font-bold text-base sm:text-lg select-all tracking-wider">
                    {details.upc}
                  </p>
                ) : loadingDeepData ? (
                  <p className="text-xs text-purple-300 flex items-center gap-1.5 py-1">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-purple-400" />
                    {t("Retrieving UPC code from catalog...", "Извлечение UPC кода из каталога...")}
                  </p>
                ) : (
                  <p className="text-xs text-white/40 italic py-0.5">
                    {t("Not specified in open catalogs", "Не указан в открытых каталогах")}
                  </p>
                )}
              </div>

              {details?.upc && (
                <button
                  onClick={() => handleCopyField(details.upc, "upc")}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border transition-all cursor-pointer ${
                    copiedField === "upc"
                      ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                      : "bg-purple-600/20 hover:bg-purple-600/40 border-purple-500/30 text-purple-300 hover:text-white active:scale-95"
                  }`}
                  title={t("Copy UPC code", "Скопировать UPC код")}
                >
                  {copiedField === "upc" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              )}
            </div>

            {/* 5. ISRC Code */}
            <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                    {t("ISRC Code", "ISRC Код")}
                  </p>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 font-semibold border border-blue-500/20">
                    Recording ID
                  </span>
                </div>

                {details?.isrc ? (
                  <p className="text-white font-mono font-bold text-sm sm:text-base select-all tracking-wide">
                    {details.isrc}
                  </p>
                ) : loadingDeepData ? (
                  <p className="text-xs text-white/50 flex items-center gap-1.5 py-1">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    {t("Searching ISRC...", "Поиск ISRC...")}
                  </p>
                ) : (
                  <p className="text-xs text-white/40 italic py-0.5">
                    {t("Not specified", "Не указан")}
                  </p>
                )}
              </div>

              {details?.isrc && (
                <button
                  onClick={() => handleCopyField(details.isrc, "isrc")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                  title={t("Copy ISRC code", "Скопировать ISRC код")}
                >
                  {copiedField === "isrc" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              )}
            </div>

            {/* 6. Label / Distributor */}
            <div className="bg-white/[0.04] border border-amber-500/25 rounded-2xl p-3.5 flex items-center justify-between gap-3 relative overflow-hidden">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                    {t("Record Label / Distributor", "Лейбл / Дистрибьютор")}
                  </p>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {t("Function under maintenance", "Функция в переработке")}
                  </span>
                </div>
                <div className="text-white font-medium text-sm select-all break-words">
                  {details?.distributor ? (
                    <span><span className="text-white/50 text-xs font-normal">Дистрибьютор:</span> {details.distributor}</span>
                  ) : details?.label && details.label !== "Не указан" && details.label !== "No label" ? (
                    <span><span className="text-white/50 text-xs font-normal">Дистрибьютор/Лейбл:</span> {details.label}</span>
                  ) : (
                    <span className="text-amber-300/80 italic text-xs">В переработке (поиск дистрибьютора)</span>
                  )}
                </div>
              </div>
              {details?.label && details.label !== "Не указан" && (
                <button
                  onClick={() => handleCopyField(details.distributor || details.label, "label")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                  title={t("Copy label", "Скопировать")}
                >
                  {copiedField === "label" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              )}
            </div>

            {/* 7. Copyright / Rights Holder */}
            <div className="bg-white/[0.04] border border-amber-500/25 rounded-2xl p-3.5 flex items-center justify-between gap-3 relative overflow-hidden">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                    {t("Copyright / Rights Holder", "Копирайт / Правообладатель")}
                  </p>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {t("Function under maintenance", "Функция в переработке")}
                  </span>
                </div>
                <div className="text-white font-medium text-sm select-all break-words">
                  {details?.copyright && details.copyright !== "Не указан" ? (
                    <span><span className="text-white/50 text-xs font-normal">Правообладатель:</span> {details.copyright}</span>
                  ) : (
                    <span className="text-amber-300/80 italic text-xs">В переработке (поиск правообладателя)</span>
                  )}
                </div>
              </div>
              {details?.copyright && details.copyright !== "Не указан" && (
                <button
                  onClick={() => handleCopyField(details.copyright, "copyright")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                  title={t("Copy copyright", "Скопировать")}
                >
                  {copiedField === "copyright" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              )}
            </div>

            {/* 8. Authors Music / Lyrics */}
            {details?.authorsMusic && (
              <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                    {t("Music Composers", "Авторы музыки")}
                  </p>
                  <p className="text-white font-medium text-sm select-all break-words">
                    {details.authorsMusic}
                  </p>
                </div>
                <button
                  onClick={() => handleCopyField(details.authorsMusic, "authorsMusic")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                >
                  {copiedField === "authorsMusic" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            )}

            {details?.authorsText && (
              <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                    {t("Lyricists / Text Authors", "Авторы слов")}
                  </p>
                  <p className="text-white font-medium text-sm select-all break-words">
                    {details.authorsText}
                  </p>
                </div>
                <button
                  onClick={() => handleCopyField(details.authorsText, "authorsText")}
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-all shrink-0 cursor-pointer"
                >
                  {copiedField === "authorsText" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            )}

            {/* 9. Technical Details: Duration & Date */}
            <div className="grid grid-cols-2 gap-2.5">
              {details?.releaseDate && (
                <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Calendar className="w-3 h-3 text-white/40" />
                    <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                      {t("Release Date", "Дата выхода")}
                    </p>
                  </div>
                  <p className="text-white font-medium text-xs sm:text-sm select-all">
                    {new Date(details.releaseDate).toLocaleDateString("ru-RU")}
                  </p>
                </div>
              )}

              {formattedDuration && (
                <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-3">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Clock className="w-3 h-3 text-white/40" />
                    <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">
                      {t("Duration", "Длительность")}
                    </p>
                  </div>
                  <p className="text-white font-medium text-xs sm:text-sm select-all font-mono">
                    {formattedDuration} • Lossless
                  </p>
                </div>
              )}
            </div>

            {/* 10. Video Snapshot & Clips (Яндекс Музыка) */}
            <div className="bg-white/[0.04] border border-purple-500/20 rounded-2xl p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                    <Film className="w-3.5 h-3.5" />
                  </div>
                  <p className="text-white font-bold text-xs uppercase tracking-wider">
                    Видео-снапшот и клипы
                  </p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                  Яндекс Музыка
                </span>
              </div>

              {loadingSnapshot ? (
                <div className="flex items-center gap-2 py-3 text-white/50 text-xs">
                  <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                  <span>Проверка видеошота...</span>
                </div>
              ) : snapshotData?.hasVideoSnapshot ? (
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span className="font-medium">
                      Официальный видеошот доступен для этого трека
                    </span>
                  </div>

                  {/* Video preview & direct download button */}
                  <div className="flex flex-col sm:flex-row items-center gap-3 bg-black/40 p-3 rounded-xl border border-white/5">
                    {snapshotData.videoSnapshot?.streamUrl && (
                      <div 
                        onClick={() => setIsVideoSnapshotModalOpen(true)}
                        className="w-24 sm:w-28 aspect-[9/16] rounded-xl overflow-hidden shrink-0 border border-white/15 bg-black shadow-md cursor-pointer relative group hover:scale-[1.03] transition-transform"
                        title="Нажмите, чтобы открыть видеошот на весь экран"
                      >
                        <video
                          src={snapshotData.videoSnapshot.streamUrl}
                          autoPlay
                          loop
                          muted
                          playsInline
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 flex items-center justify-center transition-colors">
                          <div className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white border border-white/20">
                            <Maximize2 className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      </div>
                    )}
                    <div className="flex-1 min-w-0 text-center sm:text-left">
                      <p className="text-white text-xs font-semibold mb-1 flex items-center justify-center sm:justify-start gap-1.5">
                        <span>Оригинальный видеошот 9:16</span>
                      </p>
                      <p className="text-white/50 text-[11px] leading-relaxed mb-3">
                        Оригинальный вертикальный видеофайл в формате MP4 для воспроизведения в Яндекс Музыке.
                      </p>
                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                        <button
                          onClick={() => setIsVideoSnapshotModalOpen(true)}
                          className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white transition-all border border-white/10 active:scale-95 cursor-pointer"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                          <span>Смотреть полностью</span>
                        </button>
                        <button
                          onClick={() => handleDownloadSnapshot(snapshotData.videoSnapshot?.downloadUrl, 'snapshot')}
                          disabled={isDownloadingSnapshot}
                          className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all shadow-md active:scale-95 cursor-pointer ${
                            snapshotDownloadSuccess
                              ? 'bg-emerald-500 text-white'
                              : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-900/30'
                          }`}
                        >
                          {isDownloadingSnapshot ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : snapshotDownloadSuccess ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Скачано!</span>
                            </>
                          ) : (
                            <>
                              <Download className="w-3.5 h-3.5" />
                              <span>Скачать MP4</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : snapshotData?.clips && snapshotData.clips.length > 0 ? (
                <div className="flex flex-col gap-2.5">
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/25 text-blue-300 text-xs">
                    <Film className="w-4 h-4 shrink-0 text-blue-400" />
                    <span className="font-medium">
                      Видео-снапшот 9:16 не загружен, но доступен официальный видеоклип
                    </span>
                  </div>

                  {snapshotData.clips.map((clip: any, idx: number) => (
                    <div key={clip.clipId || idx} className="flex items-center justify-between gap-3 p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <div className="min-w-0">
                        <p className="text-white text-xs font-semibold truncate">{clip.title || `Клип #${idx + 1}`}</p>
                        {clip.duration && <p className="text-white/40 text-[10px]">{Math.floor(clip.duration / 60)}:{(clip.duration % 60).toString().padStart(2, '0')}</p>}
                      </div>
                      {clip.downloadUrl && (
                        <button
                          onClick={() => handleDownloadSnapshot(clip.downloadUrl, 'clip')}
                          className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Скачать клип (MP4)</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white/5 border border-white/5 text-white/50 text-xs">
                  <AlertCircle className="w-4 h-4 text-white/40 shrink-0" />
                  <span>
                    Видеошот отсутствует для данного трека в Яндекс Музыке.
                  </span>
                </div>
              )}
            </div>

          </div>

          {/* Quick Action Footer */}
          <div className="p-3.5 sm:p-4 border-t border-white/10 bg-[#161e2a] flex flex-wrap items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2 flex-1 min-w-[240px]">
              {/* Play Track */}
              {onPlayTrack && (
                <button
                  onClick={() => {
                    onPlayTrack(track);
                    onClose();
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 active:scale-95 text-white font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{t("Play", "Слушать")}</span>
                </button>
              )}

              {/* Download WAV */}
              <button
                onClick={handleDownloadWav}
                disabled={isDownloadingWav}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-semibold text-xs sm:text-sm transition-all border border-white/10 cursor-pointer disabled:opacity-50"
                title={t("Download lossless audio", "Скачать трек в формате WAV")}
              >
                {isDownloadingWav ? (
                  <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                <span>WAV</span>
              </button>

              {/* Download Cover */}
              <button
                onClick={handleDownloadCover3000}
                disabled={isDownloadingCover}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-semibold text-xs sm:text-sm transition-all border border-white/10 cursor-pointer disabled:opacity-50"
                title={t("Download 3000x3000px cover", "Скачать обложку 3000×3000")}
              >
                {isDownloadingCover ? (
                  <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                ) : coverDownloadSuccess ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <ImageIcon className="w-4 h-4" />
                )}
                <span className="hidden sm:inline">3000×3000</span>
              </button>

              {/* Export as PDF */}
              <button
                id="btn-track-info-export-pdf"
                onClick={handleExportPdf}
                disabled={isExportingPdf}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-rose-300 hover:text-white active:scale-95 font-semibold text-xs sm:text-sm transition-all border border-red-500/30 cursor-pointer disabled:opacity-50"
                title={t("Export release sheet as PDF", "Экспорт паспорта релиза в PDF")}
              >
                {isExportingPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin text-rose-300" />
                ) : (
                  <FileCheck className="w-4 h-4 text-rose-400" />
                )}
                <span>PDF</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white font-semibold text-xs sm:text-sm transition-colors cursor-pointer ml-auto"
            >
              {t("Close", "Закрыть")}
            </button>
          </div>

        </motion.div>
      </div>

      {/* Full-Screen Video Snapshot Modal */}
      <VideoSnapshotModal
        track={track}
        isOpen={isVideoSnapshotModalOpen}
        onClose={() => setIsVideoSnapshotModalOpen(false)}
        onPlayTrack={onPlayTrack}
        onOpenStudio={(trackInfo) => window.dispatchEvent(new CustomEvent('openVideoShotStudio', { detail: trackInfo }))}
      />
    </AnimatePresence>
  );
}
