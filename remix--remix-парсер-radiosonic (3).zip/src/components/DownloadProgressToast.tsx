import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, CheckCircle2, AlertCircle, Loader2, X, Music } from 'lucide-react';
import { subscribeDownloadState, DownloadState } from '../utils/audioDownloader';

interface DownloadProgressToastProps {
  t: (en: string, ru: string) => string;
}

export const DownloadProgressToast: React.FC<DownloadProgressToastProps> = ({ t }) => {
  const [state, setState] = useState<DownloadState>({
    isDownloading: false,
    loadedBytes: 0,
    totalBytes: 0,
    status: 'idle',
  });

  useEffect(() => {
    return subscribeDownloadState((newState) => {
      setState(newState);
    });
  }, []);

  const isVisible = state.status !== 'idle';

  const formatBytes = (bytes: number): string => {
    if (bytes <= 0) return '';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.aside
          aria-label="Download notification"
          initial={{ opacity: 0, y: 40, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="fixed bottom-24 sm:bottom-6 right-4 sm:right-6 z-50 max-w-sm w-[calc(100vw-2rem)] sm:w-96 rounded-2xl bg-zinc-900/95 dark:bg-[#18181b]/95 text-white backdrop-blur-xl border border-white/10 shadow-2xl p-4 overflow-hidden"
        >
          {/* Subtle animated gradient background accent */}
          <div className="absolute -top-12 -left-12 w-28 h-28 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -right-12 w-28 h-28 bg-blue-500/20 rounded-full blur-2xl pointer-events-none" />

          <div className="relative flex items-start gap-3">
            {/* Status Icon with animation */}
            <div className="relative flex-shrink-0 mt-0.5">
              {state.status === 'completed' ? (
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <CheckCircle2 className="w-5 h-5 animate-bounce" />
                </div>
              ) : state.status === 'error' ? (
                <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/30">
                  <AlertCircle className="w-5 h-5" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30 relative overflow-hidden">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {/* Equalizer animation waves */}
                  <div className="absolute bottom-1 flex items-end gap-0.5 h-2">
                    <span className="w-0.5 bg-purple-400 animate-pulse h-1" />
                    <span className="w-0.5 bg-purple-400 animate-pulse h-2" style={{ animationDelay: '150ms' }} />
                    <span className="w-0.5 bg-purple-400 animate-pulse h-1.5" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
            </div>

            {/* Content info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="inline-block text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-purple-500/30 text-purple-300 border border-purple-400/20">
                    WAV Lossless
                  </span>
                  <span className="text-xs text-zinc-400 truncate">
                    {state.status === 'preparing' && t('Preparing...', 'Подготовка...')}
                    {state.status === 'converting' && t('Transcoding...', 'Конвертация в 44.1kHz...')}
                    {state.status === 'downloading' && t('Downloading...', 'Скачивание аудио...')}
                    {state.status === 'completed' && t('Ready & Saved', 'Скачано и сохранено!')}
                    {state.status === 'error' && t('Download Error', 'Ошибка скачивания')}
                  </span>
                </div>
              </div>

              <div className="font-semibold text-sm text-zinc-100 truncate mt-1">
                {state.title || t('Track', 'Трек')}
              </div>
              {state.artists && (
                <div className="text-xs text-zinc-400 truncate">
                  {state.artists}
                </div>
              )}

              {/* Progress bar or animated streaming bar */}
              {state.status !== 'completed' && state.status !== 'error' && (
                <div className="mt-2.5 space-y-1">
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden relative">
                    {state.progress !== undefined && state.progress >= 0 ? (
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-300 ease-out"
                        style={{ width: `${Math.max(5, state.progress)}%` }}
                      />
                    ) : (
                      <div className="h-full bg-gradient-to-r from-purple-500 via-indigo-400 to-purple-500 w-1/2 rounded-full animate-[shimmer_1.5s_infinite] relative left-0" />
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-zinc-400 font-mono pt-0.5">
                    <span>
                      {state.loadedBytes > 0 ? formatBytes(state.loadedBytes) : '16-bit PCM'}
                    </span>
                    <span>
                      {state.progress !== undefined && state.progress > 0
                        ? `${state.progress}%`
                        : state.status === 'converting'
                        ? '44.1 kHz'
                        : 'Streaming...'}
                    </span>
                  </div>
                </div>
              )}

              {state.status === 'error' && state.errorMessage && (
                <p className="text-xs text-rose-300 mt-1 leading-snug break-words">
                  {state.errorMessage}
                </p>
              )}
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
};
