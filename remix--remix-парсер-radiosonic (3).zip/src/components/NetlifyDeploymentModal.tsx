import React, { useState } from 'react';
import { 
  Cloud, ExternalLink, Copy, Check, 
  Database
} from 'lucide-react';

export function NetlifyDeploymentModal({
  isOpen,
  onClose,
  t
}: {
  isOpen: boolean;
  onClose: () => void;
  t?: (en: string, ru: string) => string;
}) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2200);
  };

  const netlifyEnvSnippet = `VITE_SUPABASE_URL=https://oeurpptqbkuxyqyfaahj.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_d4xsXd0ZQW8KUKWGHyOF0g_vXbj_mFo
BACKEND_API_URL=https://ais-dev-i7wri7sns2xsauvagu3rfk-535024170731.europe-west2.run.app`;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#0f1117] border-2 border-teal-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl text-left space-y-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#00AD9F]/10 border-2 border-[#00AD9F]/40 flex items-center justify-center text-[#00C7B7] shrink-0 shadow-lg">
              {/* Netlify Logo */}
              <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor">
                <path d="M6.48 2.052a.762.762 0 0 0-.583.275l-4.7 5.752a.763.763 0 0 0-.083.824l6.095 12.833a.76.76 0 0 0 .685.438.76.76 0 0 0 .684-.438l6.095-12.833a.763.763 0 0 0-.083-.824L9.89 2.327a.76.76 0 0 0-.583-.275H6.48zM12 2.174l2.946 5.892-2.946 5.892-2.946-5.892L12 2.174zm4.127.153a.76.76 0 0 1 .583.275l4.7 5.752a.763.763 0 0 1 .083.824l-6.095 12.833a.76.76 0 0 1-.685.438V2.327h1.414z"/>
              </svg>
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-xs font-black uppercase tracking-wider mb-1 border border-teal-500/40">
                <Cloud className="w-3 h-3" />
                <span>Netlify Cloud & ZIP Деплой</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Инструкция: Запуск на Netlify + Свой домен
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* 3-Step Guide */}
        <div className="space-y-4 text-xs sm:text-sm">
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-700 space-y-2">
            <div className="flex items-center gap-2 text-teal-400 font-extrabold text-sm">
              <span className="w-6 h-6 rounded-full bg-teal-500/20 flex items-center justify-center border border-teal-400/30 text-xs">1</span>
              <span>Деплой из ZIP / Git на Netlify</span>
            </div>
            <p className="text-zinc-300 leading-relaxed pl-8">
              В проекте уже настроен файл <code className="bg-black px-2 py-0.5 rounded border border-zinc-700 font-mono text-teal-300">netlify.toml</code> и правила редиректов <code className="bg-black px-2 py-0.5 rounded border border-zinc-700 font-mono text-teal-300">_redirects</code>.
            </p>
            <div className="pl-8 space-y-1.5 text-zinc-400">
              <p>• <b>Вариант А (Через Git):</b> Загрузите код в GitHub / GitLab и подключите репозиторий в панели Netlify. Сборка выполнится автоматически: <code className="bg-black px-1.5 py-0.5 rounded text-white font-mono">npm run build</code>, папка публикации: <code className="bg-black px-1.5 py-0.5 rounded text-white font-mono">dist</code>.</p>
              <p>• <b>Вариант Б (Netlify Drop):</b> Распакуйте ZIP, выполните <code className="bg-black px-1.5 py-0.5 rounded text-white font-mono">npm run build</code> и перетащите папку <code className="bg-black px-1.5 py-0.5 rounded text-teal-300 font-mono">dist</code> прямо в окно <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-teal-400 underline font-semibold">Netlify Drop</a> для мгновенного запуска без Git.</p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-teal-400 font-extrabold text-sm">
                <span className="w-6 h-6 rounded-full bg-teal-500/20 flex items-center justify-center border border-teal-400/30 text-xs">2</span>
                <span>Переменные окружения (Environment Variables в Netlify)</span>
              </div>
              <button
                onClick={() => handleCopy(netlifyEnvSnippet, 'env')}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-teal-300 border border-zinc-700 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedKey === 'env' ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'env' ? 'Скопировано!' : 'Копировать все'}</span>
              </button>
            </div>
            <p className="text-zinc-300 leading-relaxed pl-8">
              В панели проекта Netlify перейдите в <b>Site configuration &rarr; Environment variables &rarr; Add a variable</b>:
            </p>
            <div className="bg-black p-3.5 rounded-xl border border-zinc-800 font-mono text-xs text-zinc-300 space-y-1.5 overflow-x-auto ml-8">
              <div><span className="text-teal-400 font-bold">VITE_SUPABASE_URL</span> = https://oeurpptqbkuxyqyfaahj.supabase.co</div>
              <div><span className="text-teal-400 font-bold">VITE_SUPABASE_ANON_KEY</span> = sb_publishable_d4xsXd0ZQW8KUKWGHyOF0g_vXbj_mFo</div>
              <div><span className="text-purple-400 font-bold">BACKEND_API_URL</span> = https://ais-dev-i7wri7sns2xsauvagu3rfk-535024170731.europe-west2.run.app</div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-700 space-y-2">
            <div className="flex items-center gap-2 text-teal-400 font-extrabold text-sm">
              <span className="w-6 h-6 rounded-full bg-teal-500/20 flex items-center justify-center border border-teal-400/30 text-xs">3</span>
              <span>Подключение кастомного домена (Custom Domain)</span>
            </div>
            <p className="text-zinc-300 leading-relaxed pl-8">
              В Netlify перейдите в <b>Domain management &rarr; Add a domain</b>, введите ваше доменное имя (например, <code className="bg-black px-1.5 py-0.5 rounded text-white font-mono">music.yourdomain.com</code>). В настройках DNS вашего регистратора добавьте CNAME запись на ваш адрес <code className="bg-black px-1.5 py-0.5 rounded text-teal-300 font-mono">*.netlify.app</code>. Netlify автоматически выдаст бесплатный SSL Let's Encrypt!
            </p>
          </div>
        </div>

        {/* Cloud Architecture diagram / info */}
        <div className="p-4 rounded-2xl bg-black border-2 border-teal-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Database className="w-8 h-8 text-teal-400 shrink-0" />
            <div className="text-xs">
              <p className="font-bold text-white">Облако Supabase + Netlify Edge CDN + Google Cloud</p>
              <p className="text-zinc-400">Маршрутизация API /api/* автоматически проксируется через Netlify Edge на сервер Google Cloud Run, а данные хранятся в облаке Supabase.</p>
            </div>
          </div>
          <a
            href="https://app.netlify.com/"
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-black font-extrabold text-xs flex items-center gap-2 shrink-0 transition-all cursor-pointer shadow-md"
          >
            <span>Открыть Netlify</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
}
