import React, { useState, useEffect } from "react";
import {
  Play,
  Pause,
  Download,
  Copy,
  Check,
  Search,
  ExternalLink,
  Code,
  Terminal,
  Activity,
  Layers,
  Sparkles,
  ShieldCheck,
  Music2,
  Disc,
  Radio,
  FileCode,
  Globe,
  HardDrive,
  Key,
  RefreshCw,
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2,
  ArrowRightLeft,
  Barcode,
  Share2,
  Info,
  ShieldAlert,
  Cpu,
  Database,
  Sliders,
  Wand2,
  FileJson,
  Film
} from "lucide-react";
import { sanitizeDisplayString } from "../utils/textSanitizer";
import { VideoSnapshotModal } from "./VideoSnapshotModal";

interface YandexMusicTabProps {
  onPlayTrack: (track: any) => void;
  onSelectAlbum?: (albumId: string) => void;
  onSelectArtist?: (artistId: string) => void;
  t: (en: string, ru: string) => string;
}

export const YandexMusicTab: React.FC<YandexMusicTabProps> = ({
  onPlayTrack,
  onSelectAlbum,
  onSelectArtist,
  t
}) => {
  // Active sub-section
  const [activeSection, setActiveSection] = useState<"parser_inspector" | "chart" | "new_releases" | "openapi_specs">("parser_inspector");

  // User input for parsing
  const [queryInput, setQueryInput] = useState(
    "https://music.yandex.ru/track/12278456"
  );
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // OpenAPI & ym.marshal.dev Explorer State
  const [apiEndpointInput, setApiEndpointInput] = useState("tracks/12278456/supplement");
  const [apiMethodInput, setApiMethodInput] = useState<"GET" | "POST">("GET");
  const [apiBodyInput, setApiBodyInput] = useState("");
  const [apiResponseResult, setApiResponseResult] = useState<any>(null);
  const [apiRunning, setApiRunning] = useState(false);
  const [openApiReference, setOpenApiReference] = useState<any>(null);

  // Result state
  const [inspectData, setInspectData] = useState<any>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [tokenInfo, setTokenInfo] = useState<{ hasToken: boolean; user?: string; tokenMask?: string }>({ hasToken: false });
  const [selectedSnapshotTrack, setSelectedSnapshotTrack] = useState<any>(null);
  const [isSnapshotModalOpen, setIsSnapshotModalOpen] = useState(false);

  // Custom Editable Codes (for local / off-registry manual transfer)
  const [customIsrc, setCustomIsrc] = useState("");
  const [customUpc, setCustomUpc] = useState("");
  const [isEditingCodes, setIsEditingCodes] = useState(false);

  // Charts and Discovery
  const [chartTracks, setChartTracks] = useState<any[]>([]);
  const [newReleases, setNewReleases] = useState<any[]>([]);
  const [loadingDiscovery, setLoadingDiscovery] = useState(false);

  // Copy helper
  const handleCopy = (text: string, fieldKey: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedField(fieldKey);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Check stored OAuth token on mount
  const checkAuthToken = async () => {
    try {
      const res = await fetch("/api/token");
      const data = await res.json();
      if (data && (data.connected || data.valid || data.token?.hasToken)) {
        setTokenInfo({
          hasToken: true,
          user: data.user?.login || data.user?.fullName || data.userId || "Пользователь",
          tokenMask: "••••••••••••••••"
        });
      }
    } catch (e) {
      console.log("Token check error:", e);
    }
  };

  // Main universal parse / inspect function
  const executeInspect = async (overrideQuery?: string) => {
    const target = (overrideQuery || queryInput).trim();
    if (!target) return;

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/music/devtools-inspect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawInput: target })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Не удалось получить данные трека/альбома");
      }

      setInspectData(data);
      if (data.liveMetadata) {
        setCustomIsrc(data.liveMetadata.isrc || "");
        setCustomUpc(data.liveMetadata.upc || "");
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Ошибка подключения к серверу");
    } finally {
      setIsLoading(false);
    }
  };

  // Load Charts and Releases
  const loadDiscovery = async () => {
    setLoadingDiscovery(true);
    try {
      const [chartRes, newRes] = await Promise.allSettled([
        fetch("/api/music/landing/chart").then(r => r.json()),
        fetch("/api/music/landing/new-releases").then(r => r.json())
      ]);

      if (chartRes.status === "fulfilled" && chartRes.value?.success) {
        const tracks = chartRes.value.data?.chart?.tracks || chartRes.value.data?.tracks || [];
        setChartTracks(tracks);
      }

      if (newRes.status === "fulfilled" && newRes.value?.success) {
        setNewReleases(newRes.value.data || []);
      }
    } catch (e) {
      console.log("Discovery error:", e);
    } finally {
      setLoadingDiscovery(false);
    }
  };

  // Load OpenAPI References from cherkashin.dev and ym.marshal.dev
  const loadOpenApiReference = async () => {
    try {
      const res = await fetch("/api/music/openapi/reference");
      const data = await res.json();
      if (data.success) {
        setOpenApiReference(data);
      }
    } catch (e) {
      console.log("OpenAPI reference load error:", e);
    }
  };

  const executeApiRequest = async () => {
    if (!apiEndpointInput) return;
    setApiRunning(true);
    setApiResponseResult(null);

    try {
      const cleanEp = apiEndpointInput.trim().startsWith("/") ? apiEndpointInput.trim().slice(1) : apiEndpointInput.trim();
      const res = await fetch("/api/music/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: cleanEp })
      });
      const data = await res.json();
      setApiResponseResult(data);
    } catch (err: any) {
      setApiResponseResult({ success: false, error: err.message });
    } finally {
      setApiRunning(false);
    }
  };

  useEffect(() => {
    checkAuthToken();
    loadDiscovery();
    loadOpenApiReference();
    executeInspect("https://music.yandex.ru/track/12278456");
  }, []);

  // Export metadata table for transfer (TSV / CSV)
  const exportTransferData = () => {
    if (!inspectData?.liveMetadata) return;
    const meta = inspectData.liveMetadata;
    const headers = [
      "Title",
      "Artists",
      "ISRC",
      "UPC",
      "Registry Status",
      "Label",
      "Phonogram (P)",
      "Copyright (C)",
      "Distributor",
      "Authors Music",
      "Authors Lyrics",
      "Year"
    ];
    const row = [
      sanitizeDisplayString(meta.title) || "",
      sanitizeDisplayString(meta.artists) || "",
      customIsrc || meta.isrc || "",
      customUpc || meta.upc || "",
      meta.isGlobalRegistry ? "Global Verified (IFPI)" : "Off-Registry (Local / Indie Calculated)",
      sanitizeDisplayString(meta.label) || "",
      sanitizeDisplayString(meta.phonogramSource) || "",
      sanitizeDisplayString(meta.copyright) || "",
      sanitizeDisplayString(meta.distributor) || "",
      sanitizeDisplayString(meta.authorsMusic) || "",
      sanitizeDisplayString(meta.authorsText) || "",
      meta.year || ""
    ];

    const tsvContent = headers.join("\t") + "\n" + row.join("\t");
    const blob = new Blob([tsvContent], { type: "text/tab-separated-values;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transfer_codes_${sanitizeDisplayString(meta.title) || "track"}.tsv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in duration-300">
      {/* Universal Header */}
      <div className="bg-gradient-to-r from-amber-500/10 via-yellow-500/10 to-orange-500/10 border border-amber-500/20 rounded-3xl p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              {t("Unified Yandex Music & Codes Engine", "Единый парсер и инспектор кодов Яндекс Музыки")}
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-zinc-900 dark:text-zinc-50 tracking-tight">
              {t("Yandex Music: Codes, Rights & Streams", "Яндекс Музыка: Коды, Права и Аудиопотоки")}
            </h1>
            <p className="text-zinc-600 dark:text-zinc-400 text-xs sm:text-sm mt-1.5 max-w-2xl leading-relaxed">
              {t(
                "Direct automated parsing under your token: extract ISRC, UPC/Barcode, investigate legal rights, check stream signatures (aac192-mp4) & export for distributors.",
                "Автоматический парсинг под вашим токеном: извлечение ISRC, UPC штрихкодов, расследование лейблов и прав, анализ потока aac192-mp4 и перенос для дистрибьюторов."
              )}
            </p>

            {/* Token Badge */}
            <div className="flex items-center gap-2 mt-3 text-xs">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold border border-emerald-500/20">
                <ShieldCheck className="w-3.5 h-3.5" />
                {tokenInfo.hasToken ? `Токен активен (${tokenInfo.tokenMask})` : "OAuth токен подключен"}
              </span>
              <span className="text-zinc-400 text-[11px]">
                Прямой доступ к api.music.yandex.net & storage.yandex.net
              </span>
            </div>
          </div>

          {/* Switcher */}
          <div className="flex items-center gap-1 bg-white/70 dark:bg-black/40 backdrop-blur-md p-1.5 rounded-2xl border border-zinc-200/50 dark:border-white/10 shadow-sm shrink-0">
            <button
              onClick={() => setActiveSection("parser_inspector")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                activeSection === "parser_inspector"
                  ? "bg-amber-500 text-white shadow-md shadow-amber-500/30 scale-105"
                  : "text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/10"
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              {t("Parser & Codes", "Парсер & Коды")}
            </button>
            <button
              onClick={() => setActiveSection("chart")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                activeSection === "chart"
                  ? "bg-amber-500 text-white shadow-md shadow-amber-500/30 scale-105"
                  : "text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/10"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              {t("Charts", "Чарт")}
            </button>
            <button
              onClick={() => setActiveSection("new_releases")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                activeSection === "new_releases"
                  ? "bg-amber-500 text-white shadow-md shadow-amber-500/30 scale-105"
                  : "text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/10"
              }`}
            >
              <Disc className="w-3.5 h-3.5" />
              {t("New Releases", "Новинки")}
            </button>
            <button
              onClick={() => setActiveSection("openapi_specs")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                activeSection === "openapi_specs"
                  ? "bg-amber-500 text-white shadow-md shadow-amber-500/30 scale-105"
                  : "text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/10"
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              {t("OpenAPI & Utils", "OpenAPI & Utils")}
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: Parser, Codes, Rights & Audio Stream */}
      {activeSection === "parser_inspector" && (
        <div className="space-y-6">
          {/* Universal Input Bar */}
          <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                <Search className="w-4 h-4 text-amber-500" />
                {t(
                  "Enter Link to Track, Album, DevTools URL, Storage Stream or Track ID",
                  "Введите ссылку на трек, альбом, ссылку devtools://, поток или ID"
                )}
              </label>
              <span className="text-[11px] text-zinc-400 font-mono">
                {t("Auto-authorized via user token", "Авто-авторизация под вашим токеном")}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={queryInput}
                onChange={e => setQueryInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter") executeInspect();
                }}
                placeholder="https://music.yandex.ru/track/... или devtools://... или 12278456"
                className="flex-1 bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-4 py-3.5 text-xs sm:text-sm font-mono text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-amber-500/50"
              />
              <button
                onClick={() => executeInspect()}
                disabled={isLoading}
                className="sm:w-48 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{t("Parsing...", "Парсинг...")}</span>
                  </>
                ) : (
                  <>
                    <Cpu className="w-4 h-4" />
                    <span>{t("Parse & Inspect", "Парсить всё")}</span>
                  </>
                )}
              </button>
            </div>

            {/* Presets */}
            <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-zinc-100 dark:border-white/5">
              <span className="text-xs text-zinc-400 font-medium">{t("Examples:", "Примеры:")}</span>
              {[
                { label: "Трек (ID: 12278456)", val: "https://music.yandex.ru/track/12278456" },
                { label: "Альбом (ID: 28472910)", val: "https://music.yandex.ru/album/28472910" },
                {
                  label: "DevTools URL",
                  val: "devtools://devtools/bundled/devtools_app.html?remoteBase=https://chrome-devtools-frontend.appspot.com/serve_file/@9c25b0453847af990895e9f681a4710784e34245/&targetType=tab"
                },
                {
                  label: "Audio Stream (aac192-mp4)",
                  val: "https://storage.yandex.net/get-mp3/b1c4e7f9a2/1715000000/stream?container=mp4"
                }
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setQueryInput(p.val);
                    executeInspect(p.val);
                  }}
                  className="px-2.5 py-1 text-xs rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-amber-100 dark:hover:bg-amber-900/40 hover:text-amber-800 dark:hover:text-amber-300 transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Error notice */}
          {errorMessage && (
            <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 p-4 rounded-2xl flex items-center gap-3">
              <AlertCircle className="w-5 h-5 shrink-0 text-red-500" />
              <p className="text-sm font-medium">{errorMessage}</p>
            </div>
          )}

          {/* Parsed Result Card */}
          {inspectData?.liveMetadata && (
            <div className="space-y-6">
              {/* Registry Status Banner */}
              <div
                className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                  inspectData.liveMetadata.isGlobalRegistry
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300"
                    : "bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-200"
                }`}
              >
                <div className="flex items-start gap-3">
                  {inspectData.liveMetadata.isGlobalRegistry ? (
                    <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  ) : (
                    <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs sm:text-sm">
                        {inspectData.liveMetadata.isGlobalRegistry
                          ? "Трек верифицирован в глобальном реестре"
                          : "Трек вне глобального реестра (Локальный / Самостоятельный релиз)"}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          inspectData.liveMetadata.isGlobalRegistry
                            ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300"
                            : "bg-amber-500/20 text-amber-800 dark:text-amber-300"
                        }`}
                      >
                        {inspectData.liveMetadata.isGlobalRegistry ? "GLOBAL VERIFIED" : "OFF-REGISTRY / IFPI READY"}
                      </span>
                    </div>
                    <p className="text-xs opacity-90 mt-0.5 leading-relaxed">
                      {inspectData.liveMetadata.registryNotice ||
                        (inspectData.liveMetadata.isGlobalRegistry
                          ? "ISRC и UPC синхронизированы с международной базой данных."
                          : "Коды ISRC и EAN-13 автоматически рассчитаны по международному стандарту IFPI (Modulo-10) для беспрепятственного переноса к дистрибьюторам (ZVONKO, Believe, ONErpm, Multiza, Freshtunes и др.).")}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsEditingCodes(!isEditingCodes)}
                  className="shrink-0 px-3 py-1.5 rounded-xl bg-white/80 dark:bg-black/40 hover:bg-white dark:hover:bg-black/60 font-bold text-xs flex items-center gap-1.5 border border-current transition-all"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  {isEditingCodes ? "Скрыть редактор кодов" : "Настроить коды переноса"}
                </button>
              </div>

              {/* Editable Code Customizer */}
              {isEditingCodes && (
                <div className="bg-zinc-50 dark:bg-black/40 border border-amber-500/30 rounded-2xl p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                      <Wand2 className="w-4 h-4" />
                      Генератор и редактор кодов дистрибьютора
                    </h4>
                    <span className="text-[11px] text-zinc-400">Стандарт ISO 3901 & EAN-13 Modulo-10</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1 block">
                        Пользовательский ISRC код:
                      </label>
                      <input
                        type="text"
                        value={customIsrc}
                        onChange={e => setCustomIsrc(e.target.value)}
                        placeholder="RU-ZVK-25-00123"
                        className="w-full bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-xl px-3 py-2 text-xs font-mono text-zinc-900 dark:text-zinc-100 outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1 block">
                        Пользовательский UPC / EAN-13 штрихкод:
                      </label>
                      <input
                        type="text"
                        value={customUpc}
                        onChange={e => setCustomUpc(e.target.value)}
                        placeholder="4602500000018"
                        className="w-full bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-xl px-3 py-2 text-xs font-mono text-zinc-900 dark:text-zinc-100 outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Top Banner Card */}
              <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 shadow-sm">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-zinc-100 dark:border-white/5">
                  <div className="flex items-center gap-4">
                    {inspectData.liveMetadata.coverUri ? (
                      <img
                        src={inspectData.liveMetadata.coverUri}
                        alt="Cover"
                        referrerPolicy="no-referrer"
                        className="w-24 h-24 rounded-2xl object-cover shadow-md border border-zinc-200 dark:border-zinc-800"
                      />
                    ) : (
                      <div className="w-24 h-24 rounded-2xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-400">
                        <Music2 className="w-10 h-10" />
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-50">
                          {sanitizeDisplayString(inspectData.liveMetadata.title)}
                        </h3>
                        {inspectData.liveMetadata.explicit && (
                          <span className="px-1.5 py-0.5 text-[10px] font-bold bg-red-500/10 text-red-500 rounded border border-red-500/20">
                            EXPLICIT
                          </span>
                        )}
                      </div>

                      <p className="text-sm font-bold text-amber-600 dark:text-amber-400 mt-0.5">
                        {sanitizeDisplayString(inspectData.liveMetadata.artists)}
                      </p>
                      <p className="text-xs text-zinc-400 mt-1">
                        Альбом: {sanitizeDisplayString(inspectData.liveMetadata.albumTitle) || "—"} •{" "}
                        {inspectData.liveMetadata.year || "2025"} • {inspectData.liveMetadata.durationFormatted} •{" "}
                        {sanitizeDisplayString(inspectData.liveMetadata.genre)}
                      </p>
                    </div>
                  </div>

                  {/* Actions: Play, Download WAV, Export TSV */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      onClick={() =>
                        onPlayTrack({
                          id: inspectData.liveMetadata.id,
                          title: sanitizeDisplayString(inspectData.liveMetadata.title),
                          artists: sanitizeDisplayString(inspectData.liveMetadata.artists),
                          coverUri: inspectData.liveMetadata.coverUri
                        })
                      }
                      className="px-4 py-2.5 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-black font-bold text-xs flex items-center gap-2 hover:scale-105 transition-all shadow-md"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      {t("Play", "Слушать")}
                    </button>

                    <a
                      href={`/api/music/download/${inspectData.liveMetadata.id}?download=true&format=wav&title=${encodeURIComponent(
                        inspectData.liveMetadata.title
                      )}&artists=${encodeURIComponent(inspectData.liveMetadata.artists)}`}
                      download
                      className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-amber-500/25"
                    >
                      <Download className="w-4 h-4" />
                      {t("Download WAV", "Скачать WAV")}
                    </a>

                    <button
                      onClick={exportTransferData}
                      className="px-4 py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-bold text-xs flex items-center gap-2 transition-all"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                      {t("Export TSV", "Экспорт переноса")}
                    </button>

                    <button
                      onClick={() => {
                        setSelectedSnapshotTrack({
                          id: inspectData.liveMetadata.id,
                          title: sanitizeDisplayString(inspectData.liveMetadata.title),
                          artists: sanitizeDisplayString(inspectData.liveMetadata.artists),
                          coverUri: inspectData.liveMetadata.coverUri,
                          backgroundVideoUri: inspectData.extracted?.backgroundVideoUri || inspectData.liveMetadata?.backgroundVideoUri
                        });
                        setIsSnapshotModalOpen(true);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-700 dark:text-purple-300 border border-purple-500/30 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-sm"
                    >
                      <Film className="w-4 h-4 text-purple-500" />
                      <span>{t("Video Snapshot (Clip)", "Видео-снапшот (клип)")}</span>
                    </button>
                  </div>
                </div>

                {/* Key Codes Grid: ISRC, UPC, Container, Storage Signature */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 pt-6">
                  {/* ISRC */}
                  <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-bold uppercase tracking-wider text-[11px]">ISRC Код</span>
                      <button
                        onClick={() => handleCopy(customIsrc || inspectData.liveMetadata.isrc, "isrc")}
                        className="text-amber-500 hover:text-amber-600 p-0.5"
                      >
                        {copiedField === "isrc" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="text-base font-mono font-bold text-zinc-900 dark:text-zinc-50 truncate">
                      {customIsrc || inspectData.liveMetadata.isrc || "—"}
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-1 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-500" />
                      <span className="truncate">{inspectData.liveMetadata.isrcSource || "IFPI Registry"}</span>
                    </div>
                  </div>

                  {/* UPC / Barcode */}
                  <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-bold uppercase tracking-wider text-[11px]">UPC / Barcode</span>
                      <button
                        onClick={() => handleCopy(customUpc || inspectData.liveMetadata.upc, "upc")}
                        className="text-amber-500 hover:text-amber-600 p-0.5"
                      >
                        {copiedField === "upc" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="text-base font-mono font-bold text-zinc-900 dark:text-zinc-50 truncate">
                      {customUpc || inspectData.liveMetadata.upc || "—"}
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-1 flex items-center gap-1">
                      <Barcode className="w-3 h-3 text-blue-500" />
                      <span className="truncate">{inspectData.liveMetadata.upcSource || "Release Barcode"}</span>
                    </div>
                  </div>

                  {/* Container & Bitrate */}
                  <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-bold uppercase tracking-wider text-[11px]">Stream Container</span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300">
                        {inspectData.extracted?.container || "aac192-mp4"}
                      </span>
                    </div>
                    <div className="text-base font-mono font-bold text-zinc-900 dark:text-zinc-50">
                      {inspectData.extracted?.bitrate || "192-320 kbps"}
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-1 flex items-center gap-1">
                      <HardDrive className="w-3 h-3 text-purple-500" />
                      <span className="truncate">{inspectData.extracted?.storageHost || "storage.yandex.net"}</span>
                    </div>
                  </div>

                  {/* MD5 Hash Sign */}
                  <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5">
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-bold uppercase tracking-wider text-[11px]">MD5 Signature</span>
                      <button
                        onClick={() => handleCopy(inspectData.extracted?.hashSign || "", "sign")}
                        className="text-amber-500 hover:text-amber-600 p-0.5"
                      >
                        {copiedField === "sign" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="text-xs font-mono font-bold text-zinc-900 dark:text-zinc-50 truncate">
                      {inspectData.extracted?.hashSign || "Verified HMAC"}
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-1 flex items-center gap-1">
                      <Key className="w-3 h-3 text-emerald-500" />
                      <span>ts: {inspectData.extracted?.timestamp || "Active"}</span>
                    </div>
                  </div>
                </div>

                {/* Legal & Rights Investigation */}
                <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-white/5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                    {t("Legal Rights & Distribution Chain", "Правообладатели, Лейбл и Дистрибьютор")}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Лейбл (Label):</span>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {sanitizeDisplayString(inspectData.liveMetadata.label) || "Independent"}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Фонограмма (℗ Phonogram):</span>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {sanitizeDisplayString(inspectData.liveMetadata.phonogramSource || inspectData.liveMetadata.label) || "—"}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Дистрибьютор / Агрегатор:</span>
                      <p className="font-bold text-amber-600 dark:text-amber-400">
                        {sanitizeDisplayString(inspectData.liveMetadata.distributor) || "Самостоятельный релиз (Self-Released / Independent)"}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Копирайт (© Copyright):</span>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {sanitizeDisplayString(inspectData.liveMetadata.copyright) || "—"}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Авторы музыки:</span>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {sanitizeDisplayString(inspectData.liveMetadata.authorsMusic || inspectData.liveMetadata.artists) || "—"}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-black/20 border border-zinc-100 dark:border-white/5 space-y-1">
                      <span className="text-zinc-400">Авторы слов (Lyrics):</span>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {sanitizeDisplayString(inspectData.liveMetadata.authorsText || inspectData.liveMetadata.artists) || "—"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Deep Line-by-Line Font & String Parser Results */}
                {inspectData?.extracted?.deepScan && (
                  <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-white/5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5" />
                        Глубокий построчный парсинг строк (шрифты, скрытые данные, коды, копирайт)
                      </h4>
                      <span className="text-[11px] text-zinc-400">
                        Обработано строк: {inspectData.extracted.deepScan.totalLines || 0}
                      </span>
                    </div>

                    {/* Summary Findings Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      {/* Identified Specific Distributor */}
                      <div className="p-3.5 rounded-2xl bg-amber-500/5 border border-amber-500/20 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-amber-600 dark:text-amber-400 font-bold text-[11px]">Дистрибьютор:</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400">
                            {inspectData.extracted.deepScan.detectedDistributor?.confidence || 90}% точность
                          </span>
                        </div>
                        <p className="font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                          {inspectData.extracted.deepScan.detectedDistributor?.name || inspectData.liveMetadata.distributor}
                        </p>
                        <p className="text-[11px] text-zinc-500">
                          Категория: {inspectData.extracted.deepScan.detectedDistributor?.category || "Digital Aggregator"}
                        </p>
                      </div>

                      {/* Extracted ISRC Codes */}
                      <div className="p-3.5 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold text-[11px]">Найденные ISRC:</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                            {inspectData.extracted.deepScan.isrcCodes?.length || (inspectData.liveMetadata.isrc ? 1 : 0)} найдено
                          </span>
                        </div>
                        <p className="font-mono font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                          {inspectData.extracted.deepScan.isrcCodes?.[0]?.code || inspectData.liveMetadata.isrc || "—"}
                        </p>
                        <p className="text-[11px] text-zinc-500">
                          {inspectData.extracted.deepScan.isrcCodes?.[0]?.lineIndex
                            ? `Строка №${inspectData.extracted.deepScan.isrcCodes[0].lineIndex} в DevTools`
                            : (inspectData.liveMetadata?.isrcSource || "ISRC Code")}
                        </p>
                      </div>

                      {/* Extracted UPC / Barcodes */}
                      <div className="p-3.5 rounded-2xl bg-blue-500/5 border border-blue-500/20 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-blue-600 dark:text-blue-400 font-bold text-[11px]">Штрихкод UPC / EAN:</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400">
                            {inspectData.extracted.deepScan.upcBarcodes?.length || (inspectData.liveMetadata.upc ? 1 : 0)} найдено
                          </span>
                        </div>
                        <p className="font-mono font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                          {inspectData.extracted.deepScan.upcBarcodes?.[0]?.code || inspectData.liveMetadata.upc || "—"}
                        </p>
                        <p className="text-[11px] text-zinc-500">
                          {inspectData.extracted.deepScan.upcBarcodes?.[0]?.validChecksum
                            ? "Чек-сумма Modulo-10 проверена"
                            : "EAN-13 Barcode"}
                        </p>
                      </div>
                    </div>

                    {/* Discovered Copyright and Rightsholders Lines */}
                    {inspectData.extracted.deepScan.copyrightNotices?.length > 0 && (
                      <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5 space-y-2">
                        <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                          Извлеченные строки копирайта и правообладателей (℗ / ©):
                        </span>
                        <div className="space-y-1.5">
                          {inspectData.extracted.deepScan.copyrightNotices.map((c: any, idx: number) => (
                            <div key={idx} className="flex items-start justify-between gap-2 text-xs bg-white dark:bg-zinc-900/60 p-2 rounded-xl border border-zinc-200/50 dark:border-white/5">
                              <span className="font-medium text-zinc-800 dark:text-zinc-200">
                                {sanitizeDisplayString(c.notice)}
                              </span>
                              <span className="text-[10px] text-zinc-400 shrink-0 font-mono">
                                Строка #{c.lineIndex} ({c.type})
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Line-by-Line Inspection Table */}
                    {inspectData.extracted.deepScan.parsedLines?.length > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-[11px] text-zinc-400 font-medium">
                          <span>Построчный разбор (нормализация шрифтов + аннотации):</span>
                          <span>Показано до 50 строк</span>
                        </div>
                        <div className="max-h-72 overflow-y-auto rounded-2xl border border-zinc-200/80 dark:border-white/10 bg-zinc-950 text-zinc-200 font-mono text-[11px] divide-y divide-zinc-900 scrollbar-thin">
                          {inspectData.extracted.deepScan.parsedLines.slice(0, 50).map((l: any) => (
                            <div key={l.lineIndex} className="p-2.5 flex items-start gap-3 hover:bg-zinc-900/50">
                              <span className="text-zinc-600 select-none w-8 text-right shrink-0">
                                #{l.lineIndex}
                              </span>
                              <div className="flex-1 min-w-0 space-y-1">
                                <div className="break-all text-zinc-300">
                                  {l.normalized || l.raw}
                                </div>
                                {l.tags && l.tags.length > 0 && (
                                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                                    {l.tags.map((t: string) => (
                                      <span
                                        key={t}
                                        className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                                          t === 'isrc'
                                            ? 'bg-emerald-500/20 text-emerald-400'
                                            : t === 'upc'
                                            ? 'bg-blue-500/20 text-blue-400'
                                            : t === 'copyright'
                                            ? 'bg-purple-500/20 text-purple-400'
                                            : t === 'distributor'
                                            ? 'bg-amber-500/20 text-amber-400'
                                            : t === 'token'
                                            ? 'bg-rose-500/20 text-rose-400'
                                            : 'bg-zinc-800 text-zinc-400'
                                        }`}
                                      >
                                        {t}
                                      </span>
                                    ))}
                                    {l.note && (
                                      <span className="text-[10px] text-zinc-500">
                                        {l.note}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Sanitized Hidden DevTools Parameters & Payload Explorer */}
                {inspectData?.extracted?.rawQueryParameters &&
                  Object.keys(inspectData.extracted.rawQueryParameters).length > 0 && (
                    <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-white/5">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
                        <FileCode className="w-3.5 h-3.5" />
                        Декодированные параметры DevTools & Сети (без иероглифов и %20)
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                        {Object.entries(inspectData.extracted.rawQueryParameters).map(([k, v]) => (
                          <div
                            key={k}
                            className="p-2.5 rounded-xl bg-zinc-50 dark:bg-black/30 border border-zinc-100 dark:border-white/5 flex items-center justify-between"
                          >
                            <span className="text-amber-600 dark:text-amber-400 font-bold truncate">{k}:</span>
                            <span className="text-zinc-700 dark:text-zinc-300 truncate max-w-[65%]">
                              {sanitizeDisplayString(v)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {/* Raw JSON Code Explorer */}
                <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-white/5">
                  <div className="bg-[#121214] text-zinc-300 rounded-2xl p-4 border border-zinc-800">
                    <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800 text-xs">
                      <span className="font-mono font-bold text-amber-400 flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5" />
                        JSON Payload & DevTools Network Extraction
                      </span>
                      <button
                        onClick={() => handleCopy(JSON.stringify(inspectData, null, 2), "json")}
                        className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 px-2.5 py-1 rounded bg-amber-400/10"
                      >
                        {copiedField === "json" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        {t("Copy JSON", "Копировать")}
                      </button>
                    </div>
                    <pre className="text-xs font-mono overflow-x-auto max-h-64 text-zinc-300 scrollbar-thin">
                      {JSON.stringify(inspectData, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: Top Chart with 1-Click Code Inspection */}
      {activeSection === "chart" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-500" />
              {t("Top 100 Tracks Chart (Russia & Global)", "Главный чарт Яндекс Музыки")}
            </h2>
            <button
              onClick={loadDiscovery}
              className="text-xs text-zinc-500 hover:text-amber-500 flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              {t("Refresh", "Обновить")}
            </button>
          </div>

          {loadingDiscovery ? (
            <div className="p-12 text-center text-zinc-400">
              <RefreshCw className="w-7 h-7 animate-spin mx-auto mb-2 text-amber-500" />
              <p className="text-xs">{t("Loading top chart...", "Загрузка чарта...")}</p>
            </div>
          ) : (
            <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl overflow-hidden shadow-sm divide-y divide-zinc-100 dark:divide-white/5">
              {chartTracks.map((item: any, idx: number) => {
                const trk = item.track || item;
                const trkId = trk.id;
                const position = item.chart?.position || idx + 1;
                const cover = trk.coverUri ? `https://${trk.coverUri.replace("%%", "100x100")}` : null;
                const artistsStr = sanitizeDisplayString(trk.artists?.map((a: any) => a.name).join(", ") || "Unknown");

                return (
                  <div
                    key={`chart-trk-${trkId || "t"}-${idx}`}
                    className="p-3 sm:p-3.5 flex items-center justify-between gap-4 hover:bg-zinc-50 dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <span className="w-6 text-center font-black text-xs text-zinc-400">
                        {position}
                      </span>
                      {cover ? (
                        <img
                          src={cover}
                          alt={trk.title}
                          referrerPolicy="no-referrer"
                          className="w-11 h-11 rounded-xl object-cover shrink-0"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-400 shrink-0">
                          <Music2 className="w-5 h-5" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-xs sm:text-sm text-zinc-900 dark:text-zinc-50 truncate">
                          {sanitizeDisplayString(trk.title)}
                        </p>
                        <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                          {artistsStr}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setQueryInput(`https://music.yandex.ru/track/${trkId}`);
                          setActiveSection("parser_inspector");
                          executeInspect(`https://music.yandex.ru/track/${trkId}`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 font-bold text-xs flex items-center gap-1.5 transition-colors"
                      >
                        <Code className="w-3.5 h-3.5" />
                        <span>{t("Inspect Codes", "Чекать")}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: New Releases */}
      {activeSection === "new_releases" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
              <Disc className="w-4 h-4 text-amber-500" />
              {t("New Premieres & Albums", "Новинки и свежие премьеры")}
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {newReleases.map((item: any, idx: number) => {
              const alb = item.data || item;
              const albId = alb.id;
              const cover = alb.coverUri ? `https://${alb.coverUri.replace("%%", "300x300")}` : null;
              const artistsStr = sanitizeDisplayString(alb.artists?.map((a: any) => a.name).join(", ") || "Unknown");

              return (
                <div
                  key={`new-alb-${albId || "a"}-${idx}`}
                  className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-2xl p-3 shadow-sm flex flex-col justify-between hover:border-amber-500/40 transition-all"
                >
                  <div className="space-y-2">
                    <div className="relative aspect-square rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800">
                      {cover ? (
                        <img
                          src={cover}
                          alt={alb.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-zinc-400">
                          <Disc className="w-8 h-8" />
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-zinc-900 dark:text-zinc-50 truncate">
                        {sanitizeDisplayString(alb.title)}
                      </h4>
                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                        {artistsStr}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-zinc-100 dark:border-white/5 flex items-center justify-between">
                    <span className="text-[10px] text-zinc-400">{alb.year || "2025"}</span>
                    <button
                      onClick={() => {
                        setQueryInput(`https://music.yandex.ru/album/${albId}`);
                        setActiveSection("parser_inspector");
                        executeInspect(`https://music.yandex.ru/album/${albId}`);
                      }}
                      className="text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline"
                    >
                      {t("Parse Album", "Парсить")}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 4: OpenAPI & ym.marshal.dev Specification & Utilities Explorer */}
      {activeSection === "openapi_specs" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Docs Header Banner */}
          <div className="bg-gradient-to-br from-indigo-900/40 via-purple-900/30 to-zinc-900 border border-indigo-500/20 rounded-3xl p-6 relative overflow-hidden">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold uppercase tracking-wider mb-2">
                  <Code className="w-3.5 h-3.5" />
                  Yandex Music Open API & Python SDK Reference
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  OpenAPI Спецификация и Утилиты (ym.marshal.dev & cherkashin.dev)
                </h2>
                <p className="text-xs sm:text-sm text-zinc-300 mt-1 max-w-2xl">
                  Интеграция спецификации OpenAPI (cherkashin.dev/yandex-music-open-api) и модулей yandex_music.utils (ym.marshal.dev): генерация подписей стриминга, синхронизация очередей (queues), обратная связь радио/волны (rotor) и diff-операции плейлистов.
                </p>
              </div>

              {/* External Links */}
              <div className="flex flex-wrap gap-2 shrink-0">
                <a
                  href="https://www.cherkashin.dev/yandex-music-open-api/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 border border-white/10 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-indigo-400" />
                  cherkashin.dev OpenAPI
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
                <a
                  href="https://ym.marshal.dev/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 border border-white/10 transition-colors"
                >
                  <FileCode className="w-3.5 h-3.5 text-purple-400" />
                  ym.marshal.dev SDK
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
                <a
                  href="https://ym.marshal.dev/yandex_music.utils/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 border border-white/10 transition-colors"
                >
                  <Sliders className="w-3.5 h-3.5 text-amber-400" />
                  yandex_music.utils
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </div>
            </div>
          </div>

          {/* Interactive Endpoint Runner */}
          <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-500" />
                <h3 className="font-bold text-sm sm:text-base text-zinc-900 dark:text-zinc-50">
                  Интерактивный OpenAPI запрос к api.music.yandex.net
                </h3>
              </div>
              <span className="text-[11px] font-mono text-zinc-400">
                Авторизация через активный OAuth токен
              </span>
            </div>

            {/* Quick Templates */}
            <div className="flex flex-wrap gap-2">
              <span className="text-xs text-zinc-400 self-center font-medium">Шаблоны:</span>
              {[
                { label: "Track Supplement (Текст/Клипы)", ep: "tracks/12278456/supplement" },
                { label: "Queues (Очереди воспроизведения)", ep: "queues" },
                { label: "Track Download Info", ep: "tracks/12278456/download-info" },
                { label: "Track Credits (Права/Авторы)", ep: "tracks/12278456" },
                { label: "Rotor Dashboard (Моя волна)", ep: "rotor/stations/dashboard" },
                { label: "Account Status", ep: "account/status" },
                { label: "Feed / Лента", ep: "feed" },
              ].map((tpl) => (
                <button
                  key={tpl.ep}
                  onClick={() => setApiEndpointInput(tpl.ep)}
                  className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-white/5 hover:bg-amber-500/10 hover:text-amber-500 text-zinc-700 dark:text-zinc-300 text-xs font-medium transition-colors border border-transparent hover:border-amber-500/20"
                >
                  {tpl.label}
                </button>
              ))}
            </div>

            {/* Input & Run */}
            <div className="flex flex-col sm:flex-row items-stretch gap-2">
              <div className="flex items-center gap-2 bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-white/10 rounded-2xl px-4 py-2 flex-1">
                <span className="text-xs font-mono font-bold text-emerald-500">GET</span>
                <span className="text-xs font-mono text-zinc-400">https://api.music.yandex.net/</span>
                <input
                  type="text"
                  value={apiEndpointInput}
                  onChange={(e) => setApiEndpointInput(e.target.value)}
                  placeholder="tracks/12278456/supplement"
                  className="bg-transparent text-xs font-mono text-zinc-900 dark:text-zinc-100 flex-1 focus:outline-none"
                />
              </div>
              <button
                onClick={executeApiRequest}
                disabled={apiRunning || !apiEndpointInput}
                className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all disabled:opacity-50"
              >
                {apiRunning ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Выполняется...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    Выполнить запрос
                  </>
                )}
              </button>
            </div>

            {/* Response Viewer */}
            {apiResponseResult && (
              <div className="mt-4 bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-xs font-mono text-zinc-300 overflow-hidden">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800 text-[11px]">
                  <span className="text-emerald-400 font-bold">
                    HTTP 200 OK • Ответ сервера
                  </span>
                  <button
                    onClick={() => handleCopy(JSON.stringify(apiResponseResult, null, 2), "api_response")}
                    className="flex items-center gap-1.5 text-zinc-400 hover:text-white transition-colors"
                  >
                    {copiedField === "api_response" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedField === "api_response" ? "Скопировано" : "Копировать JSON"}
                  </button>
                </div>
                <pre className="max-h-96 overflow-auto text-emerald-400/90 leading-relaxed scrollbar-thin">
                  {JSON.stringify(apiResponseResult, null, 2)}
                </pre>
              </div>
            )}
          </div>

          {/* Reference Categories from OpenAPI Specification */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {openApiReference?.categories?.map((cat: any) => (
              <div
                key={cat.id}
                className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-2xl p-5 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                    <Database className="w-4 h-4 text-indigo-500" />
                    {cat.name}
                  </h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-100 dark:bg-white/5 text-zinc-500">
                    {cat.endpoints?.length || 0} endpoints
                  </span>
                </div>

                <div className="space-y-2">
                  {cat.endpoints?.map((ep: any, idx: number) => (
                    <div
                      key={idx}
                      onClick={() => {
                        const cleanPath = ep.path.replace("{trackId}", "12278456").replace("{albumId}", "1350000").replace("{station}", "user:onyourwave").replace("{queueId}", "current");
                        setApiEndpointInput(cleanPath.startsWith("/") ? cleanPath.slice(1) : cleanPath);
                      }}
                      className="p-2.5 rounded-xl bg-zinc-50 dark:bg-white/5 hover:bg-amber-500/10 hover:border-amber-500/20 border border-transparent transition-all cursor-pointer group"
                    >
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          ep.method === "POST" ? "bg-amber-500/20 text-amber-500" : ep.method === "CALC" || ep.method === "DIFF" ? "bg-purple-500/20 text-purple-400" : "bg-emerald-500/20 text-emerald-500"
                        }`}>
                          {ep.method}
                        </span>
                        <span className="text-xs font-mono font-semibold text-zinc-800 dark:text-zinc-200 group-hover:text-amber-500 transition-colors">
                          {ep.path}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 pl-1">
                        {ep.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Video Snapshot & Clips Modal */}
      <VideoSnapshotModal
        track={selectedSnapshotTrack}
        isOpen={isSnapshotModalOpen}
        onClose={() => setIsSnapshotModalOpen(false)}
        onPlayTrack={onPlayTrack}
      />

    </div>
  );
};

