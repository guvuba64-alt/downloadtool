import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

const translations = {
  ru: {
    title: "ОТЧЁТ РОЯЛТИ",
    reportNumber: "ОТЧЁТ №",
    date: "Дата:",
    currency: "Валюта:",
    reason: "Причина изменения доли:",
    note: "Примечание:",
    distributorDetails: "РЕКВИЗИТЫ ДИСТРИБЬЮТОРА",
    name: "Название:",
    type: "Тип:",
    contacts: "Контакты:",
    rightsHolderDetails: "ПРАВООБЛАДАТЕЛЬ",
    distributor: "ДИСТРИБЬЮТОР",
    fullName: "ФИО:",
    passport: "Паспорт:",
    inn: "ИНН:",
    phone: "Телефон:",
    account: "Счет:",
    website: "Сайт:",
    distribution: "Распределение:",
    detailsHeader: "ДЕТАЛИЗАЦИЯ НАЧИСЛЕНИЙ",
    artist: "Артист",
    release: "Релиз",
    track: "Трек",
    platform: "Площадка",
    streams: "Стримы",
    listens: "Прослушивания",
    grossRevenue: "Доход",
    commission: "Удержано",
    netRevenue: "К выплате",
    total: "ИТОГО",
    finalCalc: "ИТОГОВЫЙ РАСЧЕТ",
    signatures: "ПОДПИСИ СТОРОН",
    payoutSum: "Сумма к выплате:",
    fromDist: "От дистрибьютора:",
    fromHolder: "От правообладателя:",
    footerNote: "Данный отчёт сформирован автоматически и является официальным документом.",
    defDistType: "Дистрибьютор",
    defHolderType: "Исполнитель",
    rightsHolderStr: "Правообладатель",
    labelStr: "Лейбл",
    approved: "APPROVED"
  },
  en: {
    title: "ROYALTY STATEMENT",
    reportNumber: "REPORT #",
    date: "Date:",
    currency: "Currency:",
    reason: "Share change reason:",
    note: "Note:",
    distributorDetails: "DISTRIBUTOR DETAILS",
    name: "Name:",
    type: "Type:",
    contacts: "Contacts:",
    rightsHolderDetails: "RIGHTS HOLDER",
    distributor: "DISTRIBUTOR",
    fullName: "Full Name:",
    passport: "Passport/ID:",
    inn: "Tax ID:",
    phone: "Phone:",
    account: "Account:",
    website: "Website:",
    distribution: "Distribution:",
    detailsHeader: "ACCRUAL DETAILS",
    artist: "Artist",
    release: "Release",
    track: "Track",
    platform: "Platform",
    streams: "Streams",
    listens: "Listens",
    grossRevenue: "Revenue",
    commission: "Commission",
    netRevenue: "Payout",
    total: "TOTAL",
    finalCalc: "FINAL CALCULATION",
    signatures: "PARTIES SIGNATURES",
    payoutSum: "Total Payout:",
    fromDist: "Distributor Signature:",
    fromHolder: "Rights Holder Signature:",
    footerNote: "This statement is automatically generated and serves as an official document.",
    defDistType: "Distributor",
    defHolderType: "Artist",
    rightsHolderStr: "Rights Holder",
    labelStr: "Label",
    approved: "APPROVED"
  }
};


function translatePlatformName(name, lang) {
  if (!name || name === '—') return name;
  if (lang === 'en') {
    const map = {
      'яндекс музыка': 'Yandex Music',
      'яндекс.музыка': 'Yandex Music',
      'yandex': 'Yandex Music',
      'yandex music': 'Yandex Music',
      'вк музыка': 'VK Music',
      'vk музыка': 'VK Music',
      'vk music': 'VK Music',
      'vk': 'VK Music',
      'вконтакте': 'VK Music',
      'звук': 'Zvuk',
      'сберзвук': 'Zvuk',
      'мтс музыка': 'MTS Music',
      'mts music': 'MTS Music',
      'одноклассники': 'OK',
      'ok.ru': 'OK',
      'ютуб': 'YouTube',
      'ютуб музыка': 'YouTube Music',
      'youtube': 'YouTube',
      'youtube music': 'YouTube Music',
      'эпл мьюзик': 'Apple Music',
      'apple music': 'Apple Music',
      'спотифай': 'Spotify',
      'spotify': 'Spotify',
      'бум': 'VK Music',
      'boom': 'VK Music',
      'тикток': 'TikTok',
      'tiktok': 'TikTok',
      'амазон': 'Amazon Music',
      'amazon': 'Amazon Music',
      'шазам': 'Shazam',
      'shazam': 'Shazam',
      'deezer': 'Deezer',
      'дизер': 'Deezer'
    };
    const lower = name.toString().toLowerCase().trim();
    return map[lower] || name;
  }
  return name;
}

let cachedRobotoRegularB64: string | null = null;
let cachedRobotoMediumB64: string | null = null;

export async function ensureRobotoFonts(doc: jsPDF): Promise<void> {
  try {
    if (!cachedRobotoRegularB64) {
      const fontUrl = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Regular.ttf';
      const response = await fetch(fontUrl);
      const buffer = await response.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = '';
      const chunkSize = 8192;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunkSize, bytes.length)) as any);
      }
      cachedRobotoRegularB64 = btoa(binary);
    }
    if (!cachedRobotoMediumB64) {
      const fontUrlMedium = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Medium.ttf';
      const resMedium = await fetch(fontUrlMedium);
      const bufMedium = await resMedium.arrayBuffer();
      const bytesM = new Uint8Array(bufMedium);
      let binaryM = '';
      const chunkSize = 8192;
      for (let i = 0; i < bytesM.length; i += chunkSize) {
        binaryM += String.fromCharCode.apply(null, bytesM.subarray(i, Math.min(i + chunkSize, bytesM.length)) as any);
      }
      cachedRobotoMediumB64 = btoa(binaryM);
    }
    doc.addFileToVFS('Roboto-Regular.ttf', cachedRobotoRegularB64);
    doc.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
    doc.addFileToVFS('Roboto-Medium.ttf', cachedRobotoMediumB64);
    doc.addFont('Roboto-Medium.ttf', 'Roboto', 'bold');
    doc.setFont('Roboto');
  } catch (err) {
    console.warn('Could not load custom Roboto font for PDF:', err);
  }
}

export async function generateRoyaltyStatement(data: any, isMaster: boolean = false, previewMode: boolean | 'blob' = false, lang: 'ru' | 'en' = 'ru') {
  const doc = new jsPDF();
  const t = translations[lang] || translations.ru;

  const _safeText = (val: any, x: number, y: number) => {
    if (Array.isArray(val)) {
       doc.text(val.map(v => v !== undefined && v !== null ? String(v) : ''), x, y);
    } else {
       doc.text(val !== undefined && val !== null ? String(val) : '', x, y);
    }
  };

  // Font loading with caching
  await ensureRobotoFonts(doc);
  
  // Colors (Strict Business Theme)
  const primaryColor = [30, 41, 59];
  const textColor = [15, 23, 42];
  const lightText = [100, 116, 139];
  const bgLight = [241, 245, 249];
  const accentLight = [248, 250, 252];
  const borderColor = [203, 213, 225];
  
  const isGeneral = data.reportNumber === "ND-GENERAL";
  
  // 1. Header
  doc.setFont('Roboto', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  _safeText(data.documentTitle || t.title, 14, 25);
  
  doc.setFontSize(10);
  doc.setFont('Roboto', 'normal');
  doc.setTextColor(lightText[0], lightText[1], lightText[2]);
  _safeText(data.reportPeriod, 14, 32);
  
  
  
  let currentY = 40;
  if (data.artistSharePercent !== 100) {
     doc.setFont('Roboto', 'bold');
     doc.setTextColor(textColor[0], textColor[1], textColor[2]);
     const text = [];
     if (data.reason) text.push(`${t.reason} ${data.reason}`);
     if (data.note) text.push(`${t.note} ${data.note}`);
     if (text.length > 0) {
        _safeText(text, 14, currentY);
        currentY += text.length * 5 + 2;
     }
  }

  // Report Info Box (Top Right)
  doc.setFillColor(bgLight[0], bgLight[1], bgLight[2]);
  doc.roundedRect(130, 14, 66, 25, 2, 2, 'F');
  
  doc.setFontSize(9);
  doc.setTextColor(lightText[0], lightText[1], lightText[2]);
  _safeText(t.reportNumber, 134, 21);
  _safeText(t.date, 134, 27);
  _safeText(t.currency, 134, 33);
  
  doc.setFont('Roboto', 'bold');
  doc.setTextColor(textColor[0], textColor[1], textColor[2]);
  _safeText(data.reportNumber || "—", 155, 21);
  _safeText(data.reportDate, 155, 27);
  _safeText(data.currency, 155, 33);
  
  let startY = 48;

  // 2. Details
  if (isGeneral) {
    const boxHeight = 28;
    doc.setFillColor(bgLight[0], bgLight[1], bgLight[2]);
    doc.roundedRect(14, startY, 182, boxHeight, 2, 2, 'F');
    doc.setFontSize(10);
    doc.setFont('Roboto', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    _safeText(t.distributorDetails, 14, startY - 2);
    
    doc.setFontSize(9);
    doc.setTextColor(lightText[0], lightText[1], lightText[2]);
    doc.setFont('Roboto', 'normal');
    _safeText(t.name, 18, startY + 8);
    _safeText(t.type, 18, startY + 15);
    _safeText(t.contacts, 18, startY + 22);
    
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFont('Roboto', 'bold');
    _safeText(data.distributor.name || "—", 40, startY + 8);
    doc.setFont('Roboto', 'normal');
    _safeText(data.distributor.type || t.defDistType, 40, startY + 15);
    _safeText([data.distributor.website || "—", data.distributor.email || "—", data.distributor.phone || "—"].filter(Boolean).join(" • "), 40, startY + 22);
    
    startY += boxHeight + 10;
  } else {
    const boxHeight = data.includeHolderDetails ? 42 : 28;
    
    doc.setFontSize(10);
    doc.setFont('Roboto', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    _safeText(t.rightsHolderDetails, 14, startY);
    _safeText(t.distributor, 108, startY);
    
    startY += 3;
    doc.setFillColor(bgLight[0], bgLight[1], bgLight[2]);
    doc.roundedRect(14, startY, 90, boxHeight, 2, 2, 'F');
    doc.roundedRect(108, startY, 88, boxHeight, 2, 2, 'F');
    
    // Holder labels
    doc.setFontSize(9);
    doc.setTextColor(lightText[0], lightText[1], lightText[2]);
    doc.setFont('Roboto', 'normal');
    if (data.includeHolderDetails) {
      _safeText(t.fullName, 18, startY + 8);
      _safeText(t.passport, 18, startY + 15);
      _safeText(t.inn, 18, startY + 22);
      _safeText(t.phone, 18, startY + 29);
      _safeText(t.account, 18, startY + 36);
      
      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('Roboto', 'bold');
      _safeText((data.holderDetails && data.holderDetails.fullName) ? data.holderDetails.fullName : data.rightsHolder.name, 40, startY + 8);
      doc.setFont('Roboto', 'normal');
      _safeText(data.holderDetails?.passport || "—", 40, startY + 15);
      _safeText(data.holderDetails?.inn || "—", 40, startY + 22);
      _safeText(data.holderDetails?.phone || "—", 40, startY + 29);
      _safeText(data.holderDetails?.account || "—", 40, startY + 36);
    } else {
      _safeText(t.name, 18, startY + 8);
      _safeText(t.type, 18, startY + 15);
      
      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('Roboto', 'bold');
      _safeText(data.rightsHolder.name || "—", 40, startY + 8);
      doc.setFont('Roboto', 'normal');
      _safeText(data.rightsHolder.type || t.defHolderType, 40, startY + 15);
    }
    
    // Dist labels
    doc.setTextColor(lightText[0], lightText[1], lightText[2]);
    doc.setFont('Roboto', 'normal');
    _safeText(t.name, 112, startY + 8);
    _safeText(t.type, 112, startY + 15);
    _safeText(t.website, 112, startY + 22);
    _safeText(t.distribution, 112, startY + 29);
    
    // Dist values
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFont('Roboto', 'bold');
    _safeText(data.distributor.name || "—", 137, startY + 8);
    doc.setFont('Roboto', 'normal');
    _safeText(data.distributor.type || t.defDistType, 137, startY + 15);
    _safeText(data.distributor.website || "—", 137, startY + 22);
    
    doc.setFont('Roboto', 'bold');
    _safeText(`${data.artistSharePercent}% (${t.rightsHolderStr}) / ${100 - data.artistSharePercent}% (${t.labelStr})`, 137, startY + 29);
    
    startY += boxHeight + 10;
  }
  
  // 3. Table
  doc.setFont('Roboto', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  _safeText(t.detailsHeader, 14, startY);
  startY += 4;
  
  let tableHead, tableBody;
  
  const fmtLocale = lang === 'ru' ? 'ru-RU' : 'en-US';
  
  if (isMaster) {
      if (data.detailedMaster) {
          tableHead = [[t.artist, t.release, t.track, t.platform, t.streams, `${t.grossRevenue} (${data.currency})`, t.commission, `${t.netRevenue} (${data.currency})`]];
          tableBody = data.platforms.map((p: any) => [
            p.artist || '—',
            p.release || '—',
            p.track || '—',
            translatePlatformName(p.platform || p.name || '—', lang),
            p.streams.toLocaleString(fmtLocale),
            p.grossRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            p.commissionAmount.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            p.netRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
          ]);
          tableBody.push([
            { content: t.total, colSpan: 4, styles: { halign: 'center' } },
            data.totals.streams.toLocaleString(fmtLocale),
            data.totals.gross.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            data.totals.commission.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            data.totals.net.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
          ]);
      } else {
          tableHead = [[t.artist, t.listens, `${t.grossRevenue} (${data.currency})`, t.commission, `${t.netRevenue} (${data.currency})`]];
          tableBody = data.platforms.map((p: any) => [
            p.name || '—',
            p.streams.toLocaleString(fmtLocale),
            p.grossRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            p.commissionAmount.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            p.netRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
          ]);
          tableBody.push([
            t.total,
            data.totals.streams.toLocaleString(fmtLocale),
            data.totals.gross.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            data.totals.commission.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
            data.totals.net.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
          ]);
      }
  } else {
      tableHead = [[t.release, t.track, t.platform, t.streams, `${t.grossRevenue} (${data.currency})`, t.commission, `${t.netRevenue} (${data.currency})`]];
      tableBody = data.platforms.map((p: any) => [
        p.release || '—',
        p.track || '—',
        translatePlatformName(p.platform || p.name || '—', lang),
        p.streams.toLocaleString(fmtLocale),
        p.grossRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        p.commissionAmount.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        p.netRevenue.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      ]);
      tableBody.push([
        { content: t.total, colSpan: 3, styles: { halign: 'center' } },
        data.totals.streams.toLocaleString(fmtLocale),
        data.totals.gross.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        data.totals.commission.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        data.totals.net.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      ]);
  }
  
  (autoTable as any)(doc, {
    startY: startY,
    head: tableHead,
    body: tableBody,
    styles: { font: 'Roboto', fontStyle: 'normal', fontSize: 9, cellPadding: 4, lineColor: [226, 232, 240], lineWidth: 0.1 },
    headStyles: { fillColor: primaryColor, textColor: [255,255,255], fontStyle: 'bold' },
    footStyles: { fillColor: [241, 245, 249], textColor: textColor, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    willDrawCell: function(data: any) {
        if (data.row.index === tableBody.length - 1 && data.section === 'body') {
           doc.setFont('Roboto', 'bold');
           doc.setFillColor(241, 245, 249);
       }
    }
  });
  
  let finalY = (doc as any).lastAutoTable.finalY + 15;
  if (finalY > 230) {
     doc.addPage();
     finalY = 20;
  }
  
  // 4. Totals & Signatures
  doc.setFont('Roboto', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  _safeText(t.finalCalc, 14, finalY);
  if (!isGeneral) {
    _safeText(t.signatures, 108, finalY);
  }
  finalY += 4;
  
  // Big Payout Box
  doc.setFillColor(accentLight[0], accentLight[1], accentLight[2]);
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.setLineWidth(0.1);
  doc.roundedRect(14, finalY, 86, 35, 2, 2, 'FD');
  
  doc.setFontSize(10);
  doc.setTextColor(lightText[0], lightText[1], lightText[2]);
  doc.setFont('Roboto', 'normal');
  _safeText(t.payoutSum, 20, finalY + 10);
  
  doc.setFontSize(20);
  doc.setFont('Roboto', 'bold');
  doc.setTextColor(textColor[0], textColor[1], textColor[2]);
  const netStr = data.totals.net.toLocaleString(fmtLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  _safeText(netStr, 20, finalY + 22);
  
  const netWidth = doc.getTextWidth(netStr);
  doc.setFontSize(12);
  doc.setFont('Roboto', 'normal');
  doc.setTextColor(lightText[0], lightText[1], lightText[2]);
  _safeText(data.currency, 20 + netWidth + 4, finalY + 22);
  
  // Signatures Box
  if (!isGeneral) {
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(108, finalY, 88, 35, 2, 2, 'FD');
    
    doc.setFontSize(8);
    doc.setTextColor(lightText[0], lightText[1], lightText[2]);
    _safeText(t.fromDist, 112, finalY + 8);
    _safeText(t.fromHolder, 155, finalY + 8);
    
    if (data.distributorSignature) {
      doc.addImage(data.distributorSignature, 'PNG', 112, finalY + 10, 30, 15);
    }
    
    if (data.rightsHolderSignature) {
      doc.addImage(data.rightsHolderSignature, 'PNG', 155, finalY + 10, 30, 15);
    } else {
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.circle(170, finalY + 17, 7, 'S');
      doc.setFontSize(5);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      _safeText(t.approved, 166, finalY + 18);
    }
    
    doc.setFontSize(8);
    doc.setFont('Roboto', 'bold');
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    _safeText(data.distributor.name, 112, finalY + 30);
    _safeText((data.includeHolderDetails && data.holderDetails && data.holderDetails.fullName) ? data.holderDetails.fullName : data.rightsHolder.name, 155, finalY + 30);
  }
  
  // Footer note
  doc.setFontSize(7);
  doc.setFont('Roboto', 'normal');
  doc.setTextColor(148, 163, 184); 
  _safeText(t.footerNote, 14, 285);
  
  if (previewMode === 'blob') {
    return (doc as any).output('blob');
  } else if (previewMode) {
    return (doc as any).output('bloburl');
  } else {
    doc.save(`Royalty_Statement_${data.rightsHolder.name.replace(/[^a-zA-Z0-9а-яА-Я]/g, '_')}.pdf`);
  }
}

export interface ReleaseSheetMetadata {
  title?: string;
  artists?: string;
  pseudonym?: string;
  performer?: string;
  albumTitle?: string;
  releaseDate?: string;
  year?: number | string;
  coverUri?: string;
  cover3000?: string;
  cover?: string;
  isrc?: string;
  upc?: string;
  barcode?: string;
  authorsMusic?: string;
  authorsText?: string;
  durationMs?: number;
  duration?: number;
  copyright?: string | null;
  pLine?: string | null;
  cLine?: string | null;
  copyrightOwnerName?: string | null;
  copyrightOwnerId?: number | string | null;
  label?: string | null;
  distributor?: string | null;
  entityType?: 'single' | 'album' | string;
  platform?: string;
  releaseId?: number | string | null;
  idForDownload?: number | string | null;
  track?: any;
  tracks?: Array<{
    id?: string | number;
    trackNumber?: number;
    title: string;
    artists?: string;
    pseudonym?: string;
    performer?: string;
    authorsMusic?: string;
    authorsText?: string;
    isrc?: string;
    upc?: string;
    durationMs?: number;
    duration?: number;
    copyright?: string;
    copyrightOwnerName?: string;
    copyrightOwnerId?: number | string;
  }>;
  [key: string]: any;
}

function formatDurationSec(secOrMs?: number): string {
  if (!secOrMs || isNaN(secOrMs)) return '—';
  const totalSec = secOrMs > 1000 ? Math.round(secOrMs / 1000) : Math.round(secOrMs);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

async function loadCoverImageAsDataUrl(coverUri?: string): Promise<string | null> {
  if (!coverUri) return null;
  let cleanUrl = String(coverUri).trim();
  if (!cleanUrl) return null;
  if (cleanUrl.includes('%%')) {
    cleanUrl = cleanUrl.replace('%%', '600x600');
  }
  if (!cleanUrl.startsWith('http') && !cleanUrl.startsWith('/api') && !cleanUrl.startsWith('data:')) {
    cleanUrl = 'https://' + cleanUrl;
  }
  if (cleanUrl.startsWith('data:')) return cleanUrl;

  const tryUrls: string[] = [];
  if (cleanUrl.startsWith('http')) {
    tryUrls.push(`/api/music/proxy-image?url=${encodeURIComponent(cleanUrl)}`);
  }
  tryUrls.push(cleanUrl);

  for (const url of tryUrls) {
    try {
      const res = await fetch(url);
      if (res.ok) {
        const blob = await res.blob();
        return await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
      }
    } catch {
      // try next url
    }
  }

  // HTML Image element fallback with canvas
  return new Promise<string | null>((resolve) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = Math.min(img.naturalWidth || 600, 800);
          canvas.height = Math.min(img.naturalHeight || 600, 800);
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            resolve(canvas.toDataURL('image/jpeg', 0.92));
            return;
          }
        } catch {}
        resolve(null);
      };
      img.onerror = () => resolve(null);
      img.src = cleanUrl.startsWith('http') ? `/api/music/proxy-image?url=${encodeURIComponent(cleanUrl)}` : cleanUrl;
    } catch {
      resolve(null);
    }
  });
}

/**
 * Generates a studio-grade, professional release metadata passport PDF with cover artwork,
 * full legal credits, ISRC/UPC codes, technical parameters, and structured tracklist.
 */
export async function generateReleaseSheetPdf(
  metadata: ReleaseSheetMetadata,
  options: { previewMode?: boolean | 'blob'; lang?: 'ru' | 'en' } = {}
) {
  const { previewMode = false, lang = 'ru' } = options;
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });

  const _safeText = (val: any, x: number, y: number, textOptions?: any) => {
    if (val === undefined || val === null) return;
    if (Array.isArray(val)) {
      doc.text(val.map(v => v !== undefined && v !== null ? String(v) : ''), x, y, textOptions);
    } else {
      doc.text(String(val), x, y, textOptions);
    }
  };

  // 1. Ensure Unicode Roboto Fonts are loaded
  await ensureRobotoFonts(doc);

  // Extract core fields safely
  const releaseTitle = metadata.title || metadata.albumTitle || metadata.track?.title || 'Без названия';
  const artistName = metadata.artists || metadata.pseudonym || metadata.performer || metadata.track?.artists || 'Не указан';
  const albumTitle = metadata.albumTitle || (metadata.entityType === 'album' ? metadata.title : '');
  const upc = metadata.upc || metadata.barcode || metadata.track?.upc || '';
  const isrc = metadata.isrc || metadata.track?.isrc || '';
  const relDateStr = metadata.releaseDate || (metadata.year ? String(metadata.year) : '') || 'Не указана';
  const label = metadata.label || metadata.distributor || 'Не указан (Self-Released)';
  const distributor = metadata.distributor || metadata.label || 'Unified DSP Delivery';
  const copyright = metadata.copyright || metadata.pLine || metadata.cLine || (metadata.copyrightOwnerName ? `℗ ${metadata.copyrightOwnerName}` : 'Не указан');
  const copyrightOwner = metadata.copyrightOwnerName || (metadata.copyrightOwnerId ? `ID: #${metadata.copyrightOwnerId}` : '—');
  const musicAuthor = metadata.authorsMusic || metadata.track?.authorsMusic || 'Не указан';
  const lyricsAuthor = metadata.authorsText || metadata.track?.authorsText || 'Не указан';
  const platform = (metadata.platform || 'OK.RU / Universal').toUpperCase();
  const entityType = metadata.entityType === 'album' || (metadata.tracks && metadata.tracks.length > 1) ? 'album' : 'single';
  const releaseId = metadata.releaseId || metadata.idForDownload || (upc ? `UPC-${upc.slice(-6)}` : `REL-${Date.now().toString(36).toUpperCase()}`);

  const coverUrl = metadata.cover3000 || metadata.coverUri || metadata.cover || metadata.track?.coverUri;

  // Prepare tracklist array
  const rawTracks = Array.isArray(metadata.tracks) && metadata.tracks.length > 0 
    ? metadata.tracks 
    : [{
        trackNumber: 1,
        title: releaseTitle,
        artists: artistName,
        isrc: isrc,
        duration: metadata.duration || (metadata.durationMs ? Math.round(metadata.durationMs / 1000) : undefined) || metadata.track?.duration,
        authorsMusic: musicAuthor !== 'Не указан' ? musicAuthor : '',
        authorsText: lyricsAuthor !== 'Не указан' ? lyricsAuthor : '',
      }];

  // Calculate total duration
  let totalSec = 0;
  rawTracks.forEach((t) => {
    const sec = t.duration || (t.durationMs ? Math.round(t.durationMs / 1000) : 0);
    if (sec) totalSec += sec;
  });
  const totalDurationStr = totalSec > 0 ? formatDurationSec(totalSec) : '—';

  // 2. Load Cover Art Image
  let coverDataUrl: string | null = null;
  if (coverUrl) {
    try {
      coverDataUrl = await loadCoverImageAsDataUrl(coverUrl);
    } catch (e) {
      console.warn('Cover art load failed, using vector placeholder:', e);
    }
  }

  // --- PAGE 1: HEADER & IDENTITY ---

  // Top Category Pill Badge
  doc.setFillColor(254, 243, 199);
  doc.roundedRect(14, 11, 64, 6, 1.5, 1.5, 'F');
  doc.setFontSize(7);
  doc.setTextColor(180, 83, 9);
  doc.setFont('Roboto', 'bold');
  _safeText(lang === 'en' ? 'DIGITAL DISTRIBUTION PASSPORT' : 'ПАСПОРТ ЦИФРОВОЙ ДИСТРИБУЦИИ', 17, 15.2);

  // Main Header Title
  doc.setFontSize(15);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'bold');
  _safeText(lang === 'en' ? 'OFFICIAL RELEASE METADATA SHEET' : 'ПАСПОРТ МЕТАДАННЫХ РЕЛИЗА', 14, 23);

  // Subtitle
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'normal');
  _safeText('Official Music Catalog & Master Recording Specification • DDEX & GS1 Standard', 14, 28);

  // Top-Right Metadata Card
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.2);
  doc.roundedRect(132, 10, 64, 20, 2, 2, 'FD');

  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'normal');
  _safeText('REF NO:', 135, 15);
  _safeText('DATE:', 135, 20);
  _safeText('SOURCE:', 135, 25);

  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'bold');
  _safeText(String(releaseId), 150, 15);
  _safeText(new Date().toLocaleDateString(lang === 'en' ? 'en-US' : 'ru-RU'), 150, 20);
  _safeText(platform, 150, 25);

  // Subtle Header Divider
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.3);
  doc.line(14, 32, 196, 32);

  // --- HERO SECTION: COVER ART + CORE IDENTITY CARD ---
  const heroY = 36;
  const coverSize = 54;

  if (coverDataUrl) {
    try {
      doc.addImage(coverDataUrl, 'JPEG', 14, heroY, coverSize, coverSize);
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.2);
      doc.roundedRect(14, heroY, coverSize, coverSize, 1.5, 1.5, 'S');
    } catch {
      // Fallback
      doc.setFillColor(30, 41, 59);
      doc.roundedRect(14, heroY, coverSize, coverSize, 2, 2, 'F');
      doc.setFillColor(51, 65, 85);
      doc.circle(41, heroY + 27, 18, 'F');
      doc.setFillColor(15, 23, 42);
      doc.circle(41, heroY + 27, 7, 'F');
    }
  } else {
    // Elegant Vinyl Disc Placeholder
    doc.setFillColor(30, 41, 59);
    doc.roundedRect(14, heroY, coverSize, coverSize, 2, 2, 'F');
    doc.setFillColor(51, 65, 85);
    doc.circle(41, heroY + 25, 18, 'F');
    doc.setFillColor(15, 23, 42);
    doc.circle(41, heroY + 25, 7, 'F');
    doc.setFillColor(234, 88, 12);
    doc.circle(41, heroY + 25, 2.5, 'F');
    doc.setFontSize(6.5);
    doc.setTextColor(203, 213, 225);
    doc.setFont('Roboto', 'bold');
    doc.text('COVER ARTWORK', 41, heroY + 47, { align: 'center' });
  }

  // Label under cover
  doc.setFontSize(6);
  doc.setTextColor(148, 163, 184);
  doc.setFont('Roboto', 'normal');
  _safeText('HD ARTWORK • 3000×3000px', 14, heroY + coverSize + 4);

  // Right Identity Card
  const cardX = 72;
  const cardW = 124;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.2);
  doc.roundedRect(cardX, heroY, cardW, coverSize, 2.5, 2.5, 'FD');

  // Format Pill inside Card
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(cardX + 4, heroY + 4, 46, 5, 1, 1, 'F');
  doc.setFontSize(6.5);
  doc.setTextColor(71, 85, 105);
  doc.setFont('Roboto', 'bold');
  const entityTypeLabel = entityType === 'album' 
    ? `💿 АЛЬБОМ (${rawTracks.length} ТРЕКОВ)` 
    : '🎵 СИНГЛ / ТРЕК';
  _safeText(entityTypeLabel, cardX + 6, heroY + 7.5);

  // Release Title (Wrapped)
  doc.setFontSize(12.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'bold');
  const titleLines = doc.splitTextToSize(releaseTitle, cardW - 8);
  doc.text(titleLines.slice(0, 2), cardX + 4, heroY + 14);

  // Artist Name
  const artistY = heroY + 14 + (titleLines.length > 1 ? 9 : 6);
  doc.setFontSize(9);
  doc.setTextColor(234, 88, 12);
  doc.setFont('Roboto', 'bold');
  const artistLines = doc.splitTextToSize(`Артист: ${artistName}`, cardW - 8);
  doc.text(artistLines[0], cardX + 4, artistY);

  // Release Date & Details
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'normal');
  _safeText(`Дата релиза: ${relDateStr}${albumTitle && albumTitle !== releaseTitle ? ` • Альбом: ${albumTitle}` : ''}`, cardX + 4, artistY + 5);

  // Barcode & ISRC Highlight Box
  const codeBoxY = heroY + 36;
  const halfW = (cardW - 12) / 2;

  // UPC Box
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(cardX + 4, codeBoxY, halfW, 14, 1.5, 1.5, 'FD');
  doc.setFontSize(6);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('UPC / EAN BARCODE', cardX + 7, codeBoxY + 4.5);
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  _safeText(upc || 'Не указан в каталоге', cardX + 7, codeBoxY + 10.5);

  // ISRC Box
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(cardX + 8 + halfW, codeBoxY, halfW, 14, 1.5, 1.5, 'FD');
  doc.setFontSize(6);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('MASTER ISRC CODE', cardX + 11 + halfW, codeBoxY + 4.5);
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  _safeText(isrc || 'Не указан', cardX + 11 + halfW, codeBoxY + 10.5);

  // --- SECTION: RIGHTS & LICENSING ---
  const rightsY = 98;
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'bold');
  _safeText('ПРАВА И ДИСТРИБУЦИЯ (RIGHTS & LICENSING)', 14, rightsY);

  const rightsBoxY = rightsY + 3;
  const rightsBoxH = 28;
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, rightsBoxY, 182, rightsBoxH, 2, 2, 'FD');

  const colW = 58;
  // Col 1: Label & Distributor
  const col1X = 18;
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('ИЗДАТЕЛЬ / ЛЕЙБЛ:', col1X, rightsBoxY + 6);
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const labelLines = doc.splitTextToSize(label, colW);
  doc.text(labelLines[0], col1X, rightsBoxY + 11);

  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('ДИСТРИБЬЮТОР:', col1X, rightsBoxY + 18);
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const distLines = doc.splitTextToSize(distributor, colW);
  doc.text(distLines[0], col1X, rightsBoxY + 23);

  // Col 2: Copyright & Owner
  const col2X = 78;
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('КОПИРАЙТ (P-LINE):', col2X, rightsBoxY + 6);
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const cLines = doc.splitTextToSize(copyright, colW);
  doc.text(cLines[0], col2X, rightsBoxY + 11);

  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('ПРАВООБЛАДАТЕЛЬ:', col2X, rightsBoxY + 18);
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const ownerLines = doc.splitTextToSize(copyrightOwner, colW);
  doc.text(ownerLines[0], col2X, rightsBoxY + 23);

  // Col 3: Composer & Lyricist
  const col3X = 138;
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('АВТОР МУЗЫКИ (КОМПОЗИТОР):', col3X, rightsBoxY + 6);
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const musLines = doc.splitTextToSize(musicAuthor, colW);
  doc.text(musLines[0], col3X, rightsBoxY + 11);

  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.setFont('Roboto', 'bold');
  _safeText('АВТОР ТЕКСТА (ПОЭТ / АВТОР):', col3X, rightsBoxY + 18);
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'normal');
  const lyrLines = doc.splitTextToSize(lyricsAuthor, colW);
  doc.text(lyrLines[0], col3X, rightsBoxY + 23);

  // --- SECTION: TECHNICAL SPECIFICATIONS ---
  const techY = 136;
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('Roboto', 'bold');
  _safeText('ТЕХНИЧЕСКИЕ СПЕЦИФИКАЦИИ И ИДЕНТИФИКАТОРЫ', 14, techY);

  const pillW = 43.5;
  const pillH = 13;
  const pillY = techY + 3;

  const specs = [
    { label: 'АУДИО СТАНДАРТ', val: 'WAV 16-bit 44.1kHz PCM' },
    { label: 'ИСТОЧНИК ДАННЫХ', val: platform },
    { label: 'ИДЕНТИФИКАТОР', val: String(releaseId) },
    { label: 'ХРОНОМЕТРАЖ / ТРЕКИ', val: `${rawTracks.length} тр. • ${totalDurationStr}` }
  ];

  specs.forEach((s, idx) => {
    const px = 14 + idx * (pillW + 2.6);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(px, pillY, pillW, pillH, 1.5, 1.5, 'FD');
    doc.setFontSize(5.5);
    doc.setTextColor(100, 116, 139);
    doc.setFont('Roboto', 'bold');
    _safeText(s.label, px + 3, pillY + 4.5);
    doc.setFontSize(7);
    doc.setTextColor(15, 23, 42);
    _safeText(s.val, px + 3, pillY + 9.5);
  });

  // --- SECTION: TRACKLIST & ISRC CODES (AUTOTABLE) ---
  const tableStartY = pillY + pillH + 6;

  const tableHead = [[
    '#', 
    'Название трека', 
    'Исполнитель', 
    'ISRC Код', 
    'Длит.', 
    'Авторы (Музыка / Текст)'
  ]];

  const tableBody = rawTracks.map((tr, idx) => {
    const trTitle = tr.title || `Track ${idx + 1}`;
    const trArtist = tr.artists || tr.pseudonym || tr.performer || artistName;
    const trIsrc = tr.isrc || isrc || '—';
    const trDuration = formatDurationSec(tr.duration || (tr.durationMs ? Math.round(tr.durationMs / 1000) : undefined));
    const authorsArr = [tr.authorsMusic || (musicAuthor !== 'Не указан' ? musicAuthor : ''), tr.authorsText || (lyricsAuthor !== 'Не указан' ? lyricsAuthor : '')].filter(Boolean);
    const authorsStr = authorsArr.length > 0 ? authorsArr.join(' / ') : '—';
    return [
      String(tr.trackNumber || idx + 1),
      trTitle,
      trArtist,
      trIsrc,
      trDuration,
      authorsStr
    ];
  });

  (autoTable as any)(doc, {
    startY: tableStartY,
    head: tableHead,
    body: tableBody,
    theme: 'plain',
    margin: { left: 14, right: 14, bottom: 20 },
    styles: { 
      font: 'Roboto', 
      fontStyle: 'normal', 
      fontSize: 7.5, 
      cellPadding: 2.5, 
      lineColor: [226, 232, 240], 
      lineWidth: 0.1,
      textColor: [30, 41, 59]
    },
    headStyles: { 
      fillColor: [30, 41, 59], 
      textColor: [255, 255, 255], 
      fontStyle: 'bold', 
      fontSize: 7.5 
    },
    alternateRowStyles: { 
      fillColor: [248, 250, 252] 
    },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center', fontStyle: 'bold' },
      1: { cellWidth: 48, fontStyle: 'bold' },
      2: { cellWidth: 38 },
      3: { cellWidth: 32, fontStyle: 'bold', textColor: [15, 23, 42] },
      4: { cellWidth: 14, halign: 'center' },
      5: { cellWidth: 42 }
    }
  });

  // Stamp / Verification Note at the end of table
  const lastY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY + 6 : 250;
  if (lastY < 265) {
    doc.setFillColor(240, 253, 244);
    doc.setDrawColor(187, 247, 208);
    doc.roundedRect(14, lastY, 182, 12, 1.5, 1.5, 'FD');
    doc.setFontSize(6.5);
    doc.setTextColor(22, 101, 52);
    doc.setFont('Roboto', 'bold');
    _safeText('✔ ВЕРИФИКАЦИЯ МЕТАДАННЫХ РЕЛИЗА', 18, lastY + 4.5);
    doc.setFontSize(6);
    doc.setFont('Roboto', 'normal');
    doc.setTextColor(21, 128, 61);
    _safeText('Данный документ является официальным паспортом релиза для передачи на цифровые стриминг-сервисы (Яндекс Музыка, VK Музыка, Звук, Spotify, Apple Music).', 18, lastY + 8.5);
  }

  // --- FOOTER ON EVERY PAGE ---
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.2);
    doc.line(14, 285, 196, 285);

    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    doc.setFont('Roboto', 'normal');
    _safeText('ПАСПОРТ МЕТАДАННЫХ РЕЛИЗА • UNIVERSAL CATALOG & DISTRIBUTION SUITE', 14, 290);
    doc.text(`Стр. ${i} из ${totalPages}`, 196, 290, { align: 'right' });
  }

  // Output or download
  const cleanTitle = (releaseTitle || 'Release').replace(/[^a-zA-Z0-9а-яА-ЯёЁ_-]/g, '_');
  const cleanArtist = (artistName || 'Artist').replace(/[^a-zA-Z0-9а-яА-ЯёЁ_-]/g, '_');
  const fileName = `Release_Sheet_${cleanTitle}_${cleanArtist}.pdf`;

  if (previewMode === 'blob') {
    return (doc as any).output('blob');
  } else if (previewMode) {
    return (doc as any).output('bloburl');
  } else {
    doc.save(fileName);
  }
}
