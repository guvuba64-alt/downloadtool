/**
 * Complete SQL Migration Script for Supabase (PostgreSQL)
 * Can be run in Supabase SQL Editor in 1 click.
 */
export const SUPABASE_SQL_SCHEMA = `-- ==============================================================================
-- СХЕМА БАЗЫ ДАННЫХ ДЛЯ МУЗЫКАЛЬНОГО СЕРВЕРА И ТЕЛЕГРАМ БОТА
-- Поддержка: Яндекс Музыка, VK Музыка, OK.ru, Telegram Mini App, Моя волна, Поиск
-- ==============================================================================

-- 1. Таблица профилей пользователей (Web + Telegram)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id BIGINT UNIQUE,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Универсальное хранилище токенов (Яндекс, VK, OK.ru, Spotify, Telegram)
CREATE TABLE IF NOT EXISTS public.auth_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL DEFAULT 'default_user',
  provider TEXT NOT NULL, -- 'yandex', 'vk', 'ok_ru', 'spotify', 'telegram_bot'
  token TEXT NOT NULL,
  refresh_token TEXT,
  session_data JSONB DEFAULT '{}'::jsonb,
  is_valid BOOLEAN DEFAULT TRUE,
  account_name TEXT,
  account_uid TEXT,
  expires_at BIGINT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, provider)
);

-- 3. Сессии и состояние «Моей волны» (My Wave / Rotor)
CREATE TABLE IF NOT EXISTS public.wave_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  station_id TEXT NOT NULL DEFAULT 'user:onyourwave',
  batch_id TEXT,
  current_track_id TEXT,
  current_track_title TEXT,
  current_track_artist TEXT,
  current_track_cover TEXT,
  liked_tracks JSONB DEFAULT '[]'::jsonb,
  disliked_tracks JSONB DEFAULT '[]'::jsonb,
  history JSONB DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, station_id)
);

-- 4. История и кэш поисковых запросов
CREATE TABLE IF NOT EXISTS public.search_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT DEFAULT 'guest',
  platform TEXT NOT NULL DEFAULT 'all', -- 'yandex', 'vk', 'ok_ru', 'all'
  query TEXT NOT NULL,
  results_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Избранные треки и плейлисты (кросс-платформенная синхронизация)
CREATE TABLE IF NOT EXISTS public.favorites_sync (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  track_id TEXT NOT NULL,
  title TEXT NOT NULL,
  artist TEXT NOT NULL,
  album TEXT,
  cover_uri TEXT,
  platform TEXT DEFAULT 'yandex',
  duration INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, track_id, platform)
);

-- 6. Конфигурация серверов, доменов и Telegram-бота
CREATE TABLE IF NOT EXISTS public.server_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain TEXT NOT NULL UNIQUE,
  telegram_bot_token TEXT,
  telegram_webhook_url TEXT,
  cors_allowed_origins TEXT[] DEFAULT ARRAY['*'],
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Индексы для сверхбыстрого поиска
CREATE INDEX IF NOT EXISTS idx_auth_tokens_user_provider ON public.auth_tokens(user_id, provider);
CREATE INDEX IF NOT EXISTS idx_profiles_telegram_id ON public.profiles(telegram_id);
CREATE INDEX IF NOT EXISTS idx_wave_sessions_user ON public.wave_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_user ON public.favorites_sync(user_id);
CREATE INDEX IF NOT EXISTS idx_search_logs_query ON public.search_logs(query);

-- Включение Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wave_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites_sync ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.server_configs ENABLE ROW LEVEL SECURITY;

-- Публичные политики для доступа через Anon/Service-Role Key
DROP POLICY IF EXISTS "Allow public read access for tokens" ON public.auth_tokens;
CREATE POLICY "Allow public read access for tokens" ON public.auth_tokens FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public access for profiles" ON public.profiles;
CREATE POLICY "Allow public access for profiles" ON public.profiles FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public access for wave" ON public.wave_sessions;
CREATE POLICY "Allow public access for wave" ON public.wave_sessions FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public access for search" ON public.search_logs;
CREATE POLICY "Allow public access for search" ON public.search_logs FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public access for favorites" ON public.favorites_sync;
CREATE POLICY "Allow public access for favorites" ON public.favorites_sync FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public access for configs" ON public.server_configs;
CREATE POLICY "Allow public access for configs" ON public.server_configs FOR ALL USING (true);
`;
