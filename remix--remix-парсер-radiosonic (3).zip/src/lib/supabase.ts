import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastChecked?: number;
  error?: string | null;
}

let cachedClient: SupabaseClient | null = null;
let currentConfigHash: string = '';

export const DEFAULT_SUPABASE_URL = 'https://oeurpptqbkuxyqyfaahj.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_d4xsXd0ZQW8KUKWGHyOF0g_vXbj_mFo';

export function getSupabaseConfig(): SupabaseConfig {
  const metaEnv = (import.meta as any).env || {};
  const envUrl = (metaEnv.VITE_SUPABASE_URL || metaEnv.SUPABASE_URL || '').trim();
  const envKey = (metaEnv.VITE_SUPABASE_ANON_KEY || metaEnv.SUPABASE_ANON_KEY || '').trim();

  const savedUrl = (typeof window !== 'undefined' ? localStorage.getItem('supabase_project_url') : '') || '';
  const savedKey = (typeof window !== 'undefined' ? localStorage.getItem('supabase_anon_key') : '') || '';

  const url = savedUrl || envUrl || DEFAULT_SUPABASE_URL;
  const anonKey = savedKey || envKey || DEFAULT_SUPABASE_ANON_KEY;

  return {
    url,
    anonKey,
    isConnected: Boolean(url && anonKey),
  };
}

export function saveSupabaseConfig(url: string, anonKey: string): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem('supabase_project_url', url.trim());
    localStorage.setItem('supabase_anon_key', anonKey.trim());
  }
  cachedClient = null;
  currentConfigHash = '';
}

export function clearSupabaseConfig(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('supabase_project_url');
    localStorage.removeItem('supabase_anon_key');
  }
  cachedClient = null;
  currentConfigHash = '';
}

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  const hash = `${config.url}:::${config.anonKey}`;
  if (cachedClient && currentConfigHash === hash) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    currentConfigHash = hash;
    return cachedClient;
  } catch (err) {
    console.error('Failed to create Supabase client:', err);
    return null;
  }
}

export async function testSupabaseConnection(customUrl?: string, customKey?: string): Promise<{ success: boolean; message: string; latencyMs?: number; tables?: string[] }> {
  const config = getSupabaseConfig();
  const url = (customUrl || config.url || '').trim();
  const key = (customKey || config.anonKey || '').trim();

  if (!url || !key) {
    return { success: false, message: 'Укажите URL проекта и Anon/Public Key' };
  }

  const start = performance.now();
  try {
    const client = createClient(url, key);
    // Ping auth or table
    const { data, error } = await client.from('auth_tokens').select('id').limit(1);

    const latency = Math.round(performance.now() - start);

    if (error) {
      // Table might not exist yet, check if project is reachable
      if (error.code === '42P01') {
        return { 
          success: true, 
          message: 'Подключение к Supabase успешно! (Таблицы еще не созданы, выполните SQL миграцию)', 
          latencyMs: latency 
        };
      }
      return { success: false, message: `Ошибка Supabase: ${error.message} (код: ${error.code})` };
    }

    return { 
      success: true, 
      message: 'Подключение успешно! Таблицы доступны.', 
      latencyMs: latency 
    };
  } catch (err: any) {
    return { success: false, message: `Сетевая ошибка: ${err.message || 'Не удалось подключиться к Supabase'}` };
  }
}

export async function syncTokenToSupabase(
  provider: 'yandex' | 'vk' | 'ok_ru' | 'spotify' | 'telegram_bot',
  token: string,
  extra: { accountName?: string; accountUid?: string; sessionData?: any } = {},
  userId: string = 'default_user'
) {
  const client = getSupabaseClient();
  if (!client) {
    throw new Error('Supabase client not configured');
  }

  const { data, error } = await client
    .from('auth_tokens')
    .upsert({
      user_id: userId,
      provider,
      token,
      account_name: extra.accountName || null,
      account_uid: extra.accountUid || null,
      session_data: extra.sessionData || {},
      is_valid: true,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id,provider' });

  if (error) throw error;
  return data;
}

export async function loadTokensFromSupabase(userId: string = 'default_user'): Promise<Record<string, any>> {
  const client = getSupabaseClient();
  if (!client) return {};

  try {
    const { data, error } = await client
      .from('auth_tokens')
      .select('*')
      .eq('user_id', userId);

    if (error || !data) return {};

    const tokensMap: Record<string, any> = {};
    for (const item of data) {
      tokensMap[item.provider] = item;
    }
    return tokensMap;
  } catch (e) {
    console.error('Error loading tokens from Supabase:', e);
    return {};
  }
}

export async function syncWaveSessionToSupabase(session: {
  userId: string;
  stationId: string;
  batchId?: string;
  currentTrack?: any;
  likedTracks?: string[];
  dislikedTracks?: string[];
  history?: any[];
}) {
  const client = getSupabaseClient();
  if (!client) return null;

  try {
    const { data, error } = await client
      .from('wave_sessions')
      .upsert({
        user_id: session.userId || 'default_user',
        station_id: session.stationId || 'user:onyourwave',
        batch_id: session.batchId || null,
        current_track_id: session.currentTrack?.id ? String(session.currentTrack.id) : null,
        current_track_title: session.currentTrack?.title || null,
        current_track_artist: session.currentTrack?.artists ? (Array.isArray(session.currentTrack.artists) ? session.currentTrack.artists.map((a: any) => typeof a === 'string' ? a : a.name).join(', ') : session.currentTrack.artists) : null,
        current_track_cover: session.currentTrack?.coverUri || null,
        liked_tracks: session.likedTracks || [],
        disliked_tracks: session.dislikedTracks || [],
        history: session.history || [],
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id,station_id' });

    if (error) console.error('Error syncing wave to Supabase:', error);
    return data;
  } catch (e) {
    console.error('Failed to sync wave session:', e);
    return null;
  }
}
