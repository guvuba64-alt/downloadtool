/**
 * Owner Authentication and Access Control Helper
 * Chief Telegram ID: 8981404137
 */

export const CHIEF_OWNER_TG_ID = '8981404137';

export function isChiefOwnerAuthenticated(): boolean {
  if (typeof window === 'undefined') return false;

  // 1. Check URL parameters
  try {
    const params = new URLSearchParams(window.location.search);
    const tgParam = params.get('tg_id') || params.get('owner') || params.get('admin_id');
    if (tgParam === CHIEF_OWNER_TG_ID) {
      localStorage.setItem('owner_tg_id', CHIEF_OWNER_TG_ID);
      localStorage.setItem('adminTgId', CHIEF_OWNER_TG_ID);
      return true;
    }
  } catch (e) {}

  // 2. Check Telegram Mini App initDataUnsafe
  try {
    const tgUser = (window as any).Telegram?.WebApp?.initDataUnsafe?.user;
    if (tgUser?.id && String(tgUser.id) === CHIEF_OWNER_TG_ID) {
      localStorage.setItem('owner_tg_id', CHIEF_OWNER_TG_ID);
      localStorage.setItem('adminTgId', CHIEF_OWNER_TG_ID);
      return true;
    }
  } catch (e) {}

  // 3. Check persistent localStorage
  const savedOwner = localStorage.getItem('owner_tg_id');
  const savedAdmin = localStorage.getItem('adminTgId');
  if (savedOwner === CHIEF_OWNER_TG_ID || savedAdmin === CHIEF_OWNER_TG_ID) {
    return true;
  }

  return false;
}

export function setChiefOwnerAuthenticated(id: string): boolean {
  if (typeof window === 'undefined') return false;
  const cleanId = String(id || '').trim();
  if (cleanId === CHIEF_OWNER_TG_ID) {
    localStorage.setItem('owner_tg_id', CHIEF_OWNER_TG_ID);
    localStorage.setItem('adminTgId', CHIEF_OWNER_TG_ID);
    return true;
  }
  return false;
}

export function revokeChiefOwner(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('owner_tg_id');
  localStorage.removeItem('adminTgId');
}
