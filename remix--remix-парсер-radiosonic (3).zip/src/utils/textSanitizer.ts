/**
 * Client-Side Text Sanitizer, Unicode / URI Decoder & Mojibake Fixer
 */

export function safeEncodeURIComponent(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    const wellFormed = typeof (str as any).toWellFormed === "function"
      ? (str as any).toWellFormed()
      : str.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, "\uFFFD");
    return encodeURIComponent(wellFormed);
  } catch {
    try {
      return encodeURIComponent(str.replace(/[^\x20-\x7E]/g, ""));
    } catch {
      return escape(str);
    }
  }
}

export function safeDecodeURIComponent(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  try {
    return decodeURIComponent(str.replace(/\+/g, " "));
  } catch {
    try {
      return str.replace(/%([0-9a-fA-F]{2})/g, (match, hex) => {
        try {
          return String.fromCharCode(parseInt(hex, 16));
        } catch {
          return match;
        }
      }).replace(/\+/g, " ");
    } catch {
      return str;
    }
  }
}

export function decodePercentEncoded(input: string): string {
  if (!input || typeof input !== "string") return "";
  let current = input;
  let prev = "";
  let depth = 0;
  while (current !== prev && depth < 5) {
    prev = current;
    try {
      if (/%[0-9a-fA-F]{2}/.test(current)) {
        current = safeDecodeURIComponent(current.replace(/\+/g, " "));
      } else {
        break;
      }
    } catch {
      current = current.replace(/%([0-9a-fA-F]{2})/g, (_, hex) => {
        try {
          return String.fromCharCode(parseInt(hex, 16));
        } catch {
          return _;
        }
      });
      break;
    }
    depth++;
  }
  return current;
}

export function decodeUnicodeEscapes(input: string): string {
  if (!input || typeof input !== "string") return "";
  let out = input;
  try {
    out = out.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
    out = out.replace(/\\x([0-9a-fA-F]{2})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
  } catch {}
  return out;
}

export function decodeHtmlEntities(input: string): string {
  if (!input || typeof input !== "string") return "";
  return input
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#(\d+);/g, (_, num) => String.fromCharCode(parseInt(num, 10)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
}

export function stripControlAndProtobuf(input: string): string {
  if (!input || typeof input !== "string") return "";
  return input
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "")
    .replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ")
    .replace(/(?:\\x0[0-9a-f]|\\x1[0-9a-f])+/gi, "")
    .replace(/[ \t]+/g, " ")
    .trim();
}

export function fixMojibake(input: string): string {
  if (!input || typeof input !== "string") return "";
  let str = input;

  if (/[ÐÑ][\x80-\xFF]/.test(str) || /[\xC2\xC3][\x80-\xBF]/.test(str)) {
    try {
      // Browser UTF-8 decode simulation from raw char codes
      const bytes = new Uint8Array(str.length);
      for (let i = 0; i < str.length; i++) {
        bytes[i] = str.charCodeAt(i) & 0xff;
      }
      const decoder = new TextDecoder("utf-8");
      const decoded = decoder.decode(bytes);
      if (/[а-яА-ЯёЁ]/.test(decoded)) {
        str = decoded;
      }
    } catch {}
  }

  return str;
}

export function sanitizeDisplayString(val: any): string {
  if (val === null || val === undefined) return "";
  if (typeof val !== "string") val = String(val);
  if (!val.trim()) return "";

  let cleaned = val.trim();
  cleaned = decodePercentEncoded(cleaned);
  cleaned = decodeUnicodeEscapes(cleaned);
  cleaned = decodeHtmlEntities(cleaned);
  cleaned = fixMojibake(cleaned);
  cleaned = stripControlAndProtobuf(cleaned);

  return cleaned;
}
