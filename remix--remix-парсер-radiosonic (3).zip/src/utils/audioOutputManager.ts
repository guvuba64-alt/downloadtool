// Audio Output Device Manager & Media Session Bluetooth Integration

export interface AudioOutputDevice {
  deviceId: string;
  label: string;
  kind: 'audiooutput';
  groupId: string;
  isBluetooth: boolean;
  isDefault: boolean;
  type: 'bluetooth' | 'headphones' | 'speaker' | 'usb' | 'default';
}

export interface MediaMetadataConfig {
  title: string;
  artist: string;
  album?: string;
  artworkUrl?: string;
}

type DeviceChangeListener = (devices: AudioOutputDevice[], activeDeviceId: string) => void;

class AudioOutputManagerService {
  private activeDeviceId: string = 'default';
  private devices: AudioOutputDevice[] = [];
  private attachedAudio: HTMLAudioElement | null = null;
  private listeners = new Set<DeviceChangeListener>();
  private mediaSessionConfig: MediaMetadataConfig | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.loadSavedDevice();
      this.refreshDevices();

      if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
        navigator.mediaDevices.addEventListener('devicechange', () => {
          this.refreshDevices();
        });
      }
    }
  }

  private loadSavedDevice() {
    try {
      const saved = localStorage.getItem('yandex_music_output_device_id');
      if (saved) {
        this.activeDeviceId = saved;
      }
    } catch (e) {}
  }

  public subscribe(listener: DeviceChangeListener): () => void {
    this.listeners.add(listener);
    listener(this.devices, this.activeDeviceId);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => {
      try {
        fn(this.devices, this.activeDeviceId);
      } catch (e) {
        console.error(e);
      }
    });
  }

  public async refreshDevices(): Promise<AudioOutputDevice[]> {
    if (typeof window === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      return [];
    }

    try {
      const allDevices = await navigator.mediaDevices.enumerateDevices();
      const audioOutputs = allDevices.filter((d) => d.kind === 'audiooutput');

      const parsed: AudioOutputDevice[] = audioOutputs.map((d, index) => {
        const rawLabel = d.label || (index === 0 ? 'Основной динамик / Default' : `Аудиовыход ${index + 1}`);
        const lower = rawLabel.toLowerCase();

        const isBluetooth =
          lower.includes('bluetooth') ||
          lower.includes('airpods') ||
          lower.includes('buds') ||
          lower.includes('wh-') ||
          lower.includes('wf-') ||
          lower.includes('wireless') ||
          lower.includes('jbl') ||
          lower.includes('bose') ||
          lower.includes('sennheiser') ||
          lower.includes('beats') ||
          lower.includes('hands-free') ||
          lower.includes('headset') ||
          lower.includes('galaxy') ||
          lower.includes('freebuds');

        let type: AudioOutputDevice['type'] = 'default';
        if (isBluetooth) {
          type = 'bluetooth';
        } else if (lower.includes('headphone') || lower.includes('наушники') || lower.includes('earphone')) {
          type = 'headphones';
        } else if (lower.includes('usb') || lower.includes('dac') || lower.includes('цап')) {
          type = 'usb';
        } else if (lower.includes('speaker') || lower.includes('динамик') || lower.includes('realtek')) {
          type = 'speaker';
        }

        return {
          deviceId: d.deviceId,
          label: rawLabel,
          kind: 'audiooutput',
          groupId: d.groupId,
          isBluetooth,
          isDefault: d.deviceId === 'default' || index === 0,
          type,
        };
      });

      // If no labels exist yet (permission not granted), provide placeholder devices
      if (parsed.length === 0) {
        parsed.push({
          deviceId: 'default',
          label: 'Системное аудио / Bluetooth наушники',
          kind: 'audiooutput',
          groupId: '',
          isBluetooth: false,
          isDefault: true,
          type: 'default',
        });
      }

      this.devices = parsed;
      this.notify();
      return this.devices;
    } catch (e) {
      console.warn('Could not enumerate audio output devices:', e);
      return [];
    }
  }

  public attach(audio: HTMLAudioElement) {
    this.attachedAudio = audio;
    if (this.activeDeviceId && this.activeDeviceId !== 'default') {
      this.setDevice(this.activeDeviceId).catch(() => {});
    }
  }

  public async setDevice(deviceId: string): Promise<boolean> {
    this.activeDeviceId = deviceId;
    try {
      localStorage.setItem('yandex_music_output_device_id', deviceId);
    } catch (e) {}

    if (this.attachedAudio && typeof (this.attachedAudio as any).setSinkId === 'function') {
      try {
        await (this.attachedAudio as any).setSinkId(deviceId);
        this.notify();
        return true;
      } catch (err: any) {
        console.warn('setSinkId error:', err.message);
        this.notify();
        return false;
      }
    }

    this.notify();
    return true;
  }

  public getActiveDevice(): AudioOutputDevice | undefined {
    return this.devices.find((d) => d.deviceId === this.activeDeviceId) || this.devices[0];
  }

  public async requestPermissions(): Promise<boolean> {
    if (typeof window === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return false;
    }

    try {
      // Temporarily request microphone stream to reveal hardware device labels
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      await this.refreshDevices();
      return true;
    } catch (e) {
      console.warn('User dismissed audio permissions:', e);
      return false;
    }
  }

  /**
   * Updates Media Session metadata for Bluetooth headsets, car audio, smart watches, lock screen
   */
  public updateMediaSession(
    config: MediaMetadataConfig,
    handlers: {
      onPlay?: () => void;
      onPause?: () => void;
      onNext?: () => void;
      onPrevious?: () => void;
      onSeekTo?: (time: number) => void;
      onSeekForward?: () => void;
      onSeekBackward?: () => void;
    }
  ) {
    if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;

    this.mediaSessionConfig = config;

    const artworkList: MediaImage[] = [];
    if (config.artworkUrl) {
      artworkList.push(
        { src: config.artworkUrl, sizes: '96x96', type: 'image/jpeg' },
        { src: config.artworkUrl, sizes: '128x128', type: 'image/jpeg' },
        { src: config.artworkUrl, sizes: '256x256', type: 'image/jpeg' },
        { src: config.artworkUrl, sizes: '512x512', type: 'image/jpeg' }
      );
    }

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: config.title || 'Unknown Title',
        artist: config.artist || 'Unknown Artist',
        album: config.album || 'Yandex Music',
        artwork: artworkList,
      });

      // Bluetooth & Hardware action handlers
      const actionMap: Array<[MediaSessionAction, (() => void) | undefined]> = [
        ['play', handlers.onPlay],
        ['pause', handlers.onPause],
        ['previoustrack', handlers.onPrevious],
        ['nexttrack', handlers.onNext],
        ['seekforward', handlers.onSeekForward],
        ['seekbackward', handlers.onSeekBackward],
      ];

      actionMap.forEach(([action, handler]) => {
        try {
          if (handler) {
            navigator.mediaSession.setActionHandler(action, handler);
          } else {
            navigator.mediaSession.setActionHandler(action, null);
          }
        } catch (e) {}
      });

      if (handlers.onSeekTo) {
        try {
          navigator.mediaSession.setActionHandler('seekto', (details) => {
            if (details.seekTime !== undefined && handlers.onSeekTo) {
              handlers.onSeekTo(details.seekTime);
            }
          });
        } catch (e) {}
      }
    } catch (e) {
      console.warn('MediaSession update warning:', e);
    }
  }

  public setPlaybackState(state: 'none' | 'paused' | 'playing') {
    if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.playbackState = state;
    } catch (e) {}
  }

  public setPositionState(state: { duration: number; playbackRate?: number; position: number }) {
    if (typeof window === 'undefined' || !('mediaSession' in navigator) || !navigator.mediaSession.setPositionState) return;
    try {
      if (state.duration > 0 && !isNaN(state.position) && state.position <= state.duration) {
        navigator.mediaSession.setPositionState({
          duration: Math.max(0, state.duration),
          playbackRate: state.playbackRate || 1.0,
          position: Math.max(0, state.position),
        });
      }
    } catch (e) {}
  }

  public playTestChime() {
    if (typeof window === 'undefined') return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.36);
    } catch (e) {}
  }
}

export const audioOutputManager = new AudioOutputManagerService();
