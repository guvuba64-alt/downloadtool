/**
 * Instant Track Metadata Extractor & Utility
 * Synchronously extracts full metadata from track & album objects with zero delay.
 */

export interface TrackMetadataDetails {
  id?: string;
  albumId?: string;
  albumTitle?: string;
  title: string;
  artists: string;
  performer: string;
  label: string;
  phonogramSource: string;
  copyright: string;
  isrc?: string | null;
  upc?: string | null;
  releaseDate?: string | null;
  year?: string | number | null;
  authorsMusic?: string | null;
  authorsText?: string | null;
  coverUri?: string | null;
}

export function extractTrackDetails(
  track: any,
  fallbackArtists?: string,
  fallbackCover?: string
): TrackMetadataDetails | null {
  if (!track) return null;

  const alb = (Array.isArray(track.albums) && track.albums.length > 0) 
    ? track.albums[0] 
    : (track.album || {});

  // Artists / Performer
  let artistsStr = '';
  if (fallbackArtists) {
    artistsStr = fallbackArtists;
  } else if (typeof track.artists === 'string') {
    artistsStr = track.artists;
  } else if (Array.isArray(track.artists) && track.artists.length > 0) {
    artistsStr = track.artists
      .map((a: any) => typeof a === 'string' ? a : (a.name || ''))
      .filter(Boolean)
      .join(', ');
  } else if (track.artist) {
    artistsStr = typeof track.artist === 'string' ? track.artist : (track.artist.name || '');
  }

  // Distributor information (User instruction: Label must search for information written as distributor)
  let distributorStr = '';
  if (typeof track.distributor === 'string' && track.distributor.trim()) {
    distributorStr = track.distributor.trim();
  } else if (track.distributor?.name) {
    distributorStr = track.distributor.name;
  } else if (Array.isArray(track.distributors) && track.distributors.length > 0) {
    distributorStr = typeof track.distributors[0] === 'string' ? track.distributors[0] : (track.distributors[0]?.name || '');
  } else if (typeof alb.distributor === 'string' && alb.distributor.trim()) {
    distributorStr = alb.distributor.trim();
  } else if (alb.distributor?.name) {
    distributorStr = alb.distributor.name;
  } else if (Array.isArray(alb.distributors) && alb.distributors.length > 0) {
    distributorStr = typeof alb.distributors[0] === 'string' ? alb.distributors[0] : (alb.distributors[0]?.name || '');
  } else if (track.aggregator) {
    distributorStr = typeof track.aggregator === 'string' ? track.aggregator : (track.aggregator.name || '');
  } else if (alb.aggregator) {
    distributorStr = typeof alb.aggregator === 'string' ? alb.aggregator : (alb.aggregator.name || '');
  } else if (track.detectedDistributor?.name) {
    distributorStr = track.detectedDistributor.name;
  }

  // Label: prioritize distributor if present, or search in labels/publisher/major
  let labelStr = distributorStr || track.label || track.hiddenLabel || '';
  if (!labelStr && Array.isArray(alb.labels) && alb.labels.length > 0) {
    labelStr = typeof alb.labels[0] === 'string' ? alb.labels[0] : (alb.labels[0]?.name || '');
  }
  if (!labelStr && Array.isArray(track.labels) && track.labels.length > 0) {
    labelStr = typeof track.labels[0] === 'string' ? track.labels[0] : (track.labels[0]?.name || '');
  }
  if (!labelStr && alb.label) {
    labelStr = typeof alb.label === 'string' ? alb.label : (alb.label?.name || '');
  }
  if (!labelStr && track.major?.name) {
    labelStr = track.major.name;
  }
  if (!labelStr && track.publisher) {
    labelStr = track.publisher;
  }
  if (!labelStr && distributorStr) {
    labelStr = distributorStr;
  }

  // Release Date & Year
  const releaseDate = track.releaseDate || alb.releaseDate || (track.year ? `${track.year}-01-01` : (alb.year ? `${alb.year}-01-01` : null));
  const year = track.year || alb.year || (releaseDate ? new Date(releaseDate).getFullYear() : new Date().getFullYear());

  // Copyright & Rights Holder (user instruction: search copyright and rights holder)
  let copyrightStr = track.copyright || track.pLine || '';
  if (!copyrightStr && Array.isArray(alb.copyrights) && alb.copyrights.length > 0) {
    copyrightStr = alb.copyrights.join(', ');
  }
  if (!copyrightStr && alb.copyright) {
    copyrightStr = alb.copyright;
  }
  if (!copyrightStr && alb.pLine) {
    copyrightStr = alb.pLine;
  }
  if (!copyrightStr && (track.copyrightOwnerName || alb.copyrightOwnerName)) {
    copyrightStr = `℗ ${year} ${track.copyrightOwnerName || alb.copyrightOwnerName}`;
  }
  if (!copyrightStr && labelStr && labelStr !== 'No label' && labelStr !== 'Не указан') {
    copyrightStr = `℗ ${year} ${labelStr}`;
  }

  // Phonogram Source
  let phonoSource = track.phonogramSource || '';
  if (!phonoSource || phonoSource === 'No phonogram source') {
    if (labelStr && labelStr !== 'No label' && labelStr !== 'Не указан') {
      phonoSource = labelStr;
    } else if (copyrightStr && copyrightStr !== 'No copyright' && copyrightStr !== 'Copyright не найден') {
      phonoSource = copyrightStr.replace(/^[℗©]\s*\d{4}\s*/, '');
    } else {
      phonoSource = 'Не указан';
    }
  }

  // ISRC & UPC
  const isrc = track.isrc || track.trackIsrc || alb.isrc || alb.recordingIsrc || track.credits?.isrc || track.pcode || null;
  const upc = track.upc || track.barcode || track.ean || alb.upc || alb.barcode || alb.ean || alb.catalogNumber || null;

  // Authors
  let authorsMusic = track.authorsMusic || null;
  let authorsText = track.authorsText || null;

  if (!authorsMusic && Array.isArray(track.credits)) {
    const musicCredits = track.credits.filter((c: any) => 
      c.role === 'composer' || c.role === 'music' || c.role === 'writer' || (c.type && String(c.type).includes('music'))
    ).map((c: any) => c.name || c.person).filter(Boolean);
    if (musicCredits.length > 0) authorsMusic = musicCredits.join(', ');
  } else if (!authorsMusic && track.credits?.music) {
    authorsMusic = Array.isArray(track.credits.music) ? track.credits.music.join(', ') : String(track.credits.music);
  }

  if (!authorsText && Array.isArray(track.credits)) {
    const textCredits = track.credits.filter((c: any) => 
      c.role === 'lyricist' || c.role === 'author' || c.role === 'text' || (c.type && String(c.type).includes('text'))
    ).map((c: any) => c.name || c.person).filter(Boolean);
    if (textCredits.length > 0) authorsText = textCredits.join(', ');
  } else if (!authorsText && track.credits?.text) {
    authorsText = Array.isArray(track.credits.text) ? track.credits.text.join(', ') : String(track.credits.text);
  }

  const rawAlbumId = alb.id || alb.albumId || track.albumId || (Array.isArray(track.albums) && track.albums[0]?.id);
  const rawAlbumTitle = alb.title || track.albumTitle || (Array.isArray(track.albums) && track.albums[0]?.title) || undefined;

  return {
    id: track.id ? String(track.id) : undefined,
    albumId: rawAlbumId ? String(rawAlbumId) : undefined,
    albumTitle: rawAlbumTitle,
    title: track.title || '',
    artists: artistsStr || 'Не указан',
    performer: artistsStr || 'Не указан',
    label: labelStr || 'Не указан',
    phonogramSource: phonoSource || 'Не указан',
    copyright: copyrightStr || 'Не указан',
    isrc: isrc,
    upc: upc,
    releaseDate: releaseDate,
    year: year,
    authorsMusic: authorsMusic,
    authorsText: authorsText,
    coverUri: track.coverUri || alb.coverUri || fallbackCover || null,
  };
}
