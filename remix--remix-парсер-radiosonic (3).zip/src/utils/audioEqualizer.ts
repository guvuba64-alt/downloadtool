// Web Audio API Equalizer & Audio DSP Fine-Tuning Engine

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // in dB (-12 to +12)
  type: BiquadFilterType;
}

export interface EqualizerPreset {
  id: string;
  name: string;
  nameRu: string;
  bands: number[]; // 10 values for each band
  bassBoost?: number; // 0 to 100
  surround?: number; // 0 to 100
  vocalClarity?: number; // 0 to 100
}

export interface FineTuningSettings {
  enabled: boolean;
  presetId: string;
  bands: number[]; // 10 bands: 32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
  preAmp: number; // in dB (-6 to +6)
  bassBoost: number; // 0 to 100
  surround: number; // 0 to 100 (3D Spatial effect)
  vocalClarity: number; // 0 to 100
  balance: number; // -1 (Left) to +1 (Right)
  playbackRate: number; // 0.5 to 2.0
  preservePitch: boolean;
}

export const FREQUENCIES = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
export const FREQUENCY_LABELS = ['32 Гц', '64 Гц', '125 Гц', '250 Гц', '500 Гц', '1 кГц', '2 кГц', '4 кГц', '8 кГц', '16 кГц'];

export const EQUALIZER_PRESETS: EqualizerPreset[] = [
  {
    id: 'flat',
    name: 'Flat',
    nameRu: 'Обычный / Flat',
    bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    bassBoost: 0,
    surround: 0,
    vocalClarity: 0,
  },
  {
    id: 'bass_boost',
    name: 'Bass Boost',
    nameRu: 'Усиление баса',
    bands: [8, 7, 5, 3, 1, 0, 0, 0, 0, 0],
    bassBoost: 75,
    surround: 20,
    vocalClarity: 10,
  },
  {
    id: 'super_bass',
    name: 'Club / Sub-Bass',
    nameRu: 'Сверхбас / Клубный',
    bands: [10, 9, 6, 2, 0, 1, 2, 3, 4, 5],
    bassBoost: 90,
    surround: 40,
    vocalClarity: 15,
  },
  {
    id: 'treble_boost',
    name: 'Treble Boost',
    nameRu: 'Высокие частоты',
    bands: [0, 0, 0, 0, 1, 2, 4, 6, 8, 9],
    bassBoost: 0,
    surround: 15,
    vocalClarity: 40,
  },
  {
    id: 'vocal_clarity',
    name: 'Vocal Clarity',
    nameRu: 'Четкость вокала и речи',
    bands: [-2, -1, 0, 2, 5, 6, 4, 2, 1, 0],
    bassBoost: 10,
    surround: 10,
    vocalClarity: 85,
  },
  {
    id: 'electronic',
    name: 'Electronic / EDM',
    nameRu: 'Электроника / EDM',
    bands: [6, 5, 2, 0, -1, 2, 3, 5, 6, 7],
    bassBoost: 60,
    surround: 50,
    vocalClarity: 20,
  },
  {
    id: 'rock',
    name: 'Rock',
    nameRu: 'Рок',
    bands: [6, 4, 2, -1, -2, 1, 3, 5, 6, 6],
    bassBoost: 45,
    surround: 30,
    vocalClarity: 35,
  },
  {
    id: 'pop',
    name: 'Pop',
    nameRu: 'Поп',
    bands: [-1, 2, 4, 5, 4, 2, 1, 2, 4, 3],
    bassBoost: 30,
    surround: 25,
    vocalClarity: 50,
  },
  {
    id: 'hiphop',
    name: 'Hip-Hop',
    nameRu: 'Хип-хоп / R&B',
    bands: [8, 7, 4, 1, -1, 0, 2, 1, 3, 4],
    bassBoost: 80,
    surround: 35,
    vocalClarity: 30,
  },
  {
    id: 'jazz',
    name: 'Jazz',
    nameRu: 'Джаз',
    bands: [3, 2, 1, 2, -1, -1, 0, 2, 3, 4],
    bassBoost: 25,
    surround: 30,
    vocalClarity: 40,
  },
  {
    id: 'classical',
    name: 'Classical',
    nameRu: 'Классика',
    bands: [4, 3, 2, 1, -1, -1, 0, 2, 4, 5],
    bassBoost: 20,
    surround: 45,
    vocalClarity: 35,
  },
  {
    id: 'acoustic',
    name: 'Acoustic',
    nameRu: 'Акустика',
    bands: [3, 3, 2, 2, 3, 3, 2, 3, 4, 3],
    bassBoost: 20,
    surround: 35,
    vocalClarity: 60,
  },
  {
    id: 'headphones',
    name: 'Headphones / Bluetooth',
    nameRu: 'Наушники / Bluetooth',
    bands: [5, 4, 2, 1, 0, 1, 2, 4, 5, 5],
    bassBoost: 50,
    surround: 60,
    vocalClarity: 40,
  },
  {
    id: 'custom',
    name: 'Custom',
    nameRu: 'Пользовательский',
    bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    bassBoost: 0,
    surround: 0,
    vocalClarity: 0,
  },
];

const DEFAULT_SETTINGS: FineTuningSettings = {
  enabled: true,
  presetId: 'flat',
  bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  preAmp: 0,
  bassBoost: 0,
  surround: 0,
  vocalClarity: 0,
  balance: 0,
  playbackRate: 1.0,
  preservePitch: true,
};

const STORAGE_KEY = 'yandex_music_audio_eq_settings_v2';

class AudioEqualizerService {
  private audioCtx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private preAmpGain: GainNode | null = null;
  private filterNodes: BiquadFilterNode[] = [];
  private bassBoostNode: BiquadFilterNode | null = null;
  private vocalClarityNode: BiquadFilterNode | null = null;
  private surroundDelayNode: DelayNode | null = null;
  private surroundGainNode: GainNode | null = null;
  private dryGainNode: GainNode | null = null;
  private pannerNode: StereoPannerNode | null = null;
  private masterGain: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private attachedAudioElement: HTMLAudioElement | null = null;

  private settings: FineTuningSettings = DEFAULT_SETTINGS;
  private listeners = new Set<(settings: FineTuningSettings) => void>();

  constructor() {
    this.loadSettings();
  }

  private loadSettings() {
    if (typeof window === 'undefined') return;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.settings = { ...DEFAULT_SETTINGS, ...parsed };
      }
    } catch (e) {
      console.warn('Failed to load EQ settings from localStorage', e);
    }
  }

  public saveSettings() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch (e) {
      console.warn('Failed to save EQ settings', e);
    }
  }

  public getSettings(): FineTuningSettings {
    return { ...this.settings };
  }

  public subscribe(listener: (settings: FineTuningSettings) => void): () => void {
    this.listeners.add(listener);
    listener(this.getSettings());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.saveSettings();
    this.listeners.forEach((fn) => {
      try {
        fn(this.getSettings());
      } catch (e) {
        console.error(e);
      }
    });
  }

  /**
   * Initializes the Web Audio graph and attaches to the HTMLAudioElement
   */
  public attach(audio: HTMLAudioElement) {
    if (typeof window === 'undefined' || !audio) return;
    if (this.attachedAudioElement === audio && this.audioCtx && this.sourceNode) {
      this.applyAllNodes();
      return;
    }

    try {
      this.attachedAudioElement = audio;
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;

      if (!this.audioCtx || this.audioCtx.state === 'closed') {
        this.audioCtx = new AudioContextClass();
      }

      if (this.audioCtx.state === 'suspended') {
        const unlock = () => {
          this.audioCtx?.resume().catch(() => {});
          document.removeEventListener('click', unlock);
          document.removeEventListener('touchstart', unlock);
          document.removeEventListener('keydown', unlock);
        };
        document.addEventListener('click', unlock, { once: true });
        document.addEventListener('touchstart', unlock, { once: true });
        document.addEventListener('keydown', unlock, { once: true });
      }

      // Reuse existing source node if attached previously on this audio element
      let source: MediaElementAudioSourceNode | null = (audio as any).__mediaElementSourceNode || null;
      if (!source) {
        try {
          source = this.audioCtx.createMediaElementSource(audio);
          (audio as any).__mediaElementSourceNode = source;
        } catch (e: any) {
          console.warn('MediaElementSource attach notice:', e?.message || e);
          if ((audio as any).__mediaElementSourceNode) {
            source = (audio as any).__mediaElementSourceNode;
          }
        }
      }

      this.sourceNode = source;
      if (!this.sourceNode) {
        return;
      }

      // 1. PreAmp Gain
      this.preAmpGain = this.audioCtx.createGain();

      // 2. Bass Boost Filter (lowshelf at 80Hz)
      this.bassBoostNode = this.audioCtx.createBiquadFilter();
      this.bassBoostNode.type = 'lowshelf';
      this.bassBoostNode.frequency.value = 80;

      // 3. 10-Band EQ Filters
      this.filterNodes = FREQUENCIES.map((freq, index) => {
        const filter = this.audioCtx!.createBiquadFilter();
        filter.frequency.value = freq;
        if (index === 0) {
          filter.type = 'lowshelf';
        } else if (index === FREQUENCIES.length - 1) {
          filter.type = 'highshelf';
        } else {
          filter.type = 'peaking';
          filter.Q.value = 1.4;
        }
        return filter;
      });

      // 4. Vocal Clarity Filter (peaking at 2800Hz)
      this.vocalClarityNode = this.audioCtx.createBiquadFilter();
      this.vocalClarityNode.type = 'peaking';
      this.vocalClarityNode.frequency.value = 2800;
      this.vocalClarityNode.Q.value = 1.2;

      // 5. 3D Surround / Spatial Delay Network
      this.surroundDelayNode = this.audioCtx.createDelay();
      this.surroundDelayNode.delayTime.value = 0.018; // 18ms spatial Haas effect
      this.surroundGainNode = this.audioCtx.createGain();
      this.dryGainNode = this.audioCtx.createGain();

      // 6. Stereo Panner for Balance
      if (this.audioCtx.createStereoPanner) {
        this.pannerNode = this.audioCtx.createStereoPanner();
      }

      // 7. Master Gain & Analyser
      this.masterGain = this.audioCtx.createGain();
      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 256;
      this.analyserNode.smoothingTimeConstant = 0.8;

      // Connect Chain:
      // Source -> PreAmp -> BassBoost -> Filter[0] -> ... -> Filter[9] -> VocalClarity
      try {
        this.sourceNode.disconnect();
      } catch (e) {}

      let current: AudioNode = this.sourceNode;

      current.connect(this.preAmpGain);
      current = this.preAmpGain;

      current.connect(this.bassBoostNode);
      current = this.bassBoostNode;

      for (const filter of this.filterNodes) {
        current.connect(filter);
        current = filter;
      }

      current.connect(this.vocalClarityNode);
      current = this.vocalClarityNode;

      // Surround / Spatial Split:
      // Dry path: current -> dryGain -> panner
      // Wet path: current -> surroundDelay -> surroundGain -> panner
      current.connect(this.dryGainNode);
      current.connect(this.surroundDelayNode);
      this.surroundDelayNode.connect(this.surroundGainNode);

      const merger = this.pannerNode || this.masterGain;
      this.dryGainNode.connect(merger);
      this.surroundGainNode.connect(merger);

      if (this.pannerNode) {
        this.pannerNode.connect(this.masterGain);
      }

      this.masterGain.connect(this.analyserNode);
      this.analyserNode.connect(this.audioCtx.destination);

      this.applyAllNodes();
    } catch (e) {
      console.warn('Web Audio API EQ attach warning:', e);
    }
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getAudioContext(): AudioContext | null {
    return this.audioCtx;
  }

  public resumeAudioContext() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
  }

  private applyAllNodes() {
    if (!this.audioCtx) return;
    const s = this.settings;
    const now = this.audioCtx.currentTime;

    // Enabled check
    const isBypassed = !s.enabled;

    // PreAmp Gain (-6dB to +6dB => linear factor)
    if (this.preAmpGain) {
      const preAmpDb = isBypassed ? 0 : s.preAmp;
      const gainVal = Math.pow(10, preAmpDb / 20);
      this.preAmpGain.gain.setValueAtTime(gainVal, now);
    }

    // Bass Boost Filter (0 to 100 => 0 to +12dB)
    if (this.bassBoostNode) {
      const bassDb = isBypassed ? 0 : (s.bassBoost / 100) * 12;
      this.bassBoostNode.gain.setValueAtTime(bassDb, now);
    }

    // 10-Band EQ Filters
    this.filterNodes.forEach((node, i) => {
      const db = isBypassed ? 0 : s.bands[i] || 0;
      node.gain.setValueAtTime(db, now);
    });

    // Vocal Clarity Filter (0 to 100 => 0 to +8dB)
    if (this.vocalClarityNode) {
      const vocalDb = isBypassed ? 0 : (s.vocalClarity / 100) * 8;
      this.vocalClarityNode.gain.setValueAtTime(vocalDb, now);
    }

    // Surround / Spatial Widener
    if (this.surroundGainNode && this.dryGainNode) {
      const surroundFactor = isBypassed ? 0 : s.surround / 100;
      this.surroundGainNode.gain.setValueAtTime(surroundFactor * 0.45, now);
      this.dryGainNode.gain.setValueAtTime(1.0, now);
    }

    // Stereo Panner Balance (-1 to +1)
    if (this.pannerNode) {
      const balanceVal = isBypassed ? 0 : Math.max(-1, Math.min(1, s.balance));
      this.pannerNode.pan.setValueAtTime(balanceVal, now);
    }

    // Audio element playback rate & pitch
    if (this.attachedAudioElement) {
      this.attachedAudioElement.playbackRate = s.playbackRate || 1.0;
      if ('preservesPitch' in this.attachedAudioElement) {
        (this.attachedAudioElement as any).preservesPitch = s.preservePitch;
      }
    }
  }

  // Setters
  public setEnabled(enabled: boolean) {
    this.settings.enabled = enabled;
    this.applyAllNodes();
    this.notify();
  }

  public applyPreset(presetId: string) {
    this.setPreset(presetId);
  }

  public updateSettings(partial: Partial<FineTuningSettings>) {
    this.settings = { ...this.settings, ...partial };
    if (partial.bands) {
      this.settings.bands = [...partial.bands];
    }
    this.applyAllNodes();
    this.notify();
  }

  public setPreset(presetId: string) {
    const p = EQUALIZER_PRESETS.find((item) => item.id === presetId);
    if (!p) return;

    this.settings.presetId = presetId;
    this.settings.bands = [...p.bands];
    if (p.bassBoost !== undefined) this.settings.bassBoost = p.bassBoost;
    if (p.surround !== undefined) this.settings.surround = p.surround;
    if (p.vocalClarity !== undefined) this.settings.vocalClarity = p.vocalClarity;

    this.applyAllNodes();
    this.notify();
  }

  public setBandGain(index: number, gain: number) {
    const clamped = Math.max(-12, Math.min(12, Math.round(gain * 10) / 10));
    this.settings.bands[index] = clamped;
    this.settings.presetId = 'custom';
    this.applyAllNodes();
    this.notify();
  }

  public setPreAmp(preAmp: number) {
    this.settings.preAmp = Math.max(-6, Math.min(6, Math.round(preAmp * 10) / 10));
    this.applyAllNodes();
    this.notify();
  }

  public setBassBoost(val: number) {
    this.settings.bassBoost = Math.max(0, Math.min(100, Math.round(val)));
    this.settings.presetId = 'custom';
    this.applyAllNodes();
    this.notify();
  }

  public setSurround(val: number) {
    this.settings.surround = Math.max(0, Math.min(100, Math.round(val)));
    this.settings.presetId = 'custom';
    this.applyAllNodes();
    this.notify();
  }

  public setVocalClarity(val: number) {
    this.settings.vocalClarity = Math.max(0, Math.min(100, Math.round(val)));
    this.settings.presetId = 'custom';
    this.applyAllNodes();
    this.notify();
  }

  public setBalance(balance: number) {
    this.settings.balance = Math.max(-1, Math.min(1, Math.round(balance * 100) / 100));
    this.applyAllNodes();
    this.notify();
  }

  public setPlaybackRate(rate: number) {
    this.settings.playbackRate = Math.max(0.5, Math.min(2.0, rate));
    this.applyAllNodes();
    this.notify();
  }

  public setPreservePitch(preserve: boolean) {
    this.settings.preservePitch = preserve;
    this.applyAllNodes();
    this.notify();
  }

  public resetAll() {
    this.settings = { ...DEFAULT_SETTINGS };
    this.applyAllNodes();
    this.notify();
  }
}

export const audioEqualizer = new AudioEqualizerService();
