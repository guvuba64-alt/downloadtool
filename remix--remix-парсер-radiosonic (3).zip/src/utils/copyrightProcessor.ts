export interface TrackData {
  id?: string | number;
  title: string;
  artists?: string | string[] | any[];
  artist?: string;
  isrc?: string;
  okruTrackId?: string | number;
  matchedTrackId?: string | number;
  year?: number | string;
  releaseDate?: string;
  duration?: number;
  durationMs?: number;
  [key: string]: any;
}

export interface ResolvedCopyrightInfo {
  copyright: string | null;
  copyrightOwner?: string | null;
  copyrightOwnerName?: string | null;
  copyrightOwnerId: string | number | null;
  copyrightYear?: number | null;
  copyrightFormatted?: string | null;
  copyrightStatus: 'found' | 'not_found';
  source?: string;
  distributorName?: string | null;
  distributorType?: string | null;
  distributorConfidence?: number | null;
  matchedTrackId?: string | number;
  [key: string]: any;
}

export interface CopyrightAggregation {
  source: string;
  tracks: Array<TrackData & ResolvedCopyrightInfo>;
}

export function cleanCopyrightOwner(name?: string | null): string | null {
  if (!name) return null;
  return name
    .replace(/^[([]?[pPcC℗©\u2117\u00A9][)\]]?\s*/g, '')
    .replace(/^[([]?[pPcC℗©\u2117\u00A9][)\]]?\s*/g, '')
    .replace(/^\d{4}\s+/, '')
    .trim() || null;
}

export function formatCleanCopyright(owner?: string | null, year?: string | number | null, pLine?: string | null): string | null {
  const base = (pLine || owner || '').trim();
  if (!base) return null;

  const yearMatch = base.match(/\b(19\d\d|20\d\d)\b/);
  const parsedYear = yearMatch ? yearMatch[1] : (year ? String(year) : null);

  let cleanOwner = base
    .replace(/^[([]?[pPcC℗©\u2117\u00A9][)\]]?\s*/g, '')
    .replace(/^[([]?[pPcC℗©\u2117\u00A9][)\]]?\s*/g, '')
    .trim();

  if (parsedYear && cleanOwner.startsWith(parsedYear)) {
    cleanOwner = cleanOwner.substring(parsedYear.length).trim();
  }

  cleanOwner = cleanOwner.replace(/^[([]?[pPcC℗©\u2117\u00A9][)\]]?\s*/g, '').trim();

  if (parsedYear && cleanOwner) {
    return `℗ ${parsedYear} ${cleanOwner}`;
  }
  if (cleanOwner) {
    return `℗ ${cleanOwner}`;
  }
  return base;
}

// Client-side In-Memory Cache to prevent redundant API calls
const clientCopyrightCache = new Map<string, ResolvedCopyrightInfo>();

function normalizeStr(str?: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function getClientCacheKeys(track: TrackData): string[] {
  const keys: string[] = [];
  if (track.id) keys.push(`id_${track.id}`);
  if (track.okruTrackId) keys.push(`id_${track.okruTrackId}`);
  if (track.matchedTrackId) keys.push(`id_${track.matchedTrackId}`);
  if (track.isrc) keys.push(`isrc_${String(track.isrc).trim().toUpperCase()}`);

  const title = normalizeStr(track.title);
  let artists = '';
  if (Array.isArray(track.artists)) {
    artists = normalizeStr(track.artists.filter(Boolean).join(' '));
  } else if (typeof track.artists === 'string') {
    artists = normalizeStr(track.artists);
  } else if (typeof track.artist === 'string') {
    artists = normalizeStr(track.artist);
  }

  if (title) {
    keys.push(`meta_${title}_${artists}`);
    if (!artists) keys.push(`title_${title}`);
  }
  return keys;
}

/**
 * Resolves copyright for a single track with in-memory cache.
 */
export async function resolveSingleTrackCopyright(track: TrackData): Promise<ResolvedCopyrightInfo> {
  if (!track || !track.title) {
    return {
      copyright: null,
      copyrightOwner: null,
      copyrightOwnerName: null,
      copyrightOwnerId: null,
      copyrightYear: null,
      copyrightFormatted: null,
      copyrightStatus: 'not_found',
      source: 'OK.RU'
    };
  }

  const keys = getClientCacheKeys(track);
  for (const k of keys) {
    if (clientCopyrightCache.has(k)) {
      return clientCopyrightCache.get(k)!;
    }
  }

  try {
    const response = await fetch('/api/okru/resolve-copyright', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(track)
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const cleanOwner = cleanCopyrightOwner(data.copyrightOwnerName || data.copyrightOwner);
    const cleanYear = data.copyrightYear ? Number(data.copyrightYear) : (track.year ? Number(track.year) : null);
    const formatted = formatCleanCopyright(cleanOwner || data.copyrightOwnerName || data.copyright, cleanYear, data.copyrightFormatted || data.pLine);

    const resolved: ResolvedCopyrightInfo = {
      copyright: formatted || cleanOwner || data.copyright || null,
      copyrightOwner: cleanOwner,
      copyrightOwnerName: cleanOwner,
      copyrightOwnerId: data.copyrightOwnerId || null,
      copyrightYear: cleanYear,
      copyrightFormatted: formatted,
      copyrightStatus: (cleanOwner || data.copyrightStatus === 'found') ? 'found' : 'not_found',
      source: data.source || 'OK.RU',
      distributorName: data.distributorName || null,
      distributorType: data.distributorType || null,
      distributorConfidence: data.distributorConfidence || null,
      matchedTrackId: data.matchedTrackId || null,
    };

    for (const k of keys) {
      clientCopyrightCache.set(k, resolved);
    }
    if (resolved.matchedTrackId) {
      clientCopyrightCache.set(`id_${resolved.matchedTrackId}`, resolved);
    }

    return resolved;
  } catch (err) {
    const fallback: ResolvedCopyrightInfo = {
      copyright: null,
      copyrightOwner: null,
      copyrightOwnerName: null,
      copyrightOwnerId: null,
      copyrightYear: null,
      copyrightFormatted: null,
      copyrightStatus: 'not_found',
      source: 'OK.RU'
    };
    return fallback;
  }
}

/**
 * Maps over a list of tracks, calls the OK.ru copyright resolver endpoint for each,
 * and aggregates the results into a structured format with in-memory caching.
 * Prevents halting if one track fails to resolve.
 */
export async function processCopyrights(
  source: string,
  tracks: TrackData[],
  concurrency = 4
): Promise<CopyrightAggregation> {
  const results = new Array(tracks.length);
  const queue = tracks.map((track, index) => ({ track, index }));

  // Helper to process the queue concurrently
  const worker = async () => {
    while (queue.length > 0) {
      const item = queue.shift();
      if (!item) break;

      const { track, index } = item;
      try {
        const resolved = await resolveSingleTrackCopyright(track);
        results[index] = {
          ...track,
          ...resolved,
          title: track.title,
          artists: track.artists,
        };
      } catch (error) {
        console.error(`Failed to resolve copyright for track: ${track.title}`, error);
        results[index] = {
          ...track,
          title: track.title,
          artists: track.artists,
          copyright: null,
          copyrightOwner: null,
          copyrightOwnerName: null,
          copyrightOwnerId: null,
          copyrightYear: null,
          copyrightFormatted: null,
          copyrightStatus: 'not_found',
          source: 'OK.RU',
        };
      }
    }
  };

  const workers = [];
  for (let i = 0; i < Math.min(concurrency, tracks.length); i++) {
    workers.push(worker());
  }

  await Promise.all(workers);

  return {
    source,
    tracks: results
  };
}
