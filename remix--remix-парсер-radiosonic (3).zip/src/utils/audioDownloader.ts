// Audio Downloader utility with progress tracking and event dispatching

export interface DownloadState {
  isDownloading: boolean;
  trackId?: string;
  title?: string;
  artists?: string;
  progress?: number; // 0 to 100 or -1 if unknown
  loadedBytes: number;
  totalBytes: number;
  status: 'idle' | 'preparing' | 'converting' | 'downloading' | 'completed' | 'error';
  errorMessage?: string;
}

type DownloadListener = (state: DownloadState) => void;

let currentState: DownloadState = {
  isDownloading: false,
  loadedBytes: 0,
  totalBytes: 0,
  status: 'idle',
};

const listeners = new Set<DownloadListener>();

export function subscribeDownloadState(listener: DownloadListener): () => void {
  listeners.add(listener);
  listener(currentState);
  return () => {
    listeners.delete(listener);
  };
}

function updateState(newState: Partial<DownloadState>) {
  currentState = { ...currentState, ...newState };
  listeners.forEach((listener) => {
    try {
      listener(currentState);
    } catch (e) {
      console.error('Error in download listener:', e);
    }
  });
}

export async function downloadWavTrack({
  trackId,
  title,
  artists,
  upc,
  isrc,
  coverUri,
  t,
}: {
  trackId: string;
  title?: string;
  artists?: string;
  upc?: string;
  isrc?: string;
  coverUri?: string;
  t?: (en: string, ru: string) => string;
}): Promise<void> {
  const trans = t || ((_en: string, ru: string) => ru);
  const trackTitle = title || 'Audio';
  const trackArtists = artists || '';

  if (currentState.isDownloading) {
    // Already downloading a track
    return;
  }

  updateState({
    isDownloading: true,
    trackId,
    title: trackTitle,
    artists: trackArtists,
    progress: 0,
    loadedBytes: 0,
    totalBytes: 0,
    status: 'preparing',
    errorMessage: undefined,
  });

  try {
    let cleanCoverUri = coverUri || '';
    if (cleanCoverUri) {
      cleanCoverUri = cleanCoverUri.replace('%%', '1000x1000').replace('400x400', '1000x1000');
    }

    const queryParams = new URLSearchParams({
      download: 'true',
      format: 'wav',
      title: trackTitle,
      artists: trackArtists,
      upc: upc || '',
      isrc: isrc || '',
      coverUri: cleanCoverUri,
    });

    const url = `/api/music/download/${trackId}?${queryParams.toString()}`;

    updateState({
      status: 'converting',
      progress: 10,
    });

    const response = await fetch(url);

    if (!response.ok) {
      let cleanErrorMessage = '';
      try {
        const errorData = await response.json();
        cleanErrorMessage = errorData.error || errorData.details || errorData.message || '';
      } catch (e) {
        cleanErrorMessage = await response.text().catch(() => '');
      }

      if (cleanErrorMessage.includes('no-rights') || cleanErrorMessage.includes('защищен правообладателем')) {
        cleanErrorMessage = trans(
          'Track is protected by rightsholder or unavailable in this region (no-rights).',
          'Трек недоступен для скачивания (ограничение правообладателя / no-rights).'
        );
      }

      throw new Error(
        cleanErrorMessage ||
          trans(
            'Failed to download track. Check your connection or authorization.',
            'Не удалось скачать трек. Проверьте авторизацию или соединение.'
          )
      );
    }

    const contentLengthHeader = response.headers.get('content-length');
    const totalBytes = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;

    updateState({
      status: 'downloading',
      totalBytes,
      progress: totalBytes > 0 ? 15 : -1,
    });

    if (!response.body) {
      const blob = await response.blob();
      if (!blob || blob.size === 0) {
        throw new Error(trans('Empty audio stream received', 'Получен пустой аудиопоток от сервера'));
      }
      saveBlob(blob, trackArtists, trackTitle);
    } else {
      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let receivedBytes = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        chunks.push(value);
        receivedBytes += value.length;

        const calculatedProgress =
          totalBytes > 0
            ? Math.min(99, Math.round((receivedBytes / totalBytes) * 100))
            : -1;

        updateState({
          loadedBytes: receivedBytes,
          progress: calculatedProgress,
        });
      }

      if (chunks.length === 0 || receivedBytes === 0) {
        throw new Error(trans('Empty audio stream received', 'Получен пустой аудиопоток от сервера'));
      }

      const combinedBlob = new Blob(chunks, { type: 'audio/wav' });
      if (combinedBlob.size === 0) {
        throw new Error(trans('Failed to construct WAV file', 'Не удалось собрать WAV файл'));
      }
      saveBlob(combinedBlob, trackArtists, trackTitle);
    }

    updateState({
      status: 'completed',
      progress: 100,
    });

    // Auto-dismiss completed state after 3.5 seconds
    setTimeout(() => {
      if (currentState.status === 'completed') {
        updateState({
          isDownloading: false,
          status: 'idle',
          trackId: undefined,
        });
      }
    }, 3500);
  } catch (err: any) {
    console.error('WAV Download error:', err);
    updateState({
      status: 'error',
      errorMessage:
        err?.message ||
        trans('Error downloading WAV file.', 'Ошибка при скачивании WAV файла.'),
      isDownloading: false,
    });

    setTimeout(() => {
      if (currentState.status === 'error') {
        updateState({
          status: 'idle',
          trackId: undefined,
          errorMessage: undefined,
        });
      }
    }, 5000);
  }
}

function saveBlob(blob: Blob, artists: string, title: string) {
  let fileName = artists ? `${artists} - ${title}` : title;
  fileName = String(fileName).replace(/[/\\?%*:|"<>]/g, '-').trim();
  if (!fileName.toLowerCase().endsWith('.wav')) {
    fileName += '.wav';
  }

  const downloadUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  setTimeout(() => {
    URL.revokeObjectURL(downloadUrl);
  }, 15000);
}
