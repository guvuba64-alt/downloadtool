/**
 * Safely parse JSON from a fetch Response, providing clean user-friendly
 * error messages if the response is plain text / HTML (e.g. "Rate exceeded.", 502/503/429 errors).
 */
export async function safeParseResponse<T = any>(res: Response): Promise<T> {
  const text = await res.text();
  if (!text || !text.trim()) {
    if (!res.ok) {
      throw new Error(`Ошибка сервера (HTTP ${res.status})`);
    }
    return {} as T;
  }

  try {
    return JSON.parse(text) as T;
  } catch {
    // Check for rate limiting
    if (text.includes("Rate exceeded") || res.status === 429) {
      throw new Error(
        "Превышен лимит запросов к серверу (Rate limit exceeded). Пожалуйста, подождите несколько секунд и повторите попытку или используйте авторизацию по Cookie."
      );
    }
    if (res.status === 502 || res.status === 503 || res.status === 504) {
      throw new Error(`Сервер временно недоступен (HTTP ${res.status}). Пожалуйста, повторите попытку позже.`);
    }
    if (text.startsWith("<") && text.includes("</")) {
      throw new Error(`Ошибка сервера (HTTP ${res.status}): получен HTML-ответ вместо JSON.`);
    }
    throw new Error(text.length > 250 ? text.slice(0, 250) + "..." : text);
  }
}

export async function safeFetchJson<T = any>(
  url: string,
  options?: RequestInit
): Promise<{ ok: boolean; status: number; data: T; error?: string }> {
  try {
    const res = await fetch(url, options);
    const data = await safeParseResponse<T>(res);
    return { ok: res.ok, status: res.status, data };
  } catch (err: any) {
    return { ok: false, status: 0, data: {} as T, error: err?.message || String(err) };
  }
}
