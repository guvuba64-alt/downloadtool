/**
 * Cleanly merges and normalizes music and text authors from various APIs (Yandex, Spotify, VK, OK.ru)
 * into a single, clean, comma-separated string without duplicates or raw formatting artifacts.
 */
export function cleanMergeAuthors(input: any): string {
  if (!input) return "";

  const rawList: string[] = [];

  const extractTokens = (val: any) => {
    if (!val) return;

    if (typeof val === "string") {
      // Remove common prefix markers
      let cleaned = val
        .replace(/^(автор(?:ы)?\s*(?:музыки|слов|текста)?|музыка|слова|текст|композитор|composer|music(?:\s*by)?|lyrics(?:\s*by)?|written\s*by|produced\s*by|arranged\s*by)\s*[:=-]\s*/gi, "")
        .trim();

      // Split by common delimiters: comma, semicolon, slash, &, bullet, newline, " and ", " feat. ", " ft. "
      const parts = cleaned.split(/[,;\/\n\r•|&]|\band\b|\bfeat\.?\b|\bft\.?\b/gi);
      for (let p of parts) {
        p = p
          .trim()
          .replace(/^["'«»“”\[\]\(\)]+|["'«»“”\[\]\(\)]+$/g, "")
          .trim();

        if (
          p &&
          !["-", "–", "—", "none", "unknown", "нет", "не указан", "н/д", "n/a", "null", "undefined", "no label"].includes(
            p.toLowerCase()
          )
        ) {
          rawList.push(p);
        }
      }
    } else if (Array.isArray(val)) {
      val.forEach(extractTokens);
    } else if (typeof val === "object") {
      if (val.name) extractTokens(val.name);
      else if (val.value) extractTokens(val.value);
      else if (val.text) extractTokens(val.text);
      else if (val.artist) extractTokens(val.artist);
      else if (val.title && !val.title.match(/^(автор|композитор|музыка|слова|текст|лейбл|label)/i)) {
        extractTokens(val.title);
      }
    }
  };

  extractTokens(input);

  // Case-insensitive deduplication while keeping the cleanest presentation
  const seen = new Set<string>();
  const result: string[] = [];

  for (const item of rawList) {
    const lower = item.toLowerCase();
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(item);
    }
  }

  return result.join(", ");
}
