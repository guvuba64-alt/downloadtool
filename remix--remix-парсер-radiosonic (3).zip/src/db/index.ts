import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';
import * as schema from './schema';
import path from 'path';
import fs from 'fs';

// Ensure .data folder exists for sqlite
const dataDir = path.resolve(process.cwd(), '.data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbFilePath = path.resolve(dataDir, 'sqlite.db');

// Use a local sqlite file for the database
export let sqlite = createClient({
  url: `file:${dbFilePath}`,
});

export let db = drizzle(sqlite, { schema });

// Initialize database (DDL)
export async function initDb() {
  try {
    await runMigrations();
  } catch (e: any) {
    console.error("Database initialization error, recovering...", e?.message);
    if (e?.message && (e.message.includes("malformed") || e.message.includes("corrupt") || e.message.includes("SQLITE_CORRUPT"))) {
      try {
        const corruptPath = path.resolve(dataDir, `sqlite.db.corrupt.${Date.now()}`);
        if (fs.existsSync(dbFilePath)) {
          fs.renameSync(dbFilePath, corruptPath);
        }
        sqlite = createClient({
          url: `file:${dbFilePath}`,
        });
        db = drizzle(sqlite, { schema });
        await runMigrations();
        console.log("Database successfully recovered and re-initialized!");
      } catch (recoverErr: any) {
        console.error("Failed to recover database:", recoverErr?.message);
      }
    }
  }
}

async function runMigrations() {
  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS tokens (
      id INTEGER PRIMARY KEY,
      user_id TEXT NOT NULL DEFAULT 'default_user',
      access_token TEXT NOT NULL,
      refresh_token TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      api_calls_count INTEGER NOT NULL DEFAULT 0
    )
  `);
  await sqlite.execute(`ALTER TABLE tokens ADD COLUMN api_calls_count INTEGER NOT NULL DEFAULT 0;`).catch(() => {});
  
  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS okru_session (
      id INTEGER PRIMARY KEY,
      cookies TEXT NOT NULL,
      updated_at INTEGER
    )
  `);
  
  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS okru_proxy (
      id INTEGER PRIMARY KEY,
      enabled INTEGER NOT NULL DEFAULT 0,
      proxy_url TEXT NOT NULL DEFAULT ''
    )
  `);

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS vk_session (
      id INTEGER PRIMARY KEY,
      token TEXT,
      cookies TEXT,
      user_info TEXT,
      updated_at INTEGER
    )
  `);

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS vk_proxy (
      id INTEGER PRIMARY KEY,
      enabled INTEGER NOT NULL DEFAULT 0,
      proxy_url TEXT NOT NULL DEFAULT ''
    )
  `);

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS tg_config (
      id INTEGER PRIMARY KEY,
      tokens TEXT NOT NULL,
      contacts TEXT NOT NULL
    )
  `);

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS mini_app_code (
      id INTEGER PRIMARY KEY,
      html TEXT,
      commands TEXT
    )
  `);

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS tg_ai_config (
      id INTEGER PRIMARY KEY,
      enabled INTEGER NOT NULL DEFAULT 0,
      provider TEXT NOT NULL DEFAULT 'custom',
      api_url TEXT NOT NULL DEFAULT '',
      api_key TEXT NOT NULL DEFAULT '',
      model TEXT NOT NULL DEFAULT '',
      system_prompt TEXT NOT NULL DEFAULT '',
      temperature REAL NOT NULL DEFAULT 0.7,
      max_tokens INTEGER NOT NULL DEFAULT 1500,
      access_mode TEXT NOT NULL DEFAULT 'all',
      history_limit INTEGER NOT NULL DEFAULT 8,
      owner_chat_id TEXT NOT NULL DEFAULT '8160231965',
      unauthorized_response TEXT NOT NULL DEFAULT 'silent'
    )
  `);
  await sqlite.execute(`ALTER TABLE tg_ai_config ADD COLUMN owner_chat_id TEXT NOT NULL DEFAULT '8160231965';`).catch(() => {});
  await sqlite.execute(`ALTER TABLE tg_ai_config ADD COLUMN unauthorized_response TEXT NOT NULL DEFAULT 'silent';`).catch(() => {});

  await sqlite.execute(`
    CREATE TABLE IF NOT EXISTS tg_ai_chat_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      timestamp INTEGER NOT NULL
    )
  `);
}

// Fire init immediately
initDb();
