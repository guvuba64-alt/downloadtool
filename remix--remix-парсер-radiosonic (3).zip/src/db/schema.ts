import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';

export const tokens = sqliteTable('tokens', {
  id: integer('id').primaryKey(),
  userId: text('user_id').notNull().default('default_user'), // Just for single-user context in this demo
  accessToken: text('access_token').notNull(),
  refreshToken: text('refresh_token').notNull(),
  expiresAt: integer('expires_at').notNull(), // Unix timestamp in seconds
  updatedAt: integer('updated_at').notNull(),
  apiCallsCount: integer('api_calls_count').notNull().default(0),
});
