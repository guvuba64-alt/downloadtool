const fs = require('fs');

const componentCode = `import React from 'react';
import { X, ExternalLink } from 'lucide-react';
import { TelegramIcon } from './Icons';

export const BotInfoModal = ({ isBotInfoOpen, setIsBotInfoOpen, botName, botUsername, botId, botStatus, t }: any) => {
  if (!isBotInfoOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl border border-zinc-200 dark:border-zinc-800 animate-in zoom-in-95 duration-200">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <TelegramIcon className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-zinc-900 dark:text-white leading-tight">{t("Bot Info", "Информация о боте")}</h3>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className="relative flex h-2 w-2">
                    {botStatus === 'online' && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
                    <span className={"relative inline-flex rounded-full h-2 w-2 " + (botStatus === 'online' ? "bg-emerald-500" : botStatus === 'checking' ? "bg-zinc-400" : "bg-red-500")}></span>
                  </span>
                  <span className="text-xs text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">{botStatus}</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsBotInfoOpen(false)} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">{t("Name", "Имя")}</div>
              <div className="font-medium text-zinc-900 dark:text-zinc-100">{botName || "—"}</div>
            </div>
            
            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
              <div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">{t("Username", "Юзернейм")}</div>
                <div className="font-medium text-zinc-900 dark:text-zinc-100">{botUsername ? "@" + botUsername : "—"}</div>
              </div>
              {botUsername && (
                <a href={"https://t.me/" + botUsername} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-sm font-medium rounded-lg transition-colors">
                  <ExternalLink className="w-4 h-4" />
                  {t("Open", "Открыть")}
                </a>
              )}
            </div>

            <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">ID</div>
              <div className="font-mono text-sm text-zinc-900 dark:text-zinc-100">{botId || "—"}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
`;

fs.writeFileSync('src/components/BotInfoModal.tsx', componentCode);

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// Insert import
const importIndex = appCode.indexOf('import { BotStatusIndicator }');
appCode = appCode.slice(0, importIndex) + "import { BotInfoModal } from './components/BotInfoModal';\n" + appCode.slice(importIndex);

const targetBlock = `{isBotInfoOpen && (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
    <div className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl border border-zinc-200 dark:border-zinc-800 animate-in zoom-in-95 duration-200">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
              <TelegramIcon className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-zinc-900 dark:text-white leading-tight">{t("Bot Info", "Информация о боте")}</h3>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="relative flex h-2 w-2">
                  {botStatus === 'online' && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
                  <span className={"relative inline-flex rounded-full h-2 w-2 " + (botStatus === 'online' ? "bg-emerald-500" : botStatus === 'checking' ? "bg-zinc-400" : "bg-red-500")}></span>
                </span>
                <span className="text-xs text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">{botStatus}</span>
              </div>
            </div>
          </div>
          <button onClick={() => setIsBotInfoOpen(false)} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800">
            <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">{t("Name", "Имя")}</div>
            <div className="font-medium text-zinc-900 dark:text-zinc-100">{botName || "—"}</div>
          </div>
          
          <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
            <div>
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">{t("Username", "Юзернейм")}</div>
              <div className="font-medium text-zinc-900 dark:text-zinc-100">{botUsername ? "@" + botUsername : "—"}</div>
            </div>
            {botUsername && (
              <a href={"https://t.me/" + botUsername} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-sm font-medium rounded-lg transition-colors">
                <ExternalLink className="w-4 h-4" />
                {t("Open", "Открыть")}
              </a>
            )}
          </div>

          <div className="bg-zinc-50 dark:bg-black/20 rounded-xl p-4 border border-zinc-100 dark:border-zinc-800">
            <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">ID</div>
            <div className="font-mono text-sm text-zinc-900 dark:text-zinc-100">{botId || "—"}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
)}`;

appCode = appCode.replace(targetBlock, `<BotInfoModal isBotInfoOpen={isBotInfoOpen} setIsBotInfoOpen={setIsBotInfoOpen} botName={botName} botUsername={botUsername} botId={botId} botStatus={botStatus} t={t} />`);

fs.writeFileSync('src/App.tsx', appCode);
console.log('Refactored BotInfoModal into separate component');
