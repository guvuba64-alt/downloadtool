const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/  const isAllowed = tgConfig\.contacts\.some\(c => c\.id === tgId\);/g, `  const allowedIds = ['8160231965'];\n  const isAllowed = allowedIds.includes(tgId) || tgConfig.contacts.some(c => c.id === tgId);`);

fs.writeFileSync('server.ts', content);
console.log("Restored admin ID.");
