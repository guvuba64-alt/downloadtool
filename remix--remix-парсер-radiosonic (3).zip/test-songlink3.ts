import axios from 'axios';
axios.get('https://song.link/ya/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
}).then(r => {
  const jsonMatch = r.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/);
  if (jsonMatch) {
    const data = JSON.parse(jsonMatch[1]);
    console.log(Object.keys(data.props.pageProps.pageData));
    if (data.props.pageProps.pageData.linksByPlatform) {
      console.log("has linksByPlatform");
    }
    const pageData = data.props.pageProps.pageData;
    console.log(pageData.title, pageData.artistName);
  }
}).catch(console.error);
