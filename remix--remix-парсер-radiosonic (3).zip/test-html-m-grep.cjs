const axios = require('axios');
axios.get('https://m.ok.ru/music/search/Tones%20And%20I%20Dance%20Monkey', {
  headers: {
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
  }
}).then(r => {
  const fs = require('fs');
  fs.writeFileSync('mok_search.html', r.data);
  console.log("Saved mok_search.html");
}).catch(console.error);
