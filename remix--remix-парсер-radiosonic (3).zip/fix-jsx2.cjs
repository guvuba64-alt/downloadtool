const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(`                        </div>
                      </div>
                    </div>
                  )}
                  {/* Actions / Audio Section */}`, `                        </div>
                      </div>
                    </div>
                  </div>
                  )}
                  {/* Actions / Audio Section */}`);

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed JSX 2');
