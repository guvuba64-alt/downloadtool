const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const spot1 = `      const tokenRes = await axios.post("https://accounts.spotify.com/api/token", 
          "grant_type=client_credentials", 
          {
              headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                  Authorization: "Basic " + Buffer.from(spotifyClientId + ":" + spotifyClientSecret).toString("base64")
              },
              timeout: 5000
          }
      );`;
const spot1New = `
      let tokenRes;
      try {
        tokenRes = await axios.post("https://accounts.spotify.com/api/token", 
            "grant_type=client_credentials", 
            {
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    Authorization: "Basic " + Buffer.from(spotifyClientId + ":" + spotifyClientSecret).toString("base64")
                },
                timeout: 5000
            }
        );
      } catch (spotAuthErr) {
         console.log("Spotify Auth error:", spotAuthErr.message);
         return res.status(403).json({ error: "Invalid Spotify credentials or Spotify API is blocking requests." });
      }
`;

code = code.replace(spot1, spot1New);
fs.writeFileSync('server.ts', code);
console.log("Patched Spotify request");
