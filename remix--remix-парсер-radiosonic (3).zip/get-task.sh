./get-task-status.sh b26cd231-1447-4e06-a386-26448ab45601/task-300
