const fs = require('fs');

let content = fs.readFileSync('src/App.tsx', 'utf8');

const oldBlock = `<div className="mt-3 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl text-sm text-blue-800 dark:text-blue-200 animate-in fade-in slide-in-from-top-2 duration-200">
                      <p className="font-bold mb-2">{t("Instructions:", "Инструкция:")}</p>
                      <ul className="list-disc pl-5 space-y-1.5 opacity-90">
                        <li>{t("Copy a link to a release or artist from Yandex Music.", "Скопируйте ссылку на трек, релиз или артиста из Яндекс.Музыки.")}</li>
                        <li>{t("Paste it into the field above and click 'Find'.", "Вставьте в поле выше и нажмите «Найти».")}</li>
                        <li>{t("The parser will collect metadata and find this release on all other platforms automatically.", "Парсер соберет все метаданные и автоматически найдет этот релиз на остальных мировых площадках.")}</li>
                        <li>{t("Once found, you can copy ISRC, UPC, copy smart links, and preview the tracks.", "После поиска вы сможете копировать ISRC, UPC, ссылки на площадки и прослушивать треки.")}</li>
                      </ul>
                    </div>`;

const newBlock = `<div className="mt-4 bg-white dark:bg-zinc-900/80 p-6 rounded-2xl border border-blue-200 dark:border-blue-900/50 text-sm text-zinc-800 dark:text-zinc-200 animate-in fade-in slide-in-from-top-2 duration-300 shadow-lg">
                      <p className="text-xl font-black mb-4 text-blue-600 dark:text-blue-400 border-b border-blue-100 dark:border-blue-900/30 pb-2">{t("Complete Guide & Instructions", "Инструкция и Полное руководство")}</p>
                      
                      <div className="space-y-6">
                        {/* 1. Архитектура */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Layers className="w-5 h-5 text-indigo-500"/> 1. Что за что отвечает (Архитектура)</h4>
                          <p className="mb-2">Приложение состоит из 3 независимых блоков:</p>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Парсеры (Сбор данных):</strong> Ищут информацию (UPC, ISRC, обложки) по скрытым API Яндекса, Spotify, VK, Звука. Избавляют от ручного поиска.</li>
                            <li><strong>Отчёты (Процессинг):</strong> Ядро, которое читает Excel/CSV от дистрибьюторов, вычитает процент лейбла и генерирует красивые PDF-акты.</li>
                            <li><strong>Логи и Рассылка (Telegram):</strong> Берет PDF-отчеты и массово рассылает артистам в личку через ваш Telegram-бот по Chat ID.</li>
                          </ul>
                        </section>

                        {/* 2. Вкладки */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Settings className="w-5 h-5 text-emerald-500"/> 2. По всем вкладкам и функциям</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Поиск (Плеер) и Моя Волна:</strong> Встроенный музыкальный стриминг. Вы можете искать треки и слушать бесконечное радио по рекомендациям нейросети Яндекса, не покидая рабочую панель.</li>
                            <li><strong>Универсальный парсер:</strong> Вы вставляете 1 ссылку из Яндекса, а парсер в фоне находит точные копии релиза в VK, Spotify и Apple, собирая вам единый "SmartLink" и технические коды для проверки.</li>
                            <li><strong>Отчёты (Генератор PDF):</strong> Превращает скучные таблицы выплат в дизайнерские PDF документы с логотипом вашего лейбла. Распределяет доходы по каждому артисту.</li>
                            <li><strong>Журнал (Telegram Логи):</strong> Отслеживает отправку отчетов. Если артист заблокировал бота, вы увидите ошибку 400. Если Telegram тормозит из-за спама, будет ошибка 429 (программа сама подождет и отправит заново).</li>
                          </ul>
                        </section>

                        {/* 3. Коды */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Code className="w-5 h-5 text-purple-500"/> 3. Коды UPC и ISRC: Что это и зачем?</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>UPC (Штрих-код релиза):</strong> 12-13 цифр. Регистрирует весь альбом/сингл как единый товар в цифровом магазине. По нему идут общие отчеты о продажах релиза.</li>
                            <li><strong>ISRC (Паспорт трека):</strong> Выдается навсегда (например, RU-A1B-23-00001). <strong>Критически важен</strong>, потому что именно по ISRC стриминги платят вам роялти (деньги). Если этот трек попадет в другой сборник, прослушивания все равно придут вам в кошелек благодаря ISRC.</li>
                          </ul>
                        </section>

                        {/* 4. API и Токены */}
                        <section>
                          <h4 className="font-bold text-lg text-zinc-900 dark:text-white mb-2 flex items-center gap-2"><Key className="w-5 h-5 text-amber-500"/> 4. API, Токены, JSON и Cookie</h4>
                          <ul className="list-disc pl-5 space-y-2 opacity-90">
                            <li><strong>Что такое API:</strong> Это "официант". Наша программа дает заказ ("Найди трек"), API несет его на кухню сервера Spotify и приносит нам данные.</li>
                            <li><strong>Что такое Токен (API Key):</strong> Ваш VIP-пропуск на эту кухню. Например, <code>Bot Token</code> доказывает серверам Telegram, что именно ВЫ владеете ботом и можете рассылать сообщения.</li>
                            <li><strong>Зачем нужны Cookie и ручной ввод JSON:</strong> VK и Одноклассники защищены от ботов. Вставляя свой Cookie (слепок сессии), наша программа "надевает маску" вашего браузера и легально собирает данные. А JSON (ответ сервера) мы просим вставить вручную, если сервер выдает капчу, которую может пройти только человек.</li>
                          </ul>
                        </section>
                      </div>
                    </div>`;

if (content.includes(oldBlock)) {
    content = content.replace(oldBlock, newBlock);
    fs.writeFileSync('src/App.tsx', content);
    console.log('Successfully replaced inline instructions');
} else {
    console.log('Could not find the old block to replace');
    // Lets find it using regex or similar
}
