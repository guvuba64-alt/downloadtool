const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

content = content.replace(/                <\/div>\n                \)\}\n              <\/div>\n              \{\/\* Right Column - Preview PDF \*\/\}/g, `                </div>\n              </div>\n              {/* Right Column - Preview PDF */}`);

content = content.replace(/                <\/div>\n              <\/div>\n              \{\/\* Right Column - Preview PDF \*\/\}/g, `                </div>\n                )}\n              </div>\n              {/* Right Column - Preview PDF */}`);

fs.writeFileSync('src/components/ReportTab.tsx', content);
