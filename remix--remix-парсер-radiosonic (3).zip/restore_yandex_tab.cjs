const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  '{ id: "vibe", label: t("My Vibe", "Моя Волна") },',
  '{ id: "yandex", label: t("Yandex Parser", "Парсер Яндекс") },\n              { id: "vibe", label: t("My Vibe", "Моя Волна") },'
);

fs.writeFileSync('src/App.tsx', code);
console.log("Restored Yandex Parser tab.");
