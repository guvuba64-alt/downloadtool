import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
axios.get(`https://api.song.link/v1-alpha.1/links?url=${url}`).then(r => console.log(r.data.entitiesByUniqueId)).catch(e => console.log(e.message));
