import { searchOkRuViaHttp } from './server-okru';

async function test() {
  const stream = await searchOkRuViaHttp('Macan Весна');
  console.log('Stream:', stream);
}
test().catch(console.error);
