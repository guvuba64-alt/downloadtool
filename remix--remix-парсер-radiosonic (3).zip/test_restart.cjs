const { execSync } = require('child_process');
console.log("restarting...");
