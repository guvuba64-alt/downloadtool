import axios from 'axios';
const url = encodeURIComponent('site:music.yandex.ru/album/7542918/track/53066380');
axios.get(`https://yandex.com/search/?text=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  validateStatus: () => true
}).then(r => {
  const match = r.data.match(/<title>(.*?)<\/title>/);
  console.log(r.status, "Title:", match ? match[1] : 'none');
  const snip = r.data.match(/<div class="[^"]*TextContainer[^"]*">(.*?)<\/div>/g);
  console.log("Snippet:", snip ? snip[0].substring(0, 100) : 'none');
}).catch(console.error);
