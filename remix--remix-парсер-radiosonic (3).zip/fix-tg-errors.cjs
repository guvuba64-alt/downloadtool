const fs = require('fs');
let content = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');

content = content.replace(
/                const errData = await res\.json\(\)\.catch\(\(\)=>\(\{\}\)\);\n                console\.error\(`Telegram Error: `, errData\);\n                if \(res\.status === 429\) \{/g, 
`                const errData = await res.json().catch(()=>({}));\n                if (res.status === 429 || errData.error_code === 429) {\n                   console.warn(\`Rate limited (429). Retrying...\`);`
);

content = content.replace(
/                   updateTgLogs\(prev => prev\.map\(l => l\.chatId === chatId \? \{ \.\.\.l, status: 'error' \} : l\)\);\n                   await new Promise\(r => setTimeout\(r, 1000\)\);\n                   break;/g,
`                   console.error(\`Telegram Error: \`, errData);\n                   updateTgLogs(prev => prev.map(l => l.chatId === chatId ? { ...l, status: 'error' } : l));\n                   await new Promise(r => setTimeout(r, 1000));\n                   break;`
);

content = content.replace(
/formData\.append\('text', tgMessage && tgMessage\.trim\(\) !== '' \? tgMessage : ' '\);/g,
`formData.append('text', tgMessage && tgMessage.trim() !== '' ? tgMessage : '...');`
);

fs.writeFileSync('src/components/ReportTab.tsx', content);
