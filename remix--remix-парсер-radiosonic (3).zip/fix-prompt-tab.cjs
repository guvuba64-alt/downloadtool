const fs = require('fs');
let code = fs.readFileSync('src/components/PromptTab/index.tsx', 'utf8');
code = code.replace(
  `throw new Error("Invalid response format: " + text.substring(0, 100));`,
  `throw new Error("Ошибка сервера. Ответ: " + text.substring(0, 100));`
);
fs.writeFileSync('src/components/PromptTab/index.tsx', code);
console.log('Fixed prompt tab error message');
