import axios from 'axios';
axios.get('https://song.link/ya/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
  validateStatus: () => true
}).then(r => {
  const title = r.data.match(/<title>(.*?)<\/title>/);
  console.log(r.status, "Title:", title ? title[1] : 'none');
}).catch(console.error);
