const fs = require('fs');

const componentCode = `import React from 'react';
import { X } from 'lucide-react';
import { SpotifyIcon } from './Icons';

export const SpotifySettingsModal = ({ 
  isSpotifyModalOpen, 
  setIsSpotifyModalOpen, 
  spotifyClientId, 
  setSpotifyClientId, 
  spotifyClientSecret, 
  setSpotifyClientSecret, 
  t 
}: any) => {
  if (!isSpotifyModalOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1c1c1e] w-full max-w-lg rounded-3xl shadow-xl overflow-hidden border border-zinc-200/50 dark:border-white/10 flex flex-col animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-100 dark:border-white/5 flex justify-between items-center">
          <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-50 flex items-center gap-2"><SpotifyIcon className="w-5 h-5 text-green-500" /> {t("Spotify API Settings", "Настройки API Spotify")}</h3>
          <button onClick={() => setIsSpotifyModalOpen(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            {t("To enable Spotify track search and fetching, you need to provide your Spotify Developer credentials.", "Чтобы включить поиск и получение треков Spotify, вам необходимо предоставить учетные данные разработчика Spotify.")}
          </p>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Client ID</label>
            <input 
              type="text" 
              value={spotifyClientId}
              onChange={(e) => setSpotifyClientId(e.target.value)}
              className="w-full px-4 py-3 bg-zinc-100 dark:bg-black/50 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition-all font-mono text-sm"
              placeholder="e.g. 8a7b..."
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Client Secret</label>
            <input 
              type="password" 
              value={spotifyClientSecret}
              onChange={(e) => setSpotifyClientSecret(e.target.value)}
              className="w-full px-4 py-3 bg-zinc-100 dark:bg-black/50 border border-zinc-200 dark:border-white/10 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition-all font-mono text-sm"
              placeholder="••••••••••••••••••••••••"
            />
          </div>
          <div className="pt-4">
            <button onClick={() => {
                localStorage.setItem('spotify_client_id', spotifyClientId);
                localStorage.setItem('spotify_client_secret', spotifyClientSecret);
                setIsSpotifyModalOpen(false);
            }} className="w-full py-3 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-colors">
              {t("Save & Close", "Сохранить и закрыть")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
`;

fs.writeFileSync('src/components/SpotifySettingsModal.tsx', componentCode);

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// Insert import
const importIndex = appCode.indexOf('import { TokenSettingsModal }');
appCode = appCode.slice(0, importIndex) + "import { SpotifySettingsModal } from './components/SpotifySettingsModal';\n" + appCode.slice(importIndex);

const targetBlockStart = '{isSpotifyModalOpen && (';
const startIdx = appCode.indexOf(targetBlockStart);
if (startIdx !== -1) {
  // find end of modal block
  let endIdx = startIdx;
  let braceCount = 0;
  let foundFirst = false;
  
  for(let i = startIdx; i < appCode.length; i++) {
    if (appCode[i] === '{') braceCount++;
    if (appCode[i] === '}') {
      braceCount--;
      foundFirst = true;
    }
    if (foundFirst && braceCount === 0) {
      endIdx = i + 1;
      break;
    }
  }
  
  const targetBlock = appCode.substring(startIdx, endIdx);
  const replacement = `<SpotifySettingsModal 
        isSpotifyModalOpen={isSpotifyModalOpen} 
        setIsSpotifyModalOpen={setIsSpotifyModalOpen} 
        spotifyClientId={spotifyClientId} 
        setSpotifyClientId={setSpotifyClientId} 
        spotifyClientSecret={spotifyClientSecret} 
        setSpotifyClientSecret={setSpotifyClientSecret} 
        t={t} 
      />`;
      
  appCode = appCode.replace(targetBlock, replacement);
  fs.writeFileSync('src/App.tsx', appCode);
  console.log('Refactored SpotifySettingsModal into separate component');
} else {
  console.log('Could not find isSpotifyModalOpen block in App.tsx');
}
