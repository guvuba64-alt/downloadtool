const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

const startIdx = code.indexOf('const apiCodeSnippets = {');
const endIdx = code.indexOf('};', startIdx) + 2;

if (startIdx !== -1 && endIdx !== -1) {
    let snippets = code.substring(startIdx, endIdx);
    
    // We have fetch(`...`) which should be fetch(\`...\`)
    // Because the snippets string is bounded by backticks, inner backticks must be \`
    
    // Fix inner backticks
    snippets = snippets.replace(/fetch\(`([^`]+)`\)/g, "fetch(\\`$1\\`)");
    snippets = snippets.replace(/fetch\(`([^`]+)`,/g, "fetch(\\`$1\\`,");
    
    // Also python snippet might have had things broken? No, python doesn't use backticks.
    
    code = code.substring(0, startIdx) + snippets + code.substring(endIdx);
    fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
    console.log('Fixed backticks');
} else {
    console.log('Snippets block not found');
}
