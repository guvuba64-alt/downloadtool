import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://translate.google.com/translate?sl=ru&tl=en&u=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
});
console.log(r.status, r.data.substring(0, 500));
