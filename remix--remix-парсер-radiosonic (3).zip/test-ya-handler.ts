import axios from 'axios';
axios.get('https://music.yandex.com/handlers/track.jsx?track=53066380:7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, typeof r.data === 'string' ? r.data.substring(0, 100) : r.data)).catch(console.error);
