import { searchOkRuViaHttp } from './server-okru.js';
searchOkRuViaHttp("Dance Monkey").then(r => console.log(r?.track?.playUrl, r?.track?.id, r?.track?.name));
