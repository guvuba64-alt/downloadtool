const axios = require('axios');
axios.get('https://api.deezer.com/search/album?q=FUKOUNA%20GIRL', { headers: { "User-Agent": "Mozilla/5.0" } })
  .then(r => {
     if (r.data.data.length > 0) {
        const id = r.data.data[0].id;
        console.log("Found Deezer album ID:", id);
        return axios.get('https://api.deezer.com/album/' + id, { headers: { "User-Agent": "Mozilla/5.0" } });
     }
  })
  .then(r => {
     if (r) {
        const trks = r.data.tracks.data.map(t => t.id);
        console.log(r.data.tracks.data.slice(0, 5).map(t => t.title));
     }
  }).catch(e => console.log(e.message));
