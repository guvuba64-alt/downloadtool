import axios from 'axios';
axios.get('https://music.yandex.ru/iframe/#track/53066380/7542918', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => {
  console.log("Iframe HTML length:", r.data.length);
  const match = r.data.match(/<title>(.*?)<\/title>/);
  console.log("Title:", match ? match[1] : 'none');
});
