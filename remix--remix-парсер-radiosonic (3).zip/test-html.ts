import axios from 'axios';

async function t() {
  const res = await axios.get('https://music.yandex.ru/album/28416827/track/119932131');
  const match = res.data.match(/<title>(.*?)<\/title>/);
  console.log(match ? match[1] : 'No title');
}
t().catch(console.error);
