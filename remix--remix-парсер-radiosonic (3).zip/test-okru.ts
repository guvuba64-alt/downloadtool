import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://ok.ru/music/track/12345').then(console.log);
