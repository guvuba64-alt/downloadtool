const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const badBlock = `  // 2. Puppeteer browser attempt (with grace                 if (json.track) {
                     foundTrack = json.track;
                     let rawOwner = json.track.copyrightOwnerName;
                     
                     let rawLabel = json.track.label || json.track.labelName || json.track.album?.label || json.track.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                     
                     if (json.track.album && json.track.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = json.track.album.year;
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     foundTrack = json.tracks[0];
                     let rawOwner = foundTrack.copyrightOwnerName;
                     
                     let rawLabel = foundTrack.label || foundTrack.labelName || foundTrack.album?.label || foundTrack.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                     
                     if (foundTrack.album && foundTrack.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = foundTrack.album.year;
                 } = [rawPline, rawPublisher, rawOwner, rawCopyright].filter(Boolean);
                     
                     let aggregator = allVals.find(s => {
                       const l = s.toLowerCase();
                       return l.includes('национальный цифровой агрегатор') || l.includes('believe') || l.includes('zvonko') || l.includes('fuga') || l.includes('onerpm');
                     });
                     foundCopyright = aggregator || rawPline || rawPublisher || rawOwner || rawCopyright || foundCopyright;
                     foundLabel = rawLabel || rawOwner || rawCopyright || foundLabel;
                     
                     if (aggregator && (!foundLabel || foundLabel === aggregator)) {
                         let other = allVals.find(s => s !== aggregator);
                         if (other) {
                             foundLabel = other;
                         }
                     }
                     if (foundLabel === foundCopyright && allVals.length > 1) {
                         let other = allVals.find(s => s !== foundLabel);
                         if (other) foundCopyright = other;
                     }
                     
                     if (foundTrack.album && foundTrack.album.year && !foundTrack.releaseDate) foundTrack.releaseDate = foundTrack.album.year;
                 }
             } catch (e) {}
          }
        }
      } catch (e) {}
    });`;

const goodBlock = `  // 2. Puppeteer browser attempt (with graceful fallback if Chrome is not installed)
  let browser;
  try {
    const puppeteerArgs = ['--no-sandbox', '--disable-setuid-sandbox'];
    if (activeProxy) {
      puppeteerArgs.push(activeProxy.puppeteerArg);
    }

    browser = await puppeteer.launch({ 
      args: puppeteerArgs,
      headless: true
    });
    const page = await browser.newPage();

    if (activeProxy && activeProxy.username) {
      await page.authenticate({
        username: activeProxy.username,
        password: activeProxy.password || '',
      });
    }

    await page.setRequestInterception(true);
    page.on('request', (req) => {
      const resourceType = req.resourceType();
      if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
        req.abort();
      } else {
        req.continue();
      }
    });

    if (okCookies && okCookies.length > 0) {
      await page.setCookie(...okCookies);
    }
    
    page.on('response', async (response) => {
      try {
        const u = response.url();
        if (u.includes('ok.ru/web-api/music') || u.includes('ok.ru/play') || u.includes('music') || u.includes('track')) {
          const text = await response.text();
          if (text.includes('"track"') || text.includes('"tracks"')) {
             try {
                 const json = JSON.parse(text);
                 if (json.track) {
                     foundTrack = json.track;
                     let rawOwner = json.track.copyrightOwnerName;
                     let rawLabel = json.track.label || json.track.labelName || json.track.album?.label || json.track.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     foundTrack = json.tracks[0];
                     let rawOwner = foundTrack.copyrightOwnerName;
                     let rawLabel = foundTrack.label || foundTrack.labelName || foundTrack.album?.label || foundTrack.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                 }
             } catch (e) {}
          }
        }
      } catch (e) {}
    });`;

code = code.replace(badBlock, goodBlock);
fs.writeFileSync('server-okru.ts', code);
