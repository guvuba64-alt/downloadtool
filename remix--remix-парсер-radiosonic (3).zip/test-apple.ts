import { universalMusicSearchAndParse } from './server-okru.js';
universalMusicSearchAndParse('https://music.apple.com/us/album/dance-monkey/1473264639?i=1473264640').then(r => console.log(r.notFound, r.title));
