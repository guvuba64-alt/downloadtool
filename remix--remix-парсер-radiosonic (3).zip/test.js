const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');
console.log(code.match(/isInfoOpen/g).length);
