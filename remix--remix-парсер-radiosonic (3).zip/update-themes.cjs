const fs = require('fs');
let code = fs.readFileSync('src/index.css', 'utf8');

// remove previous themes section
code = code.split('@layer base {')[0];

const newThemes = `
@layer base {
  [data-theme="cyberpunk"] {
    --color-zinc-50: #fdf4ff;
    --color-zinc-100: #fae8ff;
    --color-zinc-200: #f5d0fe;
    --color-zinc-800: #701a75;
    --color-zinc-900: #2a022c;
    --color-blue-500: #fcd34d;
    --color-blue-600: #fbbf24;
    background-color: var(--color-zinc-50);
  }
  .dark[data-theme="cyberpunk"] {
    background-color: var(--color-zinc-900);
  }

  [data-theme="minimalist"] {
    --color-zinc-50: #ffffff;
    --color-zinc-100: #fafafa;
    --color-zinc-200: #f5f5f5;
    --color-zinc-800: #171717;
    --color-zinc-900: #0a0a0a;
    --color-blue-500: #525252;
    --color-blue-600: #404040;
    background-color: var(--color-zinc-50);
  }
  .dark[data-theme="minimalist"] {
    background-color: var(--color-zinc-900);
  }

  [data-theme="brutalist"] {
    --color-zinc-50: #f3f4f6;
    --color-zinc-100: #e5e7eb;
    --color-zinc-200: #d1d5db;
    --color-zinc-800: #1f2937;
    --color-zinc-900: #111827;
    --color-blue-500: #ef4444;
    --color-blue-600: #dc2626;
    background-color: #ffffff;
  }
  .dark[data-theme="brutalist"] {
    background-color: #000000;
  }
  
  /* Brutalist specific overrides */
  [data-theme="brutalist"] * {
    border-radius: 0 !important;
  }
  [data-theme="brutalist"] .shadow-sm,
  [data-theme="brutalist"] .shadow-md,
  [data-theme="brutalist"] .shadow-lg {
    box-shadow: 4px 4px 0px 0px rgba(0,0,0,1) !important;
    border: 2px solid #000 !important;
  }
  .dark[data-theme="brutalist"] .shadow-sm,
  .dark[data-theme="brutalist"] .shadow-md,
  .dark[data-theme="brutalist"] .shadow-lg {
    box-shadow: 4px 4px 0px 0px rgba(255,255,255,1) !important;
    border: 2px solid #fff !important;
  }
  
  /* Minimalist specific overrides */
  [data-theme="minimalist"] .shadow-sm,
  [data-theme="minimalist"] .shadow-md,
  [data-theme="minimalist"] .shadow-lg {
    box-shadow: none !important;
    border: 1px solid var(--color-zinc-200) !important;
  }
  .dark[data-theme="minimalist"] .shadow-sm,
  .dark[data-theme="minimalist"] .shadow-md,
  .dark[data-theme="minimalist"] .shadow-lg {
    border: 1px solid var(--color-zinc-800) !important;
  }

  body[data-theme="cyberpunk"], body[data-theme="minimalist"], body[data-theme="brutalist"] {
    transition: background-color 0.5s ease;
  }
}

/* Glowing Professional Bot Status Overrides */
.bot-status-container {
  position: relative;
  overflow: hidden;
}
.bot-status-container::before {
  content: '';
  position: absolute;
  top: 0; left: -100%;
  width: 50%; height: 100%;
  background: linear-gradient(to right, transparent, rgba(255,255,255,0.1), transparent);
  transform: skewX(-20deg);
  animation: shine 6s infinite;
}
@keyframes shine {
  0% { left: -100%; }
  20% { left: 200%; }
  100% { left: 200%; }
}
`;

fs.writeFileSync('src/index.css', code + newThemes);
console.log('patched index.css with new themes');
