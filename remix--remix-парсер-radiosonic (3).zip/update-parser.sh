#!/bin/bash
# Colin's script to update the parser for parallel execution

sed -i 's/let finalCopyright = okOwnerName || okResult?.copyright || null;/let finalCopyright = okOwnerName || okResult?.copyright || extractedLabel || null;/g' server-okru.ts

echo "Done"
