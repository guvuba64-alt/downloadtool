const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

// I'll manually replace the handleParseOkRuJson string because I know exactly how it looks now!
const target = `  // Parse OK.ru JSON dump
  const handleParseOkRuJson = async () => {
    if (!okRuJson.trim()) return;
    setIsParsingOkRuJson(true);
    setOkRuResult(null);
    try {
      const res = await fetch("/api/okru/parse-json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawJson: okRuJson })
      });
      const data = await res.json();
      setOkRuResult(data);
    } catch (e: any) {
      setOkRuResult({ error: e?.message || "Ошибка парсинга" });
    } finally {
      setIsParsingOkRuJson(false);
    }
  };`;

const replacement = `  // Parse OK.ru JSON dump
  const handleParseOkRuJson = async () => {
    if (!okRuJson.trim()) return;
    setIsParsingOkRuJson(true);
    setOkRuResult(null);
    try {
      const res = await fetch("/api/okru/parse-json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawJson: okRuJson })
      });
      const data = await res.json();
      setOkRuResult(data);
      if (data.success) {
        setOkSearchResult({
          success: true,
          found: true,
          entityType: 'single',
          platform: 'search',
          title: data.title || 'Unknown',
          artists: data.artists || 'Unknown',
          copyright: data.copyright,
          copyrightOwnerName: data.copyrightOwnerName,
          copyrightOwnerId: data.copyrightOwnerId,
          label: data.label,
          distributor: data.distributor,
          distributorMatch: data.distributorMatch,
          isrc: data.isrc,
          upc: data.upc,
          playUrl: data.playUrl,
          releaseId: data.releaseId,
          idForDownload: data.idForDownload,
          rawJson: data.deepScan || data,
          tracks: []
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (e: any) {
      setOkRuResult({ error: e?.message || "Ошибка парсинга" });
    } finally {
      setIsParsingOkRuJson(false);
    }
  };`;

if (code.includes(target)) {
    code = code.replace(target, replacement);
    fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
    console.log("Replaced successfully!");
} else {
    console.log("Could not find the target string!");
}
