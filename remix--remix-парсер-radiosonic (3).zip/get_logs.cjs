const Database = require('better-sqlite3');
const db = new Database('./yandex_music.db');
const logs = db.prepare('SELECT * FROM logs ORDER BY id DESC LIMIT 50').all();
console.log(JSON.stringify(logs, null, 2));
