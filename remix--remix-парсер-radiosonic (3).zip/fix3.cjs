const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

// Fix 686: replace(/^//, "") -> replace(/^\//, "")
code = code.replace(/replace\(\/\^\/\/,/g, 'replace(/^\\//,');

// Fix 747+: ${this.baseUrl} -> \${this.baseUrl} inside the apiCodeSnippets
// The whole block of ts/python/curl etc is in apiCodeSnippets
code = code.replace(/fetch\(`\$\{this\.baseUrl\}/g, 'fetch(`\\${this.baseUrl}');

// Let's replace the whole apiCodeSnippets object
const badSnippetsStart = `  const apiCodeSnippets = {`;
const badSnippetsEnd = `  // OK.ru / VK Search & Resolution`; // something after it

code = code.replace(/this\.baseUrl \= baseUrl\.replace\(\/\/\$\/, ''\);/g, "this.baseUrl = baseUrl.replace(/\\\\/?$/, '');");

// Find all template variables inside the code snippets that got evaluated
// python: f"{self.base_url}/api/music/metadata"
code = code.replace(/f"\{self\.base_url\}/g, 'f"{self.base_url}'); // wait, python f-string doesn't need escaping in JS template string, UNLESS it was \${self.base_url}? No, python uses {}

// In curl, we might have \ for line breaks
code = code.replace(/curl -X POST http:\/\/localhost:3000\/api\/okru\/search /g, "curl -X POST http://localhost:3000/api/okru/search \\\\\\n"); // wait, let's just see line 777

fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
