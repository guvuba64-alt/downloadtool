const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/SyncedLyrics.tsx', 'utf8');

// Change text alignment from left to center
code = code.replace("text-left`}", "text-center`}");

// Adjust the karaoke animation styles
const oldClasses = `className={\`transition-all duration-[400ms] ease-out \${
              !isSynced ? 'text-white/80 text-xl font-medium mb-4' :
              i === activeIndex 
                 ? 'text-white text-3xl sm:text-4xl font-extrabold drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] origin-left mb-8 tracking-tight' 
                 : i < activeIndex 
                     ? 'text-white/30 text-xl sm:text-2xl font-bold mb-6' 
                     : 'text-white/40 text-xl sm:text-2xl font-bold mb-6 hover:text-white/80'
            }\`}`;

const newClasses = `className={\`transition-all duration-[500ms] ease-out flex flex-col items-center justify-center \${
              !isSynced ? 'text-white/80 text-xl sm:text-2xl font-bold mb-6' :
              i === activeIndex 
                 ? 'text-white text-3xl sm:text-4xl lg:text-5xl font-extrabold drop-shadow-lg origin-center mb-8 tracking-tight scale-105' 
                 : i < activeIndex 
                     ? 'text-white/30 text-2xl sm:text-3xl font-bold mb-6 scale-100' 
                     : 'text-white/40 text-2xl sm:text-3xl font-bold mb-6 hover:text-white/60 scale-100'
            }\`}`;

code = code.replace(oldClasses, newClasses);

// Add a spacer at the end so the last lyrics can scroll to center
code = code.replace('<div className="py-[40vh] space-y-4">', '<div className="py-[40vh] space-y-6 sm:space-y-8">');

fs.writeFileSync('src/components/ModernPlayer/SyncedLyrics.tsx', code);
