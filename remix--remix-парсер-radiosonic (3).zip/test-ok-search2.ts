import axios from 'axios';
const headers = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'X-Requested-With': 'XMLHttpRequest',
  'Referer': 'https://ok.ru/music'
};
const res = await axios.get('https://ok.ru/web-api/music/search', { params: { query: 'Dance Monkey' }, headers });
console.log("Status:", res.status, "Data:", res.data);
