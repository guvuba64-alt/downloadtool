import axios from 'axios';
axios.get('https://ok.ru/web-api/music/search', { params: { query: 'Tones And I Dance Monkey' }, headers: { 'User-Agent': 'Mozilla/5.0' } })
  .then(res => console.dir(res.data, {depth: 3}))
  .catch(console.error);
