import re

with open("src/components/UnifiedParserTab.tsx", "r", encoding="utf-8") as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if 'activeSubTab === "okru_vk"' in line:
        start_idx = i
    if 'activeSubTab === "openapi"' in line:
        end_idx = i
        break

if start_idx != -1 and end_idx != -1:
    new_ui = """      {/* SUBTAB 2: OK.RU / VK & UNIVERSAL PARSER (АВТОМАТИЧЕСКИЙ SNIFFER, PLAY, COPYRIGHT, СИНГЛ/АЛЬБОМ) */}
      {activeSubTab === "okru_vk" && (
        <div className="space-y-6">
          {/* Header Card (Универсальный парсер) */}
          <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-[#EE8208]/15 text-[#EE8208] flex items-center justify-center font-bold shrink-0">
                <Radio className="w-7 h-7" />
              </div>
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-xl sm:text-2xl font-bold text-zinc-900 dark:text-zinc-50">
                    Универсальный парсер
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-xs">
                    v3.2
                  </span>
                </div>
                <p className="text-sm text-zinc-500 leading-relaxed">
                  Поддерживает ссылки от Яндекс Музыки, Spotify, Apple Music, Deezer, OK.ru, VK до Звука и YouTube. За официальный Copyright (℗/©, правообладатели, ISRC/UPC и Play-поток) отвечает каталог OK.ru & UMA.
                </p>
              </div>
            </div>

            {/* Universal Search Form */}
            <div className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={okSearchQuery}
                  onChange={e => setOkSearchQuery(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleExecuteOkSearch()}
                  placeholder="Ссылка, название, ISRC или UPC..."
                  className="w-full h-14 pl-12 pr-4 rounded-[20px] bg-zinc-50 dark:bg-black/30 border border-zinc-200 dark:border-zinc-800 text-base text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#EE8208]/40 font-medium"
                />
                <Search className="w-6 h-6 text-zinc-400 absolute left-4 top-4" />
              </div>

              <button
                onClick={() => handleExecuteOkSearch()}
                disabled={okSearching || !okSearchQuery.trim()}
                className="w-full h-14 rounded-[20px] bg-[#EE8208] hover:bg-[#d67304] active:scale-95 text-white font-bold text-base flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                {okSearching ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                <span>Парсить релиз</span>
              </button>
            </div>

            {/* Source Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-sm font-semibold text-zinc-500 mr-1">Источники:</span>
              {["Яндекс.Музыка", "Spotify", "Apple Music", "Deezer", "OK.ru", "VK Music", "Штрихкод UPC", "Код ISRC"].map(src => (
                <span key={src} className="px-3 py-1.5 rounded-2xl bg-zinc-100 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-300 text-xs font-semibold">
                  {src}
                </span>
              ))}
            </div>

            {/* Quick Tests (Optional but useful for debugging) */}
            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-zinc-100 dark:border-zinc-800/60 mt-4">
              <span className="text-[11px] font-bold text-zinc-400 mr-1">Быстрый тест:</span>
              {[
                { label: "YOURE TOO SLOW", q: "Whybaby_ff, Odetari - YOURE TOO SLOW" },
                { label: "No Dazzle No Break", q: "Geek Music - No Dazzle No Break" },
                { label: "Волна", q: "Моя волна (radio)" }
              ].map(chip => (
                <button
                  key={chip.label}
                  onClick={() => { setOkSearchQuery(chip.q); handleExecuteOkSearch(chip.q); }}
                  className="px-2 py-1 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/50 text-zinc-500 text-[10px] font-semibold transition-all"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Tracker */}
            {parserStage !== "idle" && (
              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800/60 animate-in fade-in">
                <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-2.5">
                  Процесс обработки
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                  {[
                    { key: "searching", num: "1", title: "Поиск", active: ["searching", "found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage), done: ["found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage) },
                    { key: "found", num: "2", title: "Найден", active: ["found", "playing", "intercepting", "parsed", "success", "warning"].includes(parserStage), done: ["playing", "intercepting", "parsed", "success", "warning"].includes(parserStage) },
                    { key: "playing", num: "3", title: "Плей", active: ["playing", "intercepting", "parsed", "success", "warning"].includes(parserStage), done: ["intercepting", "parsed", "success", "warning"].includes(parserStage) },
                    { key: "intercepting", num: "4", title: "Sniffer", active: ["intercepting", "parsed", "success", "warning"].includes(parserStage), done: ["parsed", "success", "warning"].includes(parserStage) },
                    { key: "parsed", num: "5", title: "JSON", active: ["parsed", "success", "warning"].includes(parserStage), done: ["success", "warning"].includes(parserStage) },
                    { key: "success", num: "6", title: "Готово", active: ["success", "warning"].includes(parserStage), done: parserStage === "success" || parserStage === "warning" }
                  ].map(step => (
                    <div key={step.key} className={`p-2 rounded-xl border text-[10px] sm:text-xs flex items-center gap-1.5 transition-all ${step.done ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-bold" : step.active ? "bg-[#EE8208]/10 border-[#EE8208]/40 text-[#EE8208] font-bold animate-pulse" : "bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-400"}`}>
                      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] shrink-0 ${step.done ? "bg-emerald-500 text-white" : step.active ? "bg-[#EE8208] text-white" : "bg-zinc-200 dark:bg-zinc-800 text-zinc-500"}`}>
                        {step.done ? "✓" : step.num}
                      </span>
                      <span className="truncate">{step.title}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {okSearchError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-700 dark:text-rose-300 text-sm font-semibold flex items-center gap-2">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{okSearchError}</span>
              </div>
            )}
          </div>

          {/* New Result Card based on Screenshot */}
          {okSearchResult && (
            <div className="bg-white dark:bg-[#1c1c1e] border border-zinc-200/80 dark:border-white/10 rounded-3xl p-6 sm:p-8 shadow-sm animate-in fade-in slide-in-from-bottom-4 space-y-8">
              
              {/* Top Section: Cover & Basic Info */}
              <div className="flex flex-col md:flex-row gap-8">
                {/* Cover Image (Clickable for 3000x3000) */}
                <div className="shrink-0 flex flex-col gap-3">
                  <div 
                    onClick={() => okSearchResult.coverUri && handleDownloadCover3000(okSearchResult.coverUri, okSearchResult.title, okSearchResult.artists)}
                    className="w-48 h-48 sm:w-56 sm:h-56 rounded-[32px] overflow-hidden shadow-lg border border-zinc-200/50 dark:border-zinc-800/50 cursor-pointer relative group bg-zinc-100 dark:bg-zinc-900"
                    title="Нажмите для скачивания обложки 3000x3000px"
                  >
                    {okSearchResult.coverUri ? (
                      <>
                        <img 
                          src={okSearchResult.coverUri.replace('%%', '400')} 
                          alt="Cover" 
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          crossOrigin="anonymous"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 text-white">
                          {isDownloadingCover3000 ? (
                            <RefreshCw className="w-8 h-8 animate-spin" />
                          ) : (
                            <ImageIcon className="w-8 h-8" />
                          )}
                          <span className="font-bold text-sm text-center px-4">
                            {isDownloadingCover3000 ? "Загрузка 3000px..." : "Скачать 3000x3000"}
                          </span>
                        </div>
                      </>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Radio className="w-12 h-12 text-zinc-300 dark:text-zinc-700" />
                      </div>
                    )}
                  </div>
                  
                  {/* Action Buttons under cover */}
                  <div className="flex flex-col gap-2 w-48 sm:w-56">
                     <button
                        onClick={() => handleDownloadWavTrack({
                          idForDownload: okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track",
                          title: okSearchResult.title,
                          artists: okSearchResult.artists,
                          upc: okSearchResult.upc,
                          isrc: okSearchResult.isrc
                        })}
                        disabled={downloadingWavTrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track")}
                        className="w-full h-10 rounded-xl bg-[#EE8208] hover:bg-[#d67304] active:scale-95 text-white font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                      >
                        {downloadingWavTrackId === String(okSearchResult.idForDownload || okSearchResult.track?.id || okSearchResult.id || "ok_track") ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <FileAudio className="w-4 h-4" />
                        )}
                        <span>Скачать WAV</span>
                      </button>
                      
                      {okSearchResult.playUrl && (
                        <button
                          onClick={handleToggleOkPlay}
                          className="w-full h-10 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all"
                        >
                          {okPlayingTrack && okPlayingTrackId === "main" ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                          <span>{okPlayingTrack && okPlayingTrackId === "main" ? "Пауза" : "Слушать"}</span>
                        </button>
                      )}
                  </div>
                </div>

                {/* Info Text Column */}
                <div className="flex-1 space-y-6 pt-2">
                  <div>
                    <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1">TRACK / RELEASE TITLE</div>
                    <div className="text-2xl sm:text-4xl font-extrabold text-zinc-900 dark:text-zinc-50 leading-tight">
                      {okSearchResult.title || "-"}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1">ARTIST (PSEUDONYM)</div>
                    <div className="text-xl font-bold text-zinc-800 dark:text-zinc-200">
                      {okSearchResult.artists || "-"}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1">RELEASE DATE</div>
                    <div className="text-lg font-semibold text-zinc-700 dark:text-zinc-300">
                      {okSearchResult.track?.releasedDate || okSearchResult.releasedDate || new Date().toISOString().split('T')[0]}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                     <div>
                        <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">TRACK ID</div>
                        <div className="font-mono text-sm text-zinc-600 dark:text-zinc-400">{okSearchResult.track?.id || okSearchResult.idForDownload || okSearchResult.id || "-"}</div>
                     </div>
                     <div>
                        <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">ALBUM ID</div>
                        <div className="font-mono text-sm text-zinc-600 dark:text-zinc-400">{okSearchResult.track?.albumId || okSearchResult.albumId || "-"}</div>
                     </div>
                  </div>
                </div>
              </div>

              {/* Copyright & Metadata Section */}
              <div className="space-y-6 border-t border-zinc-100 dark:border-zinc-800/80 pt-6">
                <div>
                  <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2">COPYRIGHT (OK.RU & UMA)</div>
                  
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="text-xl sm:text-2xl font-semibold text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
                      <span>℗ ℗</span>
                      <span>{okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || okSearchResult.copyright || okSearchResult.pLine || "Не найден"}</span>
                    </div>
                    
                    {(okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || okSearchResult.copyright) && (
                      <span className="px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-xs border border-emerald-500/20 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        (найден на ok.ru)
                      </span>
                    )}
                  </div>
                  
                  <div className="mt-3">
                    <span className="px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold text-xs border border-blue-200 dark:border-blue-500/20">
                      Indie Label / Publisher
                    </span>
                  </div>
                </div>

                {/* Raw JSON Data Block */}
                <div className="bg-[#0f111a] rounded-3xl p-6 shadow-inner overflow-hidden border border-white/5 relative">
                  <div className="text-white font-bold text-lg mb-4 flex items-center justify-between">
                    <span>Raw JSON Data</span>
                    <span className="px-2 py-1 rounded bg-white/10 text-[10px] font-mono text-white/50">OK.RU NETWORK PAYLOAD</span>
                  </div>
                  <pre className="text-emerald-400 font-mono text-sm sm:text-base overflow-x-auto whitespace-pre-wrap leading-relaxed">
{`{
  "id": "${okSearchResult.track?.id || okSearchResult.idForDownload || okSearchResult.id || ""}",
  "name": "${okSearchResult.title || ""}",
  "ensembleName": "${okSearchResult.artists || ""}",
  "releasedDate": "${okSearchResult.track?.releasedDate || okSearchResult.releasedDate || new Date().toISOString().split('T')[0]}",
  "year": ${new Date().getFullYear()},
  "label": "${okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || okSearchResult.copyright || ""}",
  "pLine": "℗ ${okSearchResult.pLine || okSearchResult.copyrightOwnerName || okSearchResult.track?.copyrightOwnerName || ""}",
  "copyrightOwnerId": ${okSearchResult.track?.copyrightOwnerId || okSearchResult.copyrightOwnerId || "null"}
}`}
                  </pre>
                </div>
                
                {parserStage === "warning" && (
                   <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3">
                     <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                     <div className="text-sm text-rose-600 dark:text-rose-400 font-semibold">
                       Внимание: JSON-ответ успешно перехвачен и разобран, объект \`track\` существует, но поле \`copyrightOwnerName\` в нём отсутствует. OK.ru не предоставил данные по правообладателю для этого релиза.
                     </div>
                   </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
"""
    # Replace
    new_lines = lines[:start_idx - 1] + [new_ui] + lines[end_idx - 1:]
    with open("src/components/UnifiedParserTab.tsx", "w", encoding="utf-8") as f:
        f.writelines(new_lines)
    print("UI Patched.")
else:
    print("Could not find start/end indices")

