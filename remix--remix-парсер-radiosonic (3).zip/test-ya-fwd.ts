import axios from 'axios';
axios.get('https://api.music.yandex.net/tracks/53066380', {
  headers: { 
    'User-Agent': 'Yandex-Music-API',
    'X-Forwarded-For': '178.208.131.250' // Russian IP
  },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data)).catch(console.error);
