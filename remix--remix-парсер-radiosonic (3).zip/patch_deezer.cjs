const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const deezerReq = 'const resDeezer = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query as string)}&limit=10`);';
const deezerReqNew = `
       let resDeezer;
       try {
         resDeezer = await axios.get(\`https://api.deezer.com/search?q=\${encodeURIComponent(query as string)}&limit=10\`, {
           headers: {
             "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
           }
         });
       } catch (deezerErr) {
         console.log("Deezer API error:", deezerErr.message);
         return res.json({ success: true, data: { tracks: { results: [] }, albums: { results: [] }, artists: { results: [] } }, note: "Deezer search is temporarily unavailable" });
       }
`;

code = code.replace(deezerReq, deezerReqNew);
fs.writeFileSync('server.ts', code);
console.log("Patched Deezer request");
