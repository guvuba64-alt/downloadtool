import axios from 'axios';
axios.post('https://ok.ru/web-api/music/search/custom', new URLSearchParams({ query: 'Dance Monkey' }), {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': 'Mozilla/5.0'
  }
}).then(r => console.log(r.data)).catch(console.error);
