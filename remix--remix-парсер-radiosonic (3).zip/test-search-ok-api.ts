import axios from 'axios';
const q = 'Tones And I Dance Monkey';
axios.get(`https://ok.ru/web-api/music/search`, {
  params: { query: q },
  headers: {
    'User-Agent': 'Mozilla/5.0',
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://ok.ru/music'
  }
}).then(res => {
  console.log(typeof res.data);
  if (typeof res.data === 'string') {
    console.log(res.data.substring(0, 200));
  } else {
    console.dir(res.data, {depth: 1});
  }
}).catch(console.error);
