import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://translate.google.com/translate?sl=ru&tl=en&u=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
});
const title = r.data.match(/<title>(.*?)<\/title>/);
console.log(r.status, "Title:", title ? title[1] : 'none');
