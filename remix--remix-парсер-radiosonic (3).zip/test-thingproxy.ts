import axios from 'axios';
const url = encodeURIComponent('https://api.music.yandex.net/tracks/53066380');
axios.get(`https://thingproxy.freeboard.io/fetch/${decodeURIComponent(url)}`).then(r => console.log(r.status, r.data)).catch(e => console.log(e.message));
