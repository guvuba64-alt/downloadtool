const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');
serverCode = serverCode.replace(/\.then\(data => console\.log\('Webhook set:', data\)\)/g, ".then(data => console.log('Webhook set:', data.ok ? 'success' : data.description))");
fs.writeFileSync('server.ts', serverCode);

let reportTabCode = fs.readFileSync('src/components/ReportTab.tsx', 'utf8');
reportTabCode = reportTabCode.replace(/console\.warn\(\`Telegram API Response: \`, errData\);/g, "console.warn(`Telegram API Response: `, errData?.description);");
fs.writeFileSync('src/components/ReportTab.tsx', reportTabCode);

console.log('Fixed logs in server.ts and ReportTab.tsx');
