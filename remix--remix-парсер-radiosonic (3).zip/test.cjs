const fs = require('fs');
let code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');
const lines = code.split('\n');
lines.forEach((line, i) => {
  if (line.includes('isInfoOpen')) console.log(i + 1, line);
});
