const axios = require('axios');
const yandexToken = process.env.YANDEX_MUSIC_TOKEN || "y0__xCK7-OYBRje-AYgpby9wRYw6a7F7wddxnj7HXeOAc7Jw0Hgrw8ZXN3M3A";
axios.get("https://api.music.yandex.net/albums/35515252/with-tracks", { headers: { 'Authorization': `OAuth ${yandexToken}`, 'User-Agent': 'Yandex-Music-API' }})
  .then(r => {
     const t = r.data.result.volumes[0];
     console.log("Track 1 ISRC:", t[0].isrc);
     console.log("Track 2 ISRC:", t[1].isrc);
  }).catch(e => console.log(e.message));
