const fs = require('fs');
let code = fs.readFileSync('server-okru.ts', 'utf8');

const regex = /page\.on\('response', async \(response\) => \{[\s\S]*?\}\);(\s*)await page\.goto/m;
const replacement = `page.on('response', async (response) => {
      try {
        const u = response.url();
        if (u.includes('ok.ru/web-api/music') || u.includes('ok.ru/play') || u.includes('music') || u.includes('track')) {
          const text = await response.text();
          if (text.includes('"track"') || text.includes('"tracks"')) {
             try {
                 const json = JSON.parse(text);
                 if (json.track) {
                     foundTrack = json.track;
                     let rawOwner = json.track.copyrightOwnerName;
                     let rawLabel = json.track.label || json.track.labelName || json.track.album?.label || json.track.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                 }
                 if (json.tracks && json.tracks.length > 0) {
                     foundTrack = json.tracks[0];
                     let rawOwner = foundTrack.copyrightOwnerName;
                     let rawLabel = foundTrack.label || foundTrack.labelName || foundTrack.album?.label || foundTrack.album?.labelName || '';
                     
                     foundCopyright = (typeof rawOwner === 'string' && rawOwner.trim().length > 0) ? rawOwner.trim() : null;
                     foundLabel = rawLabel || foundLabel;
                 }
             } catch (e) {}
          }
        }
      } catch (e) {}
    });$1await page.goto`;

code = code.replace(regex, replacement);
fs.writeFileSync('server-okru.ts', code);
