import { searchOkRu } from './server-okru.js';
searchOkRu('Daft Punk Harder Better').then(console.log).catch(console.error);
