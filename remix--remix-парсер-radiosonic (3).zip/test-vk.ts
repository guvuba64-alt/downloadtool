import axios from 'axios';
const url = encodeURIComponent('https://music.yandex.ru/album/7542918/track/53066380');
const r = await axios.get(`https://vk.com/share.php?url=${url}`, {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
});
console.log(r.status, r.data.match(/<title>(.*?)<\/title>/)?.[1] || r.data.substring(0, 300));
