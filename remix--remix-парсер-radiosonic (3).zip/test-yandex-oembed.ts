import axios from 'axios';
axios.get('https://music.yandex.ru/api/v1/oembed?url=https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data)).catch(console.error);
