import axios from 'axios';
axios.get('https://ok.ru/music/track/123429066867960', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' },
  validateStatus: () => true
}).then(r => {
  const html = r.data;
  console.log("Title tag:", html.match(/<title>(.*?)<\/title>/)?.[1]);
  console.log("OG title:", html.match(/<meta property="og:title" content="(.*?)"/)?.[1]);
  console.log("OG desc:", html.match(/<meta property="og:description" content="(.*?)"/)?.[1]);
});
