const fs = require('fs');
const code = fs.readFileSync('src/components/ModernPlayer/index.tsx', 'utf8');

const start = code.indexOf("{menuState !== 'none' && (");
console.log("start is", start);
