import axios from 'axios';
axios.get('https://music.yandex.ru/album/7542918/track/53066380', {
  headers: { 'User-Agent': 'Mozilla/5.0' },
  validateStatus: () => true
}).then(r => console.log(r.status, r.data.substring(0, 200))).catch(console.error);
