import { createClient } from "@libsql/client";
import fs from "fs";

const client = createClient({ url: "file:sqlite.db" });
const result = await client.execute("SELECT cookies FROM okru_session WHERE id = 1");
if (result.rows.length > 0) {
    fs.writeFileSync('cookies.txt', result.rows[0].cookies);
    console.log('Got cookies');
} else {
    console.log('No cookies');
}
