const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetInput = `className="flex-1 bg-white dark:bg-[#1c1c1e] text-zinc-900 dark:text-white px-4 py-3 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"`;
const replacementInput = `className={\`flex-1 text-zinc-900 dark:text-white px-4 py-3 outline-none transition-all duration-300 \${
                      appTheme === 'minimalism' ? 'bg-transparent border-b-2 border-zinc-300 dark:border-zinc-700 focus:border-black dark:focus:border-white rounded-none' : 
                      appTheme === 'anime' ? 'bg-white/50 dark:bg-black/20 border-2 border-pink-200 dark:border-pink-800 focus:border-pink-400 dark:focus:border-pink-500 rounded-2xl shadow-inner' : 
                      appTheme === 'cyberpunk' ? 'bg-black/50 border border-yellow-400/50 focus:border-yellow-400 rounded-none text-yellow-400 placeholder-yellow-700' :
                      appTheme === 'brutalism' ? 'bg-white dark:bg-black border-4 border-black dark:border-white rounded-none focus:bg-yellow-100 dark:focus:bg-zinc-800' :
                      'bg-white dark:bg-[#1c1c1e] border border-zinc-200 dark:border-zinc-800 rounded-xl focus:ring-2 focus:ring-emerald-500 shadow-sm'
                    }\`}`;

code = code.replace(targetInput, replacementInput);

const targetButton = `className="px-6 py-3 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-bold rounded-xl hover:bg-zinc-800 dark:hover:bg-zinc-100 transition-colors disabled:opacity-50 flex items-center gap-2 shadow-sm"`;
const replacementButton = `className={\`px-6 py-3 font-bold transition-all duration-300 disabled:opacity-50 flex items-center gap-2 \${
                      appTheme === 'minimalism' ? 'bg-transparent text-black dark:text-white hover:opacity-70 rounded-none border-b-2 border-transparent hover:border-black dark:hover:border-white' : 
                      appTheme === 'anime' ? 'bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-2xl hover:shadow-[0_0_15px_rgba(236,72,153,0.5)] hover:scale-105' : 
                      appTheme === 'cyberpunk' ? 'bg-yellow-400 text-black rounded-none hover:bg-yellow-300 hover:shadow-[0_0_15px_rgba(250,204,21,0.8)]' :
                      appTheme === 'brutalism' ? 'bg-black dark:bg-white text-white dark:text-black border-4 border-transparent rounded-none hover:bg-white dark:hover:bg-black hover:text-black dark:hover:text-white hover:border-black dark:hover:border-white shadow-[4px_4px_0_0_rgba(0,0,0,1)] dark:shadow-[4px_4px_0_0_rgba(255,255,255,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1' :
                      'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl hover:bg-zinc-800 dark:hover:bg-zinc-100 shadow-sm'
                    }\`}`;

code = code.replace(targetButton, replacementButton);

fs.writeFileSync('src/App.tsx', code);
console.log('Parser inputs styled');
