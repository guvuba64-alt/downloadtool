const fs = require('fs');
let code = fs.readFileSync('src/components/UnifiedParserTab.tsx', 'utf8');

const startIdx = code.indexOf('const apiCodeSnippets = {');
const endIdx = code.indexOf('};', startIdx) + 2;

if (startIdx !== -1 && endIdx !== -1) {
    let snippets = code.substring(startIdx, endIdx);
    // Escape all unescaped ${ inside snippets
    // We already replaced some with \${, so let's first unescape them to ${ and then escape them ALL to \${
    snippets = snippets.replace(/\\\$\{/g, '${');
    snippets = snippets.replace(/\$\{/g, '\\${');
    
    // Also we need to make sure \n is properly escaped in curl if it was broken
    snippets = snippets.replace(/curl -X POST http:\/\/localhost:3000\/api\/okru\/search \\\n/g, "curl -X POST http://localhost:3000/api/okru/search \\\\\\n");

    code = code.substring(0, startIdx) + snippets + code.substring(endIdx);
    fs.writeFileSync('src/components/UnifiedParserTab.tsx', code);
    console.log('Fixed snippets block');
} else {
    console.log('Snippets block not found');
}
