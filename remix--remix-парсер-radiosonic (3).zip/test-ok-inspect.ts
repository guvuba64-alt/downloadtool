import axios from 'axios';
async function test() {
  const res = await axios.get('https://ok.ru/music/search/Queen', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    }
  });
  const html = res.data;
  console.log("HTML length:", html.length);
  // check if OK music data or script is present
  const scripts = html.match(/<script[\s\S]*?<\/script>/gi) || [];
  console.log("Scripts count:", scripts.length);
  for (const s of scripts) {
    if (s.includes('copyrightOwnerName') || s.includes('track') || s.includes('music')) {
      console.log("Found relevant script (len", s.length, "):", s.substring(0, 300));
    }
  }
}
test().catch(console.error);
