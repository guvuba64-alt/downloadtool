const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');
const startIndex = code.indexOf('{activeResultTab === "platforms" && (');
const endIndex = code.indexOf('{/* Actions / Audio Section */}');
let block = code.substring(startIndex, endIndex);

console.log(block);
