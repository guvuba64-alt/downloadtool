import { sqlite } from './src/db/index.js';
const res = await sqlite.execute("SELECT * FROM okru_proxy WHERE id = 1");
console.log(res.rows);
