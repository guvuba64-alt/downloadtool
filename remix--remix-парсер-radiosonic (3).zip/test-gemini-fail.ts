import axios from 'axios';
axios.post('http://localhost:3000/api/ai/naming', { inputs: 'test' }).then(x => console.log(x.status, x.data)).catch(e => console.log(e.response?.status, e.response?.data));
